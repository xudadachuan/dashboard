from __future__ import annotations

import argparse
import html
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta
from email.utils import parsedate_to_datetime
from pathlib import Path

from central_bank_tools import query_central_bank_transactions
from market_database import load_market_news, save_market_news


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
MARKET_NEWS_FILE = DATA_DIR / "market_news.json"
DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"
DEFAULT_MODEL = "deepseek-v4-flash"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BondDashboard/1.0"
REQUEST_TIMEOUT_SECONDS = 90
MAX_DAILY_NEWS = 10
MAX_SEARCH_CANDIDATES = 40

NEWS_QUERY_GROUPS = [
    (
        "重大政策",
        [
            "中国 国务院 央行 财政部 发改委 金融监管总局 证监会 重大政策 发布",
            "site:gov.cn 金融 财政 货币 重大政策",
            "site:csrc.gov.cn OR site:sse.com.cn OR site:szse.cn 监管 政策 发布",
        ],
    ),
    (
        "宏观数据",
        [
            "中国 CPI PPI PMI GDP 社融 M2 {year}年{month}月 最新发布",
            "site:stats.gov.cn 最新发布 CPI PPI PMI 工业 投资 消费",
            "site:pbc.gov.cn 社会融资规模 M2 金融统计数据",
        ],
    ),
    (
        "财政供给",
        [
            "中国 地方债 专项债 发行 招标",
            "site:mof.gov.cn 地方政府债 专项债 通知 公告",
        ],
    ),
    (
        "政策工具",
        [
            "中国人民银行 MLF 买断式逆回购 国债买卖 PSL SLF 降准 降息",
            "site:pbc.gov.cn MLF 买断式逆回购 国债买卖 PSL SLF",
        ],
    ),
    (
        "股市变化",
        [
            "A股 港股 大涨 大跌 重大变化 风险偏好",
            "上证指数 深证成指 创业板 恒生指数 大涨 大跌",
            "新华社 中国证券报 上海证券报 证券时报 股市 重大变化",
        ],
    ),
]

ALLOWED_CATEGORIES = {"重大政策", "宏观数据", "财政供给", "政策工具", "股市变化"}
CATEGORY_ORDER = ("重大政策", "宏观数据", "财政供给", "政策工具", "股市变化")
DISALLOWED_NEWS_SOURCES = {"local_temperature", "local_tool_summary", "local_market_views"}
OFFICIAL_DOMAINS = (
    "gov.cn",
    "pbc.gov.cn",
    "mof.gov.cn",
    "stats.gov.cn",
    "ndrc.gov.cn",
    "nfra.gov.cn",
    "csrc.gov.cn",
    "sse.com.cn",
    "szse.cn",
    "hkex.com.hk",
)
EXCLUDED_KEYWORDS = [
    "DR007",
    "DR001",
    "R007",
    "SHIBOR",
    "收益率上行",
    "收益率下行",
    "市场温度",
    "交易情绪",
]
STOCK_MAJOR_MOVE_KEYWORDS = (
    "大涨",
    "大跌",
    "暴涨",
    "暴跌",
    "涨停",
    "跌停",
    "涨幅",
    "跌幅",
    "上证指数",
    "深证成指",
    "创业板指",
    "恒生指数",
    "单日涨",
    "单日跌",
    "熔断",
    "股灾",
    "系统性风险",
)
MAJOR_POLICY_KEYWORDS = ("政策", "意见", "办法", "规定", "规则", "通知", "决定", "条例", "方案", "会议", "印发", "发布")
MAJOR_POLICY_EXCLUSIONS = ("立案", "处罚", "违法", "调查", "通报", "宣传", "培训", "调研", "座谈会", "监管动态")
MAJOR_POLICY_TOPIC_KEYWORDS = ("经济", "金融", "财政", "货币", "资本市场", "融资", "债券", "国债", "房地产", "碳达峰", "能源", "投资", "消费", "税", "关税")
MACRO_DATA_KEYWORDS = ("GDP", "CPI", "PPI", "PMI", "社融", "社会融资", "M2", "居民消费价格", "工业生产者出厂价格", "工业增加值", "固定资产投资", "消费", "进出口", "就业", "夏粮产量", "生产资料市场价格", "财政收入", "财政支出")
FISCAL_SUPPLY_KEYWORDS = ("国债", "地方债", "专项债", "政府债券", "特别国债", "发行", "续发行", "招标")
POLICY_TOOL_KEYWORDS = ("MLF", "中期借贷便利", "买断式逆回购", "国债买卖", "PSL", "SLF", "降准", "降息", "央票")
SOURCE_NAME_BY_DOMAIN = {
    "pbc.gov.cn": "中国人民银行",
    "mof.gov.cn": "财政部",
    "stats.gov.cn": "国家统计局",
    "gov.cn": "中国政府网",
    "ndrc.gov.cn": "国家发展改革委",
    "nfra.gov.cn": "国家金融监督管理总局",
    "csrc.gov.cn": "中国证监会",
    "sse.com.cn": "上海证券交易所",
    "szse.cn": "深圳证券交易所",
    "hkex.com.hk": "香港交易所",
    "news.cn": "新华社",
}
OFFICIAL_LISTING_SOURCES = (
    ("https://www.stats.gov.cn/sj/zxfb/", "宏观数据", "国家统计局"),
    ("https://www.stats.gov.cn/szst/", "重大政策", "中国政府网"),
    ("https://www.mof.gov.cn/gkml/bulinggonggao/tongzhitonggao/", "财政供给", "财政部"),
    ("https://www.gov.cn/zhengce/zuixin/", "重大政策", "中国政府网"),
)


def load_dotenv(path: Path = ROOT / ".env") -> None:
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def clean_text(value: str | None) -> str:
    text = re.sub(r"\s+", " ", value or "")
    return text.strip()


def clean_html_text(value: str | None) -> str:
    without_tags = re.sub(r"<[^>]+>", " ", html.unescape(value or ""))
    return clean_text(without_tags)


def build_candidate_prompt(news_date: str, candidates: list[dict]) -> str:
    compact_candidates = [
        {
            "title": clean_text(item.get("title"))[:80],
            "summary": clean_text(item.get("summary"))[:160],
            "sourceName": clean_text(item.get("sourceName")),
            "sourceUrl": clean_text(item.get("sourceUrl")),
            "publishedAt": clean_text(item.get("publishedAt")),
        }
        for item in candidates[:MAX_SEARCH_CANDIDATES]
    ]
    return f"""
你是中国债券市场消息编辑。以下候选新闻由脚本联网搜索得到，请筛选最多10条并摘要。只返回合法 JSON。

日期：{news_date}

必须纳入的类型：
重大政策、宏观数据、财政供给、政策工具、股市变化。

必须排除：
单纯的资金价格日报、DR/R/SHIBOR 报价、收益率日内涨跌、市场温度、交易情绪，以及国债/特别国债的发行、续发行和招标通知；但央行政策工具公告本身必须保留。

只能使用候选新闻，不要编造候选外信息。每条必须保留可核验 sourceUrl。

JSON 格式：
{{
  "items": [
    {{
      "category": "重大政策|宏观数据|财政供给|政策工具|股市变化",
      "title": "不超过28个中文字符",
      "summary": "50-90个中文字符，说明事实和对债市基本面的意义",
      "sourceName": "来源名称",
      "sourceUrl": "https://...",
      "publishedAt": "YYYY-MM-DD 或原始发布时间"
    }}
  ]
}}

候选新闻：
{json.dumps(compact_candidates, ensure_ascii=False, indent=2)}
""".strip()


def fetch_url(url: str, timeout: int = 15) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def _listing_publication_date(href: str, surrounding_html: str) -> date | None:
    url_match = re.search(r"t(20\d{2})(\d{2})(\d{2})", href)
    if url_match:
        try:
            return date(*(int(part) for part in url_match.groups()))
        except ValueError:
            pass

    text = clean_html_text(surrounding_html)
    for pattern, order in (
        (r"(20\d{2})[-/](\d{1,2})[-/](\d{1,2})", (0, 1, 2)),
        (r"(\d{1,2})\s+(20\d{2})[-/](\d{1,2})", (1, 2, 0)),
    ):
        matches = list(re.finditer(pattern, text))
        if not matches:
            continue
        match = matches[-1]
        values = [int(part) for part in match.groups()]
        try:
            return date(values[order[0]], values[order[1]], values[order[2]])
        except ValueError:
            continue
    return None


def parse_official_listing_candidates(
    page_text: str,
    base_url: str,
    category: str,
    source_name: str,
    news_date: str,
) -> list[dict]:
    output: list[dict] = []
    seen: set[str] = set()
    anchor_pattern = re.compile(
        r"<a\b[^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>",
        flags=re.IGNORECASE | re.DOTALL,
    )
    for match in anchor_pattern.finditer(page_text):
        href = clean_text(match.group(1))
        title = clean_html_text(match.group(2))
        if not href or not title or len(title) < 6:
            continue
        source_url = urllib.parse.urljoin(base_url, href)
        surrounding = page_text[max(0, match.start() - 220): min(len(page_text), match.end() + 120)]
        published = _listing_publication_date(source_url, surrounding)
        if not published or not is_recent_news(published.isoformat(), news_date):
            continue
        key = source_url.rstrip("/").lower()
        if key in seen:
            continue
        seen.add(key)
        output.append(
            {
                "category": category,
                "title": title[:120],
                "summary": title[:180],
                "sourceName": source_name,
                "sourceUrl": source_url,
                "publishedAt": published.isoformat(),
                "source": "official_listing_crawl",
            }
        )
    return output


def collect_official_listing_candidates(news_date: str) -> list[dict]:
    output: list[dict] = []
    for url, category, source_name in OFFICIAL_LISTING_SOURCES:
        try:
            raw = fetch_url(url)
        except Exception:
            continue
        output.extend(
            parse_official_listing_candidates(
                raw.decode("utf-8", errors="replace"),
                base_url=url,
                category=category,
                source_name=source_name,
                news_date=news_date,
            )
        )
    return output


def fetch_bing_news(query: str, limit: int = 5, news_date: str | None = None, max_age_days: int = 35) -> list[dict]:
    anchor = parse_news_date(news_date) if news_date else date.today()
    if anchor:
        after = (anchor - timedelta(days=max_age_days)).isoformat()
        query = f"{query} after:{after}"
    url = "https://www.bing.com/news/search?" + urllib.parse.urlencode({"q": query, "format": "rss", "setlang": "zh-cn"})
    raw = fetch_url(url)
    root = ET.fromstring(raw.decode("utf-8-sig", errors="replace").lstrip())
    items: list[dict] = []
    for item in root.findall("./channel/item")[:limit]:
        title = clean_text(item.findtext("title"))[:120]
        summary = clean_html_text(item.findtext("description"))[:240]
        link = clean_text(item.findtext("link"))
        published = clean_text(item.findtext("pubDate"))
        source_name = clean_text(item.findtext("source"))
        if not source_name:
            source_name = urllib.parse.urlparse(link).netloc.removeprefix("www.") or "公开来源"
        if not title or not link:
            continue
        text = f"{title} {summary}"
        if any(keyword.lower() in text.lower() for keyword in EXCLUDED_KEYWORDS):
            continue
        items.append(
            {
                "title": title,
                "summary": summary or title,
                "sourceName": source_name,
                "sourceUrl": link,
                "publishedAt": published,
                "query": query,
                "source": "online_search",
            }
        )
    return items


def candidate_queries(news_date: str | None = None) -> list[tuple[str, str]]:
    anchor = parse_news_date(news_date) or date.today()
    output: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for category, templates in NEWS_QUERY_GROUPS:
        for template in templates:
            query = template.format(year=anchor.year, month=anchor.month)
            key = (category, query)
            if key in seen:
                continue
            seen.add(key)
            output.append(key)
    return output


def collect_script_candidates(news_date: str | None = None) -> list[dict]:
    output: list[dict] = []
    seen: set[str] = set()
    for category, query in candidate_queries(news_date):
        try:
            rows = fetch_bing_news(query, limit=5, news_date=news_date)
        except Exception:
            continue
        for row in rows:
            if news_date and not is_recent_news(row.get("publishedAt"), news_date):
                continue
            key = f"{clean_text(row.get('title')).lower()}|{clean_text(row.get('sourceUrl')).lower()}"
            if key in seen:
                continue
            seen.add(key)
            output.append({**row, "category": category})
            if len(output) >= MAX_SEARCH_CANDIDATES:
                return output
    return output


def parse_json_response(text: str) -> dict:
    content = text.strip()
    if content.startswith("```"):
        content = content.removeprefix("```json").removeprefix("```").strip()
        content = content.removesuffix("```").strip()
    return json.loads(content)


def call_deepseek(prompt: str, model: str, api_key: str) -> dict:
    body = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "你是专业中国债券市场消息编辑。必须核验来源，并只返回合法 JSON。",
            },
            {"role": "user", "content": prompt},
        ],
        "response_format": {"type": "json_object"},
        "temperature": 0.1,
        "max_tokens": 4000,
        "stream": False,
    }
    request = urllib.request.Request(
        DEEPSEEK_URL,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=REQUEST_TIMEOUT_SECONDS) as response:
        payload = json.loads(response.read().decode("utf-8"))
    content = (((payload.get("choices") or [{}])[0].get("message") or {}).get("content") or "").strip()
    if not content:
        raise RuntimeError("DeepSeek returned empty content")
    return parse_json_response(content)


def call_deepseek_with_candidates(news_date: str, candidates: list[dict], model: str, api_key: str) -> dict:
    last_error: Exception | None = None
    for limit in (40, 20, 10):
        try:
            return call_deepseek(build_candidate_prompt(news_date, candidates[:limit]), model, api_key)
        except RuntimeError as exc:
            last_error = exc
            if "empty content" not in str(exc).lower():
                raise
    if last_error:
        raise last_error
    return {"items": []}


def valid_url(value: str) -> bool:
    normalized = clean_text(value).lower()
    return normalized.startswith("https://") or normalized.startswith("http://")


def is_online_news_item(item: dict) -> bool:
    source_url = clean_text(item.get("sourceUrl") or item.get("source_url"))
    source = clean_text(item.get("source"))
    return valid_url(source_url) and source not in DISALLOWED_NEWS_SOURCES


def parse_news_date(value: str | None) -> date | None:
    text = clean_text(value)
    if not text:
        return None
    for pattern in ("%Y-%m-%d", "%Y/%m/%d"):
        try:
            return datetime.strptime(text[:10], pattern).date()
        except ValueError:
            pass
    try:
        return parsedate_to_datetime(text).date()
    except (TypeError, ValueError, IndexError, OverflowError):
        return None


def _parse_chinese_number(value: str) -> int:
    digits = {"零": 0, "〇": 0, "○": 0, "一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
    if "十" not in value:
        return int("".join(str(digits[char]) for char in value))
    left, right = value.split("十", 1)
    tens = digits[left] if left else 1
    ones = digits[right] if right else 0
    return tens * 10 + ones


def extract_page_publication_date(page_text: str) -> date | None:
    text = html.unescape(page_text or "")
    contextual_patterns = (
        r"(?:datePublished|publishdate|pubdate|发布日期|发布时间|发文日期|日期)[^0-9]{0,160}(20\d{2})[-年/.](\d{1,2})[-月/.](\d{1,2})",
        r"(20\d{2})[-年/.](\d{1,2})[-月/.](\d{1,2})[^<]{0,80}(?:发布日期|发布时间|发文日期)",
    )
    for pattern in contextual_patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if not match:
            continue
        try:
            return date(*(int(part) for part in match.groups()))
        except ValueError:
            continue

    plain_text = re.sub(r"<[^>]+>", " ", text)
    chinese_match = re.search(
        r"([二〇○零一二三四五六七八九]{4})年([一二三四五六七八九十]{1,3})月([一二三四五六七八九十]{1,3})日",
        plain_text,
    )
    if chinese_match:
        try:
            return date(
                _parse_chinese_number(chinese_match.group(1)),
                _parse_chinese_number(chinese_match.group(2)),
                _parse_chinese_number(chinese_match.group(3)),
            )
        except (KeyError, ValueError):
            return None
    return None


def is_recent_news(published_at: str | None, news_date: str | None, max_age_days: int = 7) -> bool:
    published = parse_news_date(published_at)
    anchor = parse_news_date(news_date)
    if not published or not anchor:
        return False
    return anchor - timedelta(days=max_age_days) <= published <= anchor + timedelta(days=1)


def verify_source_url(url: str, news_date: str | None = None) -> tuple[bool, str, str | None]:
    try:
        request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(request, timeout=15) as response:
            status = getattr(response, "status", 200)
            final_url = response.geturl() or url
            content_type = response.headers.get("Content-Type", "")
            raw = response.read(600_000) if "html" in content_type.lower() else b""
    except Exception as exc:
        return False, url, f"{type(exc).__name__}: {exc}"
    if status >= 400:
        return False, final_url, f"HTTP {status}"
    if news_date and raw:
        source_date = extract_page_publication_date(raw.decode("utf-8", errors="replace"))
        if source_date and not is_recent_news(source_date.isoformat(), news_date):
            return False, final_url, f"source_page_date_out_of_window: {source_date.isoformat()}"
    return True, final_url, None


def is_treasury_issuance_news(item: dict) -> bool:
    text = f"{clean_text(item.get('title'))} {clean_text(item.get('summary'))}"
    return any(term in text for term in ("国债", "特别国债")) and any(
        term in text for term in ("发行", "续发行", "招标")
    )


def is_relevant_candidate(item: dict) -> bool:
    text = f"{clean_text(item.get('title'))} {clean_text(item.get('summary'))}"
    source_url = clean_text(item.get("sourceUrl") or item.get("source_url"))
    source = clean_text(item.get("source"))
    if is_treasury_issuance_news(item):
        return False
    if any(keyword.lower() in text.lower() for keyword in EXCLUDED_KEYWORDS):
        return False
    if source == "online_search" and re.search(r"/index(?:_\d+)?\.(?:s?html?|htm)$", source_url, flags=re.IGNORECASE):
        return False
    category = item.get("category")
    if category == "重大政策":
        if any(keyword in text for keyword in MAJOR_POLICY_EXCLUSIONS):
            return False
        return (
            any(keyword in text for keyword in MAJOR_POLICY_KEYWORDS)
            and any(keyword in text for keyword in MAJOR_POLICY_TOPIC_KEYWORDS)
        )
    if category == "宏观数据":
        return any(keyword.lower() in text.lower() for keyword in MACRO_DATA_KEYWORDS)
    if category == "财政供给":
        return any(keyword in text for keyword in FISCAL_SUPPLY_KEYWORDS)
    if category == "政策工具":
        return any(keyword.lower() in text.lower() for keyword in POLICY_TOOL_KEYWORDS)
    if item.get("category") == "股市变化":
        return any(keyword.lower() in text.lower() for keyword in STOCK_MAJOR_MOVE_KEYWORDS)
    return True


def source_name_from_url(url: str, fallback: str = "公开来源") -> str:
    host = urllib.parse.urlparse(url).netloc.lower().removeprefix("www.")
    for domain, name in SOURCE_NAME_BY_DOMAIN.items():
        if host == domain or host.endswith(f".{domain}"):
            return name
    return fallback if fallback.lower() not in {"bing.com", "www.bing.com", "bing news"} else host or "公开来源"


def reconcile_model_items(model_items: list[dict], candidates: list[dict]) -> list[dict]:
    candidate_by_url = {
        clean_text(item.get("sourceUrl")).rstrip("/").lower(): item
        for item in candidates
        if valid_url(clean_text(item.get("sourceUrl")))
    }
    output: list[dict] = []
    for model_item in model_items:
        key = clean_text(model_item.get("sourceUrl") or model_item.get("source_url")).rstrip("/").lower()
        candidate = candidate_by_url.get(key)
        if not candidate:
            continue
        output.append(
            {
                **model_item,
                "category": candidate.get("category"),
                "sourceName": candidate.get("sourceName"),
                "sourceUrl": candidate.get("sourceUrl"),
                "publishedAt": candidate.get("publishedAt"),
                "source": candidate.get("source") or "online_search",
            }
        )
    return output


def _source_priority(item: dict) -> int:
    host = urllib.parse.urlparse(clean_text(item.get("sourceUrl"))).netloc.lower()
    return 0 if any(host == domain or host.endswith(f".{domain}") for domain in OFFICIAL_DOMAINS) else 1


def _published_ordinal(item: dict) -> int:
    parsed = parse_news_date(item.get("publishedAt"))
    return parsed.toordinal() if parsed else 0


def select_diverse_items(items: list[dict], limit: int = MAX_DAILY_NEWS) -> list[dict]:
    ordered = sorted(
        [item for item in items if is_online_news_item(item)],
        key=lambda item: (_source_priority(item), -_published_ordinal(item)),
    )
    output: list[dict] = []
    seen: set[str] = set()

    def append(item: dict) -> None:
        key = f"{clean_text(item.get('title')).lower()}|{clean_text(item.get('sourceUrl')).lower()}"
        if key in seen or len(output) >= limit:
            return
        seen.add(key)
        output.append(item)

    for category in CATEGORY_ORDER:
        match = next((item for item in ordered if item.get("category") == category), None)
        if match:
            append(match)
    for item in ordered:
        append(item)
    return output


def normalize_items(
    result: dict,
    verify_urls: bool = False,
    rejected: list[dict] | None = None,
    news_date: str | None = None,
    limit: int = MAX_DAILY_NEWS,
) -> list[dict]:
    raw_items = result.get("items") if isinstance(result, dict) else []
    if not isinstance(raw_items, list):
        return []

    output: list[dict] = []
    for item in raw_items:
        if not isinstance(item, dict):
            continue
        title = clean_text(item.get("title"))[:60]
        summary = clean_text(item.get("summary") or item.get("title"))[:180]
        source_url = clean_text(item.get("sourceUrl") or item.get("source_url"))
        source_name = clean_text(item.get("sourceName") or item.get("source_name") or "公开来源")
        published_at = clean_text(item.get("publishedAt") or item.get("published_at"))
        source = clean_text(item.get("source")) or "online_search"
        text = f"{title} {summary}"
        if not title or not summary or not is_online_news_item({"sourceUrl": source_url, "source": source}):
            continue
        candidate = {
            "category": item.get("category"),
            "title": title,
            "summary": summary,
            "sourceUrl": source_url,
            "source": source,
        }
        if not is_relevant_candidate(candidate):
            if rejected is not None:
                rejected.append({"title": title, "sourceUrl": source_url, "reason": "category_relevance_filter"})
            continue
        if news_date and not is_recent_news(published_at, news_date):
            if rejected is not None:
                rejected.append({"title": title, "sourceUrl": source_url, "publishedAt": published_at, "reason": "published_at_out_of_daily_window"})
            continue
        if verify_urls:
            page_date_anchor = None if source == "official_policy_crawl" else news_date
            ok, final_url, reason = verify_source_url(source_url, news_date=page_date_anchor)
            if not ok:
                if rejected is not None:
                    rejected.append({"title": title, "sourceUrl": source_url, "reason": reason})
                continue
            source_url = final_url
        source_name = source_name_from_url(source_url, source_name)
        category = item.get("category") if item.get("category") in ALLOWED_CATEGORIES else "重大政策"
        output.append(
            {
                "category": category,
                "title": title,
                "summary": summary,
                "sourceName": source_name,
                "sourceUrl": source_url,
                "publishedAt": published_at,
                "source": source,
            }
        )
        if len(output) >= limit:
            break
    return output


def normalize_candidate_items(
    candidates: list[dict],
    news_date: str,
    limit: int = MAX_DAILY_NEWS,
    verify_urls: bool = False,
    rejected: list[dict] | None = None,
) -> list[dict]:
    normalized = normalize_items(
        {"items": candidates},
        news_date=news_date,
        limit=MAX_SEARCH_CANDIDATES,
        rejected=rejected,
    )
    selected = select_diverse_items(normalized, limit=min(MAX_SEARCH_CANDIDATES, max(limit * 2, limit)))
    if verify_urls:
        selected = normalize_items(
            {"items": selected},
            verify_urls=True,
            rejected=rejected,
            news_date=news_date,
            limit=limit,
        )
    return select_diverse_items(selected, limit=limit)


def collect_official_policy_candidates(news_date: str) -> list[dict]:
    allowed_tools = {"mlf", "outright_reverse_repo", "gov_bond_trade", "psl", "slf"}
    output: list[dict] = []
    for row in query_central_bank_transactions(days=7):
        source_url = clean_text(row.get("sourceUrl") or row.get("source_url"))
        published_at = clean_text(row.get("date"))
        if row.get("tool") not in allowed_tools or not valid_url(source_url):
            continue
        if not is_recent_news(published_at, news_date):
            continue
        raw_amount = float(row.get("amount") or 0)
        amount = abs(raw_amount)
        direction = "投放" if raw_amount >= 0 else "到期/回笼"
        tool_name = clean_text(row.get("toolName")) or "央行政策工具"
        output.append(
            {
                "category": "政策工具",
                "title": f"{tool_name}{direction}",
                "summary": f"{published_at}央行开展{tool_name}{direction}，金额约{amount:.0f}亿元。",
                "sourceName": "中国人民银行",
                "sourceUrl": source_url,
                "publishedAt": published_at,
                "source": "official_policy_crawl",
            }
        )
    return output


def write_debug_json(payload: dict | None = None) -> dict:
    output = payload or load_market_news(limit=10)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    MARKET_NEWS_FILE.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    return output


def update_market_news(news_date: str | None = None, dry_run: bool = False, force_deepseek: bool = False) -> dict:
    load_dotenv()
    if not os.environ.get("DEEPSEEK_API_KEY") and os.environ.get("YOUR_API_KEY"):
        os.environ["DEEPSEEK_API_KEY"] = os.environ["YOUR_API_KEY"]
    day = news_date or date.today().isoformat()
    model = os.environ.get("DEEPSEEK_NEWS_MODEL") or os.environ.get("DEEPSEEK_MODEL", DEFAULT_MODEL)
    api_key = os.environ.get("DEEPSEEK_API_KEY", "").strip()

    if force_deepseek and not api_key:
        raise RuntimeError("DEEPSEEK_API_KEY is required for market news summarization")

    rejected: list[dict] = []
    candidates = (
        collect_official_policy_candidates(day)
        + collect_official_listing_candidates(day)
        + collect_script_candidates(day)
    )
    items = normalize_candidate_items(
        candidates,
        day,
        verify_urls=True,
        rejected=rejected,
    )
    fallback_reason = None
    model_succeeded = False

    if items and api_key:
        try:
            model_result = call_deepseek_with_candidates(day, items, model, api_key)
            reconciled = reconcile_model_items(model_result.get("items") or [], items)
            model_items = normalize_items(
                {"items": reconciled},
                verify_urls=True,
                rejected=rejected,
                news_date=day,
            )
            if model_items:
                model_items = [
                    {**item, "source": "online_search_deepseek_summary"}
                    for item in model_items
                ]
                summarized_urls = {item["sourceUrl"] for item in model_items}
                items = select_diverse_items(
                    model_items + [item for item in items if item.get("sourceUrl") not in summarized_urls]
                )
                model_succeeded = True
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, ValueError, RuntimeError) as exc:
            if force_deepseek:
                raise
            fallback_reason = f"deepseek_summary_failed: {exc}"

    if not candidates:
        fallback_reason = "no_online_candidates"

    normalized = [
        {
            **item,
            "id": f"{day}-{index:02d}",
            "date": day,
            **({"model": model} if item.get("source") == "online_search_deepseek_summary" else {}),
        }
        for index, item in enumerate(items[:MAX_DAILY_NEWS], start=1)
    ]
    payload = {
        "items": normalized,
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
        "source": "online_search+deepseek" if model_succeeded else "online_search",
        "candidateCount": len(candidates),
        "rejected": rejected,
    }
    if fallback_reason:
        payload["reason"] = fallback_reason

    if not normalized and force_deepseek:
        raise RuntimeError("DeepSeek returned no source-verified market news")
    if dry_run:
        return {**payload, "dryRun": True}

    save_market_news(day, normalized, keep_days=5)
    return write_debug_json(payload)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true", help="联网生成结果但不写数据库")
    parser.add_argument("--force-write", action="store_true", help="允许在非17点后窗口强制写入今天数据")
    parser.add_argument("--force-deepseek", action="store_true", help="DeepSeek 失败或无有效来源时返回非零状态")
    args = parser.parse_args()
    if args.force_write:
        os.environ["BOND_DASHBOARD_FORCE_WRITE"] = "1"
    payload = update_market_news(dry_run=args.dry_run, force_deepseek=args.force_deepseek)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
