from __future__ import annotations

import csv
import json
import math
from collections import defaultdict
from datetime import date, datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT.parent / "data"
LOG_DIR = ROOT.parent / "logs"
INPUT_DIR = DATA_DIR / "treasury_futures" / "input"
OUTPUT_FILE = DATA_DIR / "treasury_futures" / "treasury_futures_latest.json"
OFFICIAL_FILE = DATA_DIR / "treasury_futures" / "cffex_deliverable_latest.json"
PRODUCTS = ("TS", "TF", "T", "TL")
REQUIRED_FIELDS = (
    "date", "product", "contract", "last_trading_date", "close",
    "previous_close", "volume", "open_interest",
)
ROLL_RULES = {
    "TS": {"start": 20, "volume_switch": 12, "oi_switch": 16, "window": (15, 21)},
    "TF": {"start": 19, "volume_switch": 12, "oi_switch": 15, "window": (16, 23)},
    "T": {"start": 22, "volume_switch": 13, "oi_switch": 15, "window": (18, 25)},
    "TL": {"start": 22, "volume_switch": 14, "oi_switch": 19, "window": (17, 29)},
}


def _float(value):
    try:
        parsed = float(str(value).strip())
        return parsed if math.isfinite(parsed) else None
    except (TypeError, ValueError):
        return None


def _int(value):
    parsed = _float(value)
    return int(parsed) if parsed is not None else None


def _load_official_deliverables() -> dict[str, list[dict]]:
    if not OFFICIAL_FILE.exists():
        return {}
    try:
        return json.loads(OFFICIAL_FILE.read_text(encoding="utf-8")).get("contracts") or {}
    except (OSError, json.JSONDecodeError):
        return {}


def _read_files() -> tuple[list[dict], list[str]]:
    INPUT_DIR.mkdir(parents=True, exist_ok=True)
    official = _load_official_deliverables()
    rows: dict[tuple[str, str], dict] = {}
    errors: list[str] = []
    files = sorted(INPUT_DIR.glob("treasury_futures_*.csv"), key=lambda p: (p.stat().st_mtime, p.name))
    for path in files:
        try:
            with path.open("r", encoding="utf-8-sig", newline="") as handle:
                reader = csv.DictReader(handle)
                missing_headers = [field for field in REQUIRED_FIELDS if field not in (reader.fieldnames or [])]
                if missing_headers:
                    errors.append(f"{path.name}: 缺少表头 {', '.join(missing_headers)}")
                    continue
                for line_no, raw in enumerate(reader, start=2):
                    product = str(raw.get("product") or "").strip().upper()
                    contract = str(raw.get("contract") or "").strip().upper()
                    row_date = str(raw.get("date") or "").strip()
                    last_date = str(raw.get("last_trading_date") or "").strip()
                    try:
                        date.fromisoformat(row_date)
                        date.fromisoformat(last_date)
                    except ValueError:
                        errors.append(f"{path.name}:{line_no}: 日期格式错误")
                        continue
                    if product not in PRODUCTS or not contract:
                        errors.append(f"{path.name}:{line_no}: 品种或合约代码无效")
                        continue
                    row = {
                        "date": row_date, "product": product, "contract": contract,
                        "lastTradingDate": last_date,
                        "tradingDaysToLast": _int(raw.get("trading_days_to_last")),
                        "open": _float(raw.get("open")), "high": _float(raw.get("high")),
                        "low": _float(raw.get("low")), "close": _float(raw.get("close")),
                        "previousClose": _float(raw.get("previous_close")),
                        "settlement": _float(raw.get("settlement")),
                        "settlementIf": _float(raw.get("settlement_if")),
                        "volume": _int(raw.get("volume")), "turnover": _float(raw.get("turnover")),
                        "openInterest": _int(raw.get("open_interest")),
                        "preOpenInterest": _int(raw.get("pre_open_interest")),
                        "reportedOpenInterestChange": _int(raw.get("open_interest_change")),
                        "priceType": str(raw.get("price_type") or "").strip() or None,
                        "dataSource": str(raw.get("source") or "").strip() or None,
                        "sourceUrl": str(raw.get("source_url") or "").strip() or None,
                        "retrievedAt": str(raw.get("retrieved_at") or "").strip() or None,
                        "calculationStatus": str(raw.get("calculation_status") or "").strip() or None,
                        "ctdCode": str(raw.get("ctd_code") or "").strip() or None,
                        "conversionFactor": _float(raw.get("conversion_factor")),
                        "ctdDirtyPrice": _float(raw.get("ctd_dirty_price")),
                        "ctdDv01": _float(raw.get("ctd_dv01")), "basis": _float(raw.get("basis")),
                        "irr": _float(raw.get("irr")), "sourceFile": path.name,
                        "deliverableBonds": official.get(contract, []),
                    }
                    if row["close"] is None or row["previousClose"] is None or row["close"] <= 0 or row["previousClose"] <= 0:
                        errors.append(f"{path.name}:{line_no}: 收盘价或前收盘价缺失/无效")
                        continue
                    if row["volume"] is None or row["openInterest"] is None or row["volume"] < 0 or row["openInterest"] < 0:
                        errors.append(f"{path.name}:{line_no}: 成交量或持仓量缺失/无效")
                        continue
                    rows[(row_date, contract)] = row
        except (OSError, UnicodeError, csv.Error) as exc:
            errors.append(f"{path.name}: {type(exc).__name__}: {exc}")
    return sorted(rows.values(), key=lambda item: (item["date"], item["product"], item["lastTradingDate"], item["contract"])), errors


def _pct_change(current, previous):
    return None if current is None or previous in (None, 0) else round((current / previous - 1) * 100, 2)


def _stable_main(rows_by_date: dict[str, list[dict]], field: str) -> str | None:
    dates = sorted(rows_by_date)[-3:]
    if len(dates) < 3:
        return None
    winners = [max(rows_by_date[d], key=lambda row: row[field])["contract"] for d in dates if rows_by_date[d]]
    return winners[0] if len(winners) == 3 and len(set(winners)) == 1 else None


def _five_day_share(rows_by_date: dict[str, list[dict]], old_contract: str, new_contract: str) -> float | None:
    old_volume = new_volume = 0
    used = 0
    for row_date in sorted(rows_by_date)[-5:]:
        by_contract = {row["contract"]: row for row in rows_by_date[row_date]}
        if old_contract in by_contract or new_contract in by_contract:
            old_volume += (by_contract.get(old_contract) or {}).get("volume") or 0
            new_volume += (by_contract.get(new_contract) or {}).get("volume") or 0
            used += 1
    total = old_volume + new_volume
    return round(new_volume / total * 100, 1) if used and total else None


def _consecutive_share_signal(rows_by_date: dict[str, list[dict]], old_contract: str, new_contract: str) -> bool:
    dates = sorted(rows_by_date)
    if len(dates) < 3:
        return False
    return all(
        (_five_day_share({d: rows_by_date[d] for d in dates[:i + 1]}, old_contract, new_contract) or 0) >= 20
        for i in range(len(dates) - 3, len(dates))
    )


def _alert(product: str, current: list[dict], history: dict[str, list[dict]], old: dict, new: dict, metrics: dict) -> dict:
    rules = ROLL_RULES[product]
    t_days = old.get("tradingDaysToLast")
    reasons: list[str] = []
    level, label = "green", "常规跟踪"
    stable_volume = metrics.get("stableVolumeMain")
    stable_oi = metrics.get("stableOpenInterestMain")
    if stable_volume == new["contract"] and stable_oi == new["contract"]:
        level, label = "blue", "移仓完成"
        reasons.append("新合约成交主力和持仓主力均已连续3日确认")
    else:
        if t_days is not None and t_days <= rules["window"][1]:
            level, label = "yellow", "进入观察窗口"
            reasons.append(f"距旧合约最后交易日 T-{t_days}，已进入典型观察窗口")
        share = metrics.get("newVolumeShare5d")
        if share is not None and share >= 20:
            if _consecutive_share_signal(history, old["contract"], new["contract"]):
                level, label = "orange", "移仓启动"
                reasons.append(f"新合约5日成交占比 {share:.1f}%，已连续3日不低于20%")
            elif level == "green":
                level, label = "yellow", "成交占比待确认"
                reasons.append(f"新合约5日成交占比 {share:.1f}%，尚待连续3日确认")
        if stable_volume == new["contract"]:
            level, label = "orange", "成交主力切换"
            reasons.append("新合约成交量已连续3日高于旧合约")
        old_oi_change = metrics.get("oldOiChange")
        new_oi_change = metrics.get("newOiChange")
        if old_oi_change is not None and new_oi_change is not None and old_oi_change < 0 < new_oi_change:
            level, label = "orange", "持仓迁移"
            reasons.append("旧合约持仓下降且新合约持仓上升")
        if t_days is not None and t_days <= rules["oi_switch"] and old["openInterest"] > new["openInterest"]:
            level, label = "red", "持仓切换偏慢"
            reasons.append(f"已到持仓切换基准 T-{rules['oi_switch']}，旧合约持仓仍占优")
    if not reasons:
        reasons.append("尚未触发市场移仓条件")
    return {"level": level, "label": label, "reasons": reasons, "marketOnly": True}


def _product_payload(product: str, rows: list[dict], latest_date: str) -> dict:
    product_rows = [row for row in rows if row["product"] == product]
    rows_by_date: dict[str, list[dict]] = defaultdict(list)
    for row in product_rows:
        rows_by_date[row["date"]].append(row)
    current = rows_by_date.get(latest_date, [])
    if len(current) < 2:
        return {"product": product, "available": False, "status": "至少需要最近两个合约"}
    active = sorted(current, key=lambda row: (row["lastTradingDate"], row["contract"]))
    old, new = active[0], active[1]
    prior_date = sorted(rows_by_date)[-2] if len(rows_by_date) >= 2 else None
    prior = {row["contract"]: row for row in rows_by_date.get(prior_date, [])}
    volume_main = max(current, key=lambda row: row["volume"])
    oi_main = max(current, key=lambda row: row["openInterest"])
    for row in current:
        previous = prior.get(row["contract"], {})
        row["priceChange"] = round(row["close"] - row["previousClose"], 4)
        row["priceChangePct"] = _pct_change(row["close"], row["previousClose"])
        row["volumeChangePct"] = _pct_change(row["volume"], previous.get("volume"))
        row["openInterestChange"] = None if previous.get("openInterest") is None else row["openInterest"] - previous["openInterest"]
        bonds = row.get("deliverableBonds") or []
        factors = []
        for bond in bonds:
            factor = _float(bond.get("conversionFactor")) if isinstance(bond, dict) else None
            if factor is not None:
                factors.append(factor)
        row["deliverableCount"] = len(bonds)
        row["conversionFactorMin"] = min(factors) if factors else None
        row["conversionFactorMax"] = max(factors) if factors else None
        row["ctdStatus"] = "EXACT" if row.get("ctdCode") and row.get("ctdDirtyPrice") is not None else "DEFERRED"
    metrics = {
        "newVolumeShare5d": _five_day_share(rows_by_date, old["contract"], new["contract"]),
        "newOpenInterestShare": round(new["openInterest"] / (old["openInterest"] + new["openInterest"]) * 100, 1) if old["openInterest"] + new["openInterest"] else None,
        "oldOiChange": old.get("openInterestChange"), "newOiChange": new.get("openInterestChange"),
        "stableVolumeMain": _stable_main(rows_by_date, "volume"),
        "stableOpenInterestMain": _stable_main(rows_by_date, "openInterest"),
    }
    alert = _alert(product, current, rows_by_date, old, new, metrics)
    return {
        "product": product, "available": True, "date": latest_date,
        "volumeMain": volume_main["contract"], "openInterestMain": oi_main["contract"],
        "oldContract": old["contract"], "newContract": new["contract"],
        "main": volume_main, "old": old, "new": new,
        "mainDeliverableCount": volume_main.get("deliverableCount", 0),
        "mainConversionFactorMin": volume_main.get("conversionFactorMin"),
        "mainConversionFactorMax": volume_main.get("conversionFactorMax"),
        "ctdStatus": volume_main.get("ctdStatus", "DEFERRED"),
        "quoteStatus": volume_main.get("calculationStatus") or ("EXACT" if volume_main.get("dataSource") == "CFFEX_OFFICIAL" else "ESTIMATED"),
        **metrics, "alert": alert, "contracts": current,
    }


def missing_data(rows: list[dict], products: list[dict]) -> list[dict]:
    missing: list[dict] = []
    if not rows:
        missing.append({"category": "第一阶段必需行情", "items": [
            "TS、TF、T、TL 最近至少两个合约的每日 CSV",
            "合约代码、最后交易日、收盘价、前收盘价、成交量、持仓量",
            "至少连续5个交易日历史（稳定信号建议30日以上）",
        ]})
    unavailable = [item["product"] for item in products if not item.get("available")]
    if unavailable:
        missing.append({"category": "品种覆盖", "items": [f"{', '.join(unavailable)} 缺少同日两个有效合约"]})
    if rows and any(row.get("tradingDaysToLast") is None for row in rows):
        missing.append({"category": "交易日历", "items": ["中金所实际交易日数 trading_days_to_last；需用中金所交易日历复核最后交易日规则"]})
    latest_date = max((row.get("date") for row in rows if row.get("date")), default=None)
    latest_rows = [row for row in rows if row.get("date") == latest_date]
    if latest_rows and any(row.get(field) is None for row in latest_rows for field in ("open", "high", "low", "settlement")):
        missing.append({"category": "日行情字段", "items": ["开盘价、最高价、最低价或结算价存在缺口；当前移仓信号仍可用收盘/成交量/持仓量，但完整行情列需补齐"]})
    if rows and not any(row.get("deliverableBonds") for row in rows):
        missing.append({"category": "可交割券映射", "items": ["中金所合约—可交割券—转换因子映射；建议运行 treasury_futures_cffex_enrich.py"]})
    history_days = len({row.get("date") for row in rows if row.get("date")})
    if rows and history_days < 5:
        missing.append({"category": "历史序列", "items": [
            f"当前仅获取 {history_days} 个交易日，至少还需 {5 - history_days} 个交易日才能计算连续3日主力/移仓信号",
            "建议累计保存 30 个交易日，补齐历史成交量和持仓量",
        ]})
    missing.append({"category": "账户调仓指令", "items": [
        "账户持仓、方向、手数与建仓价", "每手 DV01、目标 DV01 与风险限额",
        "保证金、滑点、替代合约及最迟移仓日期",
    ]})
    missing.append({"category": "第二阶段增强", "items": [
        "从可交割券集合中确定 CTD，并补充现券净价/全价、应计利息、YTM 与 DV01（当前 CTD 状态为 DEFERRED）",
        "交割日、完整票息现金流、融资利率，用于净基差和 IRR",
        "Level-2 盘口、券源成本、手续费和保证金，用于执行成本",
    ]})
    return missing


def build_payload() -> dict:
    rows, errors = _read_files()
    latest_date = max((row["date"] for row in rows), default=None)
    products = [_product_payload(product, rows, latest_date) for product in PRODUCTS] if latest_date else [
        {"product": product, "available": False, "status": "等待 CSV 数据"} for product in PRODUCTS
    ]
    official_quote_rows = sum(1 for row in rows if row.get("dataSource") == "CFFEX_OFFICIAL")
    latest_rows = [row for row in rows if row.get("date") == latest_date]
    deliverable_contracts = {row.get("contract") for row in latest_rows if row.get("deliverableBonds")}
    deliverable_rows = sum(len(row.get("deliverableBonds") or []) for row in latest_rows if row.get("contract") in deliverable_contracts)
    ctd_ready = sum(1 for row in rows if row.get("ctdCode") and row.get("ctdDirtyPrice") is not None)
    has_official_quotes = official_quote_rows > 0
    has_mapping = bool(deliverable_contracts)
    source_name = (
        "中金所官方日行情 + 中金所可交割券"
        if has_official_quotes and has_mapping
        else "中金所官方日行情（可交割券映射待补）"
        if has_official_quotes
        else "行情 CSV + 中金所可交割券"
        if rows and has_mapping
        else "行情 CSV 快照（来源见文件）"
        if rows
        else "等待公开行情数据"
    )
    return {
        "date": latest_date, "source": "market_csv" if rows else "unavailable",
        "sourceName": source_name,
        "mode": "market_roll_warning", "accountInstructionAvailable": False,
        "dataQuality": {
            "quoteRows": len(rows), "officialQuoteRows": official_quote_rows,
            "deliverableContracts": len(deliverable_contracts), "deliverableRows": deliverable_rows,
            "ctdReadyRows": ctd_ready,
            "quoteStatus": "EXACT" if has_official_quotes else ("ESTIMATED" if rows else "DEFERRED"),
            "ctdStatus": "EXACT" if ctd_ready else "DEFERRED",
        },
        "products": products, "missingData": missing_data(rows, products),
        "validationErrors": errors[-30:], "historyDays": len({row["date"] for row in rows}),
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
    }


def query_treasury_futures(refresh: bool = False) -> dict:
    newest_input_mtime = max((path.stat().st_mtime for path in INPUT_DIR.glob("treasury_futures_*.csv")), default=0) if INPUT_DIR.exists() else 0
    if not refresh and OUTPUT_FILE.exists() and OUTPUT_FILE.stat().st_mtime >= newest_input_mtime:
        try:
            return json.loads(OUTPUT_FILE.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            pass
    payload = build_payload()
    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    with (LOG_DIR / "treasury_futures_update.log").open("a", encoding="utf-8") as handle:
        handle.write(
            f"{payload['updatedAt']} date={payload.get('date')} historyDays={payload.get('historyDays')} "
            f"availableProducts={sum(1 for item in payload.get('products') or [] if item.get('available'))} "
            f"validationErrors={len(payload.get('validationErrors') or [])}\n"
        )
    return payload


if __name__ == "__main__":
    print(json.dumps(query_treasury_futures(refresh=True), ensure_ascii=False, indent=2))
