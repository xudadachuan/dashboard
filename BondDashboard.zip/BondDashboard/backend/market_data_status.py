from __future__ import annotations

import json
import re
from functools import wraps
from datetime import datetime, timedelta
from pathlib import Path
from market_database import load_snapshot
from trading_calendar import trading_day_status


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT.parent / "data"
STATUS_FILE = DATA_DIR / "market_data_status.json"
UPDATE_STATE_FILE = DATA_DIR / "market_update_state.json"
UPDATE_LOG_FILE = ROOT.parent / "logs" / "market_data_update.log"


DATA_FILES = {
    "pboc_omo": DATA_DIR / "pboc_omo_daily.json",
    "funding_rates": DATA_DIR / "funding_rates_cache.json",
    "chinabond_yields": DATA_DIR / "chinabond_yields_cache.json",
    "interbank_cd": DATA_DIR / "interbank_cd_cache.json",
    "interbank_cd_valuation": DATA_DIR / "chinabond_ncd_valuation_cache.json",
    "bond_temperature": DATA_DIR / "bond_temperature_index.json",
    "market_news": DATA_DIR / "market_news.json",
    "market_commentary": DATA_DIR / "market_commentary.json",
    "ai_summary": DATA_DIR / "ai_summary.json",
    "market_snapshot": DATA_DIR / "market_snapshot.json",
    "primary_issuance": DATA_DIR / "primary_issuance_excel" / "exports" / "primary_issuance_latest.json",
    "treasury_futures": DATA_DIR / "treasury_futures" / "treasury_futures_latest.json",
    "etf_data": DATA_DIR / "etf_data_cache.json",
    "funding_sentiment": DATA_DIR / "funding_sentiment_index.json",
}

REQUEST_FILES = {
    "pboc_omo": DATA_DIR / "pending_update_requests.json",
    "funding_rates": DATA_DIR / "pending_funding_rate_requests.json",
}
UPDATE_STATE_MAX_AGE = timedelta(hours=3)


def active_update_state() -> dict:
    """Discard stale flags left behind by a killed or interrupted task."""
    payload = read_json(UPDATE_STATE_FILE)
    jobs = dict(payload.get("jobs") or {}) if isinstance(payload, dict) else {}
    now = datetime.now()
    active = {}
    for name, details in jobs.items():
        try:
            started_at = datetime.fromisoformat(str((details or {}).get("startedAt")))
        except (TypeError, ValueError):
            continue
        if now - started_at <= UPDATE_STATE_MAX_AGE:
            active[name] = details
    state = {
        "is_updating": bool(active),
        "jobs": active,
        "updatedAt": now.isoformat(timespec="seconds"),
    }
    if active != jobs or not UPDATE_STATE_FILE.exists():
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        UPDATE_STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    return state


def set_update_state(job: str, active: bool) -> dict:
    """Maintain a small cross-process update registry consumed by the UI."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    jobs = dict(active_update_state().get("jobs") or {})
    if active:
        jobs[job] = {"startedAt": datetime.now().isoformat(timespec="seconds")}
    else:
        jobs.pop(job, None)
    state = {
        "is_updating": bool(jobs),
        "jobs": jobs,
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
    }
    UPDATE_STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    return state


def update_locked(job: str):
    """Decorator that guarantees the update flag is released after a runner exits."""
    def decorate(func):
        @wraps(func)
        def wrapped(*args, **kwargs):
            set_update_state(job, True)
            save_market_data_status()
            try:
                return func(*args, **kwargs)
            finally:
                set_update_state(job, False)
                save_market_data_status()
        return wrapped
    return decorate


def read_json(path: Path):
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def file_updated_at(path: Path) -> str | None:
    if not path.exists():
        return None
    return datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds")


def payload_date(payload: dict | None) -> datetime | None:
    if not isinstance(payload, dict) or not payload.get("date"):
        return None
    try:
        return datetime.fromisoformat(str(payload.get("date")))
    except ValueError:
        return None


def latest_item_date(items: list[dict], *keys: str) -> str | None:
    values = [str(item.get(key) or "")[:10] for item in items if isinstance(item, dict) for key in keys]
    valid = [value for value in values if payload_date({"date": value})]
    return max(valid, default=None)


def pending_summary(path: Path) -> dict:
    payload = read_json(path)
    if not isinstance(payload, list):
        return {"total": 0, "pending": 0, "lastError": None}
    pending = [item for item in payload if item.get("status") == "pending"]
    last_error = next((item.get("lastError") for item in reversed(payload) if item.get("lastError")), None)
    return {"total": len(payload), "pending": len(pending), "lastError": last_error}


def source_status(name: str, path: Path) -> dict:
    payload = read_json(path)
    if name == "interbank_cd":
        stored = load_snapshot("interbank_cd_daily")
        if stored:
            cache_date = payload_date(payload)
            stored_date = payload_date(stored)
            if not cache_date or (stored_date and stored_date >= cache_date):
                payload = stored
    status = {
        "file": str(path.relative_to(DATA_DIR.parent)),
        "fileUpdatedAt": file_updated_at(path),
        "exists": path.exists(),
        "date": None,
        "previousDate": None,
        "source": None,
        "updatedAt": None,
        "note": None,
    }
    if payload is None:
        status["note"] = "missing or invalid json"
        return status

    if name == "pboc_omo" and isinstance(payload, list):
        last = payload[-1] if payload else {}
        status.update({
            "date": last.get("date"),
            "source": last.get("source"),
            "updatedAt": file_updated_at(path),
            "items": len(payload),
        })
        return status

    if name == "funding_rates" and isinstance(payload, dict):
        latest = payload.get("__latest__") if isinstance(payload.get("__latest__"), dict) else {}
        status.update({
            "date": latest.get("date"),
            "source": latest.get("source"),
            "updatedAt": latest.get("updatedAt"),
            "startDate": latest.get("startDate"),
            "endDate": latest.get("endDate"),
        })
        return status

    if isinstance(payload, dict):
        status.update({
            "date": payload.get("date"),
            "previousDate": payload.get("previousDate"),
            "source": payload.get("source"),
            "updatedAt": payload.get("updatedAt"),
        })
        if name == "bond_temperature":
            status["value"] = payload.get("bond_temp")
            status["level"] = payload.get("bond_temp_level")
            status["sampleSize"] = payload.get("sampleSize")
        if name == "interbank_cd_valuation":
            status["curveName"] = payload.get("curveName")
            status["rating"] = payload.get("rating")
            status["availableTerms"] = sum(
                value is not None for value in (payload.get("termYields") or {}).values()
            )
        if name == "funding_sentiment":
            status["value"] = payload.get("value")
            status["label"] = payload.get("label")
        if name == "etf_data":
            status["items"] = len(payload.get("items") or [])
            summary = payload.get("summary") or {}
            status["totalAmount100m"] = summary.get("totalAmount100m")
            status["totalMarketValue100m"] = summary.get("totalMarketValue100m")
        if name == "market_news":
            status["items"] = len(payload.get("items") or [])
            status["date"] = latest_item_date(payload.get("items") or [], "date", "publishedAt", "createdAt")
        if name == "market_commentary":
            daily = payload.get("daily") or []
            status["items"] = len(daily)
            status["date"] = latest_item_date(daily, "date", "createdAt")
            weekly = payload.get("weekly") or {}
            status["weekEndDate"] = weekly.get("weekEndDate")
        if name == "ai_summary":
            status["headline"] = payload.get("headline")
            status["updateTime"] = payload.get("update_time")
        if name == "market_snapshot":
            status["updateTime"] = payload.get("update_time")
        if name == "primary_issuance":
            status["items"] = len(payload.get("items") or [])
            summary = payload.get("summary") or {}
            status["totalAmount100m"] = summary.get("totalActualAmount100m") or summary.get("totalAmount100m")
        return status

    status["note"] = f"unsupported payload type: {type(payload).__name__}"
    return status


def build_market_data_status() -> dict:
    sources = {name: source_status(name, path) for name, path in DATA_FILES.items()}
    request_status = {name: pending_summary(path) for name, path in REQUEST_FILES.items()}
    dates = sorted({item.get("date") for item in sources.values() if item.get("date")})
    now = datetime.now()
    module_health = {}
    for name, item in sources.items():
        item_date = payload_date(item)
        age_days = (now.date() - item_date.date()).days if item_date else None
        unavailable = not item.get("exists") or item.get("source") == "unavailable" or item.get("note")
        state = "unavailable" if unavailable else ("stale" if age_days is None or age_days > 5 else "healthy")
        module_health[name] = {
            "status": state,
            "date": item.get("date"),
            "ageDays": age_days,
            "source": item.get("source"),
            "message": "数据不可用" if state == "unavailable" else ("数据已超过 5 个自然日" if state == "stale" else "正常"),
        }
    source_modules = {
        "pbc": ("pboc_omo",),
        "chinamoney": ("funding_rates", "interbank_cd"),
        "chinabond": ("chinabond_yields", "interbank_cd_valuation", "bond_temperature"),
        "eastmoney": ("etf_data",),
        "deepseek": ("ai_summary", "market_commentary"),
    }
    health = {}
    for source_name, names in source_modules.items():
        modules = {name: module_health[name] for name in names}
        failed = [item for item in modules.values() if item["status"] == "unavailable"]
        stale = [item for item in modules.values() if item["status"] == "stale"]
        status = "unavailable" if len(failed) == len(modules) else ("degraded" if failed or stale else "healthy")
        health[source_name] = {
            "status": status,
            "modules": modules,
            "message": "数据源整体不可用" if status == "unavailable" else ("部分模块陈旧或不可用" if status == "degraded" else "正常"),
        }
    update_state = active_update_state()
    return {
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
        "sources": sources,
        "requests": request_status,
        "dataDates": dates,
        "aligned": len(dates) <= 1,
        "source_health": health,
        "module_health": module_health,
        "is_updating": bool(update_state.get("is_updating")),
        "update_jobs": update_state.get("jobs") or {},
        "tradingDay": trading_day_status(),
        "note": "不同数据源按各自发布时间取最近可得日期；债市温度通常跟随收益率曲线和资金利率的共同最近日期。",
    }


def save_market_data_status() -> dict:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    payload = build_market_data_status()
    STATUS_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload


def query_market_data_status() -> dict:
    return save_market_data_status()


LOG_FIELDS = (
    "date", "DR001", "DR007", "R007", "OMO7D", "NCDValuation", "IBNCD", "ChinaBond",
    "BondTemp", "FundingSentiment", "ETF", "News", "Commentary", "CommentaryBackfill",
    "Weekly", "PrimaryIssuanceExcel", "OfficialWrite", "Aligned", "Errors",
)
LOG_FIELD_PATTERN = re.compile(r"(?:^|\s)(" + "|".join(LOG_FIELDS) + r")=")


def parse_summary_fields(line: str) -> dict[str, str]:
    text = line.removeprefix("market data refreshed ").strip()
    matches = list(LOG_FIELD_PATTERN.finditer(text))
    fields = {}
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        fields[match.group(1)] = text[match.end():end].strip()
    return fields


def module_result(name: str, raw: str | None, valid) -> dict:
    if raw is None:
        return {"name": name, "status": "unknown", "value": None}
    value = str(raw).strip()
    return {"name": name, "status": "complete" if valid(value) else "incomplete", "value": value}


def summary_modules(fields: dict[str, str]) -> list[dict]:
    present = lambda value: value not in {"", "-", "None", "null"} and "unavailable" not in value.lower()
    positive_count = lambda value: present(value) and value.split(":", 1)[0].isdigit() and int(value.split(":", 1)[0]) > 0
    modules = [
        module_result(
            "资金利率",
            fields.get("date"),
            lambda value: present(value) and all(present(fields.get(code)) for code in ("DR001", "DR007", "R007", "OMO7D")),
        ),
        module_result("同业存单估值", fields.get("NCDValuation"), lambda value: present(value.split(":", 1)[0])),
        module_result("同业存单发行", fields.get("IBNCD"), positive_count),
        module_result("中债收益率", fields.get("ChinaBond"), present),
        module_result("债市温度", fields.get("BondTemp"), lambda value: present(value.split(":", 1)[0])),
        module_result("资金情绪", fields.get("FundingSentiment"), lambda value: present(value.split(":", 1)[0])),
        module_result("债券 ETF", fields.get("ETF"), positive_count),
        module_result("市场消息", fields.get("News"), positive_count),
        module_result("市场点评", fields.get("Commentary"), lambda value: present(value) and ":failed" not in value and ":fallback" not in value),
        module_result("一级发行", fields.get("PrimaryIssuanceExcel"), positive_count),
    ]
    return modules


def query_data_update_logs(limit: int = 30, log_path: Path = UPDATE_LOG_FILE) -> dict:
    if not log_path.exists():
        return {"items": [], "updatedAt": datetime.now().isoformat(timespec="seconds")}
    try:
        lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return {"items": [], "updatedAt": datetime.now().isoformat(timespec="seconds")}

    runs = []
    current = None
    header_pattern = re.compile(r"^====\s+(.+?)\s+request=([^\s=]+)\s+====$")
    for line in lines:
        header = header_pattern.match(line.strip())
        if header:
            if current:
                runs.append(current)
            current = {
                "startedAt": header.group(1),
                "requestId": header.group(2),
                "status": "running",
                "completedAt": None,
                "error": None,
                "fields": {},
            }
            continue
        if not current:
            continue
        stripped = line.strip()
        if stripped.startswith("market data refreshed "):
            current["fields"] = parse_summary_fields(stripped)
        elif stripped.startswith("completed "):
            current["status"] = "success"
            completed = re.search(r"\bat=(.+)$", stripped)
            current["completedAt"] = completed.group(1) if completed else None
        elif stripped.startswith("failed:"):
            current["status"] = "failed"
            current["error"] = stripped.removeprefix("failed:").strip()
    if current:
        runs.append(current)

    safe_limit = max(1, min(int(limit), 100))
    latest_by_day = []
    seen_days = set()
    for run in reversed(runs):
        run_day = str(run["startedAt"]).split("T", 1)[0]
        if run_day in seen_days:
            continue
        seen_days.add(run_day)
        latest_by_day.append(run)
        if len(latest_by_day) >= safe_limit:
            break

    items = []
    for run in latest_by_day:
        modules = summary_modules(run["fields"])
        known = [item for item in modules if item["status"] != "unknown"]
        complete = [item for item in known if item["status"] == "complete"]
        incomplete = [item for item in known if item["status"] == "incomplete"]
        if run["status"] == "success" and incomplete:
            run["status"] = "partial"
        items.append(
            {
                "startedAt": run["startedAt"],
                "runDate": str(run["startedAt"]).split("T", 1)[0],
                "completedAt": run["completedAt"],
                "requestId": run["requestId"],
                "status": run["status"],
                "dataDate": run["fields"].get("date"),
                "aligned": run["fields"].get("Aligned"),
                "officialWrite": run["fields"].get("OfficialWrite"),
                "completeCount": len(complete),
                "knownCount": len(known),
                "completeness": round(len(complete) / len(known) * 100) if known else 0,
                "modules": modules,
                "error": run["error"],
                "errors": run["fields"].get("Errors"),
            }
        )
    return {"items": items, "updatedAt": datetime.now().isoformat(timespec="seconds")}


if __name__ == "__main__":
    print(json.dumps(save_market_data_status(), ensure_ascii=False, indent=2))
