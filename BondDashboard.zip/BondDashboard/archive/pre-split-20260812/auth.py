from __future__ import annotations

import argparse
import hashlib
import hmac
import os
import re
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DEFAULT_DB_PATH = ROOT / "data" / "bond_market.db"
PASSWORD_ITERATIONS = 600_000
SESSION_LIFETIME_DAYS = 7
USERNAME_PATTERN = re.compile(r"^[A-Za-z0-9_.\-\u4e00-\u9fff]{3,32}$")
VALID_ROLES = {"admin", "user"}
VALID_COLOR_SCHEMES = {"warm", "forest", "ocean", "graphite"}


class AuthError(ValueError):
    pass


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso_utc(value: datetime | None = None) -> str:
    return (value or utc_now()).isoformat(timespec="seconds")


@contextmanager
def connect(db_path: Path = DEFAULT_DB_PATH):
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 5000")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_auth_db(db_path: Path = DEFAULT_DB_PATH) -> None:
    with connect(db_path) as conn:
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL COLLATE NOCASE UNIQUE,
                email TEXT COLLATE NOCASE UNIQUE,
                password_hash TEXT NOT NULL,
                password_salt TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('admin', 'user')),
                is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0, 1)),
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                last_login_at TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS auth_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                token_hash TEXT NOT NULL UNIQUE,
                user_id INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_auth_sessions_user_id ON auth_sessions(user_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_auth_sessions_expires_at ON auth_sessions(expires_at)")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS site_settings (
                setting_key TEXT PRIMARY KEY,
                setting_value TEXT NOT NULL,
                updated_by INTEGER,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL
            )
            """
        )
        conn.execute("PRAGMA optimize")


def validate_username(username: str) -> str:
    value = str(username or "").strip()
    if not USERNAME_PATTERN.fullmatch(value):
        raise AuthError("用户名需为 3-32 位中文、字母、数字或 . _ -")
    return value


def validate_email(email: str | None) -> str | None:
    value = str(email or "").strip().lower()
    if not value:
        return None
    if len(value) > 254 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", value):
        raise AuthError("邮箱格式不正确")
    return value


def validate_password(password: str) -> str:
    value = str(password or "")
    if len(value) < 8:
        raise AuthError("密码至少需要 8 位")
    if len(value) > 128:
        raise AuthError("密码不能超过 128 位")
    if not re.search(r"[A-Za-z]", value) or not re.search(r"\d", value):
        raise AuthError("密码必须同时包含字母和数字")
    return value


def hash_password(password: str, salt: bytes | None = None) -> tuple[str, str]:
    password = validate_password(password)
    raw_salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), raw_salt, PASSWORD_ITERATIONS)
    return digest.hex(), raw_salt.hex()


def verify_password(password: str, expected_hash: str, salt_hex: str) -> bool:
    try:
        digest = hashlib.pbkdf2_hmac(
            "sha256", str(password).encode("utf-8"), bytes.fromhex(salt_hex), PASSWORD_ITERATIONS
        ).hex()
    except (TypeError, ValueError):
        return False
    return hmac.compare_digest(digest, expected_hash)


def public_user(row: sqlite3.Row | dict) -> dict:
    return {
        "id": row["id"],
        "username": row["username"],
        "email": row["email"],
        "role": row["role"],
        "isActive": bool(row["is_active"]),
        "createdAt": row["created_at"],
        "lastLoginAt": row["last_login_at"],
    }


def create_user(
    username: str,
    password: str,
    email: str | None = None,
    role: str = "user",
    db_path: Path = DEFAULT_DB_PATH,
) -> dict:
    username = validate_username(username)
    email = validate_email(email)
    if role not in VALID_ROLES:
        raise AuthError("无效的账户角色")
    password_hash, salt = hash_password(password)
    now = iso_utc()
    init_auth_db(db_path)
    try:
        with connect(db_path) as conn:
            cursor = conn.execute(
                """
                INSERT INTO users(username, email, password_hash, password_salt, role, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (username, email, password_hash, salt, role, now, now),
            )
            row = conn.execute("SELECT * FROM users WHERE id = ?", (cursor.lastrowid,)).fetchone()
    except sqlite3.IntegrityError as exc:
        message = "用户名已存在" if "users.username" in str(exc) else "邮箱已被使用"
        raise AuthError(message) from exc
    return public_user(row)


def authenticate(identifier: str, password: str, db_path: Path = DEFAULT_DB_PATH) -> tuple[dict, str]:
    value = str(identifier or "").strip()
    init_auth_db(db_path)
    with connect(db_path) as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE username = ? COLLATE NOCASE OR email = ? COLLATE NOCASE LIMIT 1",
            (value, value),
        ).fetchone()
        if not row or not verify_password(password, row["password_hash"], row["password_salt"]):
            raise AuthError("用户名或密码错误")
        if not row["is_active"]:
            raise AuthError("账户已停用，请联系管理员")
        user_id = row["id"]
    return create_session_for_user(user_id, db_path)


def authenticate_email(email: str, password: str, db_path: Path = DEFAULT_DB_PATH) -> tuple[dict, str]:
    value = validate_email(email)
    if not value:
        raise AuthError("请输入邮箱地址")
    return authenticate(value, password, db_path)


def create_session_for_user(user_id: int, db_path: Path = DEFAULT_DB_PATH) -> tuple[dict, str]:
    init_auth_db(db_path)
    token = secrets.token_urlsafe(32)
    token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
    now = utc_now()
    expires = now + timedelta(days=SESSION_LIFETIME_DAYS)
    with connect(db_path) as conn:
        row = conn.execute("SELECT * FROM users WHERE id = ? AND is_active = 1", (user_id,)).fetchone()
        if not row:
            raise AuthError("账户不存在或已停用")
        conn.execute("DELETE FROM auth_sessions WHERE expires_at <= ?", (iso_utc(now),))
        conn.execute(
            "INSERT INTO auth_sessions(token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)",
            (token_hash, user_id, iso_utc(now), iso_utc(expires)),
        )
        conn.execute("UPDATE users SET last_login_at = ?, updated_at = ? WHERE id = ?", (iso_utc(now), iso_utc(now), user_id))
        updated = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    return public_user(updated), token


def user_for_session(token: str | None, db_path: Path = DEFAULT_DB_PATH) -> dict | None:
    if not token:
        return None
    token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
    now = iso_utc()
    init_auth_db(db_path)
    with connect(db_path) as conn:
        row = conn.execute(
            """
            SELECT u.* FROM auth_sessions s
            JOIN users u ON u.id = s.user_id
            WHERE s.token_hash = ? AND s.expires_at > ? AND u.is_active = 1
            """,
            (token_hash, now),
        ).fetchone()
    return public_user(row) if row else None


def revoke_session(token: str | None, db_path: Path = DEFAULT_DB_PATH) -> None:
    if not token:
        return
    token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
    init_auth_db(db_path)
    with connect(db_path) as conn:
        conn.execute("DELETE FROM auth_sessions WHERE token_hash = ?", (token_hash,))


def change_password(user_id: int, current_password: str, new_password: str, db_path: Path = DEFAULT_DB_PATH) -> None:
    init_auth_db(db_path)
    new_hash, new_salt = hash_password(new_password)
    with connect(db_path) as conn:
        row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        if not row or not verify_password(current_password, row["password_hash"], row["password_salt"]):
            raise AuthError("当前密码不正确")
        conn.execute(
            "UPDATE users SET password_hash = ?, password_salt = ?, updated_at = ? WHERE id = ?",
            (new_hash, new_salt, iso_utc(), user_id),
        )
        conn.execute("DELETE FROM auth_sessions WHERE user_id = ?", (user_id,))


def reset_password(user_id: int, new_password: str, db_path: Path = DEFAULT_DB_PATH) -> None:
    init_auth_db(db_path)
    new_hash, new_salt = hash_password(new_password)
    with connect(db_path) as conn:
        if not conn.execute("SELECT 1 FROM users WHERE id = ?", (user_id,)).fetchone():
            raise AuthError("用户不存在")
        conn.execute(
            "UPDATE users SET password_hash = ?, password_salt = ?, updated_at = ? WHERE id = ?",
            (new_hash, new_salt, iso_utc(), user_id),
        )
        conn.execute("DELETE FROM auth_sessions WHERE user_id = ?", (user_id,))


def list_users(db_path: Path = DEFAULT_DB_PATH) -> list[dict]:
    init_auth_db(db_path)
    with connect(db_path) as conn:
        rows = conn.execute("SELECT * FROM users ORDER BY created_at DESC, id DESC").fetchall()
    return [public_user(row) for row in rows]


def update_user(user_id: int, role: str | None, is_active: bool | None, actor_id: int, db_path: Path = DEFAULT_DB_PATH) -> dict:
    if role is not None and role not in VALID_ROLES:
        raise AuthError("无效的账户角色")
    if user_id == actor_id and is_active is False:
        raise AuthError("不能停用当前登录的管理员账户")
    if user_id == actor_id and role == "user":
        raise AuthError("不能移除当前登录账户的管理员权限")
    init_auth_db(db_path)
    with connect(db_path) as conn:
        row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        if not row:
            raise AuthError("用户不存在")
        next_role = role if role is not None else row["role"]
        next_active = int(is_active) if is_active is not None else row["is_active"]
        if row["role"] == "admin" and row["is_active"] and (next_role != "admin" or not next_active):
            active_admins = conn.execute("SELECT COUNT(*) FROM users WHERE role = 'admin' AND is_active = 1").fetchone()[0]
            if active_admins <= 1:
                raise AuthError("系统必须至少保留一个启用的管理员")
        conn.execute(
            "UPDATE users SET role = ?, is_active = ?, updated_at = ? WHERE id = ?",
            (next_role, next_active, iso_utc(), user_id),
        )
        if not next_active:
            conn.execute("DELETE FROM auth_sessions WHERE user_id = ?", (user_id,))
        updated = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    return public_user(updated)


def get_color_scheme(db_path: Path = DEFAULT_DB_PATH) -> str:
    init_auth_db(db_path)
    with connect(db_path) as conn:
        row = conn.execute("SELECT setting_value FROM site_settings WHERE setting_key = 'color_scheme'").fetchone()
    value = row["setting_value"] if row else "warm"
    return value if value in VALID_COLOR_SCHEMES else "warm"


def set_color_scheme(scheme: str, actor_user_id: int, db_path: Path = DEFAULT_DB_PATH) -> str:
    value = str(scheme or "").strip().lower()
    if value not in VALID_COLOR_SCHEMES:
        raise AuthError("无效的配色方案")
    init_auth_db(db_path)
    with connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO site_settings(setting_key, setting_value, updated_by, updated_at)
            VALUES ('color_scheme', ?, ?, ?)
            ON CONFLICT(setting_key) DO UPDATE SET
                setting_value = excluded.setting_value,
                updated_by = excluded.updated_by,
                updated_at = excluded.updated_at
            """,
            (value, actor_user_id, iso_utc()),
        )
    return value


def load_env_file(path: Path = ROOT / ".env") -> None:
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def bootstrap_admin_from_env(db_path: Path = DEFAULT_DB_PATH) -> dict | None:
    load_env_file()
    username = os.environ.get("BOND_DASHBOARD_ADMIN_USERNAME", "").strip()
    password = os.environ.get("BOND_DASHBOARD_ADMIN_PASSWORD", "")
    email = validate_email(os.environ.get("BOND_DASHBOARD_ADMIN_EMAIL"))
    if not username or not password:
        return None
    if not email:
        raise AuthError("管理员账户必须配置邮箱")
    init_auth_db(db_path)
    with connect(db_path) as conn:
        existing = conn.execute("SELECT * FROM users WHERE username = ? COLLATE NOCASE", (username,)).fetchone()
    if existing:
        if email and not existing["email"]:
            with connect(db_path) as conn:
                conn.execute("UPDATE users SET email = ?, updated_at = ? WHERE id = ?", (email, iso_utc(), existing["id"]))
                existing = conn.execute("SELECT * FROM users WHERE id = ?", (existing["id"],)).fetchone()
        return public_user(existing)
    return create_user(username, password, email, "admin", db_path)


def main() -> int:
    parser = argparse.ArgumentParser(description="债市看板账户管理")
    subparsers = parser.add_subparsers(dest="command", required=True)
    create_admin = subparsers.add_parser("create-admin", help="创建管理员账户")
    create_admin.add_argument("--username", required=True)
    create_admin.add_argument("--email", required=True)
    create_admin.add_argument("--password", required=True)
    args = parser.parse_args()
    if args.command == "create-admin":
        user = create_user(args.username, args.password, args.email, "admin")
        print(f"管理员已创建：{user['username']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
