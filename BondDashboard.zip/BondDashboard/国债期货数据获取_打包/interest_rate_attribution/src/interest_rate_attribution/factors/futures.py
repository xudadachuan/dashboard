from __future__ import annotations

"""国债期货第一阶段指标：主力识别、价格动量、持仓量变化。

第一阶段不依赖真实 CTD，全部基于真实合约的日行情。
主连/次主连合约仅用于动量分析，禁止用于 CTD（CTD 必须对应真实交割合约）。

输出状态约定：
- EXACT      使用真实合约结算价/收盘价与真实持仓量
- ESTIMATED  结算价缺失回退收盘价（CLOSE_PROXY）
- DEFERRED   缺少数据
"""

import numpy as np
import pandas as pd

DOMINANT = "DOMINANT"
SUBDOMINANT = "SUBDOMINANT"


def identify_dominant_contracts(
    daily: pd.DataFrame,
) -> pd.DataFrame:
    """按品种+交易日，以持仓量（缺失时回退成交量）识别主/次主力合约。

    返回列：trade_date, product_code, dominant_code, subdominant_code,
    dominant_open_interest, subdominant_open_interest, basis_for_rank
    """
    if daily.empty:
        return pd.DataFrame(
            columns=[
                "trade_date", "product_code", "dominant_code", "subdominant_code",
                "dominant_open_interest", "subdominant_open_interest", "basis_for_rank",
            ]
        )
    frame = daily.copy()
    frame["trade_date"] = pd.to_datetime(frame["trade_date"], errors="coerce")
    if "product_code" not in frame.columns and "contract_code" in frame.columns:
        frame["product_code"] = (
            frame["contract_code"].astype(str).str.extract(r"^([A-Za-z]+)")[0]
        )

    rank_basis = "open_interest"
    if "open_interest" in frame.columns:
        oi = pd.to_numeric(frame["open_interest"], errors="coerce")
        frame["_rank"] = oi
        frame["basis_for_rank"] = "open_interest"
        if oi.isna().all() and "volume" in frame.columns:
            frame["_rank"] = pd.to_numeric(frame["volume"], errors="coerce")
            frame["basis_for_rank"] = "volume"
    elif "volume" in frame.columns:
        frame["_rank"] = pd.to_numeric(frame["volume"], errors="coerce")
        frame["basis_for_rank"] = "volume"
    else:
        return pd.DataFrame(
            columns=[
                "trade_date", "product_code", "dominant_code", "subdominant_code",
                "dominant_open_interest", "subdominant_open_interest", "basis_for_rank",
            ]
        )

    rows: list[dict] = []
    for (trade_date, product), group in frame.groupby(["trade_date", "product_code"]):
        ranked = group.sort_values("_rank", ascending=False)
        if ranked.empty:
            continue
        dominant = ranked.iloc[0]
        row = {
            "trade_date": trade_date,
            "product_code": product,
            "dominant_code": dominant.get("contract_code"),
            "subdominant_code": ranked.iloc[1].get("contract_code") if len(ranked) > 1 else None,
            "dominant_open_interest": dominant.get("open_interest"),
            "subdominant_open_interest": (
                ranked.iloc[1].get("open_interest") if len(ranked) > 1 else None
            ),
            "basis_for_rank": group["basis_for_rank"].iloc[0],
        }
        rows.append(row)
    return pd.DataFrame(rows)


def build_price_momentum(
    daily: pd.DataFrame,
    windows: tuple[int, ...] = (5, 20, 60),
    price_column: str = "close",
) -> pd.DataFrame:
    """期货价格动量：窗口收益率。

    使用真实合约收盘价计算。主连/次主连的动量由调用方合并后另行计算。
    """
    if daily.empty:
        return pd.DataFrame()
    frame = daily.copy()
    frame["trade_date"] = pd.to_datetime(frame["trade_date"], errors="coerce")
    if price_column not in frame.columns:
        return pd.DataFrame()
    price = pd.to_numeric(frame[price_column], errors="coerce")
    parts: list[pd.DataFrame] = []
    for contract, group in frame.groupby("contract_code", sort=False):
        g = group.sort_values("trade_date").copy()
        base = pd.to_numeric(g[price_column], errors="coerce")
        for window in windows:
            g[f"MOM_FUTURES_PRICE_{window}D"] = (
                base / base.shift(window) - 1.0
            )
        parts.append(g)
    out = pd.concat(parts, ignore_index=True)
    out["calculation_status"] = "EXACT"
    return out


def build_open_interest_change(
    daily: pd.DataFrame,
    windows: tuple[int, ...] = (5, 20),
) -> pd.DataFrame:
    """期货持仓量变化（杠杆资金参与度变化）。"""
    if daily.empty:
        return pd.DataFrame()
    frame = daily.copy()
    frame["trade_date"] = pd.to_datetime(frame["trade_date"], errors="coerce")
    if "open_interest" not in frame.columns:
        return pd.DataFrame()
    parts: list[pd.DataFrame] = []
    for contract, group in frame.groupby("contract_code", sort=False):
        g = group.sort_values("trade_date").copy()
        oi = pd.to_numeric(g["open_interest"], errors="coerce")
        for window in windows:
            g[f"POSITION_CHG_FUTURES_{window}D"] = oi - oi.shift(window)
        parts.append(g)
    out = pd.concat(parts, ignore_index=True)
    out["calculation_status"] = "EXACT"
    return out
