from __future__ import annotations

"""按中金所可交割券清单批量获取 iFinD 现券 CTD 输入。

该脚本只获取现券侧数据，不涉及账户持仓或交易明细。输出的
``ctd_bond_prices.csv`` 可直接传给 ``fetch_cffex_treasury_futures.py``。
"""

import argparse
import json
from pathlib import Path
import sys

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parent
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from interest_rate_attribution.adapters.ctd_inputs import normalize_bond_prices, normalize_risk_analytics
from interest_rate_attribution.adapters.ifind import IFindPyClient


def _write(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, encoding="utf-8-sig")


def _coverage(prices: pd.DataFrame, expected_codes: list[str], start: str, end: str) -> pd.DataFrame:
    dates = pd.date_range(start, end, freq="D")
    observed = (
        prices.groupby("trade_date")["bond_code"].agg(lambda values: set(values.astype(str)))
        if not prices.empty else pd.Series(dtype=object)
    )
    rows: list[dict[str, object]] = []
    expected = set(expected_codes)
    for date in dates:
        date_key = pd.Timestamp(date).normalize()
        codes = observed.get(date_key, set())
        missing = sorted(expected - set(codes))
        rows.append(
            {
                "trade_date": date_key,
                "expected_bond_count": len(expected),
                "observed_bond_count": len(codes),
                "missing_bond_count": len(missing),
                "missing_bond_codes": ",".join(missing),
                "status": "PASS" if not missing else ("WARN" if codes else "DEFERRED"),
            }
        )
    return pd.DataFrame(rows)


def run(mapping_path: Path, start: str, end: str, output_dir: Path) -> int:
    mapping = pd.read_csv(mapping_path)
    required = {"bond_code"}
    missing = required - set(mapping.columns)
    if missing:
        raise ValueError(f"可交割券映射缺少列: {sorted(missing)}")
    codes = (
        mapping["bond_code"].dropna().astype(str).str.strip().str.upper()
        .drop_duplicates().tolist()
    )
    if not codes:
        raise ValueError("可交割券映射没有债券代码")

    client = IFindPyClient()
    try:
        raw_snapshot = client.fetch_snapshots(codes, start, end)
        raw_risk = client.fetch_risk_series(codes, start, end)
        snapshot_errors = list(client.snapshot_errors)
    finally:
        client.close()

    prices = normalize_bond_prices(raw_snapshot)
    risk = normalize_risk_analytics(raw_risk)
    if "dv01" in prices.columns:
        dv01 = prices[["trade_date", "bond_code", "dv01"]].dropna(subset=["dv01"])
        risk = risk.merge(dv01, on=["trade_date", "bond_code"], how="left", validate="one_to_one")

    output_dir.mkdir(parents=True, exist_ok=True)
    _write(raw_snapshot, output_dir / "ifind_raw_ctd_snapshot.csv")
    _write(raw_risk, output_dir / "ifind_raw_ctd_risk.csv")
    _write(prices, output_dir / "ctd_bond_prices.csv")
    _write(risk, output_dir / "ctd_risk_analytics.csv")
    _write(_coverage(prices, codes, start, end), output_dir / "ctd_input_coverage_qc.csv")
    if snapshot_errors:
        _write(pd.DataFrame(snapshot_errors), output_dir / "ctd_snapshot_errors.csv")

    summary = {
        "source": "IFIND",
        "mapping_path": str(mapping_path),
        "start": start,
        "end": end,
        "eligible_bond_count": len(codes),
        "price_rows": len(prices),
        "risk_rows": len(risk),
        "snapshot_error_count": len(snapshot_errors),
        "output_files": [
            "ctd_bond_prices.csv",
            "ctd_risk_analytics.csv",
            "ctd_input_coverage_qc.csv",
            "ifind_raw_ctd_snapshot.csv",
            "ifind_raw_ctd_risk.csv",
        ],
    }
    (output_dir / "run_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, default=str), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2, default=str))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="按中金所可交割券清单获取 iFinD 现券 CTD 输入")
    parser.add_argument("--mapping", type=Path, required=True, help="CFFEX deliverable_bond_mapping_cffex.csv")
    parser.add_argument("--start", required=True, help="开始日期 YYYY-MM-DD")
    parser.add_argument("--end", required=True, help="结束日期 YYYY-MM-DD")
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args(argv)
    if pd.Timestamp(args.start) > pd.Timestamp(args.end):
        parser.error("--start 不能晚于 --end")
    return run(args.mapping, args.start, args.end, args.output_dir)


if __name__ == "__main__":
    raise SystemExit(main())
