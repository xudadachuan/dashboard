from __future__ import annotations

"""国债期货 CTD（最便宜可交割券）计算。

第二阶段能力：
- 毛基差（gross basis）
- 交割发票价格（invoice price）
- 净基差（net basis，基于完整现金流）
- 隐含回购利率（IRR，日期现金流求解）
- CTD 选择（净基差最低 + IRR 最高，双排序）
- CTD DV01（三个口径）

状态约定：
- EXACT      现券价格来自可成交/成交/盘口，融资利率为真实账户利率
- ESTIMATED  现券价格来自估值价，或融资利率为代理值
- DEFERRED   缺少必要数据

关键原则：CTD 必须对应某个真实交割合约，主连/次主连价格禁止用于 CTD。
"""

import numpy as np
import pandas as pd

EXACT = "EXACT"
ESTIMATED = "ESTIMATED"
DEFERRED = "DEFERRED"

# 价格类型
PRICE_EXECUTABLE_BID = "EXECUTABLE_BID"
PRICE_EXECUTABLE_ASK = "EXECUTABLE_ASK"
PRICE_TRADE = "TRADE_PRICE"
PRICE_MID = "MARKET_MID"
PRICE_VALUATION = "VALUATION_PRICE"
PRICE_CLOSE_PROXY = "CLOSE_PROXY"

# 可用于 EXACT 的价格类型（前三类 + 时间对齐）
EXACT_PRICE_TYPES = {
    PRICE_EXECUTABLE_BID,
    PRICE_EXECUTABLE_ASK,
    PRICE_TRADE,
    PRICE_MID,
}


def gross_basis(bond_clean_price: float, futures_settlement: float, conversion_factor: float) -> float:
    """毛基差 = 现券净价 - 期货结算价 × 转换因子。"""
    return float(bond_clean_price) - float(futures_settlement) * float(conversion_factor)


def invoice_price(
    futures_settlement: float,
    conversion_factor: float,
    accrued_interest_on_delivery: float,
) -> float:
    """交割发票价格 = 期货结算价 × 转换因子 + 交割日应计利息。"""
    return (
        float(futures_settlement) * float(conversion_factor)
        + float(accrued_interest_on_delivery)
    )


def net_basis(
    bond_dirty_price: float,
    funding_cost_to_delivery: float,
    coupon_reinvested: float,
    invoice_price: float,
) -> float:
    """净基差 = 现券全价 + 持有至交割融资成本 - 交割前票息再投资 - 交割发票价格。"""
    return (
        float(bond_dirty_price)
        + float(funding_cost_to_delivery)
        - float(coupon_reinvested)
        - float(invoice_price)
    )


def implied_repo_rate(
    cashflows: list[tuple[float, float]],
) -> float:
    """用日期现金流求解隐含回购利率（年化）。

    cashflows: [(日期(以估值日为0的年数), 金额), ...]
    约定：估值日付现券全价为负，中间付息为正，交割日收发票价格为正。
    求使现金流净现值为零的年化利率。
    """
    if not cashflows or len(cashflows) < 2:
        return float("nan")
    cashflows = sorted(cashflows, key=lambda item: item[0])
    lo, hi = -0.99, 5.0
    def npv(rate: float) -> float:
        total = 0.0
        for t, amount in cashflows:
            total += amount / ((1.0 + rate) ** t)
        return total

    f_lo = npv(lo)
    f_hi = npv(hi)
    if f_lo * f_hi > 0:
        # 区间内无符号变化，返回 NaN（可能现金流结构异常）
        return float("nan")
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        f_mid = npv(mid)
        if abs(f_mid) < 1e-10:
            return mid
        if f_lo * f_mid < 0:
            hi = mid
        else:
            lo = mid
            f_lo = f_mid
    return 0.5 * (lo + hi)


def irr_funding_gap(irr: float, actual_funding_rate: float) -> float:
    """IRR - 实际融资利率。"""
    if not np.isfinite(irr) or not np.isfinite(actual_funding_rate):
        return float("nan")
    return float(irr) - float(actual_funding_rate)


def select_ctd(candidates: pd.DataFrame) -> pd.DataFrame:
    """从每只可交割券的明细中选择 CTD。

    candidates 需包含列：trade_date, contract_code, bond_code,
    net_basis, irr, ...
    返回每个 (trade_date, contract_code) 的 CTD 结果，含次优券与切换风险。
    """
    if candidates.empty:
        return pd.DataFrame()

    required = {"trade_date", "contract_code", "bond_code", "net_basis", "irr"}
    missing = required - set(candidates.columns)
    if missing:
        return pd.DataFrame()

    rows: list[dict] = []
    group_keys = ["trade_date", "contract_code"]
    for _, group in candidates.groupby(group_keys):
        # 净基差最低
        by_nb = group.sort_values("net_basis", ascending=True)
        # IRR 最高
        by_irr = group.sort_values("irr", ascending=False)

        best_nb = by_nb.iloc[0]
        best_irr = by_irr.iloc[0]

        # 双排序一致性
        consistent = best_nb["bond_code"] == best_irr["bond_code"]

        # 次优净基差券（用于切换风险）
        second_nb = by_nb.iloc[1] if len(by_nb) > 1 else None
        ctd_switch_gap = (
            second_nb["net_basis"] - best_nb["net_basis"] if second_nb is not None else np.nan
        )

        rows.append(
            {
                "trade_date": group["trade_date"].iloc[0],
                "contract_code": group["contract_code"].iloc[0],
                "ctd_bond_code": best_nb["bond_code"],
                "ctd_by_net_basis": best_nb["bond_code"],
                "ctd_by_irr": best_irr["bond_code"],
                "ctd_consistent": consistent,
                "best_net_basis": best_nb["net_basis"],
                "best_irr": best_nb["irr"],
                "second_best_bond_code": second_nb["bond_code"] if second_nb is not None else None,
                "ctd_switch_gap": ctd_switch_gap,
            }
        )
    return pd.DataFrame(rows)


def rank_ctd_top2(
    candidates: pd.DataFrame,
    rank_column: str | None = None,
) -> pd.DataFrame:
    """按交易日和合约输出净基差（或毛基差）的前两名交割券。

    ``rank_column`` 默认优先使用 ``net_basis``，没有该列时使用
    ``gross_basis``。排序方向都是越小越优先。输入重复的
    ``(trade_date, contract_code, bond_code)`` 只保留排序后的第一条，
    但在 ``duplicate_input_count`` 中保留重复数量，方便发现上游合并错误。

    该函数只负责排名，不会把毛基差冒充净基差。若使用毛基差，输出的
    ``selection_method`` 为 ``GROSS_BASIS_PROXY``，调用方应将结果标记为
    ``ESTIMATED`` 或 ``DEFERRED``，直到补齐票息、融资和交割日现金流。
    """
    if candidates.empty:
        return pd.DataFrame(
            columns=[
                "trade_date", "contract_code", "ctd_rank", "bond_code",
                "gross_basis", "net_basis", "irr", "dv01", "price_type",
                "selection_method", "duplicate_input_count", "calculation_status",
            ]
        )
    if rank_column is None:
        rank_column = "net_basis" if "net_basis" in candidates.columns else "gross_basis"
    required = {"trade_date", "contract_code", "bond_code", rank_column}
    missing = required - set(candidates.columns)
    if missing:
        return pd.DataFrame()

    frame = candidates.copy()
    frame["trade_date"] = pd.to_datetime(frame["trade_date"], errors="coerce").dt.normalize()
    frame[rank_column] = pd.to_numeric(frame[rank_column], errors="coerce")
    rows: list[dict[str, object]] = []
    for (trade_date, contract_code), group in frame.groupby(
        ["trade_date", "contract_code"], dropna=False
    ):
        group = group.loc[group[rank_column].notna()].copy()
        if group.empty:
            continue
        duplicate_counts = group.groupby("bond_code").size()
        duplicate_total = int(duplicate_counts[duplicate_counts > 1].sum())
        sort_columns = [rank_column]
        ascending = [True]
        if "irr" in group.columns:
            sort_columns.append("irr")
            ascending.append(False)
        group = group.sort_values(sort_columns, ascending=ascending, kind="mergesort")
        group = group.drop_duplicates("bond_code", keep="first").head(2)
        method = "NET_BASIS" if rank_column == "net_basis" else "GROSS_BASIS_PROXY"
        for rank, (_, record) in enumerate(group.iterrows(), start=1):
            status = record.get("calculation_status", "DEFERRED")
            if method == "GROSS_BASIS_PROXY" and status == "EXACT":
                status = "ESTIMATED"
            rows.append(
                {
                    "trade_date": trade_date,
                    "contract_code": contract_code,
                    "ctd_rank": rank,
                    "bond_code": record.get("bond_code"),
                    "gross_basis": record.get("gross_basis", np.nan),
                    "net_basis": record.get("net_basis", np.nan),
                    "irr": record.get("irr", np.nan),
                    "dv01": record.get("dv01", np.nan),
                    "price_type": record.get("price_type", ""),
                    "selection_method": method,
                    "duplicate_input_count": duplicate_total,
                    "calculation_status": status,
                }
            )
    return pd.DataFrame(rows)


def build_gross_basis_candidates(
    bond_prices: pd.DataFrame,
    futures: pd.DataFrame,
    conversion_factors: pd.DataFrame,
) -> pd.DataFrame:
    """用现券净价、期货结算价和中金所转换因子生成毛基差候选表。

    这是 CTD 计算的第一层输入，不包含融资成本、票息再投资和交割日应计
    利息。因此结果只能进行毛基差排名，不能替代真实净基差 CTD。
    """
    required_bond = {"trade_date", "bond_code", "clean_price"}
    required_futures = {"trade_date", "contract_code", "settlement"}
    required_cf = {"contract_code", "bond_code", "conversion_factor"}
    if (
        bond_prices.empty
        or futures.empty
        or conversion_factors.empty
        or not required_bond.issubset(bond_prices.columns)
        or not required_futures.issubset(futures.columns)
        or not required_cf.issubset(conversion_factors.columns)
    ):
        return pd.DataFrame(
            columns=[
                "trade_date", "contract_code", "bond_code", "clean_price",
                "dirty_price", "settlement", "conversion_factor", "gross_basis",
                "price_type", "calculation_status",
            ]
        )

    bp = bond_prices.copy()
    fp = futures.copy()
    cf = conversion_factors.copy()
    for frame in (bp, fp):
        frame["trade_date"] = pd.to_datetime(frame["trade_date"], errors="coerce").dt.normalize()
    for frame in (bp, fp, cf):
        for col in ("bond_code", "contract_code"):
            if col in frame.columns:
                frame[col] = frame[col].astype(str).str.strip().str.upper()
    bp["clean_price"] = pd.to_numeric(bp["clean_price"], errors="coerce")
    if "dirty_price" not in bp.columns:
        bp["dirty_price"] = bp["clean_price"]
    bp["dirty_price"] = pd.to_numeric(bp["dirty_price"], errors="coerce")
    fp["settlement"] = pd.to_numeric(fp["settlement"], errors="coerce")
    cf["conversion_factor"] = pd.to_numeric(cf["conversion_factor"], errors="coerce")
    # 官方日行情和不同来源拼接时可能重复同一合约-日期；先去重，避免
    # 候选表被笛卡尔放大。转换因子冲突应由映射 QC 报告处理，计算时保留最后一条。
    fp = fp.drop_duplicates(["contract_code", "trade_date"], keep="last")
    cf = cf.drop_duplicates(["contract_code", "bond_code"], keep="last")
    merged = bp.merge(cf, on="bond_code", how="inner")
    merged = merged.merge(
        fp[["contract_code", "trade_date", "settlement"]],
        on=["contract_code", "trade_date"],
        how="inner",
    )
    merged["gross_basis"] = (
        merged["clean_price"] - merged["settlement"] * merged["conversion_factor"]
    )
    if "price_type" not in merged.columns:
        merged["price_type"] = "VALUATION_PRICE"
    merged["calculation_status"] = np.where(
        merged["price_type"].isin(EXACT_PRICE_TYPES), EXACT, ESTIMATED
    )
    columns = [
        "trade_date", "contract_code", "bond_code", "clean_price",
        "dirty_price", "settlement", "conversion_factor", "gross_basis",
        "price_type", "calculation_status",
    ]
    columns.extend(
        column for column in ("accrued_interest", "ytm", "dv01", "modified_duration", "convexity")
        if column in merged.columns
    )
    return merged[columns].sort_values(
        ["trade_date", "contract_code", "gross_basis"]
    ).reset_index(drop=True)


def ctd_dv01(
    ctd_bond_dv01_per_100: float,
    conversion_factor: float,
    contract_notional: float,
) -> dict[str, float]:
    """CTD DV01 三个口径。

    - ctd_bond_dv01_per_100: CTD 现券每百元 DV01
    - ctd_futures_equivalent_dv01: 期货每百元 DV01 ≈ 现券 DV01 / 转换因子
    - ctd_contract_dv01: 单张期货 DV01 ≈ 每百元 DV01 × 合约面值 / 100
    """
    bond_dv01 = float(ctd_bond_dv01_per_100)
    cf = float(conversion_factor)
    futures_dv01_per_100 = bond_dv01 / cf if cf != 0 else float("nan")
    contract_dv01 = futures_dv01_per_100 * float(contract_notional) / 100.0
    return {
        "ctd_bond_dv01_per_100": bond_dv01,
        "ctd_futures_equivalent_dv01": futures_dv01_per_100,
        "ctd_contract_dv01": contract_dv01,
    }


def price_status(bond_price_type: str, funding_is_proxy: bool) -> str:
    """根据现券价格类型和融资利率是否为代理值，判定计算状态。"""
    if bond_price_type in EXACT_PRICE_TYPES and not funding_is_proxy:
        return EXACT
    if bond_price_type == PRICE_VALUATION or funding_is_proxy:
        return ESTIMATED
    return DEFERRED


def calculate_ctd_candidates(
    bond_prices: pd.DataFrame,
    futures: pd.DataFrame,
    conversion_factors: pd.DataFrame,
    funding_rate: float,
    funding_is_proxy: bool,
    delivery_dates: pd.DataFrame | None = None,
    cashflow_schedule: pd.DataFrame | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """对每个交易日、每个合约、每只可交割券计算基差/净基差/IRR。

    输入：
    - bond_prices: 每只可交割券日频全价/净价，含 bond_code, trade_date,
      dirty_price, clean_price, accrued_interest, price_type
    - futures: 期货日行情，含 contract_code, trade_date, settlement
    - conversion_factors: 合约-债券转换因子，含 contract_code, bond_code, conversion_factor
    - funding_rate: 融资利率（代理时 funding_is_proxy=True）
    - delivery_dates: 交割日期（可选），缺省时 net_basis/IRR 标记 DEFERRED
    - cashflow_schedule: 完整现金流（可选），用于 IRR 日期现金流

    返回 (ctd_candidate_daily, ctd_daily)。
    """
    if bond_prices.empty or futures.empty or conversion_factors.empty:
        empty_candidate = pd.DataFrame(
            columns=[
                "trade_date", "contract_code", "bond_code", "gross_basis",
                "net_basis", "irr", "irr_funding_gap", "price_type",
                "calculation_status",
            ]
        )
        return empty_candidate, pd.DataFrame()

    bp = bond_prices.copy()
    fp = futures.copy()
    cf = conversion_factors.copy()

    bp["trade_date"] = pd.to_datetime(bp["trade_date"], errors="coerce").dt.normalize()
    fp["trade_date"] = pd.to_datetime(fp["trade_date"], errors="coerce").dt.normalize()
    fp = fp.drop_duplicates(["contract_code", "trade_date"], keep="last")
    cf = cf.drop_duplicates(["contract_code", "bond_code"], keep="last")

    # 合并：合约-债券转换因子 + 现券价格 + 期货结算价
    merged = bp.merge(cf, on="bond_code", how="inner")
    merged = merged.merge(
        fp[["contract_code", "trade_date", "settlement"]],
        on=["contract_code", "trade_date"],
        how="inner",
    )

    rows: list[dict] = []
    for _, row in merged.iterrows():
        bond_code = row["bond_code"]
        contract_code = row["contract_code"]
        trade_date = row["trade_date"]
        cf_val = float(row["conversion_factor"])
        settlement = float(row["settlement"])
        clean_price = float(row["clean_price"])
        dirty_price = float(row["dirty_price"])

        gb = gross_basis(clean_price, settlement, cf_val)

        # 净基差与 IRR 需要交割日与现金流；缺省时标记 DEFERRED
        if delivery_dates is not None and cashflow_schedule is not None:
            delivery_date = _lookup_delivery_date(delivery_dates, contract_code, trade_date)
            if delivery_date is not None:
                accrued_delivery = _accrued_at(
                    cashflow_schedule, bond_code, delivery_date
                )
                inv_price = invoice_price(settlement, cf_val, accrued_delivery)
                days_to_delivery = (delivery_date - trade_date).days
                years_to_delivery = days_to_delivery / 365.0
                funding_cost = dirty_price * funding_rate * years_to_delivery
                coupon_reinvested = _coupon_reinvested(
                    cashflow_schedule, bond_code, trade_date, delivery_date, funding_rate
                )
                nb = net_basis(dirty_price, funding_cost, coupon_reinvested, inv_price)

                # IRR 现金流
                cf_list = _build_irr_cashflows(
                    cashflow_schedule, bond_code, trade_date, delivery_date,
                    dirty_price, inv_price,
                )
                irr = implied_repo_rate(cf_list)
                gap = irr_funding_gap(irr, funding_rate)
                status = price_status(row.get("price_type", PRICE_VALUATION), funding_is_proxy)
            else:
                nb = np.nan
                irr = np.nan
                gap = np.nan
                status = DEFERRED
        else:
            nb = np.nan
            irr = np.nan
            gap = np.nan
            status = DEFERRED

        rows.append(
            {
                "trade_date": trade_date,
                "contract_code": contract_code,
                "bond_code": bond_code,
                "gross_basis": gb,
                "net_basis": nb,
                "irr": irr,
                "irr_funding_gap": gap,
                "price_type": row.get("price_type", PRICE_VALUATION),
                "calculation_status": status,
            }
        )

    candidates = pd.DataFrame(rows)
    # 只对净基差可计算的候选券做 CTD 选择
    ctd_ready = candidates[candidates["net_basis"].notna()]
    ctd = select_ctd(ctd_ready) if not ctd_ready.empty else pd.DataFrame()
    return candidates, ctd


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------
def _lookup_delivery_date(
    delivery_dates: pd.DataFrame, contract_code: str, trade_date: pd.Timestamp
) -> pd.Timestamp | None:
    """查某合约在某交易日的交割日期（当前或未来最近交割月）。"""
    part = delivery_dates[
        delivery_dates["contract_code"].astype(str).eq(str(contract_code))
    ]
    if part.empty:
        return None
    dates = pd.to_datetime(part["delivery_date"], errors="coerce")
    valid = dates[dates.notna()]
    if valid.empty:
        return None
    future = valid[valid >= trade_date]
    if future.empty:
        return None
    return pd.Timestamp(future.min())


def _accrued_at(
    cashflow_schedule: pd.DataFrame, bond_code: str, delivery_date: pd.Timestamp
) -> float:
    """交割日应计利息。

    优先使用现金流表提供的精确应计利息；若只有票息日期和票息金额，
    对规则固定息票按相邻票息日实际天数比例估算。无法确定票息周期时
    返回 0，由上层将结果视为估计口径。
    """
    part = cashflow_schedule[
        cashflow_schedule["bond_code"].astype(str).eq(str(bond_code))
    ]
    if part.empty:
        return 0.0
    dates = pd.to_datetime(part["cashflow_date"], errors="coerce").dt.normalize()
    target = delivery_date.normalize()
    if "accrued_interest" in part.columns:
        matched = part[dates.eq(target)]
        if not matched.empty:
            value = pd.to_numeric(matched["accrued_interest"], errors="coerce").iloc[0]
            if pd.notna(value):
                return float(value)
    coupon_column = next(
        (column for column in ("coupon_cashflow", "coupon_per_100") if column in part.columns),
        None,
    )
    if coupon_column is None:
        return 0.0
    valid = part.loc[dates.notna()].copy()
    valid["_date"] = dates.loc[valid.index]
    valid = valid.sort_values("_date")
    if valid.empty:
        return 0.0
    next_rows = valid.loc[valid["_date"].ge(target)]
    if next_rows.empty:
        return 0.0
    next_row = next_rows.iloc[0]
    next_date = pd.Timestamp(next_row["_date"])
    if next_date == target:
        return 0.0
    following = valid.loc[valid["_date"].gt(next_date)]
    if following.empty:
        return 0.0
    period_days = (pd.Timestamp(following.iloc[0]["_date"]) - next_date).days
    if period_days <= 0:
        return 0.0
    previous_date = next_date - pd.Timedelta(days=period_days)
    elapsed_days = (target - previous_date).days
    coupon = pd.to_numeric(next_row[coupon_column], errors="coerce")
    if pd.isna(coupon):
        return 0.0
    return float(coupon) * max(0.0, min(1.0, elapsed_days / period_days))


def _coupon_reinvested(
    cashflow_schedule: pd.DataFrame,
    bond_code: str,
    trade_date: pd.Timestamp,
    delivery_date: pd.Timestamp,
    funding_rate: float,
) -> float:
    """交割前收到的票息及其再投资收益。"""
    part = cashflow_schedule[
        cashflow_schedule["bond_code"].astype(str).eq(str(bond_code))
    ]
    coupon_column = next(
        (column for column in ("coupon_cashflow", "coupon_per_100") if column in part.columns),
        None,
    )
    if part.empty or coupon_column is None:
        return 0.0
    dates = pd.to_datetime(part["cashflow_date"], errors="coerce").dt.normalize()
    window = part[(dates > trade_date.normalize()) & (dates <= delivery_date.normalize())]
    if window.empty:
        return 0.0
    total = 0.0
    for _, row in window.iterrows():
        coupon_value = pd.to_numeric(row.get(coupon_column), errors="coerce")
        coupon = float(coupon_value) if pd.notna(coupon_value) else 0.0
        days = (delivery_date - pd.Timestamp(row["cashflow_date"]).normalize()).days
        total += coupon * (1.0 + funding_rate * days / 365.0)
    return total


def _build_irr_cashflows(
    cashflow_schedule: pd.DataFrame,
    bond_code: str,
    trade_date: pd.Timestamp,
    delivery_date: pd.Timestamp,
    dirty_price: float,
    invoice_price: float,
) -> list[tuple[float, float]]:
    """构建 IRR 求解所需现金流：估值日负全价、中间票息正、交割日发票价格正。"""
    cashflows: list[tuple[float, float]] = [(0.0, -dirty_price)]
    part = cashflow_schedule[
        cashflow_schedule["bond_code"].astype(str).eq(str(bond_code))
    ]
    coupon_column = next(
        (column for column in ("coupon_cashflow", "coupon_per_100") if column in part.columns),
        None,
    )
    if coupon_column is not None:
        dates = pd.to_datetime(part["cashflow_date"], errors="coerce").dt.normalize()
        window = part[(dates > trade_date.normalize()) & (dates < delivery_date.normalize())]
        for _, row in window.iterrows():
            days = (pd.Timestamp(row["cashflow_date"]).normalize() - trade_date.normalize()).days
            t = days / 365.0
            cashflows.append(
                (t, float(pd.to_numeric(row.get(coupon_column), errors="coerce") or 0.0))
            )
    days = (delivery_date.normalize() - trade_date.normalize()).days
    cashflows.append((days / 365.0, invoice_price))
    return cashflows
