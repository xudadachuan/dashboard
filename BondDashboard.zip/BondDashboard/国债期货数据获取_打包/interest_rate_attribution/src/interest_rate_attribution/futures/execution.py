from __future__ import annotations

"""国债期货交易执行成本计算（第三阶段）。

基于 Level-2 盘口逐档吃单，计算滑点和交易成本。
分钟 K 线（THS_HF）不能替代 Level-2；盘口需来自 THS_SS 或专用行情源。

成本拆分为六项：
- bid_ask_cost       买卖价差成本
- depth_slippage     深度滑点（逐档吃单超出盘口中间价的成本）
- market_impact      市场冲击
- commission         佣金
- exchange_fee       交易所费用
- total_execution_cost 总执行成本

关键规则：
- 盘口不足以完成目标手数时，输出 UNFILLED_QUANTITY，不能假设剩余按第五档成交
- 状态约定：EXACT（真实盘口）/ ESTIMATED（盘口缺失用估值代理）/ DEFERRED
"""

import numpy as np
import pandas as pd

EXACT = "EXACT"
ESTIMATED = "ESTIMATED"
DEFERRED = "DEFERRED"

BUY = "BUY"
SELL = "SELL"


def _price_levels(
    bid_prices: list[float],
    bid_volumes: list[float],
    ask_prices: list[float],
    ask_volumes: list[float],
) -> tuple[list[tuple[float, float]], list[tuple[float, float]]]:
    """整理买卖盘口为 [(价格, 数量), ...] 列表，过滤缺失档位。"""
    bids: list[tuple[float, float]] = []
    asks: list[tuple[float, float]] = []
    for p, v in zip(bid_prices, bid_volumes):
        if p is not None and v is not None and np.isfinite(p) and np.isfinite(v) and v > 0:
            bids.append((float(p), float(v)))
    for p, v in zip(ask_prices, ask_volumes):
        if p is not None and v is not None and np.isfinite(p) and np.isfinite(v) and v > 0:
            asks.append((float(p), float(v)))
    return bids, asks


def walk_book(
    levels: list[tuple[float, float]],
    target_quantity: float,
) -> tuple[float, float, float]:
    """逐档吃单。

    返回 (成交均价, 已成交数量, 未成交数量)。
    levels 按价格从优到劣排序（买方向从卖一开始，卖方向从买一开始）。
    """
    if target_quantity <= 0 or not levels:
        return float("nan"), 0.0, target_quantity

    remaining = target_quantity
    total_value = 0.0
    filled = 0.0
    for price, volume in levels:
        if remaining <= 1e-12:
            break
        take = min(volume, remaining)
        total_value += take * price
        filled += take
        remaining -= take

    if filled > 0:
        avg_price = total_value / filled
    else:
        avg_price = float("nan")
    return avg_price, filled, remaining


def simulate_execution(
    bid_prices: list[float],
    bid_volumes: list[float],
    ask_prices: list[float],
    ask_volumes: list[float],
    direction: str,
    target_lots: float,
    contract_multiplier: float,
    decision_price: float | None = None,
) -> dict[str, float | str]:
    """模拟单笔交易的逐档吃单与滑点。

    参数：
    - direction: BUY（吃卖一至卖五）或 SELL（吃买一至买五）
    - target_lots: 目标手数
    - contract_multiplier: 合约乘数（每点价值，元）
    - decision_price: 决策时刻 mid，缺省时用盘口中间价

    返回字典包含成交均价、滑点、未成交手数等。
    """
    bids, asks = _price_levels(bid_prices, bid_volumes, ask_prices, ask_volumes)

    if not bids or not asks:
        return {
            "avg_price": float("nan"),
            "slippage": float("nan"),
            "unfilled_lots": target_lots,
            "filled_lots": 0.0,
            "decision_price": decision_price if decision_price is not None else float("nan"),
            "status": DEFERRED,
        }

    if decision_price is None:
        decision_price = (bids[0][0] + asks[0][0]) / 2.0

    direction = direction.upper()
    if direction == BUY:
        avg_price, filled, unfilled = walk_book(asks, target_lots)
    elif direction == SELL:
        avg_price, filled, unfilled = walk_book(bids, target_lots)
    else:
        raise ValueError(f"Unknown direction: {direction}")

    if filled <= 0:
        return {
            "avg_price": float("nan"),
            "slippage": float("nan"),
            "unfilled_lots": target_lots,
            "filled_lots": 0.0,
            "decision_price": decision_price,
            "status": DEFERRED,
        }

    # 滑点（金额）= 方向 × (模拟成交均价 - 决策价格) × 乘数 × 手数
    sign = 1.0 if direction == BUY else -1.0
    slippage = sign * (avg_price - decision_price) * contract_multiplier * filled

    return {
        "avg_price": avg_price,
        "slippage": slippage,
        "unfilled_lots": unfilled,
        "filled_lots": filled,
        "decision_price": decision_price,
        # 已成交部分用真实盘口计算，即使部分未成交也保持 EXACT；
        # 未成交数量通过 unfilled_lots 明确输出，不得假设按第五档成交。
        "status": EXACT,
    }


def execution_cost(
    bid_prices: list[float],
    bid_volumes: list[float],
    ask_prices: list[float],
    ask_volumes: list[float],
    direction: str,
    target_lots: float,
    contract_multiplier: float,
    commission_per_lot: float = 0.0,
    exchange_fee_per_lot: float = 0.0,
    decision_price: float | None = None,
) -> dict[str, float | str]:
    """拆解交易成本为六项。

    返回：
    - bid_ask_cost: 买卖价差成本（半价差 × 已成交数量 × 乘数）
    - depth_slippage: 深度滑点（超出半价差的额外滑点）
    - market_impact: 市场冲击（可选，默认 0，需外部模型）
    - commission: 佣金
    - exchange_fee: 交易所费用
    - total_execution_cost: 总执行成本
    - unfilled_quantity: 未成交数量
    """
    bids, asks = _price_levels(bid_prices, bid_volumes, ask_prices, ask_volumes)
    if not bids or not asks:
        return {
            "bid_ask_cost": float("nan"),
            "depth_slippage": float("nan"),
            "market_impact": 0.0,
            "commission": 0.0,
            "exchange_fee": 0.0,
            "total_execution_cost": float("nan"),
            "unfilled_quantity": target_lots,
            "status": DEFERRED,
        }

    mid = (bids[0][0] + asks[0][0]) / 2.0
    decision = decision_price if decision_price is not None else mid

    result = simulate_execution(
        bid_prices, bid_volumes, ask_prices, ask_volumes,
        direction, target_lots, contract_multiplier, decision,
    )
    filled = float(result["filled_lots"])
    direction = direction.upper()
    half_spread = (asks[0][0] - bids[0][0]) / 2.0

    # 买卖价差成本 = 半价差 × 已成交数量 × 乘数
    bid_ask_cost = half_spread * filled * contract_multiplier

    # 深度滑点 = 总滑点 - 买卖价差成本（超出半价差的部分）
    total_slippage = float(result["slippage"]) if np.isfinite(result["slippage"]) else 0.0
    depth_slippage = total_slippage - bid_ask_cost

    commission = commission_per_lot * filled
    exchange_fee = exchange_fee_per_lot * filled
    market_impact = 0.0  # 需外部冲击模型，默认 0

    total = (
        bid_ask_cost + depth_slippage + market_impact + commission + exchange_fee
    )

    return {
        "bid_ask_cost": bid_ask_cost,
        "depth_slippage": depth_slippage,
        "market_impact": market_impact,
        "commission": commission,
        "exchange_fee": exchange_fee,
        "total_execution_cost": total,
        "unfilled_quantity": result["unfilled_lots"],
        "status": result["status"],
    }


def build_execution_cost_table(
    orderbook: pd.DataFrame,
    cost_params: dict,
) -> pd.DataFrame:
    """从盘口快照表批量计算交易成本。

    orderbook 需包含：trade_date, contract_code, direction, target_lots,
    bid1_price..bid5_price, bid1_volume..bid5_volume,
    ask1_price..ask5_price, ask1_volume..ask5_volume
    """
    if orderbook.empty:
        return pd.DataFrame()

    rows: list[dict] = []
    for _, row in orderbook.iterrows():
        bid_prices = [row.get(f"bid{i}_price") for i in range(1, 6)]
        bid_volumes = [row.get(f"bid{i}_volume") for i in range(1, 6)]
        ask_prices = [row.get(f"ask{i}_price") for i in range(1, 6)]
        ask_volumes = [row.get(f"ask{i}_volume") for i in range(1, 6)]

        cost = execution_cost(
            bid_prices=bid_prices,
            bid_volumes=bid_volumes,
            ask_prices=ask_prices,
            ask_volumes=ask_volumes,
            direction=str(row.get("direction", BUY)),
            target_lots=float(row.get("target_lots", 0.0)),
            contract_multiplier=float(cost_params.get("contract_multiplier", 0.0)),
            commission_per_lot=float(cost_params.get("commission_per_lot", 0.0)),
            exchange_fee_per_lot=float(cost_params.get("exchange_fee_per_lot", 0.0)),
            decision_price=(
                float(row["decision_price"]) if pd.notna(row.get("decision_price")) else None
            ),
        )
        cost["trade_date"] = row.get("trade_date")
        cost["contract_code"] = row.get("contract_code")
        cost["direction"] = row.get("direction")
        cost["target_lots"] = row.get("target_lots")
        rows.append(cost)

    return pd.DataFrame(rows)
