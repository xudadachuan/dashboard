from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / "backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

import bond_temperature as bt  # noqa: E402


HERE = Path(__file__).resolve().parent
RAW = HERE / "raw"
OUTPUT = HERE / "output"


def to_rows() -> tuple[list[dict], set[str]]:
    yields = pd.read_csv(RAW / "chinabond_daily_2025_present.csv", encoding="utf-8-sig")
    funding = pd.read_csv(RAW / "funding_daily_2025_present.csv", encoding="utf-8-sig")
    omo = pd.read_csv(RAW / "pboc_omo_daily_2025_present.csv", encoding="utf-8-sig")
    yields["date"] = yields["date"].astype(str)
    funding["date"] = funding["date"].astype(str)
    omo["date"] = omo["date"].astype(str)
    omo = omo.sort_values("date").copy()
    omo["omo_5d_net"] = omo["net"].rolling(5, min_periods=1).sum()

    combined: dict[str, dict] = {}
    for _, item in yields.iterrows():
        row = combined.setdefault(item["date"], {"date": item["date"]})
        t1, t10, t30, c10 = (float(item[key]) for key in ("treasury_1y", "treasury_10y", "treasury_30y", "cdb_10y"))
        row.update(
            {
                "ytm_tbond_10y": t10,
                "ytm_tbond_30y": t30,
                "ytm_cdb_10y": c10,
                "spread_10y_1y": (t10 - t1) * 100,
                "spread_30y_10y": (t30 - t10) * 100,
                "spread_cdb10y_tbond10y": (c10 - t10) * 100,
            }
        )
    for _, item in funding.iterrows():
        combined.setdefault(item["date"], {"date": item["date"]})["dr007"] = float(item["dr007"])
    for _, item in omo.iterrows():
        row = combined.setdefault(item["date"], {"date": item["date"]})
        row["repo_rate_7d"] = float(item["repo_rate_7d"])
        row["omo_5d_net"] = float(item["omo_5d_net"])
    return [combined[key] for key in sorted(combined)], set(yields["date"])


def reconstruct() -> pd.DataFrame:
    source_rows, yield_dates = to_rows()
    rows = bt.forward_fill_rows(source_rows)
    history = {key: [] for key in bt.INDICATORS}
    history_source_dates = {key: set() for key in bt.INDICATORS}
    previous_temperature = None
    records: list[dict] = []
    for row in rows:
        scores: dict[str, float] = {}
        values: dict[str, float] = {}
        source_dates = row.get("_sourceDates") or {}
        for key in bt.INDICATORS:
            value = bt.to_float(row.get(key))
            if value is None:
                continue
            values[key] = value
            score = bt.indicator_score(key, value, history[key])
            if score is not None:
                scores[key] = score
            source_date = source_dates.get(key) or row["date"]
            if source_date not in history_source_dates[key]:
                history[key].append(value)
                history_source_dates[key].add(source_date)

        groups = bt.aggregate_group_scores(scores)
        aggregate = bt.aggregate_temperature(groups, previous_temperature)
        if aggregate:
            previous_temperature = aggregate["bond_temp"]
        if row["date"] not in yield_dates or not aggregate:
            continue
        records.append(
            {
                "date": row["date"],
                "temperature": aggregate["bond_temp"],
                "raw_temperature": aggregate["rawBondTemp"],
                "coverage_weight": aggregate["coverageWeight"],
                "treasury_10y": values.get("ytm_tbond_10y"),
                "rate_temp": groups.get("rate_temp"),
                "funding_temp": groups.get("funding_temp"),
                "curve_temp": groups.get("curve_temp"),
                "funding_available": "funding_temp" in groups,
                "omo_5d_net": values.get("omo_5d_net"),
                "dr007": values.get("dr007"),
                "repo_rate_7d": values.get("repo_rate_7d"),
                "inverse_10y": -values.get("ytm_tbond_10y"),
            }
        )
    return pd.DataFrame(records).sort_values("date").reset_index(drop=True)


def corr(left: pd.Series, right: pd.Series) -> float | None:
    pair = pd.concat([left, right], axis=1).dropna()
    if len(pair) < 10:
        return None
    value = pair.corr().iloc[0, 1]
    return round(float(value), 4) if np.isfinite(value) else None


def horizon(frame: pd.DataFrame, days: int) -> dict:
    future = (frame["treasury_10y"].shift(-days) - frame["treasury_10y"]) * 100
    pair = pd.DataFrame({"temperature": frame["temperature"], "future_bp": future}).dropna()
    low, high = pair["temperature"].quantile([0.25, 0.75])
    bottom = pair.loc[pair["temperature"] <= low, "future_bp"]
    top = pair.loc[pair["temperature"] >= high, "future_bp"]
    return {
        "observations": int(len(pair)),
        "predictor_correlations": {
            "full_temperature": corr(frame["temperature"], future),
            "rate_temp": corr(frame["rate_temp"], future),
            "funding_temp": corr(frame["funding_temp"], future),
            "curve_temp": corr(frame["curve_temp"], future),
            "negative_10y_baseline": corr(frame["inverse_10y"], future),
        },
        "bottom_quartile_future_bp": round(float(bottom.mean()), 3),
        "top_quartile_future_bp": round(float(top.mean()), 3),
        "top_minus_bottom_bp": round(float(top.mean() - bottom.mean()), 3),
        "bottom_quartile_yield_fall_hit_rate": round(float((bottom < 0).mean()), 4),
        "top_quartile_yield_rise_hit_rate": round(float((top > 0).mean()), 4),
    }


def evaluate(frame: pd.DataFrame) -> dict:
    metrics = {
        "scope": "Full production temperature reconstruction with rate, funding and curve groups; missing trading group is neutral under the production rule.",
        "observations": int(len(frame)),
        "start_date": frame["date"].iloc[0],
        "end_date": frame["date"].iloc[-1],
        "coverage_weight_distribution": {str(key): value for key, value in sorted(Counter(frame["coverage_weight"]).items())},
        "funding_group_available_share": round(float(frame["funding_available"].mean()), 4),
        "temperature_range": [round(float(frame["temperature"].min()), 2), round(float(frame["temperature"].max()), 2)],
        "contemporaneous_change_correlation": corr(frame["temperature"].diff(), frame["treasury_10y"].diff()),
        "full_sample": {str(days): horizon(frame, days) for days in (1, 5, 10, 20)},
        "by_year": {},
    }
    for year, subset in frame.groupby(pd.to_datetime(frame["date"]).dt.year):
        subset = subset.reset_index(drop=True)
        metrics["by_year"][str(year)] = {str(days): horizon(subset, days) for days in (1, 5, 10, 20)}
    return metrics


def plot(frame: pd.DataFrame, output: Path) -> None:
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    dates = pd.to_datetime(frame["date"])
    fig, temp_axis = plt.subplots(figsize=(13.2, 6.8), dpi=160)
    temp_axis.plot(dates, frame["temperature"], color="#c8523b", linewidth=1.9, label="完整市场温度")
    temp_axis.set_ylabel("市场温度（0–100）")
    temp_axis.grid(axis="y", color="#d8dde3", linewidth=0.7)
    yield_axis = temp_axis.twinx()
    yield_axis.plot(dates, frame["treasury_10y"], color="#1f5a75", linewidth=1.6, label="10年国债收益率")
    yield_axis.set_ylabel("10年国债收益率（%）")
    yield_axis.invert_yaxis()
    h1, l1 = temp_axis.get_legend_handles_labels()
    h2, l2 = yield_axis.get_legend_handles_labels()
    temp_axis.legend(h1 + h2, l1 + l2, loc="upper left", frameon=False)
    temp_axis.set_title("2025年以来：完整市场温度与10年国债收益率", loc="left", fontsize=14, fontweight="bold")
    temp_axis.set_xlabel("日期")
    fig.tight_layout()
    fig.savefig(output, facecolor="white", bbox_inches="tight")
    plt.close(fig)


def main() -> int:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    frame = reconstruct()
    if frame.empty:
        raise RuntimeError("No full-temperature observations were reconstructed")
    frame.to_csv(OUTPUT / "full_temperature_2025_present_scored.csv", index=False, encoding="utf-8-sig")
    metrics = evaluate(frame)
    (OUTPUT / "full_temperature_2025_present_metrics.json").write_text(
        json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    plot(frame, OUTPUT / "full_temperature_2025_present_vs_10y.png")
    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
