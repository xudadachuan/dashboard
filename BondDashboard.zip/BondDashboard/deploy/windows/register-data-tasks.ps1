[CmdletBinding()]
param(
    [string]$AppRoot = "C:\BondDashboard",
    [string]$PythonExe = "C:\Program Files\Python313\python.exe"
)

$ErrorActionPreference = "Stop"

$tasks = @(
    @{ Name = "BondDashboard_PBOC_OMO_Update"; Script = "update_runner.py"; Time = "09:35" },
    @{ Name = "BondDashboard_Market_Data_Update"; Script = "funding_update_runner.py"; Time = "17:00" },
    @{ Name = "BondDashboard_AI_Summary_Update"; Script = "ai_update_runner.py"; Time = "18:01" },
    @{ Name = "BondDashboard_ETF_Data_Update"; Script = "etf_update_runner.py"; Time = "21:00" }
)

$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew -RestartCount 8 -RestartInterval (New-TimeSpan -Minutes 15) -ExecutionTimeLimit (New-TimeSpan -Hours 2)
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

foreach ($task in $tasks) {
    $scriptPath = Join-Path $AppRoot "backend\$($task.Script)"
    if (-not (Test-Path -LiteralPath $scriptPath)) {
        throw "缺少更新脚本：$scriptPath"
    }
    if (-not (Test-Path -LiteralPath $PythonExe)) {
        throw "Python executable was not found: $PythonExe"
    }
    $action = New-ScheduledTaskAction -Execute $PythonExe -Argument "`"$scriptPath`"" -WorkingDirectory (Join-Path $AppRoot "backend")
    $trigger = New-ScheduledTaskTrigger -Daily -At ([datetime]::ParseExact($task.Time, "HH:mm", $null))
    Register-ScheduledTask -TaskName $task.Name -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Description "Bond dashboard automatic update: $($task.Script)" -Force | Out-Null
}
