from __future__ import annotations

"""账户期货持仓与成交明细导入（第四阶段）。

账户真实持仓和成交无法从公开行情接口获得，必须作为独立的
OMS、券商柜台或估值系统输入导入，而非默认由 iFinDPy 获取。

两张核心表：
- account_futures_position_daily.csv   日终持仓
- account_futures_trade_detail.csv     逐笔成交明细

真实调仓手数由成交明细计算，不能只用「今日持仓 - 昨日持仓」，
因为换月、移仓、平今平昨、账户划转和手工交易都会使持仓差分失真。
持仓差分仅用于与成交明细做日终核对。
"""

from dataclasses import dataclass
from pathlib import Path

import pandas as pd

# 持仓表字段
POSITION_COLUMNS = [
    "account_id",
    "portfolio_id",
    "valuation_date",
    "contract_code",
    "long_short",
    "position_lots",
    "available_lots",
    "average_cost",
    "margin",
]

# 成交明细字段
TRADE_COLUMNS = [
    "order_id",
    "trade_id",
    "contract_code",
    "trade_time",
    "buy_sell",
    "open_close",
    "fill_price",
    "fill_lots",
    "commission",
    "strategy_id",
]


@dataclass
class TradeDirection:
    """买卖与开平仓组合后的符号。"""

    buy_sell: str
    open_close: str

    def signed_multiplier(self) -> float:
        """返回该笔成交对持仓的符号贡献。

        买入开仓 +1，卖出平仓 +1（减少空头），卖出开仓 -1，买入平仓 -1（减少多头）。
        """
        bs = self.buy_sell.upper()
        oc = self.open_close.upper()
        buy = bs in ("BUY", "买入", "B")
        sell = bs in ("SELL", "卖出", "S")
        open_pos = oc in ("OPEN", "开仓", "开")
        close_pos = oc in ("CLOSE", "平仓", "平")

        if buy and open_pos:
            return 1.0
        if sell and open_pos:
            return -1.0
        if sell and close_pos:
            # 卖出平仓 = 减少多头 = -1；若为平空头则为 +1，
            # 这里按多空方向统一处理：符号由调用方结合 long_short 决定。
            return -1.0
        if buy and close_pos:
            return 1.0
        raise ValueError(f"未知买卖/开平组合: buy_sell={self.buy_sell}, open_close={self.open_close}")


def empty_position_table() -> pd.DataFrame:
    return pd.DataFrame(columns=POSITION_COLUMNS)


def empty_trade_table() -> pd.DataFrame:
    return pd.DataFrame(columns=TRADE_COLUMNS)


def load_position_table(path: Path | str) -> pd.DataFrame:
    frame = pd.read_csv(path)
    if "valuation_date" in frame.columns:
        frame["valuation_date"] = pd.to_datetime(frame["valuation_date"], errors="coerce")
    return frame


def load_trade_table(path: Path | str) -> pd.DataFrame:
    frame = pd.read_csv(path)
    if "trade_time" in frame.columns:
        frame["trade_time"] = pd.to_datetime(frame["trade_time"], errors="coerce")
    return frame


def calculate_signed_lots(trades: pd.DataFrame) -> pd.DataFrame:
    """从成交明细计算每只合约的真实调仓手数（带符号）。

    signed_lots = 买入开仓 + 卖出平仓 - 卖出开仓 - 买入平仓

    对每只合约分别按 (contract_code, trade_date) 聚合。
    """
    if trades.empty:
        return pd.DataFrame(
            columns=["contract_code", "trade_date", "signed_lots", "buy_open", "sell_open", "buy_close", "sell_close"]
        )

    frame = trades.copy()
    if "trade_time" in frame.columns:
        frame["trade_date"] = pd.to_datetime(frame["trade_time"], errors="coerce").dt.normalize()
    elif "trade_date" not in frame.columns:
        raise ValueError("trade detail requires trade_time or trade_date")

    buy = frame["buy_sell"].astype(str).str.upper().isin(("BUY", "买入", "B"))
    sell = frame["buy_sell"].astype(str).str.upper().isin(("SELL", "卖出", "S"))
    open_pos = frame["open_close"].astype(str).str.upper().isin(("OPEN", "开仓", "开"))
    close_pos = frame["open_close"].astype(str).str.upper().isin(("CLOSE", "平仓", "平"))

    lots = pd.to_numeric(frame["fill_lots"], errors="coerce").fillna(0.0)

    frame["_buy_open"] = (buy & open_pos).astype(float) * lots
    frame["_sell_open"] = (sell & open_pos).astype(float) * lots
    frame["_buy_close"] = (buy & close_pos).astype(float) * lots
    frame["_sell_close"] = (sell & close_pos).astype(float) * lots

    group = frame.groupby(["contract_code", "trade_date"], as_index=False).agg(
        buy_open=("_buy_open", "sum"),
        sell_open=("_sell_open", "sum"),
        buy_close=("_buy_close", "sum"),
        sell_close=("_sell_close", "sum"),
    )
    # signed_lots = 买入开仓 + 卖出平仓 - 卖出开仓 - 买入平仓
    group["signed_lots"] = (
        group["buy_open"] + group["sell_close"] - group["sell_open"] - group["buy_close"]
    )
    return group[
        ["contract_code", "trade_date", "signed_lots", "buy_open", "sell_open", "buy_close", "sell_close"]
    ]


def reconcile_position_diff(
    positions: pd.DataFrame,
    signed_lots: pd.DataFrame,
) -> pd.DataFrame:
    """日终核对：持仓差分 vs 成交明细推导的调仓手数。

    持仓差分 = 今日持仓 - 昨日持仓（按多空方向展开）。
    二者不一致时说明存在换月、移仓、平今平昨、划转或手工交易，
    必须标记 DISCREPANCY 而非静默用差分覆盖成交明细。
    """
    if positions.empty or signed_lots.empty:
        return pd.DataFrame()

    pos = positions.copy()
    pos["valuation_date"] = pd.to_datetime(pos["valuation_date"], errors="coerce").dt.normalize()

    # 多空方向符号：多头 +，空头 -
    pos["_signed_position"] = pos.apply(
        lambda r: (
            float(r["position_lots"])
            if str(r["long_short"]).upper() in ("LONG", "多头", "多")
            else -float(r["position_lots"])
        ),
        axis=1,
    )

    pos = pos.sort_values("valuation_date")
    # 按账户+合约+多空方向分别计算持仓差分，避免多空头寸互相抵消
    pos["_prev_signed"] = pos.groupby(
        ["contract_code", "account_id", "long_short"]
    )["_signed_position"].shift(1)
    pos["_position_diff"] = pos["_signed_position"] - pos["_prev_signed"]

    merged = pos.merge(
        signed_lots[["contract_code", "trade_date", "signed_lots"]],
        left_on=["contract_code", "valuation_date"],
        right_on=["contract_code", "trade_date"],
        how="left",
    )

    tolerance = 1e-6
    # 持仓差分是带符号净变化，与 signed_lots 语义一致；NaN 表示首日或缺失前值
    merged["discrepancy"] = (
        (merged["_position_diff"].fillna(0.0) - merged["signed_lots"].fillna(0.0)).abs() > tolerance
    )
    merged["reconcile_status"] = merged["discrepancy"].map(
        {True: "DISCREPANCY", False: "MATCH"}
    )

    return merged[
        [
            "account_id", "contract_code", "long_short", "valuation_date",
            "_position_diff", "signed_lots", "reconcile_status",
        ]
    ].rename(columns={"_position_diff": "position_diff"})


def validate_position_trade_tables(
    positions: pd.DataFrame,
    trades: pd.DataFrame,
) -> list[str]:
    """校验持仓和成交表完整性。"""
    problems: list[str] = []
    required_pos = {"account_id", "portfolio_id", "valuation_date", "contract_code", "long_short", "position_lots"}
    required_trade = {"trade_id", "contract_code", "trade_time", "buy_sell", "open_close", "fill_lots"}

    missing_pos = required_pos - set(positions.columns)
    missing_trade = required_trade - set(trades.columns)
    if missing_pos:
        problems.append(f"持仓表缺少列: {sorted(missing_pos)}")
    if missing_trade:
        problems.append(f"成交表缺少列: {sorted(missing_trade)}")

    if not trades.empty and "trade_id" in trades.columns:
        if trades["trade_id"].duplicated().any():
            problems.append("成交明细存在重复 trade_id")

    return problems
