(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.InterbankCdUi = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  function weightedValuationYield(termBuckets) {
    const valid = (Array.isArray(termBuckets) ? termBuckets : [])
      .map(item => ({ amount: Number(item.amount100m), yieldValue: Number(item.valuationYield) }))
      .filter(item => Number.isFinite(item.amount) && item.amount > 0 && Number.isFinite(item.yieldValue));
    if (!valid.length) return null;
    const totalAmount = valid.reduce((sum, item) => sum + item.amount, 0);
    return valid.reduce((sum, item) => sum + item.amount * item.yieldValue, 0) / totalAmount;
  }

  return { weightedValuationYield };
});
