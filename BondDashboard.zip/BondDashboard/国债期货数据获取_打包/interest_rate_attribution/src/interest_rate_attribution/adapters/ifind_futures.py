from __future__ import annotations

"""国债期货 iFinD 适配器。

第一阶段能力：
- 合约列表（THS_DP 板块成分）
- 合约静态资料（THS_BD）
- 日行情（THS_HQ）
- 接口探针（记录真实字段、错误码、单位、数据量）

字段名不硬编码在代码中，全部从 ``config/ifind_futures_fields.yml`` 读取；
探针确认前所有在线请求输出 ``DEFERRED`` 状态，避免把候选字段当正式字段。

计算状态约定（全项目统一）：
- EXACT      真实可成交/成交/盘口价格与真实融资成本
- ESTIMATED  估值价或代理融资利率，仅近似
- DEFERRED   缺少必要数据，暂缓计算
"""

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd


# ---------------------------------------------------------------------------
# 状态与价格类型常量
# ---------------------------------------------------------------------------
EXACT = "EXACT"
ESTIMATED = "ESTIMATED"
DEFERRED = "DEFERRED"

PRICE_EXECUTABLE_BID = "EXECUTABLE_BID"
PRICE_EXECUTABLE_ASK = "EXECUTABLE_ASK"
PRICE_TRADE = "TRADE_PRICE"
PRICE_MID = "MARKET_MID"
PRICE_VALUATION = "VALUATION_PRICE"
PRICE_CLOSE_PROXY = "CLOSE_PROXY"

PRODUCTS = ("TS", "TF", "T", "TL")


@dataclass
class ProbeRecord:
    """单次接口探针的审计记录。"""

    interface: str
    product: str
    field: str
    status: str
    errorcode: int
    errmsg: str
    return_columns: str
    unit: str
    row_count: int
    requires_auth: bool
    probed_at: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "interface": self.interface,
            "product": self.product,
            "field": self.field,
            "status": self.status,
            "errorcode": self.errorcode,
            "errmsg": self.errmsg,
            "return_columns": self.return_columns,
            "unit": self.unit,
            "row_count": self.row_count,
            "requires_auth": self.requires_auth,
            "probed_at": self.probed_at,
        }


def _now() -> str:
    return datetime.now(tz=None).isoformat(timespec="seconds")


class IFindFuturesClient:
    """对 iFinDPy 的轻量封装，聚焦国债期货三类请求。

    与 ``ifind.py`` 中的 ``IFindPyClient`` 保持一致风格：不缓存字段语义，
    只负责登录、调用、把结果规整为 DataFrame，并保存原始响应与错误码。
    """

    def __init__(self, raw_cache_dir: Path | None = None) -> None:
        try:
            import iFinDPy  # type: ignore
        except ModuleNotFoundError as exc:
            raise ModuleNotFoundError("iFinDPy is required for treasury futures") from exc

        import os

        user = os.getenv("IFIND_USER")
        key = os.getenv("IFIND_KEY")
        if not user or not key:
            raise ValueError("Set IFIND_USER and IFIND_KEY before online acquisition")
        login_result = iFinDPy.THS_iFinDLogin(user, key)
        if login_result not in (0, -201):
            raise RuntimeError(f"iFinD login failed with code {login_result}")
        self.api = iFinDPy
        self.raw_cache_dir = Path(raw_cache_dir) if raw_cache_dir is not None else None
        self.probe_records: list[ProbeRecord] = []

    def _to_frame(self, result: Any) -> pd.DataFrame:
        """把 iFinD 返回统一转为 DataFrame，记录错误码。"""
        if isinstance(result, pd.DataFrame):
            return result.copy()
        error_code = int(getattr(result, "errorcode", 0) or 0)
        errmsg = str(getattr(result, "errmsg", "") or "")
        data = getattr(result, "data", result)
        if isinstance(data, pd.DataFrame):
            return data.copy()
        return pd.DataFrame(data)

    def call_dp(
        self, block: str, query_date: str, block_id: str, fields: str
    ) -> pd.DataFrame:
        """THS_DP 板块成分。"""
        params = f"{query_date};{block_id}"
        frame = self._to_frame(self.api.THS_DP(block, params, fields))
        self._cache_raw("THS_DP", f"{block}_{query_date}", frame)
        return frame

    def call_bd(self, codes: list[str], fields: str, params: str) -> pd.DataFrame:
        """THS_BD 合约静态资料。"""
        frame = self._to_frame(self.api.THS_BD(",".join(codes), fields, params))
        self._cache_raw("THS_BD", "_".join(codes)[:80], frame)
        return frame

    def call_hq(
        self, codes: list[str], fields: str, params: str, start: str, end: str
    ) -> pd.DataFrame:
        """THS_HQ 日行情。"""
        frame = self._to_frame(
            self.api.THS_HQ(",".join(codes), fields, params, "", start, end)
        )
        self._cache_raw("THS_HQ", f"{start}_{end}", frame)
        return frame

    def _cache_raw(self, interface: str, key: str, frame: pd.DataFrame) -> None:
        if self.raw_cache_dir is None:
            return
        self.raw_cache_dir.mkdir(parents=True, exist_ok=True)
        safe = "".join(c if c.isalnum() else "_" for c in key)
        target = self.raw_cache_dir / f"{interface}_{safe}_{_now().replace(':', '')}.csv"
        frame.to_csv(target, index=False, encoding="utf-8-sig")

    def close(self) -> None:
        try:
            self.api.THS_iFinDLogout()
        except Exception:
            pass


def resolve_vendor_field(
    config: dict[str, Any], section: str, logical: str
) -> tuple[str, bool]:
    """从 YAML 配置读取某逻辑字段对应的 vendor 字段及其探针状态。

    返回 (vendor_field, verified)。verified=False 时上层必须标记 DEFERRED。
    """
    fields = (config.get(section) or {}).get(logical) or {}
    vendor = str(fields.get("vendor_field") or "")
    verified = bool(fields.get("verified"))
    return vendor, verified


def build_field_string(
    config: dict[str, Any], section: str, logical_fields: list[str]
) -> tuple[str, bool]:
    """把一组逻辑字段拼成 iFinD 字段串，返回 (fields_str, all_verified)。"""
    vendors: list[str] = []
    all_verified = True
    for logical in logical_fields:
        vendor, verified = resolve_vendor_field(config, section, logical)
        if not vendor:
            all_verified = False
            continue
        vendors.append(vendor)
        all_verified = all_verified and verified
    return ";".join(vendors), all_verified


class TreasuryFuturesAdapter:
    """把 iFinD 期货数据转换为厂商中立的标准表。"""

    def __init__(self, config: dict[str, Any], client: Any | None = None) -> None:
        self.config = config
        self.client = client

    # -- 合约列表 ---------------------------------------------------------
    def fetch_contract_list(self, as_of_date: str) -> tuple[pd.DataFrame, str]:
        """返回 (contract_master, calculation_status)。"""
        block_id = str(
            (self.config.get("block") or {}).get("treasury_futures_block_id") or ""
        )
        if not block_id:
            # 未探针确认板块 ID，标记 DEFERRED 并返回空表结构。
            return _empty_contract_master(), DEFERRED
        fields = "date:Y,thscode:Y,security_name:Y"
        try:
            frame = self.client.call_dp("block", as_of_date, block_id, fields)
        except Exception as exc:  # noqa: BLE001
            self._record_probe("THS_DP", "", "", DEFERRED, 1, str(exc), 0)
            return _empty_contract_master(), DEFERRED
        if frame.empty:
            return _empty_contract_master(), DEFERRED
        return _normalize_contract_list(frame), EXACT

    # -- 合约静态资料 -----------------------------------------------------
    def fetch_contract_static(self, codes: list[str]) -> tuple[pd.DataFrame, str]:
        section = "contract_static_fields"
        logical_fields = [
            "contract_code", "contract_name", "product_code", "listing_date",
            "last_trading_date", "delivery_month", "delivery_date",
            "contract_notional", "price_multiplier", "tick_size", "contract_status",
        ]
        fields_str, all_verified = build_field_string(self.config, section, logical_fields)
        if not fields_str:
            return _empty_contract_static(), DEFERRED
        try:
            frame = self.client.call_bd(codes, fields_str, ";".join([""] * len(logical_fields)))
        except Exception as exc:  # noqa: BLE001
            self._record_probe("THS_BD", "", "", DEFERRED, 1, str(exc), 0)
            return _empty_contract_static(), DEFERRED
        status = EXACT if all_verified else ESTIMATED
        if not all_verified:
            status = DEFERRED
        return frame, status

    # -- 日行情 -----------------------------------------------------------
    def fetch_daily_quotes(
        self, codes: list[str], start: str, end: str
    ) -> tuple[pd.DataFrame, str]:
        """获取日行情。结算价缺失时回退收盘价并标记 ESTIMATED。"""
        section = "daily_quote_fields"
        logical_fields = [
            "open", "high", "low", "close", "settlement", "pre_settlement",
            "volume", "amount", "open_interest", "limit_up", "limit_down",
            "trade_date",
        ]
        fields_str, all_verified = build_field_string(self.config, section, logical_fields)
        if not fields_str:
            return _empty_daily_quotes(), DEFERRED
        try:
            frame = self.client.call_hq(
                codes, fields_str, ";".join([""] * len(logical_fields)), start, end
            )
        except Exception as exc:  # noqa: BLE001
            self._record_probe("THS_HQ", "", "", DEFERRED, 1, str(exc), 0)
            return _empty_daily_quotes(), DEFERRED

        if frame.empty:
            return _empty_daily_quotes(), DEFERRED

        # 结算价缺失时的处理：回退收盘价，但必须显式标记，不能静默替换。
        used_close_proxy = False
        if "settlement" in frame.columns:
            settlement = pd.to_numeric(frame["settlement"], errors="coerce")
            missing = settlement.isna()
            if missing.any() and "close" in frame.columns:
                close = pd.to_numeric(frame["close"], errors="coerce")
                frame.loc[missing, "settlement"] = close[missing]
                used_close_proxy = True

        frame["price_type"] = (
            PRICE_CLOSE_PROXY if used_close_proxy else PRICE_VALUATION
        )
        # 结算价为交易所公布值，属于真实数据；仅当用了收盘价代理时降级。
        frame["calculation_status"] = (
            ESTIMATED if used_close_proxy else EXACT
        )
        if not all_verified:
            frame["calculation_status"] = DEFERRED
        return frame, (DEFERRED if not all_verified else frame["calculation_status"].iloc[0] if not frame.empty else DEFERRED)

    # -- 探针 -------------------------------------------------------------
    def probe(self, product: str, trade_date: str) -> list[ProbeRecord]:
        """对单个合约、单个交易日做接口探针，不落正式表。"""
        # 第一阶段探针仅覆盖已实现接口：THS_DP / THS_BD / THS_HQ。
        # THS_HF / THS_RQ / THS_SS 属于后续阶段，先记录为 DEFERRED。
        records: list[ProbeRecord] = []
        contract = _candidate_contract_codes(product, trade_date)[0]

        for interface, action in (
            ("THS_DP", self._probe_dp),
            ("THS_BD", lambda: self._probe_bd(product, contract)),
            ("THS_HQ", lambda: self._probe_hq(product, contract, trade_date)),
        ):
            try:
                record = action()
            except Exception as exc:  # noqa: BLE001
                record = ProbeRecord(
                    interface=interface, product=product, field="",
                    status=DEFERRED, errorcode=1, errmsg=str(exc),
                    return_columns="", unit="", row_count=0,
                    requires_auth=False, probed_at=_now(),
                )
            records.append(record)
            self.client.probe_records.append(record)

        # 尚未实现的接口
        for interface in ("THS_HF", "THS_RQ", "THS_SS"):
            record = ProbeRecord(
                interface=interface, product=product, field="",
                status=DEFERRED, errorcode=0,
                errmsg="not implemented in phase 1", return_columns="",
                unit="", row_count=0, requires_auth=True, probed_at=_now(),
            )
            records.append(record)
            self.client.probe_records.append(record)
        return records

    def _probe_dp(self) -> ProbeRecord:
        block_id = str((self.config.get("block") or {}).get("treasury_futures_block_id") or "")
        frame = self.client.call_dp("block", "2026-01-02", block_id, "date:Y,thscode:Y,security_name:Y")
        return ProbeRecord(
            interface="THS_DP", product="ALL", field="block",
            status=EXACT if not frame.empty else DEFERRED, errorcode=0,
            errmsg="", return_columns=",".join(map(str, frame.columns)),
            unit="", row_count=len(frame), requires_auth=False, probed_at=_now(),
        )

    def _probe_bd(self, product: str, contract: str) -> ProbeRecord:
        fields_str, verified = build_field_string(
            self.config, "contract_static_fields",
            ["contract_code", "contract_name", "contract_notional"],
        )
        frame = self.client.call_bd([contract], fields_str, ";".join([""] * 3))
        return ProbeRecord(
            interface="THS_BD", product=product, field="contract_static",
            status=EXACT if verified and not frame.empty else DEFERRED, errorcode=0,
            errmsg="", return_columns=",".join(map(str, frame.columns)),
            unit="", row_count=len(frame), requires_auth=False, probed_at=_now(),
        )

    def _probe_hq(self, product: str, contract: str, trade_date: str) -> ProbeRecord:
        fields_str, verified = build_field_string(
            self.config, "daily_quote_fields",
            ["open", "high", "low", "close", "settlement", "volume", "open_interest"],
        )
        frame = self.client.call_hq(
            [contract], fields_str, ";".join([""] * 7), trade_date, trade_date
        )
        return ProbeRecord(
            interface="THS_HQ", product=product, field="daily_quote",
            status=EXACT if verified and not frame.empty else DEFERRED, errorcode=0,
            errmsg="", return_columns=",".join(map(str, frame.columns)),
            unit="", row_count=len(frame), requires_auth=False, probed_at=_now(),
        )

    def _record_probe(
        self, interface: str, product: str, field: str, status: str,
        errorcode: int, errmsg: str, row_count: int,
    ) -> None:
        self.client.probe_records.append(
            ProbeRecord(
                interface=interface, product=product, field=field, status=status,
                errorcode=errorcode, errmsg=errmsg, return_columns="", unit="",
                row_count=row_count, requires_auth=False, probed_at=_now(),
            )
        )


# ---------------------------------------------------------------------------
# 合约代码候选生成（字符串规则仅作备用，必须经 THS_BD 验证）
# ---------------------------------------------------------------------------
def _candidate_contract_codes(product: str, as_of_date: str) -> list[str]:
    """按季度月份生成候选合约代码，例如 T2609.CFE、T2612.CFE。

    仅作备用：真实合约必须通过 THS_DP/THS_BD 验证，不能只靠字符串规则。
    """
    year = int(as_of_date[:4])
    codes: list[str] = []
    for y in (year, year + 1):
        for month in ("03", "06", "09", "12"):
            codes.append(f"{product}{str(y)[-2:]}{month}.CFE")
    return codes


# ---------------------------------------------------------------------------
# 空表结构
# ---------------------------------------------------------------------------
def _empty_contract_master() -> pd.DataFrame:
    return pd.DataFrame(
        columns=[
            "thscode", "security_name", "product_code", "contract_code",
            "contract_name", "listing_date", "last_trading_date",
            "delivery_month", "delivery_date", "contract_notional",
            "price_multiplier", "tick_size", "contract_status",
        ]
    )


def _empty_contract_static() -> pd.DataFrame:
    return pd.DataFrame(
        columns=[
            "contract_code", "contract_name", "product_code", "listing_date",
            "last_trading_date", "delivery_month", "delivery_date",
            "contract_notional", "price_multiplier", "tick_size", "contract_status",
        ]
    )


def _empty_daily_quotes() -> pd.DataFrame:
    return pd.DataFrame(
        columns=[
            "trade_date", "contract_code", "open", "high", "low", "close",
            "settlement", "pre_settlement", "volume", "amount", "open_interest",
            "limit_up", "limit_down", "price_type", "calculation_status",
        ]
    )


def _normalize_contract_list(frame: pd.DataFrame) -> pd.DataFrame:
    out = frame.copy()
    if "thscode" in out.columns:
        out["contract_code"] = out["thscode"].astype(str).str.strip()
    if "security_name" in out.columns:
        out["contract_name"] = out["security_name"].astype(str).str.strip()
    return out
