@echo off
setlocal
title Bond Dashboard - Generate AI Summary
cd /d "%~dp0"

if not exist "logs" mkdir "logs"
set "LOG=%CD%\logs\ai_summary_update.log"

echo.
echo ========================================
echo  Bond Dashboard - Generate AI Summary
echo ========================================
echo.

if not defined PYTHON_EXE set "PYTHON_EXE=C:\Program Files\Python313\python.exe"
if not exist "%PYTHON_EXE%" set "PYTHON_EXE=python"
where "%PYTHON_EXE%" >nul 2>nul
if errorlevel 1 if not exist "%PYTHON_EXE%" (
  echo [ERROR] python was not found in PATH.
  set "EXIT_CODE=1"
  goto finish
)

if "%DEEPSEEK_API_KEY%"=="" if not "%YOUR_API_KEY%"=="" (
  set "DEEPSEEK_API_KEY=%YOUR_API_KEY%"
)

if "%DEEPSEEK_API_KEY%"=="" (
  echo [WARN] DEEPSEEK_API_KEY is not set in this window.
  echo The Python script will load .env if available, otherwise it will keep existing summary or write fallback.
)

echo ==== %date% %time% ====>> "%LOG%"
"%PYTHON_EXE%" generate_ai_summary.py 1>> "%LOG%" 2>>&1
if errorlevel 1 (
  echo.
  echo [ERROR] AI summary generation failed. See logs\ai_summary_update.log
  set "EXIT_CODE=1"
  goto finish
)

"%PYTHON_EXE%" market_commentary.py --daily 1>> "%LOG%" 2>>&1
if errorlevel 1 (
  echo.
  echo [ERROR] Market commentary generation failed. See logs\ai_summary_update.log
  set "EXIT_CODE=1"
  goto finish
)

echo.
echo AI summary updated: data\ai_summary.json
echo Market commentary updated: data\market_commentary.json
echo Market snapshot updated: data\market_snapshot.json

:finish
echo.
if "%BOND_DASHBOARD_PAUSE%"=="1" (
  echo Press any key to close this window...
  pause >nul
)
if defined EXIT_CODE exit /b %EXIT_CODE%
exit /b 0
