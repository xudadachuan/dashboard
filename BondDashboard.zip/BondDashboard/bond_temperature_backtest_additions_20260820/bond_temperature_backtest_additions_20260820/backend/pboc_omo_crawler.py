from __future__ import annotations

import argparse
import json
import re
import sqlite3
import time
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from html import unescape
from html.parser import HTMLParser
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT.parent / "data"
DB_PATH = DATA_DIR / "bond_market.db"
CALENDAR_FILE = DATA_DIR / "interbank_calendar.json"

PBC_OMO_LIST_URL = "https://www.pbc.gov.cn/zhengcehuobisi/125207/125213/125431/125475/index.html"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BondDashboard/1.0"


@dataclass
class ArticleLink:
    title: str
    url: str
    publish_date: str | None = None


class LinkParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.links: list[tuple[str, str]] = []
        self._href: str | None = None
        self._text: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() == "a":
            self._href = dict(attrs).get("href")
            self._text = []

    def handle_data(self, data: str) -> None:
        if self._href:
            self._text.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "a" and self._href:
            text = normalize_text("".join(self._text))
            if text:
                self.links.append((text, self._href))
            self._href = None
            self._text = []


def normalize_text(text: str) -> str:
    text = unescape(text).replace("\ufeff", " ")
    text = re.sub(r"<script[\s\S]*?</script>", " ", text, flags=re.I)
    text = re.sub(r"<style[\s\S]*?</style>", " ", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = text.replace("\u3000", " ")
    return re.sub(r"\s+", " ", text).strip()


def fetch_bytes(url: str, timeout: int = 30) -> bytes:
    request = Request(url, headers={"User-Agent": USER_AGENT})
    with urlopen(request, timeout=timeout) as response:
        return response.read()


def fetch_text(url: str, timeout: int = 30) -> str:
    content = fetch_bytes(url, timeout=timeout)
    for encoding in ("utf-8", "gb18030", "gbk"):
        try:
            return content.decode(encoding)
        except UnicodeDecodeError:
            continue
    return content.decode("utf-8", errors="ignore")


def list_page_url(page_no: int) -> str:
    if page_no <= 1:
        return PBC_OMO_LIST_URL
    # The PBC column uses its page-module id in archive URLs.  The former
    # ``index1.html`` convention returns 404 and silently limited backfills to
    # the first page (roughly 20 announcements).
    return urljoin(PBC_OMO_LIST_URL, f"17081-{page_no}.html")


def extract_trade_links(pages: int = 1, limit: int = 120, pause_seconds: float = 0.2) -> list[ArticleLink]:
    links: list[ArticleLink] = []
    seen: set[str] = set()

    for page_no in range(1, pages + 1):
        page_url = list_page_url(page_no)
        try:
            html = fetch_text(page_url)
        except HTTPError as exc:
            if exc.code == 404:
                break
            raise
        parser = LinkParser()
        parser.feed(html)

        for title, href in parser.links:
            if "公开市场业务交易公告" not in title:
                continue
            if not re.search(r"[\[［]\d{4}[\]］]第\d+号", title):
                continue
            url = urljoin(page_url, href)
            if url in seen:
                continue
            seen.add(url)
            links.append(ArticleLink(title=title, url=url))
            if len(links) >= limit:
                return links

        time.sleep(pause_seconds)

    return links


def chinese_date_to_iso(text: str) -> str | None:
    match = re.search(r"(\d{4})年(\d{1,2})月(\d{1,2})日", text)
    if not match:
        match = re.search(r"\b(20\d{2})-(\d{1,2})-(\d{1,2})\b", text)
    if not match:
        return None
    y, m, d = map(int, match.groups())
    return date(y, m, d).isoformat()


def extract_announcement_no(title: str, text: str) -> str | None:
    match = re.search(r"[\[［](\d{4})[\]］]第(\d+)号", title) or re.search(r"[\[［](\d{4})[\]］]第(\d+)号", text)
    if not match:
        return None
    return f"{match.group(1)}-{int(match.group(2)):03d}"


def parse_amount(text: str, keyword: str) -> float | None:
    patterns = [
        rf"{keyword}\s*[:：]?\s*([0-9,，.]+)\s*亿元",
        rf"([0-9,，.]+)\s*亿元[^。；;]*{keyword}",
    ]
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return float(match.group(1).replace(",", "").replace("，", ""))
    return None


def parse_percent_rate(text: str) -> float | None:
    for pattern in (
        r"\d+\s*天\s+(\d+)\s*\.\s*(\d+)\s*%",
        r"利率\s+.*?(\d+)\s*\.\s*(\d+)\s*%",
        r"(\d+)\s*\.\s*(\d+)\s*%",
    ):
        match = re.search(pattern, text)
        if match:
            return float(f"{match.group(1)}.{match.group(2)}")

    match = re.search(r"(\d+(?:\.\d+)?)\s*%", text)
    return float(match.group(1)) if match else None


def parse_operation_fields(title: str, text: str) -> dict:
    compact = normalize_text(text)
    announcement_no = extract_announcement_no(title, compact)
    operation_date = chinese_date_to_iso(compact)

    amount_match = re.search(r"开展了\s*([0-9,，.]+)\s*亿元\s*(?:(\d+)\s*天期?|隔夜)\s*逆回购", compact)
    sentence_amount = None
    sentence_term = None
    if amount_match:
        sentence_amount = float(amount_match.group(1).replace(",", "").replace("，", ""))
        sentence_term = int(amount_match.group(2)) if amount_match.group(2) else 1

    term_match = re.search(r"(\d+)\s*天(?:期)?逆回购", compact) or re.search(r"(\d+)\s*天\s+\d+\s*\.", compact)
    term_days = int(term_match.group(1)) if term_match else sentence_term
    if term_days is None and re.search(r"隔夜\s*逆回购|overnight\s+reverse\s+repo", compact, flags=re.I):
        term_days = 1

    # Zero is a valid official operation amount.  Do not use ``or`` here:
    # ``0.0 or None`` incorrectly turned zero-operation announcements into
    # missing data and prevented those dates from being persisted.
    bid_amount = parse_amount(compact, "投标量")
    award_amount = parse_amount(compact, "中标量")
    if bid_amount is None:
        bid_amount = sentence_amount
    if award_amount is None:
        award_amount = sentence_amount
    # Some PBC announcements use prose such as "7天期逆回购操作量为零"
    # rather than a populated bid/award table.  That is an official zero, not
    # an unavailable observation.
    if award_amount is None and re.search(r"逆回购操作量s*(?:为|:|：)\s*(?:零|0)", compact):
        bid_amount = 0.0 if bid_amount is None else bid_amount
        award_amount = 0.0

    return {
        "announcement_no": announcement_no,
        "operation_date": operation_date,
        "term_days": term_days,
        "rate": parse_percent_rate(compact),
        "bid_amount": bid_amount,
        "award_amount": award_amount,
    }


def parse_reverse_repo_operations(title: str, text: str) -> list[dict]:
    """Parse one announcement into one or more reverse repo operations."""
    compact = normalize_text(text)
    announcement_no = extract_announcement_no(title, compact)
    operation_date = chinese_date_to_iso(compact)
    rate = parse_percent_rate(compact)
    records: list[dict] = []
    seen: set[tuple[int, float]] = set()

    for match in re.finditer(r"开展了\s*([0-9,，.]+)\s*亿元\s*(?:(\d+)\s*天期?|隔夜)\s*逆回购操作", compact):
        amount = float(match.group(1).replace(",", "").replace("，", ""))
        term_days = int(match.group(2)) if match.group(2) else 1
        key = (term_days, amount)
        if key in seen:
            continue
        seen.add(key)
        suffix = "overnight" if term_days == 1 else f"{term_days}d"
        records.append(
            {
                "announcement_no": f"{announcement_no}-{suffix}" if announcement_no and records else announcement_no,
                "operation_date": operation_date,
                "term_days": term_days,
                "rate": rate,
                "bid_amount": amount,
                "award_amount": amount,
                "source_suffix": suffix if records else None,
            }
        )

    if records:
        return records

    # Older PBC pages may arrive with their Chinese text already mojibaked,
    # while the HTML table structure and numeric cells remain intact.  Parse
    # the four-column operation table (term/rate/bid/award) independently of
    # labels so historical backfills do not stop at an encoding boundary.
    for table_match in re.finditer(r"<table\b[^>]*>[\s\S]*?</table>", text, flags=re.I):
        table_html = table_match.group(0)
        for row_match in re.finditer(r"<tr\b[^>]*>([\s\S]*?)</tr>", table_html, flags=re.I):
            cells = re.findall(r"<td\b[^>]*>([\s\S]*?)</td>", row_match.group(1), flags=re.I)
            if len(cells) not in (3, 4):
                continue
            values = [normalize_text(cell).replace(" ", "") for cell in cells]
            rate_index = next((index for index, value in enumerate(values) if "%" in value), None)
            if rate_index is None:
                continue
            term_match = re.search(r"\d+", values[0])
            rate_match = re.search(r"\d+(?:\.\d+)?", values[rate_index])
            if len(values) == 4:
                bid_match = re.search(r"[0-9,，]+(?:\.\d+)?", values[2])
                award_match = re.search(r"[0-9,，]+(?:\.\d+)?", values[3])
            else:
                # 2025 Q1 and earlier pages use term/operation amount/rate.
                bid_match = re.search(r"[0-9,，]+(?:\.\d+)?", values[1])
                award_match = bid_match
            if not all((term_match, rate_match, bid_match, award_match)):
                continue
            term_days = int(term_match.group(0))
            bid_amount = float(bid_match.group(0).replace(",", "").replace("，", ""))
            award_amount = float(award_match.group(0).replace(",", "").replace("，", ""))
            suffix = "overnight" if term_days == 1 else f"{term_days}d"
            records.append(
                {
                    "announcement_no": f"{announcement_no}-{suffix}" if announcement_no and records else announcement_no,
                    "operation_date": operation_date,
                    "term_days": term_days,
                    "rate": float(rate_match.group(0)),
                    "bid_amount": bid_amount,
                    "award_amount": award_amount,
                    "source_suffix": suffix if records else None,
                }
            )
    if records:
        return records
    return [parse_operation_fields(title, compact)]


def init_db(db_path: Path = DB_PATH) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS omo_operations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                announcement_no TEXT UNIQUE,
                title TEXT NOT NULL,
                publish_date TEXT,
                operation_date TEXT,
                maturity_date TEXT,
                term_days INTEGER,
                rate REAL,
                bid_amount REAL,
                award_amount REAL,
                source_url TEXT NOT NULL UNIQUE,
                raw_text TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS market_calendar (
                trade_date TEXT PRIMARY KEY,
                is_business_day INTEGER NOT NULL,
                market TEXT NOT NULL DEFAULT 'interbank',
                note TEXT
            )
            """
        )
        columns = {row[1] for row in conn.execute("PRAGMA table_info(omo_operations)").fetchall()}
        if "maturity_date" not in columns:
            conn.execute("ALTER TABLE omo_operations ADD COLUMN maturity_date TEXT")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_omo_operation_date ON omo_operations(operation_date)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_omo_maturity_date ON omo_operations(maturity_date)")


def import_calendar(calendar_file: Path = CALENDAR_FILE, db_path: Path = DB_PATH) -> int:
    """导入银行间交易日历。

    JSON 格式：
    {
      "market": "interbank",
      "holidays": ["2026-01-01"],
      "workdays": ["2026-02-14"],
      "notes": {"2026-01-01": "元旦"}
    }

    holidays 表示非交易日；workdays 表示周末调休上班/交易日。
    """
    init_db(db_path)
    if not calendar_file.exists():
        return 0

    payload = json.loads(calendar_file.read_text(encoding="utf-8"))
    market = payload.get("market", "interbank")
    notes = payload.get("notes", {})
    rows: list[tuple[str, int, str, str | None]] = []

    for day in payload.get("holidays", []):
        rows.append((day, 0, market, notes.get(day)))
    for day in payload.get("workdays", []):
        rows.append((day, 1, market, notes.get(day) or "调休工作日"))

    with sqlite3.connect(db_path) as conn:
        conn.executemany(
            """
            INSERT INTO market_calendar (trade_date, is_business_day, market, note)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(trade_date) DO UPDATE SET
                is_business_day=excluded.is_business_day,
                market=excluded.market,
                note=excluded.note
            """,
            rows,
        )
    return len(rows)


def is_business_day(day: date, db_path: Path = DB_PATH) -> bool:
    with sqlite3.connect(db_path) as conn:
        row = conn.execute(
            "SELECT is_business_day FROM market_calendar WHERE trade_date = ? AND market = 'interbank'",
            (day.isoformat(),),
        ).fetchone()
    if row is not None:
        return bool(row[0])
    return day.weekday() < 5


def next_business_day(day: date, db_path: Path = DB_PATH) -> date:
    while not is_business_day(day, db_path):
        day += timedelta(days=1)
    return day


def calculate_maturity_date(operation_date: str | None, term_days: int | None, db_path: Path = DB_PATH) -> str | None:
    if not operation_date or not term_days:
        return None
    natural = datetime.fromisoformat(operation_date).date() + timedelta(days=term_days)
    return next_business_day(natural, db_path).isoformat()


def upsert_operation(record: dict, db_path: Path = DB_PATH) -> None:
    now = datetime.now().isoformat(timespec="seconds")
    record["maturity_date"] = calculate_maturity_date(record.get("operation_date"), record.get("term_days"), db_path)
    fields = {**record, "created_at": now, "updated_at": now}
    if fields.get("source_suffix") and fields.get("source_url") and "#" not in fields["source_url"]:
        fields["source_url"] = f"{fields['source_url']}#{fields['source_suffix']}"
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO omo_operations (
                announcement_no, title, publish_date, operation_date, maturity_date,
                term_days, rate, bid_amount, award_amount, source_url, raw_text,
                created_at, updated_at
            ) VALUES (
                :announcement_no, :title, :publish_date, :operation_date, :maturity_date,
                :term_days, :rate, :bid_amount, :award_amount, :source_url, :raw_text,
                :created_at, :updated_at
            )
            ON CONFLICT(source_url) DO UPDATE SET
                announcement_no=excluded.announcement_no,
                title=excluded.title,
                publish_date=excluded.publish_date,
                operation_date=excluded.operation_date,
                maturity_date=excluded.maturity_date,
                term_days=excluded.term_days,
                rate=excluded.rate,
                bid_amount=excluded.bid_amount,
                award_amount=excluded.award_amount,
                raw_text=excluded.raw_text,
                updated_at=excluded.updated_at
            """,
            fields,
        )


def parse_article(link: ArticleLink) -> dict:
    html = fetch_text(link.url)
    raw_text = normalize_text(html)
    fields = parse_reverse_repo_operations(link.title, html)[0]
    return {
        **fields,
        "title": link.title,
        "publish_date": link.publish_date,
        "source_url": link.url,
        "raw_text": raw_text[:20000],
    }


def parse_article_records(link: ArticleLink) -> list[dict]:
    html = fetch_text(link.url)
    raw_text = normalize_text(html)
    return [
        {
            **fields,
            "title": link.title,
            "publish_date": link.publish_date,
            "source_url": link.url,
            "raw_text": raw_text[:20000],
        }
        for fields in parse_reverse_repo_operations(link.title, html)
    ]


def sync_latest(pages: int = 1, limit: int = 120, pause_seconds: float = 0.3) -> list[dict]:
    init_db()
    links = extract_trade_links(pages=pages, limit=limit)
    saved: list[dict] = []
    for link in links:
        try:
            for record in parse_article_records(link):
                if record.get("operation_date") and record.get("award_amount") is not None:
                    upsert_operation(record)
                    saved.append(record)
            time.sleep(pause_seconds)
        except (URLError, TimeoutError, RuntimeError, ValueError) as exc:
            print(f"跳过：{link.title} - {exc}")
    return saved


def backfill_maturity_dates(db_path: Path = DB_PATH) -> None:
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        rows = conn.execute("SELECT id, operation_date, term_days FROM omo_operations").fetchall()
        for row_id, operation_date, term_days in rows:
            maturity_date = calculate_maturity_date(operation_date, term_days, db_path)
            conn.execute("UPDATE omo_operations SET maturity_date = ? WHERE id = ?", (maturity_date, row_id))


def default_as_of(db_path: Path = DB_PATH) -> date:
    today = date.today()
    init_db(db_path)
    with sqlite3.connect(db_path) as conn:
        row = conn.execute("SELECT MAX(operation_date) FROM omo_operations").fetchone()
    if row and row[0]:
        latest_operation = datetime.fromisoformat(row[0]).date()
        return min(today, latest_operation)
    return today


def query_omo_daily(days: int = 5, db_path: Path = DB_PATH, as_of: date | None = None) -> list[dict]:
    init_db(db_path)
    cutoff = (as_of or default_as_of(db_path)).isoformat()
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            """
            WITH dates AS (
                SELECT operation_date AS day FROM omo_operations WHERE operation_date IS NOT NULL
                UNION
                SELECT maturity_date AS day FROM omo_operations WHERE maturity_date IS NOT NULL
            )
            SELECT day FROM dates WHERE day IS NOT NULL AND day <= ? ORDER BY day DESC LIMIT ?
            """,
            (cutoff, days),
        ).fetchall()

        result = []
        for row in reversed(rows):
            day = row["day"]
            injection = conn.execute(
                "SELECT SUM(award_amount) FROM omo_operations WHERE operation_date = ?",
                (day,),
            ).fetchone()[0] or 0
            maturity = conn.execute(
                "SELECT SUM(award_amount) FROM omo_operations WHERE maturity_date = ?",
                (day,),
            ).fetchone()[0] or 0
            repo_rate = conn.execute(
                "SELECT MAX(rate) FROM omo_operations WHERE operation_date = ?",
                (day,),
            ).fetchone()[0]
            result.append(
                {
                    "date": day,
                    "label": day[5:].replace("-", "/"),
                    "injection": float(injection),
                    "maturity": float(maturity),
                    "value": float(injection) - float(maturity),
                    "repoRate7d": repo_rate,
                    "source": "pbc",
                }
            )
        return result


def week_label(monday: date, sunday: date) -> str:
    if monday.month == sunday.month:
        return f"{monday:%m/%d}-{sunday:%d}"
    return f"{monday:%m/%d}-{sunday:%m/%d}"


def query_omo_weekly(weeks: int = 4, db_path: Path = DB_PATH, as_of: date | None = None) -> list[dict]:
    cutoff = as_of or default_as_of(db_path)
    daily = query_omo_daily(days=140, db_path=db_path, as_of=cutoff)
    if not daily:
        return []

    latest_monday = cutoff - timedelta(days=cutoff.weekday())
    windows = [(latest_monday - timedelta(days=7 * i)) for i in reversed(range(weeks))]

    daily_by_date = {item["date"]: item for item in daily}
    result = []
    for monday in windows:
        sunday = monday + timedelta(days=6)
        injection = maturity = 0.0
        day = monday
        while day <= sunday:
            item = daily_by_date.get(day.isoformat())
            if item:
                injection += float(item["injection"])
                maturity += float(item["maturity"])
            day += timedelta(days=1)
        result.append(
            {
                "start": monday.isoformat(),
                "end": sunday.isoformat(),
                "label": week_label(monday, sunday),
                "injection": injection,
                "maturity": maturity,
                "value": injection - maturity,
            }
        )
    return result


def query_omo_transactions(days: int = 7, db_path: Path = DB_PATH, as_of: date | None = None) -> list[dict]:
    """返回近 N 日公开市场逐笔净投放明细。

    口径：逆回购操作日记为投放（正数），到期日记为回笼（负数）。
    """
    init_db(db_path)
    today = date.today()
    if as_of is None:
        with sqlite3.connect(db_path) as conn:
            row = conn.execute(
                """
                WITH dates AS (
                    SELECT operation_date AS day FROM omo_operations WHERE operation_date IS NOT NULL
                    UNION
                    SELECT maturity_date AS day FROM omo_operations WHERE maturity_date IS NOT NULL
                )
                SELECT MAX(day) FROM dates WHERE day IS NOT NULL AND day <= ?
                """,
                (today.isoformat(),),
            ).fetchone()
        cutoff = datetime.fromisoformat(row[0]).date() if row and row[0] else today
    else:
        cutoff = as_of
    start = cutoff - timedelta(days=days - 1)

    result: list[dict] = []
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        operation_rows = conn.execute(
            """
            SELECT id, announcement_no, title, operation_date, maturity_date, term_days, rate, award_amount, source_url
            FROM omo_operations
            WHERE operation_date BETWEEN ? AND ?
            ORDER BY operation_date DESC, id DESC
            """,
            (start.isoformat(), cutoff.isoformat()),
        ).fetchall()
        maturity_rows = conn.execute(
            """
            SELECT id, announcement_no, title, operation_date, maturity_date, term_days, rate, award_amount, source_url
            FROM omo_operations
            WHERE maturity_date BETWEEN ? AND ?
            ORDER BY maturity_date DESC, id DESC
            """,
            (start.isoformat(), cutoff.isoformat()),
        ).fetchall()

    for row in operation_rows:
        amount = float(row["award_amount"] or 0)
        result.append(
            {
                "date": row["operation_date"],
                "label": row["operation_date"][5:].replace("-", "/"),
                "type": "逆回购投放",
                "tool": "reverse_repo",
                "amount": amount,
                "termDays": row["term_days"],
                "rate": row["rate"],
                "announcementNo": row["announcement_no"],
                "sourceUrl": row["source_url"],
            }
        )

    for row in maturity_rows:
        amount = float(row["award_amount"] or 0)
        result.append(
            {
                "date": row["maturity_date"],
                "label": row["maturity_date"][5:].replace("-", "/"),
                "type": "逆回购到期",
                "tool": "reverse_repo",
                "amount": -amount,
                "termDays": row["term_days"],
                "rate": row["rate"],
                "announcementNo": row["announcement_no"],
                "sourceUrl": row["source_url"],
            }
        )

    result.sort(key=lambda item: (item["date"], item["amount"]), reverse=True)
    return result


def export_json(days: int = 5, weeks: int = 4) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    as_of = default_as_of()
    payload = {
        "asOf": as_of.isoformat(),
        "omoDaily": query_omo_daily(days=days, as_of=as_of),
        "omoWeekly": query_omo_weekly(weeks=weeks, as_of=as_of),
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
    }
    (DATA_DIR / "pboc_omo_daily.json").write_text(json.dumps(payload["omoDaily"], ensure_ascii=False, indent=2), encoding="utf-8")
    (DATA_DIR / "pboc_omo_payload.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def run_daily(hour: int = 9, minute: int = 35, pages: int = 1, limit: int = 120) -> None:
    print(f"每日定时更新已启动：{hour:02d}:{minute:02d}")
    while True:
        now = datetime.now()
        next_run = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if next_run <= now:
            next_run += timedelta(days=1)
        print(f"下次更新：{next_run:%Y-%m-%d %H:%M:%S}")
        time.sleep((next_run - now).total_seconds())
        import_calendar()
        saved = sync_latest(pages=pages, limit=limit)
        backfill_maturity_dates()
        export_json()
        try:
            from central_bank_tools import (
                migrate_reverse_repo,
                sync_gov_bond_trade_from_sources,
                sync_mlf_from_sources,
                sync_outright_reverse_repo_from_sources,
                sync_treasury_cash_deposit_from_sources,
            )

            migrate_reverse_repo()
            sync_mlf_from_sources()
            sync_treasury_cash_deposit_from_sources()
            sync_gov_bond_trade_from_sources()
            sync_outright_reverse_repo_from_sources()
        except Exception as exc:
            print(f"central_bank_tools sync skipped: {exc}")
        print(f"更新完成：入库/更新 {len(saved)} 条")


def main() -> None:
    parser = argparse.ArgumentParser(description="抓取央行公开市场业务交易公告并入库")
    parser.add_argument("--sync", action="store_true", help="立即抓取最新公告并写入 SQLite")
    parser.add_argument("--export-json", action="store_true", help="从数据库导出前端使用的 JSON")
    parser.add_argument("--backfill-maturity", action="store_true", help="按交易日历重算已有操作的回笼日")
    parser.add_argument("--import-calendar", action="store_true", help="导入 data/interbank_calendar.json 交易日历")
    parser.add_argument("--daily", action="store_true", help="常驻运行，每天定时更新")
    parser.add_argument("--pages", type=int, default=1, help="抓取详细列表页页数；央行当前详细页通常首页已含近期公告")
    parser.add_argument("--limit", type=int, default=120, help="本次最多抓取公告数量")
    parser.add_argument("--hour", type=int, default=9, help="每日更新小时")
    parser.add_argument("--minute", type=int, default=35, help="每日更新分钟")
    args = parser.parse_args()

    if args.daily:
        run_daily(args.hour, args.minute, args.pages, args.limit)
        return

    if args.sync:
        saved = sync_latest(pages=args.pages, limit=args.limit)
        print(f"入库/更新 {len(saved)} 条")

    if args.import_calendar:
        count = import_calendar()
        print(f"已导入交易日历 {count} 条")

    if args.backfill_maturity:
        backfill_maturity_dates()
        print("已重算回笼日")

    if args.export_json:
        export_json()
        print(f"已导出 {DATA_DIR / 'pboc_omo_payload.json'}")

    if not any((args.sync, args.export_json, args.backfill_maturity, args.import_calendar)):
        parser.print_help()


if __name__ == "__main__":
    main()
