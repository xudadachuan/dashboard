from __future__ import annotations

import json
import ssl
from datetime import date, datetime, timedelta
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from chinabond_ncd import query_ncd_valuation
from market_database import available_dates, load_snapshot, save_interbank_cd_snapshot


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT.parent / "data"
CACHE_FILE = DATA_DIR / "interbank_cd_cache.json"
LIST_URL = "https://www.chinamoney.org.cn/ags/ms/cm-u-bond-md/BondMarketInfoListEN"
DETAIL_URL = "https://www.chinamoney.org.cn/ags/ms/cm-u-bond-md/BondDetailInfoEN"
IBNCD_BOND_TYPE = "100041"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BondDashboard/1.0"
NETWORK_TIMEOUT_SECONDS = 8
MEMORY_TTL_SECONDS = 600
_MEMORY_CACHE: tuple[datetime, dict] | None = None
MAJOR_BANK_SEGMENT = "\u56fd\u80a1\u884c"
MAJOR_BANK_KEYWORDS = (
    "Industrial and Commercial Bank of China",
    "Agricultural Bank of China",
    "Bank of China",
    "China Construction Bank",
    "Bank of Communications",
    "Postal Savings Bank",
    "China Merchants Bank",
    "China CITIC Bank",
    "China Everbright Bank",
    "Huaxia Bank",
    "China Minsheng Bank",
    "China Guangfa Bank",
    "Ping An Bank",
    "Industrial Bank",
    "Shanghai Pudong Development Bank",
    "China Zheshang Bank",
    "China Bohai Bank",
    "Hengfeng Bank",
)


def is_major_bank_issuer(issuer: str | None) -> bool:
    issuer_text = issuer or ""
    return any(keyword.lower() in issuer_text.lower() for keyword in MAJOR_BANK_KEYWORDS)


def load_cache() -> dict:
    if not CACHE_FILE.exists():
        return {}
    try:
        payload = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}
    return payload if isinstance(payload, dict) else {}


def save_cache(payload: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    CACHE_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def parse_float(value) -> float | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text or text == "---":
        return None
    try:
        return float(text.replace(",", ""))
    except ValueError:
        return None


def post_json(url: str, body: dict, referer: str) -> dict:
    context = ssl.create_default_context()
    if hasattr(ssl, "OP_LEGACY_SERVER_CONNECT"):
        context.options |= ssl.OP_LEGACY_SERVER_CONNECT
    request = Request(
        url,
        data=urlencode(body).encode("utf-8"),
        headers={
            "User-Agent": USER_AGENT,
            "Referer": referer,
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        },
        method="POST",
    )
    raw = urlopen(request, timeout=NETWORK_TIMEOUT_SECONDS, context=context).read()
    return json.loads(raw.decode("utf-8"))


def estimate_discount_yield(issue_price: float | None, issue_date: str | None, maturity_date: str | None) -> float | None:
    if not issue_price or issue_price <= 0 or not issue_date or not maturity_date:
        return None
    try:
        start = date.fromisoformat(issue_date)
        end = date.fromisoformat(maturity_date)
    except ValueError:
        return None
    days = (end - start).days
    if days <= 0:
        return None
    return round(((100 / issue_price) - 1) * 365 / days * 100, 4)


def fetch_detail(bond_defined_code: str) -> dict:
    payload = post_json(
        DETAIL_URL,
        {"bondDefinedCode": bond_defined_code},
        "https://www.chinamoney.org.cn/english/bdInfo/",
    )
    return ((payload.get("data") or {}).get("bondBaseInfo") or {})


def normalize_item(row: dict, detail: dict | None = None) -> dict:
    detail = detail or {}
    issue_price = parse_float(detail.get("issuePrice"))
    issue_date = detail.get("issueDate") or row.get("issueStartDate")
    maturity_date = detail.get("mrtyDate")
    credit_list = detail.get("creditRateEntyList") if isinstance(detail.get("creditRateEntyList"), list) else []
    rating = row.get("debtRtng") or detail.get("debtRtng")
    if (not rating or rating == "---") and credit_list:
        rating = credit_list[0].get("creditSubjectRating")
    issuer = row.get("entyFullName") or detail.get("entyFullName") or "---"
    is_major_bank = is_major_bank_issuer(issuer)
    return {
        "bondCode": row.get("bondCode") or detail.get("bondCode"),
        "issuer": issuer,
        "issueDate": issue_date,
        "maturityDate": maturity_date,
        "term": detail.get("bondPeriod") or "---",
        "issuePrice": issue_price,
        "plannedAmount100m": parse_float(detail.get("plndIssueAmnt")),
        "actualAmount100m": parse_float(detail.get("issueAmnt")),
        "couponType": detail.get("couponType") or "---",
        "couponRate": parse_float(detail.get("parCouponRate")),
        "estimatedYield": estimate_discount_yield(issue_price, issue_date, maturity_date),
        "rating": rating or "---",
        "isMajorBank": is_major_bank,
        "segment": MAJOR_BANK_SEGMENT if is_major_bank else "",
        "bondDefinedCode": row.get("bondDefinedCode"),
    }


def average_yield(items: list[dict]) -> float | None:
    values = [float(item["estimatedYield"]) for item in items if item.get("estimatedYield") is not None]
    if not values:
        return None
    return round(sum(values) / len(values), 4)


def planned_amount_sum(items: list[dict]) -> float | None:
    values = [float(item["plannedAmount100m"]) for item in items if item.get("plannedAmount100m") is not None]
    if not values:
        return None
    return round(sum(values), 2)


def normalize_term_bucket(term: str | None, issue_date: str | None = None, maturity_date: str | None = None) -> str | None:
    text = (term or "").strip().lower().replace(" ", "")
    if text in {"1m", "1month"}:
        return "1M"
    if text in {"3m", "3month"}:
        return "3M"
    if text in {"6m", "6month"}:
        return "6M"
    if text in {"9m", "9month"}:
        return "9M"
    if text in {"1y", "1year"}:
        return "1Y"
    if issue_date and maturity_date:
        try:
            days = (date.fromisoformat(maturity_date) - date.fromisoformat(issue_date)).days
        except ValueError:
            return None
        if days <= 45:
            return "1M"
        if days <= 135:
            return "3M"
        if days <= 225:
            return "6M"
        if days <= 315:
            return "9M"
        if days <= 410:
            return "1Y"
    return None


def summarize_terms(items: list[dict], valuation_curve: dict | None = None) -> list[dict]:
    buckets = {label: [] for label in ("1M", "3M", "6M", "9M", "1Y")}
    valuation_yields = (valuation_curve or {}).get("termYields") or {}
    for item in items:
        bucket = normalize_term_bucket(item.get("term"), item.get("issueDate"), item.get("maturityDate"))
        if bucket in buckets:
            buckets[bucket].append(item)
    return [
        {
            "term": term,
            "count": len(group),
            "amount100m": planned_amount_sum(group),
            "valuationYield": valuation_yields.get(term),
            "yieldSource": "chinabond" if valuation_yields.get(term) is not None else "unavailable",
        }
        for term, group in buckets.items()
    ]


def summarize_segments(items: list[dict]) -> dict:
    aaa_items = [item for item in items if str(item.get("rating") or "").upper().startswith("AAA")]
    major_items = [item for item in items if item.get("isMajorBank") or is_major_bank_issuer(item.get("issuer"))]
    rating_segments: dict[str, dict] = {}
    for item in items:
        rating = str(item.get("rating") or "").upper().strip()
        if not rating or rating.startswith("---"):
            continue
        rating_segments.setdefault(rating, {"items": []})["items"].append(item)
    rating_summary = {
        rating: {"count": len(group["items"]), "avgYield": average_yield(group["items"])}
        for rating, group in sorted(rating_segments.items())
    }
    return {
        "all": {"count": len(items), "avgYield": average_yield(items)},
        "aaa": {"count": len(aaa_items), "avgYield": average_yield(aaa_items)},
        "majorBanks": {"count": len(major_items), "avgYield": average_yield(major_items)},
        "ratings": rating_summary,
    }


def apply_valuation(items: list[dict], valuation_curve: dict) -> list[dict]:
    valuation_yields = valuation_curve.get("termYields") or {}
    enriched_items: list[dict] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        is_major_bank = item.get("isMajorBank") or is_major_bank_issuer(item.get("issuer"))
        bucket = normalize_term_bucket(item.get("term"), item.get("issueDate"), item.get("maturityDate"))
        enriched_items.append(
            {
                **item,
                "isMajorBank": bool(is_major_bank),
                "segment": item.get("segment") or (MAJOR_BANK_SEGMENT if is_major_bank else ""),
                "valuationTerm": bucket,
                "valuationYield": valuation_yields.get(bucket) if bucket else None,
            }
        )
    return enriched_items


def merge_valuation(payload: dict, valuation_curve: dict | None = None) -> dict:
    valuation_curve = valuation_curve or query_ncd_valuation(payload.get("date"))
    items = apply_valuation(payload.get("items") or [], valuation_curve)
    return {
        **payload,
        "items": items,
        "segments": summarize_segments(items),
        "termBuckets": summarize_terms(items, valuation_curve),
        "valuationCurve": valuation_curve,
        "issuanceDate": payload.get("date"),
        "issuanceSource": payload.get("source"),
        "issuanceError": payload.get("error"),
        "valuationDate": valuation_curve.get("date"),
        "valuationSource": valuation_curve.get("source"),
        "valuationError": valuation_curve.get("error"),
    }


def with_segments(payload: dict, valuation_curve: dict | None = None) -> dict:
    items = payload.get("items")
    if isinstance(items, list):
        return merge_valuation(payload, valuation_curve)
    return payload


def fetch_interbank_cd_page(page_no: int = 1, page_size: int = 16) -> tuple[list[dict], dict]:
    list_payload = post_json(
        LIST_URL,
        {
            "pageNo": str(max(page_no, 1)),
            "pageSize": str(max(page_size, 1)),
            "isin": "",
            "bondCode": "",
            "issueEnty": "",
            "bondType": IBNCD_BOND_TYPE,
            "couponType": "",
            "issueYear": "",
            "rtngShrt": "",
            "bondSpclPrjctVrty": "",
        },
        "https://www.chinamoney.org.cn/english/bdInfo/",
    )
    data = list_payload.get("data") or {}
    rows = data.get("resultList") or []
    return rows, data


def build_payload_from_rows(rows: list[dict], data: dict | None = None, limit: int | None = None) -> dict:
    items: list[dict] = []
    selected_rows = rows[:limit] if limit else rows
    for row in selected_rows:
        detail = {}
        code = row.get("bondDefinedCode")
        if code:
            try:
                detail = fetch_detail(code)
            except Exception:
                detail = {}
        items.append(normalize_item(row, detail))
    latest_date = next((item.get("issueDate") for item in items if item.get("issueDate")), None)
    return {
        "date": latest_date,
        "items": items,
        "segments": summarize_segments(items),
        "termBuckets": summarize_terms(items),
        "total": (data or {}).get("total"),
        "source": "chinamoney",
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
    }


def fetch_interbank_cd(limit: int = 16) -> dict:
    rows, data = fetch_interbank_cd_page(1, max(limit, 1))
    return build_payload_from_rows(rows, data, limit)


def backfill_interbank_cd(start_date: str, end_date: str | None = None, page_size: int = 50, max_pages: int = 20) -> dict:
    start = date.fromisoformat(start_date)
    end = date.fromisoformat(end_date) if end_date else date.today()
    rows_by_date: dict[str, list[dict]] = {}
    pages_read = 0
    reached_older = False
    for page_no in range(1, max_pages + 1):
        rows, data = fetch_interbank_cd_page(page_no, page_size)
        pages_read += 1
        if not rows:
            break
        for row in rows:
            row_date_text = row.get("issueStartDate")
            try:
                row_date = date.fromisoformat(str(row_date_text))
            except (TypeError, ValueError):
                continue
            if row_date < start:
                reached_older = True
                continue
            if start <= row_date <= end:
                rows_by_date.setdefault(row_date.isoformat(), []).append(row)
        if reached_older:
            break
        total = int(data.get("total") or 0)
        if total and page_no * page_size >= total:
            break
    saved: list[dict] = []
    for row_date, rows in sorted(rows_by_date.items()):
        payload = build_payload_from_rows(rows, {"total": len(rows)})
        save_cache(payload)
        save_interbank_cd_snapshot(payload)
        saved.append({"date": row_date, "items": len(payload.get("items") or [])})
    return {"startDate": start.isoformat(), "endDate": end.isoformat(), "pagesRead": pages_read, "saved": saved}


def with_available_dates(payload: dict) -> dict:
    dates = available_dates("interbank_cd_daily")
    if dates:
        return {**payload, "availableDates": dates, "startDate": dates[0], "endDate": dates[-1]}
    return payload


def is_future_payload(payload: dict) -> bool:
    payload_date = payload.get("date")
    if not payload_date:
        return False
    try:
        return date.fromisoformat(str(payload_date)) > date.today()
    except ValueError:
        return False


def is_intraday_payload(payload: dict) -> bool:
    payload_date = payload.get("date")
    if not payload_date:
        return False
    try:
        parsed = date.fromisoformat(str(payload_date))
    except ValueError:
        return False
    return parsed >= date.today() and datetime.now().hour < 17


def payload_date_value(payload: dict) -> date | None:
    try:
        return date.fromisoformat(str(payload.get("date")))
    except (TypeError, ValueError):
        return None


def newer_payload(first: dict, second: dict) -> dict:
    first_date = payload_date_value(first)
    second_date = payload_date_value(second)
    if first_date and second_date:
        return first if first_date >= second_date else second
    return first if first_date else second


def load_best_snapshot(query_date: str | None = None) -> dict | None:
    stored = load_snapshot("interbank_cd_daily", query_date)
    if query_date:
        return stored
    cached = load_cache()
    if stored and cached.get("items"):
        return newer_payload(stored, cached)
    return stored or (cached if cached.get("items") else None)


def query_interbank_cd(
    limit: int = 16,
    query_date: str | None = None,
    refresh: bool = False,
    valuation_curve: dict | None = None,
) -> dict:
    global _MEMORY_CACHE
    if not refresh:
        stored = load_best_snapshot(query_date)
        if stored:
            return with_available_dates(with_segments(stored, valuation_curve))

    if _MEMORY_CACHE:
        cached_at, payload = _MEMORY_CACHE
        if not query_date and (datetime.now() - cached_at).total_seconds() < MEMORY_TTL_SECONDS:
            return with_available_dates(with_segments(payload, valuation_curve))

    try:
        payload = fetch_interbank_cd(limit=limit)
        if not payload.get("items"):
            raise RuntimeError("No IBNCD records returned")
        if is_future_payload(payload) or is_intraday_payload(payload):
            save_cache(payload)
            _MEMORY_CACHE = (datetime.now(), payload)
            return with_available_dates(with_segments(payload, valuation_curve))
        save_cache(payload)
        save_interbank_cd_snapshot(payload)
        _MEMORY_CACHE = (datetime.now(), payload)
        return with_available_dates(with_segments(payload, valuation_curve))
    except Exception as exc:
        stored = load_best_snapshot(query_date)
        if stored:
            return with_available_dates(with_segments({**stored, "source": "cache", "error": str(exc)}, valuation_curve))
        fallback = load_cache()
        if fallback.get("items") and not is_future_payload(fallback) and not is_intraday_payload(fallback):
            payload = {**fallback, "source": "cache", "error": str(exc)}
            save_interbank_cd_snapshot(payload)
            _MEMORY_CACHE = (datetime.now(), payload)
            return with_available_dates(with_segments(payload, valuation_curve))
        payload = {
            "date": None,
            "items": [],
            "segments": summarize_segments([]),
            "termBuckets": summarize_terms([]),
            "total": None,
            "source": "unavailable",
            "error": str(exc),
            "updatedAt": datetime.now().isoformat(timespec="seconds"),
        }
        _MEMORY_CACHE = (datetime.now(), payload)
        return with_available_dates(with_segments(payload, valuation_curve))
