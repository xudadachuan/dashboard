[CmdletBinding()]
param(
    [string]$AppRoot = "C:\BondDashboard",
    [string]$PythonVersion = "3.13.14"
)

$ErrorActionPreference = "Stop"

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "请以管理员身份运行 PowerShell。"
}

$SourceRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$SourceFull = [IO.Path]::GetFullPath($SourceRoot).TrimEnd('\')
$TargetFull = [IO.Path]::GetFullPath($AppRoot).TrimEnd('\')
if ($SourceFull -ne $TargetFull) {
    New-Item -ItemType Directory -Path $TargetFull -Force | Out-Null
    Copy-Item -Path (Join-Path $SourceFull "*") -Destination $TargetFull -Recurse -Force
}

$PythonHome = "C:\Program Files\Python313"
$PythonExe = Join-Path $PythonHome "python.exe"
if (-not (Test-Path -LiteralPath $PythonExe)) {
    $Installer = Join-Path $env:TEMP "python-$PythonVersion-amd64.exe"
    $InstallerUrl = "https://www.python.org/ftp/python/$PythonVersion/python-$PythonVersion-amd64.exe"
    Invoke-WebRequest -UseBasicParsing -Uri $InstallerUrl -OutFile $Installer
    $signature = Get-AuthenticodeSignature -LiteralPath $Installer
    if ($signature.Status -ne "Valid" -or $signature.SignerCertificate.Subject -notmatch "Python Software Foundation") {
        throw "Python 安装包签名验证失败。"
    }
    $install = Start-Process -FilePath $Installer -ArgumentList @(
        "/quiet",
        "InstallAllUsers=1",
        "TargetDir=$PythonHome",
        "Include_launcher=1",
        "Include_test=0",
        "PrependPath=1"
    ) -Wait -PassThru
    if ($install.ExitCode -ne 0) {
        throw "Python 安装失败，退出码：$($install.ExitCode)"
    }
}

$CaddyDir = Join-Path $TargetFull "tools\caddy"
$CaddyExe = Join-Path $CaddyDir "caddy.exe"
if (-not (Test-Path -LiteralPath $CaddyExe)) {
    New-Item -ItemType Directory -Path $CaddyDir -Force | Out-Null
    $release = Invoke-RestMethod -Headers @{ "User-Agent" = "BondDashboardInstaller" } -Uri "https://api.github.com/repos/caddyserver/caddy/releases/latest"
    $asset = $release.assets | Where-Object { $_.name -match "windows_amd64\.zip$" } | Select-Object -First 1
    if (-not $asset) {
        throw "未找到 Caddy Windows amd64 安装包。"
    }
    $CaddyZip = Join-Path $env:TEMP $asset.name
    Invoke-WebRequest -UseBasicParsing -Uri $asset.browser_download_url -OutFile $CaddyZip
    Expand-Archive -LiteralPath $CaddyZip -DestinationPath $CaddyDir -Force
}

$EnvPath = Join-Path $TargetFull ".env"
if (-not (Test-Path -LiteralPath $EnvPath)) {
    @"
BOND_DASHBOARD_HOST=127.0.0.1
BOND_DASHBOARD_PORT=8765
DEEPSEEK_API_KEY=
DEEPSEEK_MODEL=deepseek-v4-flash
DEEPSEEK_NEWS_MODEL=deepseek-v4-flash
IFIND_USERNAME=
IFIND_PASSWORD=
ALIYUN_DM_SMTP_HOST=smtpdm.aliyun.com
ALIYUN_DM_SMTP_PORT=465
ALIYUN_DM_SMTP_USERNAME=
ALIYUN_DM_SMTP_PASSWORD=
ALIYUN_DM_FROM_NAME=
"@ | Set-Content -LiteralPath $EnvPath -Encoding UTF8
}

$TaskSettings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RestartCount 5 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
$SystemPrincipal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
$StartupTrigger = New-ScheduledTaskTrigger -AtStartup

$BackendAction = New-ScheduledTaskAction -Execute $PythonExe -Argument "`"$TargetFull\backend_api.py`"" -WorkingDirectory $TargetFull
Register-ScheduledTask -TaskName "BondDashboard_Backend" -Action $BackendAction -Trigger $StartupTrigger -Settings $TaskSettings -Principal $SystemPrincipal -Description "Bond dashboard backend" -Force | Out-Null

$Caddyfile = Join-Path $TargetFull "deploy\windows\Caddyfile"
$CaddyAction = New-ScheduledTaskAction -Execute $CaddyExe -Argument "run --config `"$Caddyfile`" --adapter caddyfile" -WorkingDirectory $TargetFull
Register-ScheduledTask -TaskName "BondDashboard_Caddy" -Action $CaddyAction -Trigger $StartupTrigger -Settings $TaskSettings -Principal $SystemPrincipal -Description "Bond dashboard HTTP reverse proxy" -Force | Out-Null

& (Join-Path $TargetFull "deploy\windows\register-data-tasks.ps1") -AppRoot $TargetFull

if (-not (Get-NetFirewallRule -DisplayName "Bond Dashboard HTTP" -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule -DisplayName "Bond Dashboard HTTP" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 80 -Profile Any | Out-Null
}

Stop-ScheduledTask -TaskName "BondDashboard_Backend" -ErrorAction SilentlyContinue
Stop-ScheduledTask -TaskName "BondDashboard_Caddy" -ErrorAction SilentlyContinue
Start-ScheduledTask -TaskName "BondDashboard_Backend"
Start-Sleep -Seconds 2
Start-ScheduledTask -TaskName "BondDashboard_Caddy"

Write-Host "部署完成。请先填写 $EnvPath 中的密钥，再运行 verify.ps1。"
