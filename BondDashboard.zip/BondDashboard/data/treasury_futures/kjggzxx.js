/**
 * Created by zhangyw on 2016/6/20.
 */


var arangeAllTreasifoData ={   //将后台数据按照前台规范显示的类
    createNew:function(){
        var arangeAllTreasifoData ={};
        arangeAllTreasifoData.productidRowNumb=8;
        arangeAllTreasifoData.instrumentidNumb=7;
        arangeAllTreasifoData.fullnameNumb=0;
        arangeAllTreasifoData.instruments=[0,0,0];
        arangeAllTreasifoData.productDatas ={};
        arangeAllTreasifoData.showDatas={};
        arangeAllTreasifoData.getShowData=function( allDatas,  productid){
            for( var i in allDatas){
                var lineAllDatas = allDatas[i].split(',');
                if($.trim(lineAllDatas[this.productidRowNumb]) ==productid){
                    var instrumentid=         $.trim(lineAllDatas[this.instrumentidNumb]).substr(productid.length,$.trim(lineAllDatas[this.instrumentidNumb]).length);
                    var fullname = $.trim(lineAllDatas[this.fullnameNumb])
                    var flag = 0;

                    if(!this.productDatas[fullname]){
                        this.productDatas[fullname]=[];
                    }
                    if(!this.productDatas[fullname][instrumentid]){
                        this.productDatas[fullname][instrumentid]=[];
                    }
                    this.productDatas[fullname][instrumentid].push(lineAllDatas);   //得到该产品的数据
                    if(Number(instrumentid)>this.instruments[0]&&Number(instrumentid)!=this.instruments[1]&&Number(instrumentid)!=this.instruments[2]){//维护最大的三个合约结构体
                        this.instruments[0] = Number(instrumentid);
                        this.instruments.sort();
                    }
                }
            }
            for(var key in this.productDatas){
                for(var instrumentKey in this.productDatas[key]){
                    if(instrumentKey == this.instruments[0] || instrumentKey == this.instruments[1] ||instrumentKey == this.instruments[2]){
                        if(!this.showDatas[key]){
                            this.showDatas[key]=[];
                            this.showDatas[key].cf1 = "--";
                            this.showDatas[key].cf2 = "--";
                            this.showDatas[key].cf3 = "--";
                        }
                        this.showDatas[key].fullname = this.productDatas[key][instrumentKey][0][this.fullnameNumb];
                        this.showDatas[key].treasidIB = this.productDatas[key][instrumentKey][0][1];
                        this.showDatas[key].treasidSH = this.productDatas[key][instrumentKey][0][2];
                        this.showDatas[key].treasidSZ =   this.productDatas[key][instrumentKey][0][3];
                        this.showDatas[key].expiredate =this.productDatas[key][instrumentKey][0][4];
                        this.showDatas[key].rate = this.productDatas[key][instrumentKey][0][5];
                        if(instrumentKey == this.instruments[0]){
                            this.showDatas[key].cf1 = this.productDatas[key][instrumentKey][0][6];
                        }
                        if(instrumentKey == this.instruments[1]){
                            this.showDatas[key].cf2 = this.productDatas[key][instrumentKey][0][6];
                        }
                        if(instrumentKey == this.instruments[2]){
                            this.showDatas[key].cf3 = this.productDatas[key][instrumentKey][0][6];
                        }
                    }
                }
            }
        };
        return arangeAllTreasifoData
    }
}


var kjggzxxViewModel = function() {
    var self = this;

    self.instabledata = ko.observableArray();

    var inputInstrument = "";

    self.isShow =  ko.observable(false);
    self.isShowIns =  ko.observable(false);
    self.isHavResult= ko.observable(false);

    self.instrumentOne = ko.observable();
    self.instrumentTwo = ko.observable();
    self.instrumentThree = ko.observable();

    self.download ={"url" : ko.observable(),
        "details" : ko.observable()};

    self.productChange = function () {
        inputInstrument = $.trim($("#instrument").val());
        self.instabledata([]);
        self.isShow(false);
        self.isHavResult(false);
        self.isShowIns(false);
        var selectproduct = $.trim( $("#product").val());
        $.ajax({
            dataType:"text",
             url:  "/sj/jgsj/jgqsj/"  + "index_6882.csv" ,
           //  url:  "http://www.cffex.com.cn/fzjy/jgsj/jgqsj/all_6620.csv" ,
            method: 'GET',

            success: function(response) {
                var treasiinfoArrays =[];
                var delivtreasData = $.trim(response).split("\n");
                // 仅有表头信息或没有数据
                if (delivtreasData.length < 0) {
                    alert("没有可交割国债信息数据");
                    return;
                }

                //	var parseData =Object.create(arangeAllTreasifoData);
                var parseData = arangeAllTreasifoData.createNew();
                parseData.getShowData(delivtreasData, selectproduct);

               for(var key in parseData.showDatas){
                   treasiinfoArrays.push( parseData.showDatas[key]);
               }



                self.instabledata(treasiinfoArrays);
				if( parseData.instruments[0] == 0){
				   self.instrumentOne( "--");
				}else{
                self.instrumentOne( selectproduct+ parseData.instruments[0] );
				}
				if( parseData.instruments[1] == 0){
				     self.instrumentTwo("--" );
				}else{
                self.instrumentTwo( selectproduct+ parseData.instruments[1] );
				}
				if( parseData.instruments[2] ==0){
				    self.instrumentThree("--");
				}else{
                self.instrumentThree( selectproduct+ parseData.instruments[2] );
				}
                if(treasiinfoArrays.length >0){
                    self.isShow(true) ;
                }
            },
            complete : function(response){

            }
        });
    };
    self.getDatas = function () {
        var instrumentid= $.trim($("#instrument").val())
        var selectproduct = $.trim( $("#product").val());
        inputInstrument = $.trim( $("#product").val()) + instrumentid;
        self.instabledata([]);
        self.isShow(false);
        self.isHavResult(false);
        self.isShowIns(true);
        if (instrumentid==""){
            self.isShowIns(false);
            $.ajax({
                dataType:"text",
                url:  "/sj/jgsj/jgqsj/"  + "index_6882.csv" ,
                //  url:  "http://www.cffex.com.cn/fzjy/jgsj/jgqsj/all_6620.csv" ,
                method: 'GET',

                success: function(response) {
                    var treasiinfoArrays =[];
                    var delivtreasData = $.trim(response).split("\n");
                    // 仅有表头信息或没有数据
                    if (delivtreasData.length < 0) {
                        alert("没有可交割国债信息数据");
                        return;
                    }

                    //	var parseData =Object.create(arangeAllTreasifoData);
                    var parseData = arangeAllTreasifoData.createNew();
                    parseData.getShowData(delivtreasData, selectproduct);

                    for(var key in parseData.showDatas){
                        treasiinfoArrays.push( parseData.showDatas[key]);
                    }



                    self.instabledata(treasiinfoArrays);
                    if( parseData.instruments[0] == 0){
                        self.instrumentOne( "--");
                    }else{
                        self.instrumentOne( selectproduct+ parseData.instruments[0] );
                    }
                    if( parseData.instruments[1] == 0){
                        self.instrumentTwo("--" );
                    }else{
                        self.instrumentTwo( selectproduct+ parseData.instruments[1] );
                    }
                    if( parseData.instruments[2] ==0){
                        self.instrumentThree("--");
                    }else{
                        self.instrumentThree( selectproduct+ parseData.instruments[2] );
                    }
                    if(treasiinfoArrays.length >0){
                        self.isShow(true) ;
                    }
                },
                complete : function(response){

                }
            })
        }else{
            $.ajax({
                async:true,
                dataType:"xml",
                url:  "/sj/jgsj/jgqsj/" + inputInstrument + "/index_1.xml?id="+Math.floor(Math.random()*100) ,
                //  url:  "http://www.cffex.com.cn/fzjy/jgsj/jgqsj/" + inputInstrument + "/index_1.xml" ,
                method: 'GET',

                success: function(response) {
                    var treasiinfoArrays =[];
                    $(response).find("delivtreasiinfo").each(function(){
                        var treasiinfoData = $(this);
                        var instrumentid = $.trim(treasiinfoData.find("instrumentid").text());

                        if (instrumentid === inputInstrument) {
                            //债券全称
                            var fullname = $.trim(treasiinfoData.find("fullname").text());
                            //到期日
                            var expiredate = $.trim(treasiinfoData.find("expiredate").text());
                            //票面利率
                            var rate = $.trim(treasiinfoData.find("rate").text());
                            //交割数量
                            var cf = $.trim(treasiinfoData.find("cf").text());
                            var treasidIB = $.trim(treasiinfoData.find("treasidib").text())==""?$.trim(treasiinfoData.find("treasidIB").text()):$.trim(treasiinfoData.find("treasidib").text());
                            var treasidSH = $.trim(treasiinfoData.find("treasidsh").text())==""?$.trim(treasiinfoData.find("treasidSH").text()):$.trim(treasiinfoData.find("treasidsh").text());
                            var treasidSZ = $.trim(treasiinfoData.find("treasidsz").text())==""?$.trim(treasiinfoData.find("treasidSZ").text()):$.trim(treasiinfoData.find("treasidsz").text());
                            var productid = $.trim(treasiinfoData.find("productid").text());

                            treasiinfoArrays.push({
                                "instrumentid" : instrumentid,
                                "fullname" : fullname,
                                "expiredate" : expiredate,
                                "rate" : Number(rate).toFixed(2),
                                "cf" : cf,
                                "treasidIB" : treasidIB,
                                "treasidSH" : treasidSH,
                                "treasidSZ" : treasidSZ,
                                "productid" : productid
                            })
                        }
                    });
                    self.instabledata(treasiinfoArrays);
                    if(treasiinfoArrays.length >0){
                        self.isShow(true) ;
                    }
                },
                complete : function(response){
                    if(!self.isShow()){
                        self.isHavResult(true);
                    }else{
                        self.download.url("/sj/jgsj/jgqsj/" + inputInstrument + "/" + inputInstrument +  ".csv");
                        self.download.details(inputInstrument+"可交割国债信息");
                    }
                }
            })
        }
    }
}



var main = new kjggzxxViewModel()
ko.applyBindings(main);
main.productChange();
