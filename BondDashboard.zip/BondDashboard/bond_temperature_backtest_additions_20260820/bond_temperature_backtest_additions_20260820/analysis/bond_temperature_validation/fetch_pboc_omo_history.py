from __future__ import annotations

import argparse
import csv
import sqlite3
import sys
import time
from datetime import date
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / "backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

from pboc_omo_crawler import (  # noqa: E402
    backfill_maturity_dates,
    extract_trade_links,
    import_calendar,
    init_db,
    parse_article_records,
    upsert_operation,
)


def export_daily(db_path: Path, output: Path, start: date, end: date) -> int:
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        dates = conn.execute(
            """
            SELECT day FROM (
                SELECT operation_date AS day FROM omo_operations
                UNION
                SELECT maturity_date AS day FROM omo_operations
            )
            WHERE day BETWEEN ? AND ?
            GROUP BY day
            ORDER BY day
            """,
            (start.isoformat(), end.isoformat()),
        ).fetchall()
        rows = []
        last_repo_rate = None
        for item in dates:
            day = item["day"]
            injection = conn.execute(
                "SELECT COALESCE(SUM(award_amount), 0) FROM omo_operations WHERE operation_date = ?",
                (day,),
            ).fetchone()[0]
            maturity = conn.execute(
                "SELECT COALESCE(SUM(award_amount), 0) FROM omo_operations WHERE maturity_date = ?",
                (day,),
            ).fetchone()[0]
            rate = conn.execute(
                "SELECT MAX(rate) FROM omo_operations WHERE operation_date = ? AND term_days = 7",
                (day,),
            ).fetchone()[0]
            if rate is not None:
                last_repo_rate = float(rate)
            rows.append(
                {
                    "date": day,
                    "injection": float(injection),
                    "maturity": float(maturity),
                    "net": float(injection) - float(maturity),
                    "repo_rate_7d": last_repo_rate,
                    "source": "pbc_omo_announcement",
                }
            )
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["date", "injection", "maturity", "net", "repo_rate_7d", "source"],
        )
        writer.writeheader()
        writer.writerows(rows)
    return len(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description="Backfill PBC reverse-repo announcements into an analysis-only database.")
    parser.add_argument("--start", type=date.fromisoformat, default=date(2024, 12, 1))
    parser.add_argument("--end", type=date.fromisoformat, default=date.today())
    parser.add_argument("--pages", type=int, default=30)
    parser.add_argument("--limit", type=int, default=800)
    parser.add_argument("--pause", type=float, default=0.05)
    parser.add_argument(
        "--database",
        type=Path,
        default=Path(__file__).resolve().parent / "raw" / "pboc_omo_history.sqlite",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).resolve().parent / "raw" / "pboc_omo_daily_2025_present.csv",
    )
    args = parser.parse_args()

    init_db(args.database)
    calendar = ROOT / "data" / "interbank_calendar.json"
    if calendar.exists():
        import_calendar(calendar, args.database)
    links = extract_trade_links(pages=args.pages, limit=args.limit, pause_seconds=args.pause)
    print(f"links={len(links)}", flush=True)
    saved = 0
    earliest = None
    for index, link in enumerate(links, start=1):
        try:
            records = parse_article_records(link)
        except Exception as exc:
            print(f"skip index={index} title={link.title} error={exc}", flush=True)
            continue
        for record in records:
            operation_date = record.get("operation_date")
            if not operation_date or record.get("award_amount") is None:
                continue
            earliest = operation_date if earliest is None else min(earliest, operation_date)
            if operation_date <= args.end.isoformat():
                upsert_operation(record, args.database)
                saved += 1
        if index % 25 == 0:
            print(f"progress={index}/{len(links)} saved={saved} earliest={earliest}", flush=True)
        time.sleep(args.pause)
    backfill_maturity_dates(args.database)
    daily_count = export_daily(args.database, args.output, args.start, args.end)
    print(f"saved={saved} earliest={earliest} daily_rows={daily_count}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
