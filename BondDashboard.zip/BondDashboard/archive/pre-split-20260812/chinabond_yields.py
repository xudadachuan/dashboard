from __future__ import annotations

import json
import ssl
from datetime import date, datetime, timedelta
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from market_database import load_payload_snapshot, save_payload_snapshot


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
CACHE_FILE = DATA_DIR / "chinabond_yields_cache.json"
SEARCH_URL = "https://yield.chinabond.com.cn/cbweb-mn/yc/searchYc"
REFERER = "https://yield.chinabond.com.cn/cbweb-mn/"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BondDashboard/1.0"
NETWORK_TIMEOUT_SECONDS = 10
MEMORY_TTL_SECONDS = 600

TREASURY_ID = "2c9081e50a2f9606010a3068cae70001"
CDB_ID = "8a8b2ca037a7ca910137bfaa94fa5057"
CURVES = {
    "treasury": {"id": TREASURY_ID, "label": "国债", "name": "中债国债收益率曲线"},
    "cdb": {"id": CDB_ID, "label": "国开", "name": "中债国开债收益率曲线"},
}
CURVE_BY_ID = {item["id"]: key for key, item in CURVES.items()}
CHART_TERMS = [
    (0.25, "3M"),
    (0.5, "6M"),
    (1.0, "1Y"),
    (3.0, "3Y"),
    (5.0, "5Y"),
    (7.0, "7Y"),
    (10.0, "10Y"),
    (30.0, "30Y"),
]
CARD_SPECS = [
    ("treasury10", "10年国债", "treasury", 10.0),
    ("cdb10", "10年国开", "cdb", 10.0),
    ("treasury30", "30年国债", "treasury", 30.0),
    ("cdb3", "3年国开", "cdb", 3.0),
    ("treasury7", "7年国债", "treasury", 7.0),
]
_MEMORY_CACHE: tuple[datetime, dict] | None = None


def load_cache() -> dict:
    if not CACHE_FILE.exists():
        return {}
    try:
        payload = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}
    return payload if isinstance(payload, dict) else {}


def save_cache(payload: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    CACHE_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def post_form(body: dict) -> list[dict]:
    context = ssl.create_default_context()
    if hasattr(ssl, "OP_LEGACY_SERVER_CONNECT"):
        context.options |= ssl.OP_LEGACY_SERVER_CONNECT
    request = Request(
        SEARCH_URL,
        data=urlencode(body).encode("utf-8"),
        headers={
            "User-Agent": USER_AGENT,
            "Referer": REFERER,
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        },
        method="POST",
    )
    raw = urlopen(request, timeout=NETWORK_TIMEOUT_SECONDS, context=context).read()
    payload = json.loads(raw.decode("utf-8"))
    return payload if isinstance(payload, list) else []


def nearest_value(series: list[list[float]], term: float) -> float | None:
    if not series:
        return None
    best = min(series, key=lambda point: abs(float(point[0]) - term))
    if abs(float(best[0]) - term) > 0.03:
        return None
    return round(float(best[1]), 4)


def normalize_series(series: list[list[float]]) -> list[dict]:
    points = []
    for years, value in series:
        try:
            points.append({"years": float(years), "value": round(float(value), 4)})
        except (TypeError, ValueError):
            continue
    return points


def fetch_for_date(work_date: date) -> dict | None:
    body = {
        "xyzSelect": "txy",
        "workTimes": work_date.isoformat(),
        "dxbj": "0",
        "qxll": "0,",
        "yqqxN": "N",
        "yqqxK": "K",
        "ycDefIds": f"{TREASURY_ID},{CDB_ID}",
        "wrjxCBFlag": "0",
        "locale": "zh_CN",
    }
    rows = post_form(body)
    curves: dict[str, dict] = {}
    for row in rows:
        curve_key = CURVE_BY_ID.get(str(row.get("ycDefId") or ""))
        series = row.get("seriesData") or []
        if not curve_key or not series:
            continue
        curves[curve_key] = {
            "date": row.get("worktime") or work_date.isoformat(),
            "name": row.get("ycDefName") or CURVES[curve_key]["name"],
            "series": normalize_series(series),
            "keyRates": {
                label: nearest_value(series, years)
                for years, label in CHART_TERMS
            },
        }
    if len(curves) < 2:
        return None
    return {"date": work_date.isoformat(), "curves": curves}


def previous_calendar_dates(start: date, max_days: int = 14) -> list[date]:
    return [start - timedelta(days=offset) for offset in range(max_days)]


def build_payload(days: list[dict], source: str = "chinabond", error: str | None = None) -> dict:
    latest = days[0]
    previous = days[1] if len(days) > 1 else None
    curves: dict[str, dict] = {}
    for curve_key, curve_meta in CURVES.items():
        latest_curve = latest["curves"].get(curve_key, {})
        previous_curve = (previous or {}).get("curves", {}).get(curve_key, {})
        points = []
        for years, label in CHART_TERMS:
            today_value = (latest_curve.get("keyRates") or {}).get(label)
            previous_value = (previous_curve.get("keyRates") or {}).get(label)
            points.append({
                "term": label,
                "years": years,
                "today": today_value,
                "previous": previous_value,
                "changeBp": round((today_value - previous_value) * 100, 2) if today_value is not None and previous_value is not None else None,
            })
        curves[curve_key] = {
            "label": curve_meta["label"],
            "name": latest_curve.get("name") or curve_meta["name"],
            "points": points,
            "date": latest.get("date"),
            "previousDate": (previous or {}).get("date"),
        }

    cards = []
    for key, label, curve_key, years in CARD_SPECS:
        term_label = f"{int(years)}Y"
        point = next((item for item in curves[curve_key]["points"] if item["years"] == years), None)
        cards.append({
            "key": key,
            "label": label,
            "curve": curve_key,
            "term": term_label,
            "value": (point or {}).get("today"),
            "changeBp": (point or {}).get("changeBp"),
            "source": "中债估值",
        })
    return {
        "date": latest.get("date"),
        "previousDate": (previous or {}).get("date"),
        "curves": curves,
        "cards": cards,
        "source": source,
        "error": error,
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
    }


def fetch_chinabond_yields() -> dict:
    today = date.today()
    available: list[dict] = []
    for work_date in previous_calendar_dates(today):
        try:
            payload = fetch_for_date(work_date)
        except Exception:
            continue
        if payload:
            available.append(payload)
        if len(available) >= 2:
            break
    if len(available) < 2:
        raise RuntimeError("ChinaBond yield curve data unavailable")
    return build_payload(available)


def query_chinabond_yields(refresh: bool = False) -> dict:
    global _MEMORY_CACHE
    if not refresh:
        stored = load_payload_snapshot("chinabond_yields")
        if stored:
            return stored

    if _MEMORY_CACHE:
        cached_at, payload = _MEMORY_CACHE
        if (datetime.now() - cached_at).total_seconds() < MEMORY_TTL_SECONDS:
            return payload
    try:
        payload = fetch_chinabond_yields()
        save_cache(payload)
        save_payload_snapshot("chinabond_yields", payload)
        _MEMORY_CACHE = (datetime.now(), payload)
        return payload
    except Exception as exc:
        stored = load_payload_snapshot("chinabond_yields")
        if stored:
            payload = {**stored, "source": "cache", "error": str(exc)}
            _MEMORY_CACHE = (datetime.now(), payload)
            return payload
        fallback = load_cache()
        if fallback.get("curves"):
            payload = {**fallback, "source": "cache", "error": str(exc)}
            save_payload_snapshot("chinabond_yields", payload)
            _MEMORY_CACHE = (datetime.now(), payload)
            return payload
        payload = {
            "date": None,
            "previousDate": None,
            "curves": {},
            "cards": [],
            "source": "unavailable",
            "error": str(exc),
            "updatedAt": datetime.now().isoformat(timespec="seconds"),
        }
        _MEMORY_CACHE = (datetime.now(), payload)
        return payload
