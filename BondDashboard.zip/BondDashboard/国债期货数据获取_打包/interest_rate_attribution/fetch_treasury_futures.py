from __future__ import annotations

"""国债期货数据获取命令行入口。

第一阶段：合约列表 + 日行情 + 主力识别 + 价格动量 + 持仓量变化。
CTD / Level-2 / 账户持仓属于第二至第四阶段，本入口仅保留表结构与 DEFERRED 标记。

用法：
  python fetch_treasury_futures.py --config config/ --output-dir outputs/futures/ \
      --as-of-date 2026-08-15 --probe --product T
"""

import argparse
import json
from pathlib import Path
import sys

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parent
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from interest_rate_attribution.config import load_config
from interest_rate_attribution.adapters.ifind_futures import (
    DEFERRED,
    ESTIMATED,
    EXACT,
    PRODUCTS,
    IFindFuturesClient,
    TreasuryFuturesAdapter,
)
from interest_rate_attribution.factors.futures import (
    build_open_interest_change,
    build_price_momentum,
    identify_dominant_contracts,
)


def _write_csv(frame: pd.DataFrame, output_dir: Path, name: str) -> None:
    frame.to_csv(output_dir / name, index=False, encoding="utf-8-sig")


def _empty_deferred_tables() -> dict[str, pd.DataFrame]:
    """第二至第四阶段表结构占位，标记 DEFERRED。"""
    return {
        "deliverable_bond_mapping": pd.DataFrame(
            columns=[
                "contract_code", "bond_code", "conversion_factor", "delivery_month",
                "first_delivery_date", "last_delivery_date", "mapping_effective_from",
                "mapping_effective_to", "source", "retrieved_at", "calculation_status",
            ]
        ),
        "ctd_candidate_daily": pd.DataFrame(
            columns=[
                "trade_date", "contract_code", "bond_code", "gross_basis",
                "net_basis", "irr", "irr_funding_gap", "calculation_status",
            ]
        ),
        "ctd_daily": pd.DataFrame(
            columns=[
                "trade_date", "contract_code", "ctd_bond_code", "second_best_bond_code",
                "ctd_switch_gap", "ctd_bond_dv01_per_100",
                "ctd_futures_equivalent_dv01", "ctd_contract_dv01", "calculation_status",
            ]
        ),
        "execution_cost_simulation": pd.DataFrame(
            columns=[
                "trade_date", "contract_code", "direction", "target_lots",
                "bid_ask_cost", "depth_slippage", "market_impact", "commission",
                "exchange_fee", "total_execution_cost", "unfilled_quantity",
                "calculation_status",
            ]
        ),
        "account_futures_position_daily": pd.DataFrame(
            columns=[
                "account_id", "portfolio_id", "valuation_date", "contract_code",
                "long_short", "position_lots", "available_lots", "average_cost",
                "margin", "calculation_status",
            ]
        ),
        "account_futures_trade_detail": pd.DataFrame(
            columns=[
                "order_id", "trade_id", "contract_code", "trade_time", "buy_sell",
                "open_close", "fill_price", "fill_lots", "commission", "strategy_id",
            ]
        ),
    }


def run(
    config_dir: Path,
    output_dir: Path,
    as_of_date: str,
    start: str,
    end: str,
    probe: bool,
    product: str | None,
) -> int:
    config = load_config(config_dir)
    futures_config = config.get("ifind_futures_fields", {})
    output_dir.mkdir(parents=True, exist_ok=True)

    client = IFindFuturesClient(raw_cache_dir=output_dir / "raw")
    adapter = TreasuryFuturesAdapter(futures_config, client=client)
    summary: dict[str, object] = {
        "source": "ifind",
        "as_of_date": as_of_date,
        "updated_at": pd.Timestamp.now(tz="Asia/Shanghai").isoformat(),
        "phase": 1,
        "products": list(PRODUCTS),
    }

    try:
        # -- 探针 ----------------------------------------------------------
        if probe:
            probe_product = product or "T"
            records = adapter.probe(probe_product, as_of_date)
            probe_df = pd.DataFrame([r.as_dict() for r in records])
            _write_csv(probe_df, output_dir, "ifind_futures_probe.csv")
            summary["probe_rows"] = len(probe_df)

        # -- 合约列表 ------------------------------------------------------
        contract_master, list_status = adapter.fetch_contract_list(as_of_date)
        _write_csv(contract_master, output_dir, "futures_contract_master.csv")
        summary["contract_list_status"] = list_status
        summary["contract_count"] = len(contract_master)

        # -- 日行情 --------------------------------------------------------
        codes = contract_master["contract_code"].tolist() if not contract_master.empty else []
        daily, daily_status = adapter.fetch_daily_quotes(codes, start, end)
        _write_csv(daily, output_dir, "futures_daily.csv")
        summary["daily_quote_status"] = daily_status

        # -- 第一阶段指标 --------------------------------------------------
        dominant = identify_dominant_contracts(daily)
        _write_csv(dominant, output_dir, "futures_dominant.csv")
        summary["dominant_status"] = EXACT if not dominant.empty else DEFERRED

        momentum = build_price_momentum(daily)
        _write_csv(momentum, output_dir, "futures_price_momentum.csv")
        summary["momentum_status"] = EXACT if not momentum.empty else DEFERRED

        position_change = build_open_interest_change(daily)
        _write_csv(position_change, output_dir, "futures_position_change.csv")
        summary["position_change_status"] = EXACT if not position_change.empty else DEFERRED

        # -- 第二至第四阶段表结构占位 -------------------------------------
        deferred_tables = _empty_deferred_tables()
        for name, frame in deferred_tables.items():
            _write_csv(frame, output_dir, f"{name}.csv")
        summary["deferred_tables"] = list(deferred_tables.keys())

        # -- 探针审计表 ---------------------------------------------------
        if client.probe_records:
            _write_csv(
                pd.DataFrame([r.as_dict() for r in client.probe_records]),
                output_dir, "ifind_futures_probe_audit.csv",
            )
    finally:
        client.close()

    (output_dir / "run_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, default=str), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2, default=str))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="获取中金所国债期货第一阶段数据")
    parser.add_argument("--config", required=True, help="config 目录")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--as-of-date", default=pd.Timestamp.today().strftime("%Y-%m-%d"))
    parser.add_argument("--start", default=None, help="日行情起始日期，默认 as-of 前一年")
    parser.add_argument("--end", default=None, help="日行情结束日期，默认 as-of")
    parser.add_argument("--probe", action="store_true", help="对单个合约做接口探针")
    parser.add_argument("--product", choices=PRODUCTS, default=None)
    args = parser.parse_args(argv)

    start = args.start or (pd.Timestamp(args.as_of_date) - pd.Timedelta(days=365)).strftime("%Y-%m-%d")
    end = args.end or args.as_of_date
    return run(
        Path(args.config),
        Path(args.output_dir),
        args.as_of_date,
        start,
        end,
        args.probe,
        args.product,
    )


if __name__ == "__main__":
    raise SystemExit(main())
