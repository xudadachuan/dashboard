# Windows ECS deployment

完整的环境要求、下载清单和部署命令见 [WINDOWS_SERVER_ENVIRONMENT.md](../../WINDOWS_SERVER_ENVIRONMENT.md)。

1. Upload and extract `bond-dashboard-windows.zip` to `C:\BondDashboard`.
2. Open an elevated PowerShell and run `Set-ExecutionPolicy -Scope Process Bypass`.
3. Run `C:\BondDashboard\deploy\windows\install.ps1`.
4. Fill the secret values in `C:\BondDashboard\.env` directly on the server. Do not upload a local `.env` or `管理员账户.txt`.
5. Run `C:\BondDashboard\deploy\windows\verify.ps1 -PublicIp <public-ip>`.

The installer registers the backend, Caddy, and four update jobs as `SYSTEM` scheduled tasks so they continue to run when nobody is signed in. Port 80 must also be allowed by the Alibaba Cloud security group. Add a domain before enabling HTTPS/443.
