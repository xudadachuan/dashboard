from __future__ import annotations

import argparse
import json
import re
import sqlite3
from datetime import date, datetime, timedelta
from html import unescape
from pathlib import Path
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT.parent / "data"
DB_PATH = DATA_DIR / "bond_market.db"
SOURCES_FILE = DATA_DIR / "central_bank_sources.json"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BondDashboard/1.0"


def text(value: str) -> str:
    value = unescape(value).replace("\ufeff", " ")
    value = re.sub(r"<script[\s\S]*?</script>", " ", value, flags=re.I)
    value = re.sub(r"<style[\s\S]*?</style>", " ", value, flags=re.I)
    value = re.sub(r"<[^>]+>", " ", value)
    value = value.replace("\u3000", " ")
    return re.sub(r"\s+", " ", value).strip()


def fetch_text(url: str) -> str:
    req = Request(url, headers={"User-Agent": USER_AGENT})
    raw = urlopen(req, timeout=30).read()
    for encoding in ("utf-8", "gb18030", "gbk"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="ignore")


def extract_links(html: str, base_url: str) -> list[tuple[str, str]]:
    links = []
    for match in re.finditer(r"<a[^>]+href=[\"']([^\"']+)[\"'][^>]*>([\s\S]{0,500}?)</a>", html, flags=re.I):
        href = urljoin(base_url, match.group(1))
        title = text(match.group(2))
        if title:
            links.append((title, href))
    return links


def extract_pagination_urls(html: str, base_url: str) -> list[str]:
    urls = []
    for match in re.finditer(r"(?:onclick|tagname)=[\"'][^\"']*?(/[^\"']+?\.html)[\"']", html, flags=re.I):
        url = urljoin(base_url, match.group(1))
        if url not in urls:
            urls.append(url)
    return urls


def init_tools_db(db_path: Path = DB_PATH) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS central_bank_operations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tool_type TEXT NOT NULL,
                announcement_no TEXT,
                title TEXT NOT NULL,
                operation_date TEXT,
                maturity_date TEXT,
                term_days INTEGER,
                amount REAL,
                rate REAL,
                bid_amount REAL,
                award_amount REAL,
                price REAL,
                direction TEXT,
                source_url TEXT NOT NULL UNIQUE,
                raw_text TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_cbo_tool_date ON central_bank_operations(tool_type, operation_date)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_cbo_maturity ON central_bank_operations(maturity_date)")


def operation_source_url(record: dict) -> str:
    url = record.get("source_url")
    suffix = record.get("source_suffix")
    if suffix and url and "#" not in url:
        return f"{url}#{suffix}"
    return url


def add_months(day: date, months: int) -> date:
    month_index = day.month - 1 + months
    year = day.year + month_index // 12
    month = month_index % 12 + 1
    month_lengths = [31, 29 if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    return date(year, month, min(day.day, month_lengths[month - 1]))


def next_interbank_business_day(day: date, db_path: Path = DB_PATH) -> date:
    try:
        from pboc_omo_crawler import next_business_day

        return next_business_day(day, db_path)
    except Exception:
        while day.weekday() >= 5:
            day += timedelta(days=1)
        return day


def is_interbank_business_day(day: date, db_path: Path = DB_PATH) -> bool:
    try:
        from pboc_omo_crawler import is_business_day

        return is_business_day(day, db_path)
    except Exception:
        return day.weekday() < 5


def business_day_window(cutoff: date, days_before: int, days_after: int, db_path: Path = DB_PATH) -> list[date]:
    previous_days: list[date] = []
    cursor = cutoff - timedelta(days=1)
    while len(previous_days) < days_before:
        if is_interbank_business_day(cursor, db_path):
            previous_days.append(cursor)
        cursor -= timedelta(days=1)

    future_days: list[date] = []
    cursor = cutoff + timedelta(days=1)
    while len(future_days) < days_after:
        if is_interbank_business_day(cursor, db_path):
            future_days.append(cursor)
        cursor += timedelta(days=1)

    return [*reversed(previous_days), cutoff, *future_days]


def infer_maturity_date(record: dict, db_path: Path = DB_PATH) -> str | None:
    if record.get("maturity_date"):
        return record.get("maturity_date")
    operation_date = record.get("operation_date")
    if not operation_date:
        return None

    start = datetime.fromisoformat(operation_date).date()
    raw_text = record.get("raw_text") or ""
    title = record.get("title") or ""
    haystack = f"{title} {raw_text}"

    if re.search(r"隔夜\s*逆回购|overnight\s+reverse\s+repo", haystack, flags=re.I):
        natural = start + timedelta(days=1)
    elif re.search(r"1\s*年期|one\s+year", haystack, flags=re.I):
        natural = add_months(start, 12)
    elif match := re.search(r"(\d+)\s*个月", haystack):
        natural = add_months(start, int(match.group(1)))
    elif match := re.search(r"(\d+)\s*天", haystack):
        natural = start + timedelta(days=int(match.group(1)))
    elif record.get("term_days"):
        term_days = int(record["term_days"])
        if record.get("tool_type") == "mlf" and 360 <= term_days <= 366:
            natural = add_months(start, 12)
        else:
            natural = start + timedelta(days=term_days)
    else:
        return None

    return next_interbank_business_day(natural, db_path).isoformat()


def upsert_tool_operation(record: dict, db_path: Path = DB_PATH) -> None:
    init_tools_db(db_path)
    now = datetime.now().isoformat(timespec="seconds")
    record["maturity_date"] = infer_maturity_date(record, db_path)
    fields = {
        "tool_type": None,
        "announcement_no": None,
        "title": None,
        "operation_date": None,
        "maturity_date": None,
        "term_days": None,
        "amount": None,
        "rate": None,
        "bid_amount": None,
        "award_amount": None,
        "price": None,
        "direction": None,
        "source_url": None,
        "raw_text": None,
        **record,
        "source_url": operation_source_url(record),
        "created_at": now,
        "updated_at": now,
    }
    with sqlite3.connect(db_path) as conn:
        conn.execute(
            """
            INSERT INTO central_bank_operations (
                tool_type, announcement_no, title, operation_date, maturity_date,
                term_days, amount, rate, bid_amount, award_amount, price, direction,
                source_url, raw_text, created_at, updated_at
            ) VALUES (
                :tool_type, :announcement_no, :title, :operation_date, :maturity_date,
                :term_days, :amount, :rate, :bid_amount, :award_amount, :price, :direction,
                :source_url, :raw_text, :created_at, :updated_at
            )
            ON CONFLICT(source_url) DO UPDATE SET
                tool_type=excluded.tool_type,
                announcement_no=excluded.announcement_no,
                title=excluded.title,
                operation_date=excluded.operation_date,
                maturity_date=excluded.maturity_date,
                term_days=excluded.term_days,
                amount=excluded.amount,
                rate=excluded.rate,
                bid_amount=excluded.bid_amount,
                award_amount=excluded.award_amount,
                price=excluded.price,
                direction=excluded.direction,
                raw_text=excluded.raw_text,
                updated_at=excluded.updated_at
            """,
            fields,
        )


def migrate_reverse_repo(db_path: Path = DB_PATH) -> int:
    init_tools_db(db_path)
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            """
            SELECT announcement_no, title, operation_date, maturity_date, term_days,
                   rate, bid_amount, award_amount, source_url, raw_text
            FROM omo_operations
            """
        ).fetchall()

    count = 0
    for row in rows:
        # A zero allotment is still an official announcement and must be
        # migrated to preserve an explicit zero-operation day.
        amount = row["award_amount"] if row["award_amount"] is not None else row["bid_amount"]
        upsert_tool_operation(
            {
                "tool_type": "reverse_repo",
                "announcement_no": row["announcement_no"],
                "title": row["title"],
                "operation_date": row["operation_date"],
                "maturity_date": row["maturity_date"],
                "term_days": row["term_days"],
                "amount": amount,
                "rate": row["rate"],
                "bid_amount": row["bid_amount"],
                "award_amount": row["award_amount"],
                "direction": "injection",
                "source_url": row["source_url"],
                "raw_text": row["raw_text"],
            },
            db_path,
        )
        count += 1
    return count


def chinese_date(value: str) -> str | None:
    m = re.search(r"(\d{4})年(\d{1,2})月(\d{1,2})日", value)
    if not m:
        return None
    y, mth, d = map(int, m.groups())
    return f"{y:04d}-{mth:02d}-{d:02d}"


def english_date(value: str) -> str | None:
    months = {
        "january": 1,
        "february": 2,
        "march": 3,
        "april": 4,
        "may": 5,
        "june": 6,
        "july": 7,
        "august": 8,
        "september": 9,
        "october": 10,
        "november": 11,
        "december": 12,
    }
    match = re.search(
        r"\b("
        + "|".join(months)
        + r")\s+(\d{1,2}),\s*(\d{4})\b",
        value,
        flags=re.I,
    )
    if not match:
        return None
    return f"{int(match.group(3)):04d}-{months[match.group(1).lower()]:02d}-{int(match.group(2)):02d}"


def mlf_operation_date(value: str) -> str | None:
    """Prefer the actual operation date in MLF notices over page publish dates."""
    match = re.search(
        r"\bon\s+([A-Z][a-z]+\s+\d{1,2},\s*20\d{2})\s*,?\s+(?:conduct|conducted|carry out|offer|provide)",
        value,
        flags=re.I,
    )
    if match:
        return english_date(match.group(1))

    match = re.search(r"(20\d{2}年\d{1,2}月\d{1,2}日)[^。]{0,80}(?:开展|进行)[^。]{0,80}(?:中期借贷便利|MLF)", value, flags=re.I)
    if match:
        return chinese_date(match.group(1))

    return chinese_date(value) or english_date(value)


def first_amount(value: str) -> float | None:
    english = re.search(r"RMB\s*([0-9,，.]+)\s*billion", value, flags=re.I)
    if english:
        return float(english.group(1).replace(",", "").replace("，", "")) * 10

    m = re.search(r"([0-9,，.]+)\s*亿元", value)
    if not m:
        return None
    return float(m.group(1).replace(",", "").replace("，", ""))


def all_amounts(value: str) -> list[float]:
    amounts = []
    for match in re.finditer(r"([0-9,，.]+)\s*亿元", value):
        amounts.append(float(match.group(1).replace(",", "").replace("，", "")))
    for match in re.finditer(r"RMB\s*([0-9,，.]+)\s*billion", value, flags=re.I):
        amounts.append(float(match.group(1).replace(",", "").replace("，", "")) * 10)
    return amounts


def first_rate(value: str) -> float | None:
    m = re.search(r"(\d+)\s*\.\s*(\d+)\s*%", value)
    if m:
        return float(f"{m.group(1)}.{m.group(2)}")
    m = re.search(r"(\d+(?:\.\d+)?)\s*%", value)
    return float(m.group(1)) if m else None


def first_iso_date(value: str) -> str | None:
    match = re.search(r"(20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})", value)
    if not match:
        return None
    return f"{int(match.group(1)):04d}-{int(match.group(2)):02d}-{int(match.group(3)):02d}"


def term_to_days(value: str) -> int | None:
    if re.search(r"隔夜\s*逆回购|overnight\s+reverse\s+repo", value, flags=re.I):
        return 1
    if re.search(r"one\s+year", value, flags=re.I):
        return 365
    if re.search(r"1\s*年", value):
        return 365
    m = re.search(r"(\d+)\s*个月", value)
    if m:
        return int(m.group(1)) * 30
    m = re.search(r"(\d+)\s*天", value)
    if m:
        return int(m.group(1))
    return None


def outright_reverse_repo_operation_date(value: str) -> str | None:
    match = re.search(
        r"(20\d{2}年\d{1,2}月\d{1,2}日)[^。]{0,120}(?:开展|进行)[^。]{0,80}买断式逆回购",
        value,
    )
    if match:
        return chinese_date(match.group(1))
    match = re.search(
        r"\bon\s+([A-Z][a-z]+\s+\d{1,2},\s*20\d{2})[^.]{0,160}(?:conduct|conducted|carry out)[^.]{0,120}outright\s+reverse\s+repo",
        value,
        flags=re.I,
    )
    if match:
        return english_date(match.group(1))
    return chinese_date(value) or english_date(value)


def outright_reverse_repo_maturity_date(value: str) -> str | None:
    match = re.search(r"到期日为\s*(20\d{2}年\d{1,2}月\d{1,2}日)", value)
    if match:
        return chinese_date(match.group(1))
    match = re.search(r"maturity\s+date\s+(?:is|of)?\s*([A-Z][a-z]+\s+\d{1,2},\s*20\d{2})", value, flags=re.I)
    if match:
        return english_date(match.group(1))
    return None


def outright_reverse_repo_term_days(value: str) -> int | None:
    match = re.search(r"期限为[^。；;]{0,40}?（\s*(\d+)\s*天\s*）", value)
    if match:
        return int(match.group(1))
    match = re.search(r"期限为[^。；;]{0,40}?\(\s*(\d+)\s*days?\s*\)", value, flags=re.I)
    if match:
        return int(match.group(1))
    return term_to_days(value)


def term_to_months(value: str) -> int | None:
    if re.search(r"one\s+year|1\s*年", value, flags=re.I):
        return 12
    match = re.search(r"(\d+)\s*个月", value)
    if match:
        return int(match.group(1))
    return None


def infer_direction(raw: str, default: str = "injection") -> str:
    if re.search(r"卖出|出售|sell|sold", raw, flags=re.I):
        return "withdrawal"
    if re.search(r"买入|购买|buy|bought|purchase", raw, flags=re.I):
        return "injection"
    return default


def parse_mlf_article(url: str, title_hint: str | None = None) -> dict | None:
    html = fetch_text(url)
    raw = text(html)
    title = title_hint or ""
    title_match = re.search(r"(?:中期借贷便利|MLF)[^。]{0,80}", raw, flags=re.I)
    if not title and title_match:
        title = title_match.group(0)

    if "中期借贷便利" not in raw and "MLF" not in raw.upper():
        return None

    amount = first_amount(raw)
    operation_date = mlf_operation_date(raw)
    return {
        "tool_type": "mlf",
        "announcement_no": None,
        "title": title or "中期借贷便利公告",
        "operation_date": operation_date,
        "maturity_date": None,
        "term_days": term_to_days(raw),
        "amount": amount,
        "rate": first_rate(raw),
        "bid_amount": None,
        "award_amount": amount,
        "price": None,
        "direction": "injection",
        "source_url": url,
        "raw_text": raw[:20000],
    }


def parse_mlf_articles(url: str, title_hint: str | None = None) -> list[dict]:
    """解析 MLF 公告。

    有些公告同一天会包含两笔操作，甚至一个页面里同时写“买断式逆回购”和
    “MLF”。这里先把正文里所有 RMB/billion 或“亿元”金额识别出来；
    若只有一笔，保持原逻辑；若多笔，则拆成多条 source_url#mlf-N 入库。
    """
    html = fetch_text(url)
    raw = text(html)
    if "中期借贷便利" not in raw and "MLF" not in raw.upper():
        return []

    title = title_hint or ""
    title_match = re.search(r"(?:中期借贷便利|MLF)[^。]{0,100}", raw, flags=re.I)
    if not title and title_match:
        title = title_match.group(0)

    operation_date = mlf_operation_date(raw)
    term_days = term_to_days(raw)
    rate = first_rate(raw)
    amounts = all_amounts(raw)
    if not amounts:
        return []

    # 页面模板、导航里偶尔会出现无关数字。MLF 金额通常较大，先过滤掉明显不是
    # 操作规模的小数；保留去重后的顺序。
    cleaned = []
    for amount in amounts:
        if amount <= 0:
            continue
        if amount not in cleaned:
            cleaned.append(amount)

    records = []
    for index, amount in enumerate(cleaned, start=1):
        records.append(
            {
                "tool_type": "mlf",
                "announcement_no": None,
                "title": title or "中期借贷便利公告",
                "operation_date": operation_date,
                "maturity_date": None,
                "term_days": term_days,
                "amount": amount,
                "rate": rate,
                "bid_amount": None,
                "award_amount": amount,
                "price": None,
                "direction": "injection",
                "source_url": url,
                "source_suffix": f"mlf-{index}",
                "raw_text": raw[:20000],
            }
        )
    return records


def discover_mlf_urls_from_column(column_url: str, limit: int = 24) -> list[dict]:
    html = fetch_text(column_url)
    found = []
    seen = set()
    for title, href in extract_links(html, column_url):
        if not ("中期借贷便利" in title or "MLF" in title.upper()):
            continue
        # 保留公告/操作表，过滤导航项本身。
        if not any(key in title for key in ("公告", "操作表", "操作")):
            continue
        if href in seen:
            continue
        seen.add(href)
        found.append({"title": title, "url": href})
        if len(found) >= limit:
            break
    return found


def discover_urls_from_search(search_url: str, keywords: list[str], limit: int = 20) -> list[dict]:
    html = fetch_text(search_url)
    found = []
    seen = set()
    for title, href in extract_links(html, search_url):
        haystack = title.upper()
        if not any(keyword.upper() in haystack for keyword in keywords):
            continue
        if href in seen:
            continue
        seen.add(href)
        found.append({"title": title, "url": href})
        if len(found) >= limit:
            break
    return found


def discover_urls_from_column(column_url: str, keywords: list[str], limit: int = 30) -> list[dict]:
    html = fetch_text(column_url)
    found = []
    seen = set()
    for title, href in extract_links(html, column_url):
        haystack = title.upper()
        if not any(keyword.upper() in haystack for keyword in keywords):
            continue
        if href in seen or href == column_url:
            continue
        seen.add(href)
        found.append({"title": title, "url": href})
        if len(found) >= limit:
            break
    return found


def column_page_urls(column_url: str, pages: int = 4) -> list[str]:
    parsed = urlparse(column_url)
    filename = Path(parsed.path).name
    if not filename.startswith("index"):
        return [column_url]
    base = column_url.rsplit("/", 1)[0]
    urls = [column_url]
    for page in range(1, pages):
        urls.append(f"{base}/index{page}.html")
        urls.append(f"{base}/index_{page}.html")
    return urls


def discover_urls_from_column_pages(column_url: str, keywords: list[str], limit: int = 80, pages: int = 4) -> list[dict]:
    found = []
    seen = set()
    page_urls = column_page_urls(column_url, pages)
    try:
        html = fetch_text(column_url)
        for page_url in extract_pagination_urls(html, column_url):
            if page_url not in page_urls:
                page_urls.append(page_url)
    except Exception:
        pass
    for page_url in page_urls:
        try:
            page_items = discover_urls_from_column(page_url, keywords, limit=limit)
        except Exception:
            continue
        for item in page_items:
            url = item.get("url")
            if not url or url in seen:
                continue
            seen.add(url)
            found.append(item)
            if len(found) >= limit:
                return found
    return found


def discover_mlf_urls_from_search(search_url: str, limit: int = 20) -> list[dict]:
    return discover_urls_from_search(search_url, ["MLF", "中期借贷便利"], limit)


def sync_mlf_from_sources(sources_file: Path = SOURCES_FILE) -> int:
    if not sources_file.exists():
        return 0
    payload = json.loads(sources_file.read_text(encoding="utf-8"))
    urls = list(payload.get("mlf_urls", []))
    for column_url in payload.get("mlf_column_urls", []):
        urls.extend(discover_mlf_urls_from_column(column_url))
    for search_url in payload.get("mlf_search_urls", []):
        urls.extend(discover_mlf_urls_from_search(search_url))
    count = 0
    for item in urls:
        if isinstance(item, str):
            url, title = item, None
        else:
            url, title = item.get("url"), item.get("title")
        if not url:
            continue
        records = parse_mlf_articles(url, title)
        for record in records:
            if record.get("operation_date") and record.get("amount") is not None:
                upsert_tool_operation(record)
                count += 1
    return count


def clear_tool(tool_type: str, db_path: Path = DB_PATH) -> int:
    init_tools_db(db_path)
    with sqlite3.connect(db_path) as conn:
        cursor = conn.execute("DELETE FROM central_bank_operations WHERE tool_type = ?", (tool_type,))
        return cursor.rowcount


def parse_treasury_cash_deposit_article(url: str, title_hint: str | None = None) -> dict | None:
    html = fetch_text(url)
    raw = text(html)
    if not any(key in raw for key in ("国库现金", "中央国库现金管理", "商业银行定期存款")):
        return None
    amount = first_amount(raw)
    operation_date = chinese_date(raw) or english_date(raw)
    return {
        "tool_type": "treasury_cash_deposit",
        "announcement_no": None,
        "title": title_hint or "中央国库现金管理商业银行定期存款",
        "operation_date": operation_date,
        "maturity_date": None,
        "term_days": term_to_days(raw),
        "amount": amount,
        "rate": first_rate(raw),
        "bid_amount": None,
        "award_amount": amount,
        "price": None,
        "direction": "injection",
        "source_url": url,
        "raw_text": raw[:20000],
    }


def parse_gov_bond_trade_article(url: str, title_hint: str | None = None) -> dict | None:
    html = fetch_text(url)
    raw = text(html)
    if not any(key in raw for key in ("国债买卖", "国债交易", "国债买入", "国债卖出", "government bond transaction")):
        return None
    if re.search(r"未开展[^。]{0,20}国债买卖|未开展[^。]{0,20}国债交易", raw):
        return None
    amount = first_amount(raw)
    operation_date = first_iso_date(raw) or chinese_date(raw) or english_date(raw)
    return {
        "tool_type": "gov_bond_trade",
        "announcement_no": None,
        "title": title_hint or "央行国债买卖公告",
        "operation_date": operation_date,
        "maturity_date": None,
        "term_days": None,
        "amount": amount,
        "rate": None,
        "bid_amount": None,
        "award_amount": amount,
        "price": None,
        "direction": infer_direction(raw),
        "source_url": url,
        "raw_text": raw[:20000],
    }


def parse_outright_reverse_repo_article(url: str, title_hint: str | None = None) -> dict | None:
    html = fetch_text(url)
    raw = text(html)
    if "买断式逆回购" not in raw:
        return None
    amount = first_amount(raw)
    operation_date = outright_reverse_repo_operation_date(raw)
    return {
        "tool_type": "outright_reverse_repo",
        "announcement_no": None,
        "title": title_hint or "买断式逆回购公告",
        "operation_date": operation_date,
        "maturity_date": outright_reverse_repo_maturity_date(raw),
        "term_days": outright_reverse_repo_term_days(raw),
        "amount": amount,
        "rate": first_rate(raw),
        "bid_amount": None,
        "award_amount": amount,
        "price": None,
        "direction": "injection",
        "source_url": url,
        "raw_text": raw[:20000],
    }


def sync_generic_from_sources(
    tool_type: str,
    parser,
    search_key: str,
    manual_key: str,
    keywords: list[str],
    sources_file: Path = SOURCES_FILE,
) -> int:
    if not sources_file.exists():
        return 0
    payload = json.loads(sources_file.read_text(encoding="utf-8"))
    urls = list(payload.get(manual_key, []))
    for search_url in payload.get(search_key, []):
        urls.extend(discover_urls_from_search(search_url, keywords))
    count = 0
    seen = set()
    for item in urls:
        if isinstance(item, str):
            url, title = item, None
        else:
            url, title = item.get("url"), item.get("title")
        if not url or url in seen:
            continue
        seen.add(url)
        record = parser(url, title)
        if record and record.get("operation_date") and record.get("amount") is not None:
            record["tool_type"] = tool_type
            upsert_tool_operation(record)
            count += 1
    return count


def sync_treasury_cash_deposit_from_sources(sources_file: Path = SOURCES_FILE) -> int:
    return sync_generic_from_sources(
        "treasury_cash_deposit",
        parse_treasury_cash_deposit_article,
        "treasury_cash_deposit_search_urls",
        "treasury_cash_deposit_urls",
        ["国库现金", "中央国库现金管理", "商业银行定期存款", "Treasury Cash"],
        sources_file,
    )


def sync_manual_operations(sources_file: Path = SOURCES_FILE) -> int:
    if not sources_file.exists():
        return 0
    payload = json.loads(sources_file.read_text(encoding="utf-8"))
    rows = payload.get("manual_operations", [])
    count = 0
    for index, row in enumerate(rows, start=1):
        if not row.get("tool_type") or not row.get("operation_date") or row.get("amount") is None:
            continue
        record = {
            "tool_type": row.get("tool_type"),
            "announcement_no": row.get("announcement_no"),
            "title": row.get("title") or f"手工补录 {row.get('tool_type')}",
            "operation_date": row.get("operation_date"),
            "maturity_date": row.get("maturity_date"),
            "term_days": row.get("term_days"),
            "amount": row.get("amount"),
            "rate": row.get("rate"),
            "bid_amount": row.get("bid_amount"),
            "award_amount": row.get("award_amount", row.get("amount")),
            "price": row.get("price"),
            "direction": row.get("direction", "injection"),
            "source_url": row.get("source_url") or f"manual://{row.get('tool_type')}/{row.get('operation_date')}",
            "source_suffix": row.get("source_suffix") or f"manual-{index}",
            "raw_text": row.get("note", ""),
        }
        upsert_tool_operation(record)
        count += 1
    return count


def sync_gov_bond_trade_from_sources(sources_file: Path = SOURCES_FILE) -> int:
    if not sources_file.exists():
        return 0
    payload = json.loads(sources_file.read_text(encoding="utf-8"))
    keywords = ["国债买卖", "国债交易", "国债买入", "国债卖出", "Government Bond Transaction"]
    urls = list(payload.get("gov_bond_trade_urls", []))
    for column_url in payload.get("gov_bond_trade_column_urls", []):
        urls.extend(discover_urls_from_column(column_url, keywords))
    for search_url in payload.get("gov_bond_trade_search_urls", []):
        urls.extend(discover_urls_from_search(search_url, keywords))

    count = 0
    seen = set()
    for item in urls:
        if isinstance(item, str):
            url, title = item, None
        else:
            url, title = item.get("url"), item.get("title")
        if not url or url in seen:
            continue
        seen.add(url)
        record = parse_gov_bond_trade_article(url, title)
        if record and record.get("operation_date") and record.get("amount") is not None:
            upsert_tool_operation(record)
            count += 1
    return count


def sync_outright_reverse_repo_from_sources(sources_file: Path = SOURCES_FILE) -> int:
    if not sources_file.exists():
        return 0
    payload = json.loads(sources_file.read_text(encoding="utf-8"))
    urls = list(payload.get("outright_reverse_repo_urls", []))
    for column_url in payload.get("outright_reverse_repo_column_urls", []):
        urls.extend(discover_urls_from_column_pages(column_url, ["买断式逆回购"], limit=100, pages=6))
    for search_url in payload.get("outright_reverse_repo_search_urls", []):
        urls.extend(discover_urls_from_search(search_url, ["买断式逆回购"], limit=40))

    count = 0
    seen = set()
    for item in urls:
        if isinstance(item, str):
            url, title = item, None
        else:
            url, title = item.get("url"), item.get("title")
        if not url or url in seen:
            continue
        seen.add(url)
        record = parse_outright_reverse_repo_article(url, title)
        if record and record.get("operation_date") and record.get("amount") is not None:
            upsert_tool_operation(record)
            count += 1
    return count


def month_end_from_title(value: str) -> str | None:
    months = {
        "january": 1, "february": 2, "march": 3, "april": 4,
        "may": 5, "june": 6, "july": 7, "august": 8,
        "september": 9, "october": 10, "november": 11, "december": 12,
    }
    match = re.search(r"\((January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{4})\)", value, flags=re.I)
    if not match:
        return None
    year = int(match.group(2))
    month = months[match.group(1).lower()]
    if month == 12:
        last_day = 31
    else:
        from datetime import date, timedelta

        last_day = (date(year, month + 1, 1) - timedelta(days=1)).day
    return f"{year:04d}-{month:02d}-{last_day:02d}"


def discover_overview_urls(index_url: str, limit: int = 18) -> list[dict]:
    html = fetch_text(index_url)
    found = []
    seen = set()
    for title, href in extract_links(html, index_url):
        if "Liquidity Injection via Central Bank Monetary Policy Instruments" not in title:
            continue
        if href in seen:
            continue
        seen.add(href)
        found.append({"title": title, "url": href})
        if len(found) >= limit:
            break
    return found


def parse_policy_overview_article(url: str, title_hint: str | None = None) -> list[dict]:
    html = fetch_text(url)
    raw = text(html)
    title = title_hint or "Liquidity Injection via Central Bank Monetary Policy Instruments"
    operation_date = month_end_from_title(title) or month_end_from_title(raw) or chinese_date(raw) or english_date(raw)
    if not operation_date:
        return []

    mapping = {
        "Medium-term Lending Facility (MLF)": "mlf",
        "Central Treasury Cash Management": "treasury_cash_deposit",
        "Government Bond Transactions": "gov_bond_trade",
        "Outright Reverse Repos": "outright_reverse_repo",
        "Outright Reverse Repo": "outright_reverse_repo",
        "Standing Lending Facility (SLF)": "slf",
        "Pledged Supplemental Lending (PSL)": "psl",
        "7-day Reverse Repo": "reverse_repo",
        "Other Reverse Repos": "reverse_repo",
    }
    records = []
    for instrument, tool_type in mapping.items():
        pattern = re.escape(instrument) + r"\s+(-|[0-9,，.]+)\s+(-|[0-9,，.]+)\s+(-|[0-9,，.]+)"
        match = re.search(pattern, raw)
        if not match:
            continue

        def parse_cell(cell: str) -> float:
            return 0.0 if cell == "-" else float(cell.replace(",", "").replace("，", ""))

        injection, withdrawal, net = (parse_cell(match.group(i)) for i in range(1, 4))
        base = {
            "tool_type": tool_type,
            "announcement_no": None,
            "title": f"{title} - {instrument}",
            "operation_date": operation_date,
            "maturity_date": None,
            "term_days": None,
            "rate": None,
            "bid_amount": None,
            "price": None,
            "source_url": url,
            "raw_text": raw[:20000],
        }
        if injection:
            records.append({
                **base,
                "amount": injection,
                "award_amount": injection,
                "direction": "injection",
                "source_suffix": f"overview-{tool_type}-{instrument[:8]}-injection",
            })
        if withdrawal:
            records.append({
                **base,
                "amount": withdrawal,
                "award_amount": withdrawal,
                "direction": "withdrawal",
                "source_suffix": f"overview-{tool_type}-{instrument[:8]}-withdrawal",
            })
        if not injection and not withdrawal and net:
            records.append({
                **base,
                "amount": abs(net),
                "award_amount": abs(net),
                "direction": "injection" if net > 0 else "withdrawal",
                "source_suffix": f"overview-{tool_type}-{instrument[:8]}-net",
            })
    return records


def sync_policy_overview_from_sources(sources_file: Path = SOURCES_FILE) -> int:
    if not sources_file.exists():
        return 0
    payload = json.loads(sources_file.read_text(encoding="utf-8"))
    items = []
    for index_url in payload.get("policy_instrument_overview_urls", []):
        items.extend(discover_overview_urls(index_url))
    count = 0
    seen = set()
    for item in items:
        url = item.get("url")
        if not url or url in seen:
            continue
        seen.add(url)
        for record in parse_policy_overview_article(url, item.get("title")):
            upsert_tool_operation(record)
            count += 1
    return count


def deduped_operations(tool_types: list[str] | None = None, db_path: Path = DB_PATH) -> list[dict]:
    """返回去重后的央行工具记录。

    同一笔操作可能同时出现在央行中文站和英文站。去重口径：
    tool_type + direction + operation_date + maturity_date + amount。
    若重复，优先保留中文站来源。
    """
    init_tools_db(db_path)
    params: list[str] = []
    where = ""
    if tool_types:
        where = "WHERE tool_type IN (" + ",".join("?" for _ in tool_types) + ")"
        params.extend(tool_types)

    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            f"""
            SELECT *
            FROM central_bank_operations
            {where}
            ORDER BY operation_date, id
            """,
            params,
        ).fetchall()

    chosen: dict[tuple, sqlite3.Row] = {}
    for row in rows:
        amount = row["amount"] if row["amount"] is not None else row["award_amount"]
        key = (
            row["tool_type"],
            row["direction"] or "injection",
            row["operation_date"],
            row["maturity_date"],
            round(float(amount or 0), 6),
        )
        previous = chosen.get(key)
        if previous is None:
            chosen[key] = row
            continue

        current_is_cn = "pbc.gov.cn/zhengcehuobisi" in (row["source_url"] or "")
        previous_is_cn = "pbc.gov.cn/zhengcehuobisi" in (previous["source_url"] or "")
        if current_is_cn and not previous_is_cn:
            chosen[key] = row

    return [dict(row) for row in chosen.values()]


def default_tools_as_of(db_path: Path = DB_PATH) -> date:
    # The display window is anchored to today.  A missing same-day announcement
    # must not turn known maturities into artificial "future" rows merely
    # because the latest operation record was published on an earlier day.
    return date.today()


def query_central_bank_daily(
    days: int = 5,
    tool_types: list[str] | None = None,
    db_path: Path = DB_PATH,
    as_of: date | None = None,
) -> list[dict]:
    cutoff = as_of or default_tools_as_of(db_path)
    ops = deduped_operations(tool_types=tool_types, db_path=db_path)
    dates = {
        op["operation_date"]
        for op in ops
        if op.get("operation_date") and op["operation_date"] <= cutoff.isoformat()
    } | {
        op["maturity_date"]
        for op in ops
        if op.get("maturity_date") and op["maturity_date"] <= cutoff.isoformat()
    }
    selected_dates = sorted(dates)[-days:]

    result = []
    for day in selected_dates:
        injection = maturity = 0.0
        by_tool: dict[str, dict[str, float]] = {}
        for op in ops:
            raw_amount = op.get("amount") if op.get("amount") is not None else op.get("award_amount")
            amount = float(raw_amount) if raw_amount is not None else 0.0
            tool = op["tool_type"]
            by_tool.setdefault(tool, {"injection": 0.0, "maturity": 0.0, "net": 0.0})

            if op.get("operation_date") == day:
                if (op.get("direction") or "injection") == "withdrawal":
                    maturity += amount
                    by_tool[tool]["maturity"] += amount
                else:
                    injection += amount
                    by_tool[tool]["injection"] += amount

            if op.get("maturity_date") == day and (op.get("direction") or "injection") == "injection":
                maturity += amount
                by_tool[tool]["maturity"] += amount

        for value in by_tool.values():
            value["net"] = value["injection"] - value["maturity"]
        result.append(
            {
                "date": day,
                "label": day[5:].replace("-", "/"),
                "injection": injection,
                "maturity": maturity,
                "value": injection - maturity,
                "byTool": by_tool,
                "source": "central_bank_tools",
            }
        )
    return result


def query_central_bank_window(
    days_before: int = 5,
    days_after: int = 5,
    tool_types: list[str] | None = None,
    db_path: Path = DB_PATH,
    as_of: date | None = None,
) -> list[dict]:
    cutoff = as_of or default_tools_as_of(db_path)
    selected_dates = business_day_window(cutoff, days_before, days_after, db_path)
    ops = deduped_operations(tool_types=tool_types, db_path=db_path)
    result = []

    for day in selected_dates:
        day_text = day.isoformat()
        injection = maturity = 0.0
        by_tool: dict[str, dict[str, float]] = {}
        for op in ops:
            raw_amount = op.get("amount") if op.get("amount") is not None else op.get("award_amount")
            amount = float(raw_amount) if raw_amount is not None else 0.0
            tool = op["tool_type"]
            by_tool.setdefault(tool, {"injection": 0.0, "maturity": 0.0, "net": 0.0})
            direction = op.get("direction") or "injection"

            if op.get("operation_date") == day_text and day <= cutoff:
                if direction == "withdrawal":
                    maturity += amount
                    by_tool[tool]["maturity"] += amount
                else:
                    injection += amount
                    by_tool[tool]["injection"] += amount

            if op.get("maturity_date") == day_text and direction == "injection":
                maturity += amount
                by_tool[tool]["maturity"] += amount

        for value in by_tool.values():
            value["net"] = value["injection"] - value["maturity"]
        result.append(
            {
                "date": day_text,
                "label": day_text[5:].replace("-", "/"),
                "injection": injection,
                "maturity": maturity,
                "value": injection - maturity,
                "byTool": by_tool,
                "isFuture": day > cutoff,
                "source": "central_bank_tools",
            }
        )
    return result


def query_central_bank_weekly(
    weeks: int = 4,
    tool_types: list[str] | None = None,
    db_path: Path = DB_PATH,
    as_of: date | None = None,
) -> list[dict]:
    cutoff = as_of or default_tools_as_of(db_path)
    daily = query_central_bank_daily(days=180, tool_types=tool_types, db_path=db_path, as_of=cutoff)
    daily_by_date = {item["date"]: item for item in daily}
    latest_monday = cutoff - timedelta(days=cutoff.weekday())
    windows = [latest_monday - timedelta(days=7 * i) for i in reversed(range(weeks))]
    result = []
    for monday in windows:
        sunday = monday + timedelta(days=6)
        injection = maturity = 0.0
        day = monday
        while day <= sunday:
            item = daily_by_date.get(day.isoformat())
            if item:
                injection += float(item["injection"])
                maturity += float(item["maturity"])
            day += timedelta(days=1)
        result.append(
            {
                "start": monday.isoformat(),
                "end": sunday.isoformat(),
                "label": f"{monday:%m/%d}-{sunday:%d}" if monday.month == sunday.month else f"{monday:%m/%d}-{sunday:%m/%d}",
                "injection": injection,
                "maturity": maturity,
                "value": injection - maturity,
            }
        )
    return result


TOOL_TYPE_LABELS = {
    "reverse_repo": "逆回购",
    "outright_reverse_repo": "买断式逆回购",
    "mlf": "MLF",
    "treasury_cash_deposit": "国库现金",
    "gov_bond_trade": "国债买卖",
    "slf": "SLF",
    "psl": "PSL",
}


def query_central_bank_transactions(
    days: int = 7,
    tool_types: list[str] | None = None,
    db_path: Path = DB_PATH,
    as_of: date | None = None,
) -> list[dict]:
    """返回广义央行工具逐笔净投放明细。

    口径与 query_central_bank_daily 保持一致：
    - operation_date 上，direction=injection 记正，direction=withdrawal 记负；
    - injection 类工具若有 maturity_date，则到期日另记一笔负数。
    """
    today = date.today()
    ops = deduped_operations(tool_types=tool_types, db_path=db_path)
    event_dates = []
    for op in ops:
        for field in ("operation_date", "maturity_date"):
            value = op.get(field)
            if value and value <= today.isoformat():
                event_dates.append(value)
    cutoff = as_of or (datetime.fromisoformat(max(event_dates)).date() if event_dates else today)
    start = cutoff - timedelta(days=days - 1)

    result: list[dict] = []

    def in_window(value: str | None) -> bool:
        if not value:
            return False
        day = datetime.fromisoformat(value).date()
        return start <= day <= cutoff

    def append_event(op: dict, event_date: str, amount: float, event_type: str) -> None:
        tool = op.get("tool_type") or "unknown"
        result.append(
            {
                "date": event_date,
                "label": event_date[5:].replace("-", "/"),
                "tool": tool,
                "toolName": TOOL_TYPE_LABELS.get(tool, tool),
                "type": event_type,
                "amount": amount,
                "termDays": op.get("term_days"),
                "rate": op.get("rate"),
                "announcementNo": op.get("announcement_no"),
                "title": op.get("title"),
                "sourceUrl": op.get("source_url"),
            }
        )

    for op in ops:
        amount = float(op.get("amount") or op.get("award_amount") or 0)
        if not amount:
            continue
        direction = op.get("direction") or "injection"
        tool_name = TOOL_TYPE_LABELS.get(op.get("tool_type"), op.get("tool_type") or "央行工具")

        if in_window(op.get("operation_date")):
            if direction == "withdrawal":
                append_event(op, op["operation_date"], -amount, f"{tool_name}回笼")
            else:
                append_event(op, op["operation_date"], amount, f"{tool_name}投放")

        if direction == "injection" and in_window(op.get("maturity_date")):
            append_event(op, op["maturity_date"], -amount, f"{tool_name}到期")

    result.sort(key=lambda item: (item["date"], abs(float(item["amount"])), item["type"]), reverse=True)
    return result


def query_tool_summary(db_path: Path = DB_PATH) -> list[dict]:
    rows = deduped_operations(db_path=db_path)
    summary: dict[str, dict] = {}
    for row in rows:
        tool = row["tool_type"]
        amount = float(row.get("amount") or row.get("award_amount") or 0)
        item = summary.setdefault(
            tool,
            {"tool_type": tool, "count": 0, "latest_date": None, "total_injection": 0.0, "total_withdrawal": 0.0},
        )
        item["count"] += 1
        if row.get("operation_date") and (item["latest_date"] is None or row["operation_date"] > item["latest_date"]):
            item["latest_date"] = row["operation_date"]
        if (row.get("direction") or "injection") == "withdrawal":
            item["total_withdrawal"] += amount
        else:
            item["total_injection"] += amount
    required = ("reverse_repo", "mlf", "treasury_cash_deposit", "gov_bond_trade", "slf", "psl")
    return [
        summary.get(key, {
            "tool_type": key,
            "count": 0,
            "latest_date": None,
            "total_injection": 0.0,
            "total_withdrawal": 0.0,
        })
        for key in required
    ]


def main() -> None:
    parser = argparse.ArgumentParser(description="央行工具通用表：逆回购/MLF/国库现金定存/国债买卖/央票/CBS")
    parser.add_argument("--init", action="store_true", help="初始化通用央行工具表")
    parser.add_argument("--migrate-reverse-repo", action="store_true", help="把现有逆回购表同步到通用表")
    parser.add_argument("--sync-mlf", action="store_true", help="根据 data/central_bank_sources.json 配置抓取 MLF")
    parser.add_argument("--resync-mlf", action="store_true", help="清空并重新抓取 MLF，适合解析逻辑升级后使用")
    parser.add_argument("--sync-treasury-cash", action="store_true", help="抓取国库现金定存公告")
    parser.add_argument("--sync-gov-bond-trade", action="store_true", help="抓取央行国债买卖/国债交易公告")
    parser.add_argument("--sync-outright-reverse-repo", action="store_true", help="抓取买断式逆回购公告")
    parser.add_argument("--sync-manual", action="store_true", help="同步 data/central_bank_sources.json 中的 manual_operations")
    parser.add_argument("--sync-overview", action="store_true", help="抓取央行月度货币政策工具投放概览")
    parser.add_argument("--sync-extra", action="store_true", help="抓取 MLF、国库现金定存、国债买卖、月度概览，并同步手工补录")
    parser.add_argument("--summary", action="store_true", help="输出通用表汇总")
    args = parser.parse_args()

    if args.init:
        init_tools_db()
        print("已初始化 central_bank_operations")
    if args.migrate_reverse_repo:
        print(f"已同步逆回购 {migrate_reverse_repo()} 条")
    if args.resync_mlf:
        print(f"已清空旧 MLF {clear_tool('mlf')} 条")
        print(f"已重新同步 MLF {sync_mlf_from_sources()} 条")
    elif args.sync_mlf or args.sync_extra:
        print(f"已同步 MLF {sync_mlf_from_sources()} 条")
    if args.sync_treasury_cash or args.sync_extra:
        print(f"已同步国库现金定存 {sync_treasury_cash_deposit_from_sources()} 条")
    if args.sync_gov_bond_trade or args.sync_extra:
        print(f"已同步国债买卖 {sync_gov_bond_trade_from_sources()} 条")
    if args.sync_outright_reverse_repo or args.sync_extra:
        print(f"已同步买断式逆回购 {sync_outright_reverse_repo_from_sources()} 条")
    if args.sync_overview or args.sync_extra:
        print(f"已同步月度工具概览 {sync_policy_overview_from_sources()} 条")
    if args.sync_manual or args.sync_extra:
        print(f"已同步手工补录 {sync_manual_operations()} 条")
    if args.summary:
        print(json.dumps(query_tool_summary(), ensure_ascii=False, indent=2))
    if not any(vars(args).values()):
        parser.print_help()


if __name__ == "__main__":
    main()
