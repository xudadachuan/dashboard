from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import smtplib
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from pathlib import Path
from typing import Callable
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from auth import (
    AuthError,
    DEFAULT_DB_PATH,
    connect,
    init_auth_db,
    iso_utc,
    load_env_file,
    utc_now,
    validate_email,
)


CODE_TTL = timedelta(hours=1)
GLOBAL_DAILY_SEND_LIMIT = 100
PER_EMAIL_DAILY_SEND_LIMIT = 10
RESEND_COOLDOWN = timedelta(seconds=60)
MAX_VERIFY_ATTEMPTS = 5
CODE_HASH_ITERATIONS = 80_000
VALID_PURPOSES = {"register"}
try:
    CHINA_TZ = ZoneInfo("Asia/Shanghai")
except ZoneInfoNotFoundError:
    # Windows Python installations do not always include the IANA timezone
    # database. China has no daylight-saving-time transition, so UTC+08:00 is
    # an equivalent runtime fallback that keeps the service dependency-free.
    CHINA_TZ = timezone(timedelta(hours=8), name="Asia/Shanghai")


def init_email_auth_db(db_path: Path = DEFAULT_DB_PATH) -> None:
    init_auth_db(db_path)
    with connect(db_path) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS email_verification_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL COLLATE NOCASE,
                purpose TEXT NOT NULL CHECK(purpose IN ('register', 'login')),
                code_hash TEXT NOT NULL,
                code_salt TEXT NOT NULL,
                day_key TEXT NOT NULL,
                created_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                attempt_count INTEGER NOT NULL DEFAULT 0,
                consumed_at TEXT,
                delivered INTEGER NOT NULL DEFAULT 0 CHECK(delivered IN (0, 1)),
                delivery_error TEXT
            )
            """
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_email_codes_lookup ON email_verification_codes(email, purpose, created_at)"
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_email_codes_day ON email_verification_codes(day_key)")
        conn.execute("PRAGMA optimize")


def code_digest(code: str, salt: bytes | None = None) -> tuple[str, str]:
    raw_salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", code.encode("ascii"), raw_salt, CODE_HASH_ITERATIONS)
    return digest.hex(), raw_salt.hex()


def smtp_config() -> dict:
    load_env_file()
    return {
        "host": os.environ.get("ALIYUN_DM_SMTP_HOST", "smtpdm.aliyun.com").strip(),
        "port": int(os.environ.get("ALIYUN_DM_SMTP_PORT", "465")),
        "username": os.environ.get("ALIYUN_DM_SMTP_USERNAME", "").strip(),
        "password": os.environ.get("ALIYUN_DM_SMTP_PASSWORD", ""),
        "from_name": os.environ.get("ALIYUN_DM_FROM_NAME", "债市脉搏").strip() or "债市脉搏",
    }


def deliver_with_aliyun(email: str, code: str, purpose: str) -> None:
    config = smtp_config()
    if not config["username"] or not config["password"]:
        raise AuthError("阿里云邮件服务尚未配置")
    action = "完成注册"
    message = EmailMessage()
    message["Subject"] = f"【债市脉搏】邮箱验证码 {code}"
    message["From"] = f"{config['from_name']} <{config['username']}>"
    message["To"] = email
    message.set_content(
        f"您的验证码是：{code}\n\n该验证码用于{action}，1 小时内有效，请勿转发给他人。\n如果不是您本人操作，请忽略本邮件。"
    )
    try:
        with smtplib.SMTP_SSL(config["host"], config["port"], timeout=15) as smtp:
            smtp.login(config["username"], config["password"])
            smtp.send_message(message)
    except (OSError, smtplib.SMTPException) as exc:
        raise AuthError("验证码邮件发送失败，请稍后重试") from exc


def ensure_send_allowed(conn, email: str, purpose: str, now) -> str:
    if purpose not in VALID_PURPOSES:
        raise AuthError("无效的验证码用途")
    day_key = now.astimezone(CHINA_TZ).date().isoformat()
    total_today = conn.execute(
        "SELECT COUNT(*) FROM email_verification_codes WHERE day_key = ?", (day_key,)
    ).fetchone()[0]
    if total_today >= GLOBAL_DAILY_SEND_LIMIT:
        raise AuthError("今日验证码发送额度已用完，请明日再试")
    email_today = conn.execute(
        "SELECT COUNT(*) FROM email_verification_codes WHERE day_key = ? AND email = ? COLLATE NOCASE",
        (day_key, email),
    ).fetchone()[0]
    if email_today >= PER_EMAIL_DAILY_SEND_LIMIT:
        raise AuthError("该邮箱今日获取验证码次数已达上限")
    latest = conn.execute(
        "SELECT created_at FROM email_verification_codes WHERE email = ? COLLATE NOCASE ORDER BY id DESC LIMIT 1",
        (email,),
    ).fetchone()
    if latest and now - datetime.fromisoformat(latest["created_at"]) < RESEND_COOLDOWN:
        raise AuthError("验证码发送过于频繁，请 60 秒后重试")
    if conn.execute("SELECT 1 FROM users WHERE email = ? COLLATE NOCASE", (email,)).fetchone():
        raise AuthError("该邮箱已被注册，请直接登录")
    return day_key


def issue_email_code(
    email: str,
    purpose: str,
    db_path: Path = DEFAULT_DB_PATH,
    deliver: Callable[[str, str, str], None] = deliver_with_aliyun,
) -> None:
    email = validate_email(email)
    if not email:
        raise AuthError("请输入邮箱地址")
    init_email_auth_db(db_path)
    now = utc_now()
    code = f"{secrets.randbelow(1_000_000):06d}"
    digest, salt = code_digest(code)
    with connect(db_path) as conn:
        conn.execute("BEGIN IMMEDIATE")
        day_key = ensure_send_allowed(conn, email, purpose, now)
        cursor = conn.execute(
            """
            INSERT INTO email_verification_codes(
                email, purpose, code_hash, code_salt, day_key, created_at, expires_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (email, purpose, digest, salt, day_key, iso_utc(now), iso_utc(now + CODE_TTL)),
        )
        code_id = cursor.lastrowid
    try:
        deliver(email, code, purpose)
    except Exception as exc:
        with connect(db_path) as conn:
            conn.execute(
                "UPDATE email_verification_codes SET delivery_error = ? WHERE id = ?",
                (str(exc)[:300], code_id),
            )
        raise
    with connect(db_path) as conn:
        conn.execute("UPDATE email_verification_codes SET delivered = 1 WHERE id = ?", (code_id,))


def verify_email_code(email: str, code: str, purpose: str, db_path: Path = DEFAULT_DB_PATH) -> None:
    email = validate_email(email)
    value = str(code or "").strip()
    if not email or not value.isdigit() or len(value) != 6:
        raise AuthError("请输入 6 位邮箱验证码")
    if purpose not in VALID_PURPOSES:
        raise AuthError("无效的验证码用途")
    init_email_auth_db(db_path)
    now = utc_now()
    with connect(db_path) as conn:
        row = conn.execute(
            """
            SELECT * FROM email_verification_codes
            WHERE email = ? COLLATE NOCASE AND purpose = ? AND delivered = 1 AND consumed_at IS NULL
            ORDER BY id DESC LIMIT 1
            """,
            (email, purpose),
        ).fetchone()
        if not row:
            raise AuthError("请先获取邮箱验证码")
        if row["attempt_count"] >= MAX_VERIFY_ATTEMPTS:
            raise AuthError("验证码错误次数过多，请重新获取")
        if datetime.fromisoformat(row["expires_at"]) <= now:
            raise AuthError("验证码已过期，请重新获取")
        digest, _ = code_digest(value, bytes.fromhex(row["code_salt"]))
        if not hmac.compare_digest(digest, row["code_hash"]):
            conn.execute(
                "UPDATE email_verification_codes SET attempt_count = attempt_count + 1 WHERE id = ?", (row["id"],)
            )
            raise AuthError("邮箱验证码不正确")
        conn.execute("UPDATE email_verification_codes SET consumed_at = ? WHERE id = ?", (iso_utc(now), row["id"]))
