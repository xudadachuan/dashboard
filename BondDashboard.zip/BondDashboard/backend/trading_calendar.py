from __future__ import annotations

import json
from datetime import date, timedelta
from pathlib import Path


ROOT = Path(__file__).resolve().parent
CALENDAR_FILE = ROOT.parent / "data" / "interbank_calendar.json"


def load_calendar(path: Path = CALENDAR_FILE) -> dict:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"holidays": [], "workdays": []}
    return payload if isinstance(payload, dict) else {"holidays": [], "workdays": []}


def is_interbank_trading_day(day: date | None = None, path: Path = CALENDAR_FILE) -> bool:
    target = day or date.today()
    payload = load_calendar(path)
    value = target.isoformat()
    if value in set(payload.get("workdays") or []):
        return True
    if value in set(payload.get("holidays") or []):
        return False
    return target.weekday() < 5


def latest_interbank_trading_day(day: date | None = None, path: Path = CALENDAR_FILE) -> date:
    target = day or date.today()
    while not is_interbank_trading_day(target, path):
        target -= timedelta(days=1)
    return target


def trading_day_status(day: date | None = None, path: Path = CALENDAR_FILE) -> dict:
    target = day or date.today()
    trading = is_interbank_trading_day(target, path)
    return {
        "date": target.isoformat(),
        "isTradingDay": trading,
        "latestTradingDay": latest_interbank_trading_day(target, path).isoformat(),
    }
