from __future__ import annotations

import json
import os
import sqlite3
from datetime import date, datetime, time
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
DB_PATH = DATA_DIR / "bond_market.db"


def connect(db_path: Path = DB_PATH) -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("pragma journal_mode=wal")
    return conn


def ensure_market_data_schema(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS market_payload_snapshots (
            dataset TEXT NOT NULL,
            data_date TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            source TEXT,
            updated_at TEXT NOT NULL,
            PRIMARY KEY (dataset, data_date)
        )
        """
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_market_payload_dataset_date ON market_payload_snapshots(dataset, data_date)")
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS market_commentary_daily (
            commentary_date TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            summary TEXT NOT NULL,
            tone TEXT NOT NULL,
            risk_level TEXT NOT NULL,
            source TEXT NOT NULL,
            model TEXT,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS market_commentary_weekly (
            week_end_date TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            summary TEXT NOT NULL,
            tone TEXT NOT NULL,
            risk_level TEXT NOT NULL,
            source TEXT NOT NULL,
            model TEXT,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS market_news_daily (
            news_date TEXT NOT NULL,
            news_id TEXT NOT NULL,
            category TEXT NOT NULL,
            title TEXT NOT NULL,
            summary TEXT NOT NULL,
            source_name TEXT NOT NULL,
            source_url TEXT,
            published_at TEXT,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            PRIMARY KEY (news_date, news_id)
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS interbank_cd_daily (
            data_date TEXT PRIMARY KEY,
            payload_json TEXT NOT NULL,
            source TEXT,
            updated_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS interbank_cd_items (
            data_date TEXT NOT NULL,
            bond_code TEXT NOT NULL,
            issuer TEXT,
            issue_date TEXT,
            maturity_date TEXT,
            term TEXT,
            issue_price REAL,
            planned_amount_100m REAL,
            actual_amount_100m REAL,
            coupon_type TEXT,
            coupon_rate REAL,
            estimated_yield REAL,
            rating TEXT,
            segment TEXT,
            is_major_bank INTEGER,
            bond_defined_code TEXT,
            payload_json TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            PRIMARY KEY (data_date, bond_code)
        )
        """
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_interbank_cd_items_date ON interbank_cd_items(data_date)")
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS etf_daily (
            data_date TEXT PRIMARY KEY,
            payload_json TEXT NOT NULL,
            source TEXT,
            updated_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS etf_items (
            data_date TEXT NOT NULL,
            code TEXT NOT NULL,
            name TEXT,
            exchange TEXT,
            etf_type TEXT,
            price REAL,
            change_pct REAL,
            amount_100m REAL,
            market_value_100m REAL,
            nav REAL,
            premium_pct REAL,
            net_inflow_100m REAL,
            payload_json TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            PRIMARY KEY (data_date, code)
        )
        """
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_etf_items_date ON etf_items(data_date)")


def init_market_data_db() -> None:
    with connect() as conn:
        ensure_market_data_schema(conn)


def _json(payload: dict) -> str:
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def _is_future_date(value: str | None) -> bool:
    if not value:
        return False
    try:
        return date.fromisoformat(str(value)) > date.today()
    except ValueError:
        return False


def _is_official_write_date(value: str | None) -> bool:
    if os.environ.get("BOND_DASHBOARD_FORCE_WRITE") == "1":
        return bool(value) and not _is_future_date(value)
    if not value:
        return False
    try:
        parsed = date.fromisoformat(str(value))
    except ValueError:
        return False
    if parsed > date.today():
        return False
    if parsed == date.today() and datetime.now().hour < 17:
        return False
    return True


def _is_official_etf_write_date(value: str | None) -> bool:
    if os.environ.get("BOND_DASHBOARD_FORCE_WRITE") == "1":
        return bool(value) and not _is_future_date(value)
    if not value:
        return False
    try:
        parsed = date.fromisoformat(str(value))
    except ValueError:
        return False
    if parsed > date.today():
        return False
    if parsed == date.today() and datetime.now().time() < time(21, 5):
        return False
    return True


def save_interbank_cd_snapshot(payload: dict) -> None:
    data_date = payload.get("date")
    if not _is_official_write_date(str(data_date)):
        return
    updated_at = datetime.now().isoformat(timespec="seconds")
    with connect() as conn:
        ensure_market_data_schema(conn)
        conn.execute(
            """
            INSERT INTO interbank_cd_daily(data_date, payload_json, source, updated_at)
            VALUES(?, ?, ?, ?)
            ON CONFLICT(data_date) DO UPDATE SET
                payload_json=excluded.payload_json,
                source=excluded.source,
                updated_at=excluded.updated_at
            """,
            (data_date, _json(payload), payload.get("source"), updated_at),
        )
        for item in payload.get("items") or []:
            if not item.get("bondCode"):
                continue
            conn.execute(
                """
                INSERT INTO interbank_cd_items(
                    data_date, bond_code, issuer, issue_date, maturity_date, term,
                    issue_price, planned_amount_100m, actual_amount_100m,
                    coupon_type, coupon_rate, estimated_yield, rating, segment,
                    is_major_bank, bond_defined_code, payload_json, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(data_date, bond_code) DO UPDATE SET
                    issuer=excluded.issuer,
                    issue_date=excluded.issue_date,
                    maturity_date=excluded.maturity_date,
                    term=excluded.term,
                    issue_price=excluded.issue_price,
                    planned_amount_100m=excluded.planned_amount_100m,
                    actual_amount_100m=excluded.actual_amount_100m,
                    coupon_type=excluded.coupon_type,
                    coupon_rate=excluded.coupon_rate,
                    estimated_yield=excluded.estimated_yield,
                    rating=excluded.rating,
                    segment=excluded.segment,
                    is_major_bank=excluded.is_major_bank,
                    bond_defined_code=excluded.bond_defined_code,
                    payload_json=excluded.payload_json,
                    updated_at=excluded.updated_at
                """,
                (
                    data_date,
                    item.get("bondCode"),
                    item.get("issuer"),
                    item.get("issueDate"),
                    item.get("maturityDate"),
                    item.get("term"),
                    item.get("issuePrice"),
                    item.get("plannedAmount100m"),
                    item.get("actualAmount100m"),
                    item.get("couponType"),
                    item.get("couponRate"),
                    item.get("estimatedYield"),
                    item.get("rating"),
                    item.get("segment"),
                    1 if item.get("isMajorBank") else 0,
                    item.get("bondDefinedCode"),
                    _json(item),
                    updated_at,
                ),
            )


def save_payload_snapshot(dataset: str, payload: dict, data_date: str | None = None) -> None:
    date_value = data_date or payload.get("date")
    if not dataset or not _is_official_write_date(str(date_value)):
        return
    updated_at = datetime.now().isoformat(timespec="seconds")
    with connect() as conn:
        ensure_market_data_schema(conn)
        conn.execute(
            """
            INSERT INTO market_payload_snapshots(dataset, data_date, payload_json, source, updated_at)
            VALUES(?, ?, ?, ?, ?)
            ON CONFLICT(dataset, data_date) DO UPDATE SET
                payload_json=excluded.payload_json,
                source=excluded.source,
                updated_at=excluded.updated_at
            """,
            (dataset, date_value, _json(payload), payload.get("source"), updated_at),
        )


def payload_available_dates(dataset: str) -> list[str]:
    with connect() as conn:
        ensure_market_data_schema(conn)
        rows = conn.execute(
            """
            SELECT data_date
            FROM market_payload_snapshots
            WHERE dataset = ?
            ORDER BY data_date
            """,
            (dataset,),
        ).fetchall()
    return [row["data_date"] for row in rows]


def load_payload_snapshot(dataset: str, requested_date: str | None = None) -> dict | None:
    with connect() as conn:
        ensure_market_data_schema(conn)
        if requested_date:
            row = conn.execute(
                """
                SELECT payload_json
                FROM market_payload_snapshots
                WHERE dataset = ? AND data_date = ?
                """,
                (dataset, requested_date),
            ).fetchone()
            if row:
                payload = json.loads(row["payload_json"])
                payload["requestedDate"] = requested_date
                return payload
            row = conn.execute(
                """
                SELECT payload_json
                FROM market_payload_snapshots
                WHERE dataset = ? AND data_date <= ?
                ORDER BY data_date DESC
                LIMIT 1
                """,
                (dataset, requested_date),
            ).fetchone()
            if row:
                payload = json.loads(row["payload_json"])
                payload["requestedDate"] = requested_date
                payload["asOfFallback"] = True
                return payload
        row = conn.execute(
            """
            SELECT payload_json
            FROM market_payload_snapshots
            WHERE dataset = ?
            ORDER BY data_date DESC
            LIMIT 1
            """,
            (dataset,),
        ).fetchone()
        return json.loads(row["payload_json"]) if row else None


def save_daily_commentary(payload: dict, keep_days: int = 7) -> None:
    commentary_date = payload.get("date")
    if not _is_official_write_date(str(commentary_date)):
        return
    created_at = datetime.now().isoformat(timespec="seconds")
    with connect() as conn:
        ensure_market_data_schema(conn)
        conn.execute(
            """
            INSERT INTO market_commentary_daily(
                commentary_date, title, summary, tone, risk_level, source, model, payload_json, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(commentary_date) DO UPDATE SET
                title=excluded.title,
                summary=excluded.summary,
                tone=excluded.tone,
                risk_level=excluded.risk_level,
                source=excluded.source,
                model=excluded.model,
                payload_json=excluded.payload_json,
                created_at=excluded.created_at
            """,
            (
                commentary_date,
                payload.get("title") or payload.get("headline") or "收盘点评",
                payload.get("summary") or "",
                payload.get("tone") or "neutral",
                payload.get("risk_level") or "low",
                payload.get("source") or "fallback",
                payload.get("model"),
                _json(payload),
                created_at,
            ),
        )
        rows = conn.execute(
            """
            SELECT commentary_date
            FROM market_commentary_daily
            ORDER BY commentary_date DESC
            LIMIT -1 OFFSET ?
            """,
            (keep_days,),
        ).fetchall()
        if rows:
            conn.executemany(
                "DELETE FROM market_commentary_daily WHERE commentary_date = ?",
                [(row["commentary_date"],) for row in rows],
            )


def save_weekly_commentary(payload: dict) -> None:
    week_end_date = payload.get("weekEndDate") or payload.get("date")
    if not week_end_date:
        return
    created_at = datetime.now().isoformat(timespec="seconds")
    with connect() as conn:
        ensure_market_data_schema(conn)
        conn.execute(
            """
            INSERT INTO market_commentary_weekly(
                week_end_date, title, summary, tone, risk_level, source, model, payload_json, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(week_end_date) DO UPDATE SET
                title=excluded.title,
                summary=excluded.summary,
                tone=excluded.tone,
                risk_level=excluded.risk_level,
                source=excluded.source,
                model=excluded.model,
                payload_json=excluded.payload_json,
                created_at=excluded.created_at
            """,
            (
                week_end_date,
                payload.get("title") or "周度复盘",
                payload.get("summary") or "",
                payload.get("tone") or "neutral",
                payload.get("risk_level") or "low",
                payload.get("source") or "fallback",
                payload.get("model"),
                _json(payload),
                created_at,
            ),
        )


def load_market_commentary(limit: int = 7) -> dict:
    with connect() as conn:
        ensure_market_data_schema(conn)
        daily_rows = conn.execute(
            """
            SELECT payload_json
            FROM market_commentary_daily
            ORDER BY commentary_date DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        weekly_row = conn.execute(
            """
            SELECT payload_json
            FROM market_commentary_weekly
            ORDER BY week_end_date DESC
            LIMIT 1
            """
        ).fetchone()
    return {
        "daily": [json.loads(row["payload_json"]) for row in daily_rows],
        "weekly": json.loads(weekly_row["payload_json"]) if weekly_row else None,
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
    }


MAX_DAILY_MARKET_NEWS = 10
DISALLOWED_MARKET_NEWS_SOURCES = {
    "local_temperature",
    "local_tool_summary",
    "local_market_views",
}


def _is_valid_online_market_news(item: dict) -> bool:
    source_url = str(item.get("sourceUrl") or item.get("source_url") or "").strip().lower()
    source = str(item.get("source") or "").strip()
    text = f"{item.get('title') or ''} {item.get('summary') or ''}"
    is_treasury_issuance = any(term in text for term in ("国债", "特别国债")) and any(
        term in text for term in ("发行", "续发行", "招标")
    )
    return (
        source_url.startswith(("https://", "http://"))
        and source not in DISALLOWED_MARKET_NEWS_SOURCES
        and not is_treasury_issuance
    )


def purge_invalid_market_news(conn: sqlite3.Connection) -> int:
    rows = conn.execute(
        "SELECT news_date, news_id, payload_json FROM market_news_daily"
    ).fetchall()
    invalid_keys: list[tuple[str, str]] = []
    for row in rows:
        try:
            payload = json.loads(row["payload_json"])
        except (TypeError, json.JSONDecodeError):
            payload = {}
        if not _is_valid_online_market_news(payload):
            invalid_keys.append((row["news_date"], row["news_id"]))
    if invalid_keys:
        conn.executemany(
            "DELETE FROM market_news_daily WHERE news_date = ? AND news_id = ?",
            invalid_keys,
        )
    return len(invalid_keys)


def save_market_news(news_date: str, items: list[dict], keep_days: int = 5) -> None:
    if not _is_official_write_date(str(news_date)):
        return
    created_at = datetime.now().isoformat(timespec="seconds")
    with connect() as conn:
        ensure_market_data_schema(conn)
        purge_invalid_market_news(conn)
        conn.execute("DELETE FROM market_news_daily WHERE news_date = ?", (news_date,))
        valid_items = [item for item in items if _is_valid_online_market_news(item)]
        for index, item in enumerate(valid_items[:MAX_DAILY_MARKET_NEWS], start=1):
            news_id = item.get("id") or f"{news_date}-{index:02d}"
            payload = {**item, "id": news_id, "date": news_date}
            conn.execute(
                """
                INSERT INTO market_news_daily(
                    news_date, news_id, category, title, summary, source_name,
                    source_url, published_at, payload_json, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(news_date, news_id) DO UPDATE SET
                    category=excluded.category,
                    title=excluded.title,
                    summary=excluded.summary,
                    source_name=excluded.source_name,
                    source_url=excluded.source_url,
                    published_at=excluded.published_at,
                    payload_json=excluded.payload_json,
                    created_at=excluded.created_at
                """,
                (
                    news_date,
                    news_id,
                    payload.get("category") or "市场消息",
                    payload.get("title") or "--",
                    payload.get("summary") or "",
                    payload.get("sourceName") or payload.get("source_name") or "公开来源",
                    payload.get("sourceUrl") or payload.get("source_url"),
                    payload.get("publishedAt") or payload.get("published_at"),
                    _json(payload),
                    created_at,
                ),
            )
        rows = conn.execute(
            """
            SELECT DISTINCT news_date
            FROM market_news_daily
            ORDER BY news_date DESC
            LIMIT -1 OFFSET ?
            """,
            (keep_days,),
        ).fetchall()
        for row in rows:
            conn.execute("DELETE FROM market_news_daily WHERE news_date = ?", (row["news_date"],))


def load_market_news(limit: int = MAX_DAILY_MARKET_NEWS) -> dict:
    with connect() as conn:
        ensure_market_data_schema(conn)
        purge_invalid_market_news(conn)
        rows = conn.execute(
            """
            SELECT payload_json
            FROM market_news_daily
            ORDER BY news_date DESC, news_id ASC
            LIMIT ?
            """,
            (max(0, int(limit)),),
        ).fetchall()
    return {
        "items": [json.loads(row["payload_json"]) for row in rows],
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
    }


def save_etf_snapshot(payload: dict) -> None:
    data_date = payload.get("date")
    if not _is_official_etf_write_date(str(data_date)):
        return
    updated_at = datetime.now().isoformat(timespec="seconds")
    with connect() as conn:
        ensure_market_data_schema(conn)
        conn.execute(
            """
            INSERT INTO etf_daily(data_date, payload_json, source, updated_at)
            VALUES(?, ?, ?, ?)
            ON CONFLICT(data_date) DO UPDATE SET
                payload_json=excluded.payload_json,
                source=excluded.source,
                updated_at=excluded.updated_at
            """,
            (data_date, _json(payload), payload.get("source"), updated_at),
        )
        for item in payload.get("items") or []:
            if not item.get("code"):
                continue
            conn.execute(
                """
                INSERT INTO etf_items(
                    data_date, code, name, exchange, etf_type, price, change_pct,
                    amount_100m, market_value_100m, nav, premium_pct,
                    net_inflow_100m, payload_json, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(data_date, code) DO UPDATE SET
                    name=excluded.name,
                    exchange=excluded.exchange,
                    etf_type=excluded.etf_type,
                    price=excluded.price,
                    change_pct=excluded.change_pct,
                    amount_100m=excluded.amount_100m,
                    market_value_100m=excluded.market_value_100m,
                    nav=excluded.nav,
                    premium_pct=excluded.premium_pct,
                    net_inflow_100m=excluded.net_inflow_100m,
                    payload_json=excluded.payload_json,
                    updated_at=excluded.updated_at
                """,
                (
                    data_date,
                    item.get("code"),
                    item.get("name"),
                    item.get("exchange"),
                    item.get("type"),
                    item.get("price"),
                    item.get("changePct"),
                    item.get("amount100m"),
                    item.get("marketValue100m"),
                    item.get("nav"),
                    item.get("premiumPct"),
                    item.get("netInflow100m"),
                    _json(item),
                    updated_at,
                ),
            )


def available_dates(table: str) -> list[str]:
    if table not in {"interbank_cd_daily", "etf_daily"}:
        raise ValueError(f"unsupported table: {table}")
    with connect() as conn:
        ensure_market_data_schema(conn)
        rows = conn.execute(f"SELECT data_date FROM {table} ORDER BY data_date").fetchall()
    return [row["data_date"] for row in rows]


def load_snapshot(table: str, requested_date: str | None = None) -> dict | None:
    if table not in {"interbank_cd_daily", "etf_daily"}:
        raise ValueError(f"unsupported table: {table}")
    with connect() as conn:
        ensure_market_data_schema(conn)
        if requested_date:
            row = conn.execute(f"SELECT payload_json FROM {table} WHERE data_date = ?", (requested_date,)).fetchone()
            if row:
                payload = json.loads(row["payload_json"])
                payload["requestedDate"] = requested_date
                return payload
            row = conn.execute(
                f"SELECT data_date, payload_json FROM {table} WHERE data_date <= ? ORDER BY data_date DESC LIMIT 1",
                (requested_date,),
            ).fetchone()
            if row:
                payload = json.loads(row["payload_json"])
                payload["requestedDate"] = requested_date
                payload["asOfFallback"] = True
                return payload
        row = conn.execute(f"SELECT payload_json FROM {table} ORDER BY data_date DESC LIMIT 1").fetchone()
        return json.loads(row["payload_json"]) if row else None


if __name__ == "__main__":
    init_market_data_db()
    print(json.dumps({"database": str(DB_PATH), "status": "ok"}, ensure_ascii=False))
