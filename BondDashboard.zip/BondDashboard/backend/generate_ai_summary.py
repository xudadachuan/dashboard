from __future__ import annotations

import json
import os
import re
import sys
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

from backend_api import market_payload
from market_data_status import update_locked
from trading_calendar import is_interbank_trading_day


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT.parent / "data"
MARKET_SNAPSHOT_FILE = DATA_DIR / "market_snapshot.json"
AI_SUMMARY_FILE = DATA_DIR / "ai_summary.json"
DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"
DEFAULT_MODEL = "deepseek-v4-flash"
REQUEST_TIMEOUT_SECONDS = 60


def load_dotenv(path: Path = ROOT.parent / ".env") -> None:
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def read_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def number(value) -> float | None:
    try:
        if value is None or value == "":
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def card_by_key(payload: dict, key: str) -> dict:
    cards = ((payload.get("chinabondYields") or {}).get("cards") or [])
    return next((item for item in cards if item.get("key") == key), {})


def curve_point(payload: dict, curve_key: str, term: str) -> dict:
    points = (((payload.get("chinabondYields") or {}).get("curves") or {}).get(curve_key) or {}).get("points") or []
    return next((item for item in points if item.get("term") == term), {})


def metric_value(payload: dict, code: str) -> float | None:
    metric = ((payload.get("fundingRates") or {}).get("metrics") or {}).get(code) or {}
    return number(metric.get("value"))


def build_market_snapshot() -> dict:
    payload = market_payload()
    yields = payload.get("chinabondYields") or {}
    funding = payload.get("fundingRates") or {}
    interbank_cd = payload.get("interbankCd") or {}
    bond_temp = payload.get("bondTemperature") or {}

    treasury_10y = card_by_key(payload, "treasury10")
    treasury_1y = curve_point(payload, "treasury", "1Y")
    slope_10y_1y = None
    if number(treasury_10y.get("value")) is not None and number(treasury_1y.get("today")) is not None:
        slope_10y_1y = round((number(treasury_10y.get("value")) - number(treasury_1y.get("today"))) * 100, 2)

    credit_components = (bond_temp.get("components") or {}).get("credit_temp") or {}
    dr007 = metric_value(payload, "DR007")

    snapshot = {
        "date": yields.get("date") or funding.get("date") or datetime.now().date().isoformat(),
        "market_status": "closed",
        "update_time": datetime.now().strftime("%H:%M:%S"),
        "rates": {
            "treasury_10y": {
                "name": "10年国债",
                "yield": number(treasury_10y.get("value")),
                "change_bp": number(treasury_10y.get("changeBp")),
            },
            "cdb_10y": {
                "name": "10年国开",
                "yield": number(card_by_key(payload, "cdb10").get("value")),
                "change_bp": number(card_by_key(payload, "cdb10").get("changeBp")),
            },
            "treasury_30y": {
                "name": "30年国债",
                "yield": number(card_by_key(payload, "treasury30").get("value")),
                "change_bp": number(card_by_key(payload, "treasury30").get("changeBp")),
            },
            "cdb_3y": {
                "name": "3年国开",
                "yield": number(card_by_key(payload, "cdb3").get("value")),
                "change_bp": number(card_by_key(payload, "cdb3").get("changeBp")),
            },
            "treasury_7y": {
                "name": "7年国债",
                "yield": number(card_by_key(payload, "treasury7").get("value")),
                "change_bp": number(card_by_key(payload, "treasury7").get("changeBp")),
            },
        },
        "money_market": {
            "dr001": metric_value(payload, "DR001"),
            "dr007": dr007,
            "r007": metric_value(payload, "R007"),
            "omo_7d": metric_value(payload, "OMO7D"),
            "omo_net": (number(payload.get("repoInjection")) - number(payload.get("repoMaturity")))
            if number(payload.get("repoInjection")) is not None and number(payload.get("repoMaturity")) is not None else None,
            "funding_comment": "资金利率低位平稳" if dr007 is not None and dr007 <= 1.8 else "资金价格有所抬升",
        },
        "curve": {
            "slope_10y_1y": slope_10y_1y,
            "slope_change_bp": None,
            "shape": infer_curve_shape(payload),
        },
        "credit_spread": {
            "signal": "available" if credit_components.get("available") else "unavailable",
            "comment": credit_components.get("label") or "信用利差数据暂缺",
        },
        "ncd": {
            "date": interbank_cd.get("date"),
            "total": interbank_cd.get("total"),
            "avg_yield": ((interbank_cd.get("segments") or {}).get("all") or {}).get("avgYield"),
            "ncd_comment": "同业存单发行数据已更新" if interbank_cd.get("date") else "同业存单数据暂缺",
        },
        "derived_signals": derive_signals(payload),
    }
    write_json(MARKET_SNAPSHOT_FILE, snapshot)
    return snapshot


def infer_curve_shape(payload: dict) -> str:
    one = curve_point(payload, "treasury", "1Y")
    ten = curve_point(payload, "treasury", "10Y")
    one_change = number(one.get("changeBp"))
    ten_change = number(ten.get("changeBp"))
    if one_change is None or ten_change is None:
        return "平稳"
    if ten_change < one_change:
        return "小幅走平"
    if ten_change > one_change:
        return "小幅走陡"
    return "平稳"


def derive_signals(payload: dict) -> dict:
    ten_change = number(card_by_key(payload, "treasury10").get("changeBp"))
    dr007 = metric_value(payload, "DR007")
    return {
        "rate_direction": "down" if ten_change is not None and ten_change < -1 else "up" if ten_change is not None and ten_change > 1 else "range_bound",
        "curve_signal": infer_curve_shape(payload),
        "funding_signal": "easy" if dr007 is not None and dr007 < 1.7 else "stable" if dr007 is not None and dr007 < 2.0 else "tight",
        "credit_signal": "mixed",
        "ncd_signal": "stable",
    }


def build_prompt(market_data: dict) -> str:
    return f"""
请基于以下中国债券市场结构化数据，生成债市收盘点评。
你必须严格输出 JSON，不要输出 Markdown，不要输出解释性文字。

输出 JSON 格式：
{{
  "headline": "8-16字中文标题",
  "summary": "80字以内中文市场点评",
  "tone": "neutral|positive|cautious",
  "risk_level": "low|medium|high"
}}

写作要求：
1. 只根据输入数据分析，不要编造未提供的信息。
2. 语气专业、客观、中性，类似固收收盘点评。
3. 不给投资建议，不出现“建议买入”“建议卖出”等表述。
4. 收益率下行代表债市偏强，收益率上行代表债市承压。
5. 主要指标变动均小于 1BP 时，优先表述为“窄幅震荡”。
6. headline 控制在 8-16 个中文字符，summary 控制在 80 个中文字符以内。

市场数据：
{json.dumps(market_data, ensure_ascii=False, indent=2)}
""".strip()


def parse_ai_json(content: str) -> dict:
    text = content.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    return json.loads(text)


def validate_ai_result(result: dict) -> None:
    if not isinstance(result, dict):
        raise ValueError("AI result is not a JSON object")
    for field in ("headline", "summary", "tone", "risk_level"):
        if not result.get(field):
            raise ValueError(f"AI result missing field: {field}")
    if result["tone"] not in {"neutral", "positive", "cautious"}:
        raise ValueError("tone must be neutral, positive, or cautious")
    if result["risk_level"] not in {"low", "medium", "high"}:
        raise ValueError("risk_level must be low, medium, or high")
    if len(str(result["headline"])) > 30:
        raise ValueError("headline is too long")
    if len(str(result["summary"])) > 120:
        raise ValueError("summary is too long")


def call_deepseek(prompt: str, model: str, api_key: str) -> dict:
    body = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "你是专业中国固定收益分析师。必须严格返回 json 对象，不输出 Markdown，不输出解释。",
            },
            {"role": "user", "content": prompt},
        ],
        "response_format": {"type": "json_object"},
        "temperature": 0.4,
        "max_tokens": 500,
        "stream": False,
    }
    request = urllib.request.Request(
        DEEPSEEK_URL,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=REQUEST_TIMEOUT_SECONDS) as response:
        payload = json.loads(response.read().decode("utf-8"))
    content = (((payload.get("choices") or [{}])[0].get("message") or {}).get("content") or "").strip()
    if not content:
        raise RuntimeError("DeepSeek returned empty content")
    return parse_ai_json(content)


def fallback_summary(market_data: dict) -> dict:
    signal = market_data.get("derived_signals") or {}
    rate_direction = signal.get("rate_direction")
    headline = "债市窄幅震荡"
    summary = "主要期限收益率变动有限，资金面整体平稳，曲线形态暂未出现明显方向。"
    tone = "neutral"
    risk_level = "low"
    if rate_direction == "down":
        headline = "收益率小幅下行"
        summary = "主要期限收益率小幅下行，资金面维持平稳，债市情绪略有修复。"
        tone = "positive"
    elif rate_direction == "up":
        headline = "债市小幅承压"
        summary = "主要期限收益率小幅上行，资金面总体平稳，债市表现略承压。"
        tone = "cautious"
        risk_level = "medium"
    return {
        "date": market_data.get("date"),
        "update_time": market_data.get("update_time") or datetime.now().strftime("%H:%M:%S"),
        "source": "fallback",
        "model": "fallback",
        "headline": headline,
        "summary": summary,
        "tone": tone,
        "risk_level": risk_level,
    }


def core_input_count(market_data: dict) -> int:
    return sum(value is not None for value in (
        (market_data.get("money_market") or {}).get("omo_net"),
        (market_data.get("money_market") or {}).get("dr007"),
        ((market_data.get("rates") or {}).get("treasury_10y") or {}).get("yield"),
    ))


def paused_summary(market_data: dict) -> dict:
    output = fallback_summary(market_data)
    output.update({
        "headline": "今日关键数据缺失，日评暂停生成",
        "summary": "OMO 净投放、DR007、10年国债三项核心输入中可用不足两项。为避免误导，本次未调用 AI。",
        "risk_level": "medium",
        "reason": "insufficient_core_inputs",
    })
    return output


def save_summary(market_data: dict, ai_result: dict, source: str, model: str) -> dict:
    output = {
        "date": market_data.get("date"),
        "update_time": datetime.now().strftime("%H:%M:%S"),
        "source": source,
        "model": model,
        "headline": str(ai_result["headline"]).strip(),
        "summary": str(ai_result["summary"]).strip(),
        "tone": ai_result["tone"],
        "risk_level": ai_result["risk_level"],
    }
    write_json(AI_SUMMARY_FILE, output)
    return output


@update_locked("ai_summary")
def main() -> int:
    if not is_interbank_trading_day():
        print("Skipped AI summary on a non-trading day.")
        return 0
    load_dotenv()
    if not os.environ.get("DEEPSEEK_API_KEY") and os.environ.get("YOUR_API_KEY"):
        os.environ["DEEPSEEK_API_KEY"] = os.environ["YOUR_API_KEY"]
    model = os.environ.get("DEEPSEEK_MODEL", DEFAULT_MODEL)
    market_data = build_market_snapshot()
    if core_input_count(market_data) < 2:
        output = paused_summary(market_data)
        write_json(AI_SUMMARY_FILE, output)
        print(json.dumps(output, ensure_ascii=False, indent=2))
        return 0
    prompt = build_prompt(market_data)

    try:
        api_key = os.environ["DEEPSEEK_API_KEY"].strip()
        if not api_key:
            raise KeyError
        ai_result = call_deepseek(prompt, model, api_key)
        validate_ai_result(ai_result)
        output = save_summary(market_data, ai_result, "deepseek", model)
        print(json.dumps(output, ensure_ascii=False, indent=2))
        return 0
    except KeyError:
        print("Missing DEEPSEEK_API_KEY. Keeping existing AI summary or writing fallback.", file=sys.stderr)
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, ValueError, RuntimeError) as exc:
        print(f"AI summary generation failed: {exc}", file=sys.stderr)

    existing = read_json(AI_SUMMARY_FILE)
    output = existing or fallback_summary(market_data)
    if not existing:
        write_json(AI_SUMMARY_FILE, output)
    print(json.dumps(output, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
