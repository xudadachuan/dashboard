@echo off
setlocal
cd /d "%~dp0"
if not defined PYTHON_EXE set "PYTHON_EXE=C:\Program Files\Python313\python.exe"
if not exist "%PYTHON_EXE%" set "PYTHON_EXE=python"

if not exist "logs" mkdir "logs"
set "LOG=%CD%\logs\market_data_update.log"

echo ==== %date% %time% ====>> "%LOG%"
"%PYTHON_EXE%" funding_update_runner.py 1>> "%LOG%" 2>>&1
exit /b %errorlevel%
