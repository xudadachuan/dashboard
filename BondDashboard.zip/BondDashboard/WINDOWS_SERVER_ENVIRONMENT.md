# 债市看板 Windows 云服务器环境配置与下载清单

## 1. 推荐环境

- 服务器：Windows Server 2019/2022/2025，64 位。
- 最低建议配置：2 核 CPU、4 GB 内存、20 GB 可用磁盘。
- 部署目录：`C:\BondDashboard`。不要把目录放在临时目录或个人桌面。
- 运行账户：安装时使用管理员账户；安装后服务和定时更新任务以 `SYSTEM` 身份运行，无需保持远程桌面登录。
- 对外端口：HTTP 使用 TCP 80；配置域名和 HTTPS 后再开放 TCP 443。

本项目的前端是静态文件，后端只使用 Python 标准库和 SQLite。默认数据源为东方财富，因此常规部署不需要 Node.js、npm、Java、MySQL、Redis、Office，也不需要执行 `pip install`。

## 2. 需要下载的软件

自动安装脚本会下载以下两项：

| 软件 | 使用版本 | 官方下载地址 | 安装位置 | 用途 |
| --- | --- | --- | --- | --- |
| Python 64 位 | 3.13.14 | [python-3.13.14-amd64.exe](https://www.python.org/ftp/python/3.13.14/python-3.13.14-amd64.exe) | `C:\Program Files\Python313` | 运行后端和数据更新脚本 |
| Caddy 64 位 | 安装时获取最新稳定版 | [Caddy 官方 Releases](https://github.com/caddyserver/caddy/releases/latest) | `C:\BondDashboard\tools\caddy\caddy.exe` | 监听 80/443 并反向代理到本机后端 |

安装器会验证 Python 安装包的数字签名。Python 3.13.14 是 2026-06-10 发布的正式维护版本；Caddy 使用安装时 GitHub 标记的最新稳定版。

可选项：只有把 `BOND_DASHBOARD_ETF_SOURCE` 改成 `ifind` 时，才需要安装同花顺 iFinD 客户端及其 `iFinDPy` SDK，并配置 `IFIND_USERNAME`、`IFIND_PASSWORD`。iFinD SDK 请从已有授权的 iFinD 客户端或同花顺官方渠道获取；默认 `eastmoney` 模式不需要它。

### 无公网安装

如果云服务器不能访问外网，可先在另一台电脑下载上述软件：

1. 使用默认选项把 Python 安装到 `C:\Program Files\Python313`，并选择为所有用户安装。
2. 解压 Caddy，将 `caddy.exe` 放到 `C:\BondDashboard\tools\caddy\caddy.exe`。
3. 再运行本包的安装脚本；检测到这两个文件后不会重复下载。

## 3. 网络与安全组

在云厂商安全组中添加入方向规则：

| 端口 | 协议 | 来源 | 说明 |
| --- | --- | --- | --- |
| 80 | TCP | 按实际访问范围设置 | 当前 HTTP 访问端口 |
| 443 | TCP | 按实际访问范围设置 | 仅配置域名 HTTPS 后开放 |
| 3389 | TCP | 仅管理员固定 IP | Windows 远程桌面；不要对全网开放 |

不要在安全组或 Windows 防火墙中开放后端端口 8765。后端固定监听 `127.0.0.1:8765`，只允许 Caddy 从本机访问。

自动安装需要服务器能访问 `www.python.org`、`api.github.com` 和 `github.com`。程序运行和更新还会访问人民银行、中国债券信息网、中国货币网、东方财富、政府公开信息站点、Bing 新闻；启用 AI 或邮件时还需要访问 `api.deepseek.com` 和 `smtpdm.aliyun.com:465`。

## 4. 一键安装

将整个部署包上传并解压到 `C:\BondDashboard`。以管理员身份打开 Windows PowerShell，执行：

```powershell
Set-ExecutionPolicy -Scope Process Bypass
Set-Location C:\BondDashboard
.\deploy\windows\install.ps1
```

安装脚本会完成以下配置：

- 安装或复用 Python 3.13.14；
- 下载并解压 Caddy；
- 创建 `.env` 配置模板；
- 注册后端、Caddy 和 4 个数据更新计划任务；
- 放行 Windows 防火墙 TCP 80；
- 启动后端和 Caddy。

如果部署包暂时不在目标目录，也可以从解压目录运行：

```powershell
.\deploy\windows\install.ps1 -AppRoot C:\BondDashboard
```

脚本会把部署包复制到目标目录。

## 5. 配置 `.env`

安装后，用记事本编辑 `C:\BondDashboard\.env`。建议至少填写管理员三项：

```dotenv
BOND_DASHBOARD_HOST=127.0.0.1
BOND_DASHBOARD_PORT=8765

BOND_DASHBOARD_ADMIN_USERNAME=admin
BOND_DASHBOARD_ADMIN_EMAIL=admin@example.com
BOND_DASHBOARD_ADMIN_PASSWORD=请替换为至少12位的强密码
BOND_DASHBOARD_AUTH_DB_PATH=C:\BondDashboard\data\accounts.db

DEEPSEEK_API_KEY=
DEEPSEEK_MODEL=deepseek-v4-flash
DEEPSEEK_NEWS_MODEL=deepseek-v4-flash

BOND_DASHBOARD_ETF_SOURCE=eastmoney
IFIND_USERNAME=
IFIND_PASSWORD=

ALIYUN_DM_SMTP_HOST=smtpdm.aliyun.com
ALIYUN_DM_SMTP_PORT=465
ALIYUN_DM_SMTP_USERNAME=
ALIYUN_DM_SMTP_PASSWORD=
ALIYUN_DM_FROM_NAME=债市脉搏
```

- `DEEPSEEK_API_KEY`：生成 AI 摘要和市场评论时需要；留空时相关功能使用已有缓存或降级结果。
- 阿里云邮件参数：邮箱验证码功能需要；不用邮件登录时可留空。
- 管理员只在用户名不存在时于后端启动阶段创建。填写或修改 `.env` 后必须重启后端任务。
- `.env` 含真实密钥，不要发送给他人，也不要提交到代码仓库。

保存后执行：

```powershell
Stop-ScheduledTask -TaskName BondDashboard_Backend -ErrorAction SilentlyContinue
Start-ScheduledTask -TaskName BondDashboard_Backend
```

## 6. 验证部署

先检查本机和公网健康状态：

```powershell
Set-Location C:\BondDashboard
.\deploy\windows\verify.ps1 -PublicIp 你的云服务器公网IP
```

正常结果应满足：

- `BackendStatus` 为 `ok`；
- `PublicStatusCode` 为 `200`；
- `BackendTask` 和 `CaddyTask` 为 `0`，或任务仍在长期运行且健康接口正常。

浏览器访问 `http://你的公网IP/`。也可单独检查：

```powershell
Invoke-RestMethod http://127.0.0.1:8765/api/health
Invoke-WebRequest http://127.0.0.1/api/health -UseBasicParsing
Get-ScheduledTask -TaskName "BondDashboard_*" | Format-Table TaskName, State
```

日志位于 `C:\BondDashboard\logs`。数据文件和 SQLite 数据库位于 `C:\BondDashboard\data`，应纳入服务器备份。

## 7. 定时任务

| 任务 | 每日时间（服务器本地时间） | 内容 |
| --- | --- | --- |
| `BondDashboard_PBOC_OMO_Update` | 09:35 | 公开市场操作更新 |
| `BondDashboard_Market_Data_Update` | 17:00 | 资金、存单、债券等市场数据更新 |
| `BondDashboard_AI_Summary_Update` | 17:10 | AI 摘要和市场评论更新 |
| `BondDashboard_ETF_Data_Update` | 21:00 | ETF 数据更新 |

请把 Windows 时区设置为中国标准时间：

```powershell
Set-TimeZone -Id "China Standard Time"
```

## 8. 域名与 HTTPS（可选）

先把域名 A 记录解析到服务器公网 IP，再把 `C:\BondDashboard\deploy\windows\Caddyfile` 第一行的 `:80` 改为实际域名，例如：

```caddyfile
bond.example.com {
    encode zstd gzip
    reverse_proxy 127.0.0.1:8765
}
```

开放安全组和 Windows 防火墙 TCP 443 后重启 Caddy：

```powershell
New-NetFirewallRule -DisplayName "Bond Dashboard HTTPS" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 443 -Profile Any
Stop-ScheduledTask -TaskName BondDashboard_Caddy -ErrorAction SilentlyContinue
Start-ScheduledTask -TaskName BondDashboard_Caddy
```

Caddy 会自动申请和续期 HTTPS 证书；申请证书时域名必须已正确解析，且公网能够访问 80/443。

## 9. 常见故障

- 公网访问超时：检查云安全组 TCP 80、Windows 防火墙规则和 `BondDashboard_Caddy` 任务。
- 本机 8765 不通：查看 `BondDashboard_Backend` 的任务结果，确认 `.env` 没有错误端口或无效数据库路径。
- 管理员没有创建：填写管理员三项后重启后端；用户名已存在时不会用 `.env` 覆盖密码。
- 定时更新失败：查看 `C:\BondDashboard\logs\*.log`，并确认服务器可以访问所需外部站点。
- 邮件验证码失败：核对阿里云 DirectMail 发信地址、SMTP 密码、465 端口和服务器出方向规则。
