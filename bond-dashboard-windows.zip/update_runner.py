from __future__ import annotations

import json
import os
import subprocess
import sys
import traceback
from datetime import datetime
from pathlib import Path

from market_data_status import save_market_data_status, update_locked
from trading_calendar import is_interbank_trading_day


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
LOG_DIR = ROOT / "logs"
REQUEST_FILE = DATA_DIR / "pending_update_requests.json"
LOG_FILE = LOG_DIR / "pboc_omo_update.log"


COMMANDS = [
    [
        sys.executable,
        "pboc_omo_crawler.py",
        "--import-calendar",
        "--sync",
        "--backfill-maturity",
        "--export-json",
        "--pages",
        "1",
        "--limit",
        "200",
    ],
    [
        sys.executable,
        "central_bank_tools.py",
        "--init",
        "--migrate-reverse-repo",
        "--sync-extra",
        "--summary",
    ],
]


def now_text() -> str:
    return datetime.now().isoformat(timespec="seconds")


def load_requests() -> list[dict]:
    if not REQUEST_FILE.exists():
        return []
    try:
        payload = json.loads(REQUEST_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        backup = REQUEST_FILE.with_suffix(f".broken-{datetime.now():%Y%m%d%H%M%S}.json")
        REQUEST_FILE.replace(backup)
        return []
    return payload if isinstance(payload, list) else []


def save_requests(items: list[dict]) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    REQUEST_FILE.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")


def append_log(message: str) -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    with LOG_FILE.open("a", encoding="utf-8") as handle:
        handle.write(message)
        if not message.endswith("\n"):
            handle.write("\n")


def create_request() -> dict:
    created_at = now_text()
    return {
        "id": f"pboc-omo-{datetime.now():%Y%m%d-%H%M%S}",
        "createdAt": created_at,
        "status": "pending",
        "attempts": 0,
        "lastAttemptAt": None,
        "lastError": None,
        "completedAt": None,
    }


def run_update() -> None:
    if os.environ.get("PBOC_UPDATE_FORCE_FAIL") == "1":
        raise RuntimeError("Simulated network/update failure")

    for command in COMMANDS:
        append_log(f"$ {' '.join(command)}")
        completed = subprocess.run(
            command,
            cwd=ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        append_log(completed.stdout)
        if completed.returncode != 0:
            raise RuntimeError(f"Command failed with exit code {completed.returncode}: {' '.join(command)}")


@update_locked("pboc_omo")
def main() -> int:
    if not is_interbank_trading_day():
        append_log(f"skipped non-trading day at={now_text()}")
        return 0
    requests = load_requests()
    current = create_request()
    requests.append(current)
    save_requests(requests)

    append_log(f"==== {now_text()} request={current['id']} ====")
    try:
        pending = [item for item in requests if item.get("status") == "pending"]
        for item in pending:
            item["attempts"] = int(item.get("attempts") or 0) + 1
            item["lastAttemptAt"] = now_text()

        run_update()

        completed_at = now_text()
        for item in requests:
            if item.get("status") == "pending":
                item["status"] = "completed"
                item["completedAt"] = completed_at
                item["lastError"] = None
        save_requests(requests)
        save_market_data_status()
        append_log(f"completed pending_requests={len(pending)} at={completed_at}")
        return 0
    except Exception as exc:
        error = "".join(traceback.format_exception_only(type(exc), exc)).strip()
        for item in requests:
            if item.get("status") == "pending":
                item["lastError"] = error
        save_requests(requests)
        save_market_data_status()
        append_log(f"failed: {error}")
        append_log(traceback.format_exc())
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
