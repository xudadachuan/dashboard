from __future__ import annotations

"""从中金所公开端点获取国债期货官方日行情。

该脚本参考 ``国债期货数据获取_打包`` 的 CFFEX 适配器，只写入官方日行情，
可交割券和转换因子由 ``treasury_futures_cffex_enrich.py`` 单独更新。遇到
非交易日时向前回溯，保证面板始终展示最近一个有数据的交易日。
"""

import csv
import json
import re
import time
import xml.etree.ElementTree as ET
from datetime import date, timedelta
from pathlib import Path
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT.parent / "data" / "treasury_futures"
INPUT_DIR = DATA_DIR / "input"
CALENDAR_FILE = ROOT.parent / "data" / "interbank_calendar.json"
PRODUCTS = ("TS", "TF", "T", "TL")
URL_TEMPLATE = "http://www.cffex.com.cn/sj/hqsj/rtj/{yyyymm}/{dd}/index.xml"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (BondDashboard; CFFEX public data)",
    "Accept": "application/xml,text/xml,*/*;q=0.5",
    "Referer": "http://www.cffex.com.cn/cn/kjggzxx.html",
}


def _tag(value: str) -> str:
    return str(value).rsplit("}", 1)[-1].lower()


def _text(node: ET.Element, name: str) -> str:
    for child in node.iter():
        if _tag(child.tag) == name.lower():
            return (child.text or "").strip()
    return ""


def _number(value: object) -> str:
    text = "" if value is None else str(value).strip().replace(",", "")
    if not text or text.lower() in {"null", "nan", "--", "-"}:
        return ""
    try:
        return str(float(text))
    except ValueError:
        return ""


def _date8(value: object) -> str:
    text = "" if value is None else str(value).strip()
    if re.fullmatch(r"\d{8}", text):
        return f"{text[:4]}-{text[4:6]}-{text[6:]}"
    return text[:10] if re.fullmatch(r"\d{4}-\d{2}-\d{2}.*", text) else ""


def parse_daily(payload: bytes) -> list[dict[str, str]]:
    root = ET.fromstring(payload)
    rows: list[dict[str, str]] = []
    for node in root.iter():
        if _tag(node.tag) != "dailydata":
            continue
        product = _text(node, "productid").upper()
        instrument = _text(node, "instrumentid").upper()
        if product not in PRODUCTS or not re.fullmatch(rf"{product}\d{{4}}", instrument):
            continue
        settlement_raw = _text(node, "settlementprice")
        settlement = _number(settlement_raw)
        settlement_if = _number(_text(node, "settlementpriceif"))
        if not settlement and settlement_if:
            settlement = settlement_if
        pre_oi = _number(_text(node, "preopeninterest"))
        oi = _number(_text(node, "openinterest"))
        oi_change = ""
        try:
            if pre_oi and oi:
                oi_change = str(float(oi) - float(pre_oi))
        except ValueError:
            pass
        used_proxy = bool(settlement_if and not settlement_raw)
        rows.append({
            "date": _date8(_text(node, "tradingday")),
            "product": product,
            "contract": instrument,
            "last_trading_date": "",
            "trading_days_to_last": "",
            "open": _number(_text(node, "openprice")),
            "high": _number(_text(node, "highestprice")),
            "low": _number(_text(node, "lowestprice")),
            "close": _number(_text(node, "closeprice")),
            "previous_close": _number(_text(node, "presettlementprice")),
            "settlement": settlement,
            "settlement_if": settlement_if,
            "volume": _number(_text(node, "volume")),
            "turnover": _number(_text(node, "turnover")),
            "open_interest": oi,
            "pre_open_interest": pre_oi,
            "open_interest_change": oi_change,
            "price_type": "SETTLEMENT_IF_PROXY" if used_proxy else "SETTLEMENT",
            "source": "CFFEX_OFFICIAL",
            "source_url": "",
            "retrieved_at": "",
            "calculation_status": "ESTIMATED" if used_proxy else "EXACT",
            "ctd_code": "",
            "conversion_factor": "",
            "ctd_dirty_price": "",
            "ctd_dv01": "",
            "basis": "",
            "irr": "",
        })
    return rows


def _last_trading_date(contract: str) -> str:
    match = re.fullmatch(r"[A-Z]+(\d{2})(\d{2})", contract)
    if not match:
        return ""
    year, month = 2000 + int(match.group(1)), int(match.group(2))
    first = date(year, month, 1)
    first_friday = first + timedelta(days=(4 - first.weekday()) % 7)
    return (first_friday + timedelta(days=7)).isoformat()


def _trading_days_to_last(data_date: str, last_date: str) -> str:
    try:
        calendar = json.loads(CALENDAR_FILE.read_text(encoding="utf-8"))
        holidays = set(calendar.get("holidays") or [])
        workdays = set(calendar.get("workdays") or [])
        current = date.fromisoformat(data_date) + timedelta(days=1)
        end = date.fromisoformat(last_date)
    except (OSError, ValueError, json.JSONDecodeError):
        return ""
    count = 0
    while current <= end:
        key = current.isoformat()
        if key in workdays or (current.weekday() < 5 and key not in holidays):
            count += 1
        current += timedelta(days=1)
    return str(count)


def _fetch_for(day: date) -> list[dict[str, str]]:
    yyyymm, dd = day.strftime("%Y%m"), day.strftime("%d")
    url = URL_TEMPLATE.format(yyyymm=yyyymm, dd=dd)
    request = Request(url, headers=HEADERS)
    payload = urlopen(request, timeout=30).read()
    if b"404_1.gif" in payload or "网页错误" in payload.decode("utf-8", "ignore"):
        return []
    rows = parse_daily(payload)
    for row in rows:
        row["source_url"] = url
        row["retrieved_at"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")
        row["last_trading_date"] = _last_trading_date(row["contract"])
        row["trading_days_to_last"] = _trading_days_to_last(row["date"], row["last_trading_date"])
    return rows


def main() -> None:
    today = date.today()
    rows: list[dict[str, str]] = []
    errors: list[str] = []
    selected_date = ""
    for offset in range(0, 11):
        target = today - timedelta(days=offset)
        try:
            rows = _fetch_for(target)
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{target.isoformat()}: {type(exc).__name__}: {exc}")
            rows = []
        if rows:
            selected_date = rows[0]["date"]
            break
    INPUT_DIR.mkdir(parents=True, exist_ok=True)
    output = INPUT_DIR / f"treasury_futures_{selected_date or today.isoformat()}.csv"
    fields = [
        "date", "product", "contract", "last_trading_date", "trading_days_to_last",
        "open", "high", "low", "close", "previous_close", "settlement", "settlement_if",
        "volume", "turnover", "open_interest", "pre_open_interest", "open_interest_change",
        "price_type", "source", "source_url", "retrieved_at", "calculation_status",
        "ctd_code", "conversion_factor", "ctd_dirty_price", "ctd_dv01", "basis", "irr",
    ]
    with output.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({"date": selected_date or None, "file": str(output), "rows": len(rows), "errors": errors[-5:]}, ensure_ascii=False))
    if not rows:
        raise SystemExit("中金所最近 11 天未返回可解析行情")


if __name__ == "__main__":
    main()
