const BondDashboardApi = (() => {
  const jsonHeaders = { Accept: 'application/json' };

  async function getJson(url) {
    const response = await fetch(url, { headers: jsonHeaders, cache: 'no-store' });
    if (response.status === 401) window.dispatchEvent(new CustomEvent('bond-auth-required'));
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
  }

  function dateQuery(date) {
    return date ? `?date=${encodeURIComponent(date)}` : '';
  }

  async function fetchFundingRates(date) {
    return getJson(`/api/funding-rates${dateQuery(date)}`);
  }

  async function fetchInterbankCd(date) {
    return getJson(`/api/interbank-cd${dateQuery(date)}`);
  }

  async function fetchEtfData(date) {
    const payload = normalizeEtfDashboardPayload(await getJson(`/api/etf-data${dateQuery(date)}`));
    if (!etfPayloadNeedsPrevious(payload) || !payload.date || !Array.isArray(payload.availableDates)) return payload;
    const previousDate = payload.availableDates.filter(value => value < payload.date).at(-1);
    if (!previousDate) return payload;
    try {
      return normalizeEtfDashboardPayload(payload, await getJson(`/api/etf-data?date=${encodeURIComponent(previousDate)}`));
    } catch (error) {
      return payload;
    }
  }

  async function fetchMarketNews() {
    return getJson('/api/market-news');
  }

  return {
    getJson,
    fetchFundingRates,
    fetchInterbankCd,
    fetchEtfData,
    fetchMarketNews,
  };
})();
