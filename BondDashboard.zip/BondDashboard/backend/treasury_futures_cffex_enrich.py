"""Fetch official CFFEX deliverable-bond metadata for the latest futures CSV."""

from __future__ import annotations

import csv
import json
import xml.etree.ElementTree as ET
from datetime import date
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT.parent / "data" / "treasury_futures"
INPUT_DIR = DATA_DIR / "input"
OUTPUT_FILE = DATA_DIR / "cffex_deliverable_latest.json"
URL = "http://www.cffex.com.cn/sj/jgsj/jgqsj/index_6882.csv"
HEADERS = {"User-Agent": "Mozilla/5.0"}


def fetch_index() -> dict[str, list[dict]]:
    request = Request(URL, headers=HEADERS)
    raw = urlopen(request, timeout=30).read().decode("utf-8-sig", "replace")
    result: dict[str, list[dict]] = {}
    for line_no, line in enumerate(raw.splitlines(), start=1):
        fields = [field.strip() for field in line.split(",")]
        if len(fields) < 9:
            continue
        fullname, bank_code, sh_code, sz_code, maturity, coupon, factor, contract, product = fields[:9]
        if not contract or not product:
            continue
        result.setdefault(contract, []).append({
            "fullname": fullname, "bankCode": bank_code, "shCode": sh_code,
            "szCode": sz_code, "maturity": maturity, "coupon": coupon,
            "conversionFactor": factor, "product": product,
        })
    return result


def latest_contracts() -> list[str]:
    files = sorted(INPUT_DIR.glob("treasury_futures_*.csv"), key=lambda path: path.stat().st_mtime)
    if not files:
        return []
    with files[-1].open("r", encoding="utf-8-sig", newline="") as handle:
        return sorted({row.get("contract", "").strip() for row in csv.DictReader(handle) if row.get("contract")})


def fetch_contract_xml(contract: str) -> list[dict]:
    url = f"http://www.cffex.com.cn/sj/jgsj/jgqsj/{contract}/index_1.xml"
    try:
        root = ET.fromstring(urlopen(Request(url, headers=HEADERS), timeout=30).read())
    except Exception:
        return []
    rows: list[dict] = []
    for node in root.findall("delivtreasiinfo"):
        rows.append({
            "fullname": (node.findtext("fullname") or "").strip(),
            "maturity": (node.findtext("expiredate") or "").strip(),
            "coupon": (node.findtext("rate") or "").strip(),
            "conversionFactor": (node.findtext("cf") or "").strip(),
            "bankCode": (node.findtext("treasidib") or node.findtext("treasidIB") or "").strip(),
            "shCode": (node.findtext("treasidsh") or node.findtext("treasidSH") or "").strip(),
            "szCode": (node.findtext("treasidsz") or node.findtext("treasidSZ") or "").strip(),
            "product": (node.findtext("productid") or "").strip(),
        })
    return rows


def main() -> None:
    index = fetch_index()
    contracts = latest_contracts()
    result = {contract: index.get(contract) or fetch_contract_xml(contract) for contract in contracts}
    payload = {"date": date.today().isoformat(), "source": URL, "contracts": result}
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"date": payload["date"], "contracts": len(result), "deliverableRows": sum(len(rows) for rows in result.values()), "file": str(OUTPUT_FILE)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
