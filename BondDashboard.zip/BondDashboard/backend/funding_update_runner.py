from __future__ import annotations

import json
import os
import subprocess
import sys
import traceback
from datetime import datetime
from pathlib import Path

from auth import load_env_file
from chinabond_yields import query_chinabond_yields
from chinabond_ncd import query_ncd_valuation
from funding_rates import query_funding_rates
from interbank_cd import query_interbank_cd
from bond_temperature import query_bond_temperature, save_bond_temperature
from etf_data import query_etf_data
from funding_sentiment import save_funding_sentiment
from market_data_status import save_market_data_status, update_locked
from market_commentary import backfill_daily_commentary, generate_daily, generate_weekly
from market_news import update_market_news
from primary_issuance_merge import run_daily_pipeline
from treasury_futures import query_treasury_futures
from trading_calendar import is_interbank_trading_day


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT.parent / "data"
LOG_DIR = ROOT.parent / "logs"
REQUEST_FILE = DATA_DIR / "pending_funding_rate_requests.json"


def log_file() -> Path:
    return LOG_DIR / f"market_data_update_{datetime.now():%Y-%m-%d}.log"
load_env_file(ROOT.parent / ".env")


def now_text() -> str:
    return datetime.now().isoformat(timespec="seconds")


def load_requests() -> list[dict]:
    if not REQUEST_FILE.exists():
        return []
    try:
        payload = json.loads(REQUEST_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        backup = REQUEST_FILE.with_suffix(f".broken-{datetime.now():%Y%m%d%H%M%S}.json")
        REQUEST_FILE.replace(backup)
        return []
    return payload if isinstance(payload, list) else []


def save_requests(items: list[dict]) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    REQUEST_FILE.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")


def append_log(message: str) -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        with log_file().open("a", encoding="utf-8") as handle:
            handle.write(message)
            if not message.endswith("\n"):
                handle.write("\n")
    except PermissionError:
        # Batch files redirect stdout/stderr to the same log. On Windows that
        # handle can lock the file, so fall back to stdout instead of failing
        # the whole scheduled update.
        print(message)


def create_request() -> dict:
    created_at = now_text()
    return {
        "id": f"funding-rates-{datetime.now():%Y%m%d-%H%M%S}",
        "createdAt": created_at,
        "status": "pending",
        "attempts": 0,
        "lastAttemptAt": None,
        "lastError": None,
        "completedAt": None,
        "completedDataDate": None,
    }


def has_required_rates(payload: dict) -> bool:
    metrics = payload.get("metrics") or {}
    return all((metrics.get(code) or {}).get("value") is not None for code in ("DR001", "DR007", "R007", "OMO7D"))


def is_official_update_window() -> bool:
    if os.environ.get("BOND_DASHBOARD_FORCE_WRITE") == "1":
        return True
    return datetime.now().hour >= 17


def should_update_etf() -> bool:
    return os.environ.get("BOND_DASHBOARD_INCLUDE_ETF") == "1" or os.environ.get("BOND_DASHBOARD_FORCE_WRITE") == "1"


def update_treasury_futures(official_write: bool) -> dict:
    if not official_write:
        return query_treasury_futures()
    try:
        subprocess.run([sys.executable, str(ROOT / "treasury_futures_cffex_fetch.py")], cwd=ROOT, check=True)
    except subprocess.CalledProcessError:
        # 中金所临时不可用时保留原有公开快照兜底，避免面板清空。
        subprocess.run([sys.executable, str(ROOT / "treasury_futures_eastmoney_fetch.py")], cwd=ROOT, check=True)
    subprocess.run([sys.executable, str(ROOT / "treasury_futures_cffex_enrich.py")], cwd=ROOT, check=True)
    return query_treasury_futures(refresh=True)


def run_update() -> dict:
    if os.environ.get("FUNDING_UPDATE_FORCE_FAIL") == "1":
        raise RuntimeError("Simulated funding-rate update failure")

    official_write = is_official_update_window()
    errors: dict[str, str] = {}

    def run_step(name: str, func, fallback):
        try:
            return func()
        except Exception as exc:
            errors[name] = f"{type(exc).__name__}: {exc}"
            append_log(f"{name} failed: {errors[name]}")
            append_log(traceback.format_exc())
            return fallback

    def update_funding_rates() -> dict:
        payload = query_funding_rates(refresh=official_write)
        if payload.get("source") != "chinamoney" or not has_required_rates(payload):
            # ChinaMoney's latest endpoint can lag or return empty near close.
            # Probe recent dates explicitly before treating the run as failed.
            from datetime import date, timedelta

            if official_write:
                for offset in range(0, 8):
                    candidate = (date.today() - timedelta(days=offset)).isoformat()
                    candidate_payload = query_funding_rates(candidate, refresh=True)
                    if candidate_payload.get("source") == "chinamoney" and has_required_rates(candidate_payload):
                        payload = candidate_payload
                        break

        if official_write and (payload.get("source") != "chinamoney" or not has_required_rates(payload)):
            raise RuntimeError(f"Funding rates not refreshed from ChinaMoney: source={payload.get('source')} error={payload.get('error')}")
        return payload

    payload = run_step("funding_rates", update_funding_rates, {"date": None, "metrics": {}, "source": "unavailable"})
    interbank_cd_valuation = run_step(
        "interbank_cd_valuation",
        lambda: query_ncd_valuation(refresh=official_write),
        {"date": None, "termYields": {}, "source": "unavailable"},
    )
    interbank_cd = run_step(
        "interbank_cd_issuance",
        lambda: query_interbank_cd(refresh=official_write, valuation_curve=interbank_cd_valuation),
        {"items": [], "source": "unavailable"},
    )
    chinabond_yields = run_step("chinabond_yields", lambda: query_chinabond_yields(refresh=official_write), {"date": None})
    bond_temperature = run_step("bond_temperature", lambda: save_bond_temperature() if official_write else query_bond_temperature(), {"date": None})
    funding_sentiment = run_step("funding_sentiment", lambda: save_funding_sentiment() if official_write else {"date": None}, {"date": None})
    etf_data = run_step("etf_data", lambda: query_etf_data(refresh=True) if official_write and should_update_etf() else query_etf_data(), {"items": []})
    market_news = run_step("market_news", lambda: update_market_news() if official_write else {"items": []}, {"items": []})
    commentary = run_step("market_commentary_daily", lambda: generate_daily() if official_write else {"date": "-", "source": "skipped"}, {"date": "-", "source": "failed"})
    commentary_backfill = run_step("market_commentary_backfill", lambda: backfill_daily_commentary() if official_write else [], [])
    weekly_commentary = run_step("market_commentary_weekly", lambda: generate_weekly() if official_write else None, None)
    primary_issuance = run_step(
        "primary_issuance_excel",
        lambda: run_daily_pipeline()["output"] if official_write else {"items": []},
        {"items": []},
    )
    treasury_futures = run_step(
        "treasury_futures",
        lambda: update_treasury_futures(official_write),
        query_treasury_futures(),
    )
    status = run_step("market_data_status", save_market_data_status, {"aligned": False})
    append_log(
        "market data refreshed "
        f"date={payload.get('date')} "
        f"DR001={(payload.get('metrics') or {}).get('DR001', {}).get('value')} "
        f"DR007={(payload.get('metrics') or {}).get('DR007', {}).get('value')} "
        f"R007={(payload.get('metrics') or {}).get('R007', {}).get('value')} "
        f"OMO7D={(payload.get('metrics') or {}).get('OMO7D', {}).get('value')} "
        f"NCDValuation={interbank_cd_valuation.get('date')}:{interbank_cd_valuation.get('source')} "
        f"IBNCD={len(interbank_cd.get('items') or [])}:{interbank_cd.get('issuanceDate') or interbank_cd.get('date')}:{interbank_cd.get('issuanceSource') or interbank_cd.get('source')} "
        f"ChinaBond={chinabond_yields.get('date')} "
        f"BondTemp={bond_temperature.get('date')}:{bond_temperature.get('bond_temp')} "
        f"FundingSentiment={funding_sentiment.get('date')}:{funding_sentiment.get('value')} "
        f"ETF={len(etf_data.get('items') or [])} "
        f"News={len(market_news.get('items') or [])} "
        f"Commentary={commentary.get('date')}:{commentary.get('source')} "
        f"CommentaryBackfill={len(commentary_backfill)} "
        f"Weekly={weekly_commentary.get('weekEndDate') if weekly_commentary else '-'} "
        f"PrimaryIssuanceExcel={len(primary_issuance.get('items') or [])} "
        f"TreasuryFutures={treasury_futures.get('date')}:{sum(1 for item in treasury_futures.get('products') or [] if item.get('available'))} "
        f"OfficialWrite={official_write} "
        f"Aligned={status.get('aligned')} "
        f"Errors={errors or '-'}"
    )
    if errors:
        critical = {"funding_rates", "chinabond_yields", "bond_temperature", "market_data_status"}
        if critical.intersection(errors):
            raise RuntimeError("critical market data update step(s) failed: " + "; ".join(f"{key}={value}" for key, value in errors.items()))
    return payload


@update_locked("market_data")
def main() -> int:
    if not is_interbank_trading_day():
        append_log(f"skipped non-trading day at={now_text()}")
        return 0
    requests = load_requests()
    current = create_request()
    requests.append(current)
    save_requests(requests)

    append_log(f"==== {now_text()} request={current['id']} ====")
    try:
        pending = [item for item in requests if item.get("status") == "pending"]
        for item in pending:
            item["attempts"] = int(item.get("attempts") or 0) + 1
            item["lastAttemptAt"] = now_text()

        payload = run_update()

        completed_at = now_text()
        for item in requests:
            if item.get("status") == "pending":
                item["status"] = "completed"
                item["completedAt"] = completed_at
                item["completedDataDate"] = payload.get("date")
                item["lastError"] = None
        save_requests(requests)
        append_log(f"completed pending_requests={len(pending)} at={completed_at}")
        return 0
    except Exception as exc:
        error = "".join(traceback.format_exception_only(type(exc), exc)).strip()
        for item in requests:
            if item.get("status") == "pending":
                item["lastError"] = error
        save_requests(requests)
        save_market_data_status()
        append_log(f"failed: {error}")
        append_log(traceback.format_exc())
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
