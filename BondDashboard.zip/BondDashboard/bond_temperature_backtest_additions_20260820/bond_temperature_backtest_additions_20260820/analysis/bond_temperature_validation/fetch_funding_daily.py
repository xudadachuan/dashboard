from __future__ import annotations

import argparse
import csv
import json
import re
from datetime import date
from http.cookiejar import Cookie, CookieJar
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import HTTPCookieProcessor, Request, build_opener


BASE_URL = "https://www.macroview.club"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/127.0 Safari/537.36"


def browser_view_id(user_agent: str) -> str:
    cleaned = re.sub(r"[\s/().,;0-9]+", "", user_agent)
    return "".join(reversed(cleaned[::2]))


def cookie(name: str, value: str) -> Cookie:
    return Cookie(
        version=0,
        name=name,
        value=value,
        port=None,
        port_specified=False,
        domain="www.macroview.club",
        domain_specified=True,
        domain_initial_dot=False,
        path="/",
        path_specified=True,
        secure=True,
        expires=None,
        discard=True,
        comment=None,
        comment_url=None,
        rest={},
        rfc2109=False,
    )


def fetch_series(code: str, start: date, end: date) -> tuple[dict, list[list]]:
    jar = CookieJar()
    opener = build_opener(HTTPCookieProcessor(jar))
    page_url = f"{BASE_URL}/data?code={code}"
    page_request = Request(page_url, headers={"User-Agent": USER_AGENT})
    html = opener.open(page_request, timeout=30).read().decode("utf-8")
    match = re.search(r"var csrf = '([^']+)'", html)
    if not match:
        raise RuntimeError(f"CSRF token missing for {code}")
    csrf = match.group(1)
    jar.set_cookie(cookie("view_id", browser_view_id(USER_AGENT)))
    body = urlencode(
        {
            "code": code,
            "start": start.isoformat(),
            "end": end.isoformat(),
            "num": "all",
            "csrfmiddlewaretoken": csrf,
            "is_limited": "",
        }
    ).encode("utf-8")
    request = Request(
        f"{BASE_URL}/get-data",
        data=body,
        headers={
            "User-Agent": USER_AGENT,
            "Referer": page_url,
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "X-CSRFToken": next((item.value for item in jar if item.name == "csrftoken"), csrf),
            "X-Requested-With": "XMLHttpRequest",
        },
        method="POST",
    )
    payload = json.loads(opener.open(request, timeout=30).read().decode("utf-8"))
    if payload.get("status") == 400:
        raise RuntimeError(payload.get("msg") or f"Series request failed: {code}")
    return payload.get("chart") or {}, payload.get("data") or []


def main() -> int:
    parser = argparse.ArgumentParser(description="Fetch daily weighted DR007 history from a public data mirror.")
    parser.add_argument("--start", type=date.fromisoformat, default=date(2025, 1, 1))
    parser.add_argument("--end", type=date.fromisoformat, default=date.today())
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).resolve().parent / "raw" / "funding_daily_2025_present.csv",
    )
    args = parser.parse_args()

    chart, values = fetch_series("cn_dr007", args.start, args.end)
    rows = []
    for item in values:
        if not isinstance(item, list) or len(item) < 2:
            continue
        try:
            item_date = date.fromisoformat(str(item[0]))
        except ValueError:
            continue
        if not (args.start <= item_date <= args.end):
            continue
        rows.append({"date": item[0], "dr007": item[1], "source": "macroview_cn_dr007"})
    rows.sort(key=lambda item: item["date"])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["date", "dr007", "source"])
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({"chart": chart, "observations": len(rows), "first": rows[:1], "last": rows[-1:]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
