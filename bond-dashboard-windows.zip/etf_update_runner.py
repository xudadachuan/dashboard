from __future__ import annotations

import os
import traceback
from datetime import datetime, time
from pathlib import Path

from etf_data import BOND_ETF_UNIVERSE, query_etf_data
from market_data_status import save_market_data_status, update_locked
from trading_calendar import is_interbank_trading_day


ROOT = Path(__file__).resolve().parent
LOG_DIR = ROOT / "logs"
LOG_FILE = LOG_DIR / "etf_data_update.log"


def now_text() -> str:
    return datetime.now().isoformat(timespec="seconds")


def append_log(message: str) -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        with LOG_FILE.open("a", encoding="utf-8") as handle:
            handle.write(message)
            if not message.endswith("\n"):
                handle.write("\n")
    except PermissionError:
        # Batch files redirect stdout/stderr to the same log. On Windows that
        # handle can lock the file, so fall back to stdout instead of failing
        # the whole scheduled update.
        print(message)


def is_etf_update_window() -> bool:
    if os.environ.get("BOND_DASHBOARD_FORCE_WRITE") == "1":
        return True
    return datetime.now().time() >= time(21, 0)


def validate_refreshed_payload(payload: dict) -> None:
    items = payload.get("items") or []
    source = payload.get("source")
    min_items = len(BOND_ETF_UNIVERSE)
    if source not in {"eastmoney", "ifind"}:
        raise RuntimeError(f"ETF data was not refreshed from a live quote source: source={source} date={payload.get('date')}")
    if len(items) < min_items:
        raise RuntimeError(f"ETF universe incomplete: got {len(items)} item(s), expected at least {min_items}")


@update_locked("etf_data")
def main() -> int:
    if not is_interbank_trading_day():
        append_log(f"skipped non-trading day at={now_text()}")
        return 0
    append_log(f"==== {now_text()} ETF update ====")
    try:
        if not is_etf_update_window():
            payload = query_etf_data(refresh=False)
            save_market_data_status()
            append_log(f"skipped before 21:05 latest={payload.get('date')} source={payload.get('source')}")
            return 0

        payload = query_etf_data(refresh=True)
        validate_refreshed_payload(payload)
        status = save_market_data_status()
        append_log(
            "ETF refreshed "
            f"date={payload.get('date')} "
            f"items={len(payload.get('items') or [])} "
            f"source={payload.get('source')} "
            f"aligned={status.get('aligned')}"
        )
        return 0
    except Exception as exc:
        save_market_data_status()
        append_log(f"failed: {''.join(traceback.format_exception_only(type(exc), exc)).strip()}")
        append_log(traceback.format_exc())
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
