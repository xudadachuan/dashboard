@echo off
setlocal
cd /d "%~dp0"

if not exist "logs" mkdir "logs"
set "LOG=%CD%\logs\pboc_omo_update.log"

echo ==== %date% %time% ====>> "%LOG%"
python update_runner.py
exit /b %errorlevel%
