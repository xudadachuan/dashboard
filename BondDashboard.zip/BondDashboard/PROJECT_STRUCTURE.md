# 项目结构

```
bond-dashboard-windows/
├─ frontend/       # 浏览器页面：HTML、CSS 和 JavaScript
├─ backend/        # Python API、认证和数据更新任务
├─ data/           # 共享运行数据与 SQLite 用户库（不属于前端静态文件）
├─ logs/           # 自动更新日志
└─ deploy/         # Windows 服务、Caddy 与计划任务配置
```

前端只通过 `/api/*` 访问受保护的数据。后端服务从 `frontend/` 提供页面，计划任务从 `backend/` 执行。

`data/` 与根目录 `.env` 保留在项目根目录，以便部署升级时持续复用现有用户、市场数据和密钥配置；不要把它们移动到浏览器可访问的 `frontend/` 中。
