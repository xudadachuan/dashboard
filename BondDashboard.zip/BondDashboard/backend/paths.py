"""Shared filesystem locations for the split frontend/backend layout."""

from pathlib import Path


BACKEND_ROOT = Path(__file__).resolve().parent
APP_ROOT = BACKEND_ROOT.parent
DATA_DIR = APP_ROOT / "data"
LOG_DIR = APP_ROOT / "logs"
ENV_FILE = APP_ROOT / ".env"
FRONTEND_DIR = APP_ROOT / "frontend"
