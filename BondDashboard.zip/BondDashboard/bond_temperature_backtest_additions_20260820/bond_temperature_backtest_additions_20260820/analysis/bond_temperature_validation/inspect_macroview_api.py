from __future__ import annotations

import ast
import json
import re
from urllib.request import Request, urlopen


URL = "https://www.macroview.club/static/dist/js/app/data.js?v=202309"


def js_parse_int(value: str) -> int:
    match = re.match(r"^[\s]*([+-]?\d+)", str(value))
    if not match:
        raise ValueError(value)
    return int(match.group(1))


def main() -> int:
    request = Request(URL, headers={"User-Agent": "Mozilla/5.0"})
    source = urlopen(request, timeout=30).read().decode("utf-8")
    raw_array = re.search(r"var _0x3967=(\[[\s\S]*?\]);var _0x3df72f", source).group(1)
    values = ast.literal_eval(raw_array)

    def at(code: int) -> str:
        return values[code - 0x198]

    for _ in range(len(values) * 3):
        try:
            checksum = (
                -js_parse_int(at(0x22E))
                - js_parse_int(at(0x1FB))
                - js_parse_int(at(0x2A4))
                + js_parse_int(at(0x24B))
                + js_parse_int(at(0x203)) * js_parse_int(at(0x246))
                - js_parse_int(at(0x1A7)) * -js_parse_int(at(0x228))
                + js_parse_int(at(0x210)) * js_parse_int(at(0x1B6))
            )
        except ValueError:
            checksum = None
        if checksum == 0x5F0D8:
            break
        values.append(values.pop(0))
    else:
        raise RuntimeError("Unable to rotate string table")

    decoded = re.sub(
        r"_0x[0-9a-fA-F]+\((0x[0-9a-fA-F]+)\)",
        lambda match: json.dumps(at(int(match.group(1), 16)), ensure_ascii=False),
        source,
    )
    for endpoint in ("/get-data", "/data-dl"):
        print(f"\n=== {endpoint} ===")
        positions = [match.start() for match in re.finditer(re.escape(endpoint), decoded)]
        for position in positions:
            start = max(0, position - 1800)
            end = min(len(decoded), position + 2600)
            print(decoded[start:end])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
