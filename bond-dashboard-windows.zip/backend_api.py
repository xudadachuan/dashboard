from __future__ import annotations

import json
import os
import sqlite3
from http.cookies import SimpleCookie
from datetime import date, datetime
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from auth import (
    AuthError,
    authenticate_email,
    bootstrap_admin_from_env,
    change_password,
    create_user,
    get_color_scheme,
    init_auth_db,
    list_users,
    load_env_file,
    revoke_session,
    reset_password,
    set_color_scheme,
    update_user,
    user_for_session,
)
from email_auth import issue_email_code, verify_email_code

from central_bank_tools import (
    query_central_bank_transactions,
    query_central_bank_window,
    query_central_bank_weekly,
    query_tool_summary,
)
from pboc_omo_crawler import query_omo_daily
from chinabond_yields import query_chinabond_yields
from funding_rates import query_funding_rates
from interbank_cd import query_interbank_cd
from bond_temperature import query_bond_temperature
from etf_data import query_etf_data
from market_data_status import query_data_update_logs, query_market_data_status
from market_database import load_market_commentary, load_market_news
from primary_issuance_excel import query_primary_issuance
from trading_calendar import trading_day_status


ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT / "data" / "pboc_omo_daily.json"
PAYLOAD_FILE = ROOT / "data" / "pboc_omo_payload.json"
DB_PATH = ROOT / "data" / "bond_market.db"
load_env_file()
AUTH_DB_PATH = Path(os.environ.get("BOND_DASHBOARD_AUTH_DB_PATH", str(DB_PATH))).expanduser().resolve()
NET_TOOL_TYPES = ["reverse_repo", "treasury_cash_deposit", "gov_bond_trade"]
TRANSACTION_TOOL_TYPES = [*NET_TOOL_TYPES, "outright_reverse_repo", "mlf", "slf", "psl"]
TRANSACTION_HISTORY_DAYS = 30
HOST = os.environ.get("BOND_DASHBOARD_HOST", "127.0.0.1")
PORT = int(os.environ.get("BOND_DASHBOARD_PORT", "8765"))
SERVICE_VERSION = "2026-07-20.3"
SESSION_COOKIE_NAME = "bond_dashboard_session"
MAX_JSON_BODY_BYTES = 64 * 1024


def current_iso_date() -> str:
    return date.today().isoformat()


def latest_current_omo_row(rows: list[dict]) -> dict:
    today = current_iso_date()
    current_rows = [
        row
        for row in rows
        if row.get("date") and str(row.get("date")) <= today and not row.get("isFuture")
    ]
    return max(current_rows, key=lambda row: str(row.get("date")), default={})


def load_omo_daily() -> list[dict]:
    rows = query_central_bank_window(days_before=5, days_after=5, tool_types=NET_TOOL_TYPES)
    if rows:
        repo_rates = {row["date"]: row.get("repoRate7d") for row in query_omo_daily(days=30)}
        for row in rows:
            row["repoRate7d"] = repo_rates.get(row.get("date"))
        return rows

    if not DATA_FILE.exists():
        return []
    rows = json.loads(DATA_FILE.read_text(encoding="utf-8"))
    rows.sort(key=lambda item: item.get("date", ""))
    return rows[-11:]


def load_omo_weekly() -> list[dict]:
    rows = query_central_bank_weekly(weeks=4, tool_types=NET_TOOL_TYPES)
    if rows:
        return rows

    if PAYLOAD_FILE.exists():
        payload = json.loads(PAYLOAD_FILE.read_text(encoding="utf-8"))
        rows = payload.get("omoWeekly", [])
        if isinstance(rows, list):
            return rows[-4:]
    return []


def latest_omo_payload() -> dict:
    omo_daily = load_omo_daily()
    omo_weekly = load_omo_weekly()
    latest = latest_current_omo_row(omo_daily)
    return {
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
        "unit": "亿元",
        "repoInjection": latest.get("injection", 0),
        "repoMaturity": latest.get("maturity", 0),
        "repoRate": latest.get("repoRate7d", 0),
        "omoDaily": omo_daily,
        "omoWeekly": omo_weekly,
    }


def market_payload() -> dict:
    omo = latest_omo_payload()
    chart_daily = omo["omoDaily"]
    chart_weekly = omo.get("omoWeekly", [])
    latest = latest_current_omo_row(chart_daily)
    chinabond_yields = query_chinabond_yields()
    funding_rates = query_funding_rates()
    interbank_cd = query_interbank_cd()
    bond_temperature = query_bond_temperature()
    etf_data = query_etf_data()
    news = load_market_news(limit=10)
    commentary = load_market_commentary(limit=7)
    dr001_change = (funding_rates.get("metrics", {}).get("DR001") or {}).get("changeBp")
    return {
        "dr001": (funding_rates.get("metrics", {}).get("DR001") or {}).get("value"),
        "dr001Change": dr001_change if dr001_change is not None else 0,
        "dr007": (funding_rates.get("metrics", {}).get("DR007") or {}).get("value"),
        "r001": None,
        "r007": (funding_rates.get("metrics", {}).get("R007") or {}).get("value"),
        "gc001": None,
        "repoInjection": latest.get("injection", omo["repoInjection"]),
        "repoMaturity": latest.get("maturity", omo["repoMaturity"]),
        "repoRate": omo["repoRate"],
        "omoDate": latest.get("date"),
        "omoUpdatedAt": omo["updatedAt"],
        "omoDaily": [
            {
                "date": row.get("date"),
                "label": row["label"],
                "value": row["value"],
                "injection": row.get("injection", 0),
                "maturity": row.get("maturity", 0),
                "isFuture": bool(row.get("isFuture")),
            }
            for row in chart_daily
        ],
        "omoWeekly": [
            {
                "label": row["label"],
                "value": row["value"],
                "injection": row.get("injection", 0),
                "maturity": row.get("maturity", 0),
            }
            for row in chart_weekly
        ],
        "omoTransactions": query_central_bank_transactions(days=TRANSACTION_HISTORY_DAYS, tool_types=TRANSACTION_TOOL_TYPES),
        "centralBankTransactions": query_central_bank_transactions(days=TRANSACTION_HISTORY_DAYS, tool_types=TRANSACTION_TOOL_TYPES),
        "centralBankDaily": query_central_bank_window(days_before=5, days_after=5, tool_types=NET_TOOL_TYPES),
        "centralBankWeekly": query_central_bank_weekly(weeks=4, tool_types=NET_TOOL_TYPES),
        "centralBankTools": query_tool_summary(),
        "centralBankNetInjection": central_bank_net_injection_payload(),
        "chinabondYields": chinabond_yields,
        "fundingRates": funding_rates,
        "interbankCd": interbank_cd,
        "bondTemperature": bond_temperature,
        "etfData": etf_data,
        "primaryIssuance": query_primary_issuance(),
        "marketNews": news,
        "marketCommentary": commentary,
        "marketDataStatus": query_market_data_status(),
        "tradingDay": trading_day_status(),
        "updatedAt": omo["updatedAt"],
    }


def query_market_views(limit: int = 20) -> dict:
    if not DB_PATH.exists():
        return {"items": [], "latestReview": None, "updatedAt": datetime.now().isoformat(timespec="seconds")}
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        items = [
            dict(row)
            for row in conn.execute(
                """
                select as_of_date, source_name, source_type, source_url, source_published_at,
                       view_title, view_summary, view_tone, risk_level, tags, confidence, created_at
                from market_views
                order by source_published_at desc, id desc
                limit ?
                """,
                (limit,),
            )
        ]
        review = conn.execute(
            """
            select summary_date, summary_update_time, summary_headline, summary_text,
                   market_consensus, alignment, gaps, created_at
            from ai_summary_reviews
            order by id desc
            limit 1
            """
        ).fetchone()
    return {
        "items": items,
        "latestReview": dict(review) if review else None,
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
    }


class DashboardHandler(SimpleHTTPRequestHandler):
    def log_message(self, format: str, *args) -> None:
        return

    def end_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def send_json(self, payload: dict | list, status: int = 200, headers: dict[str, str] | None = None) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        self.end_headers()
        self.wfile.write(body)

    def session_token(self) -> str | None:
        cookie = SimpleCookie(self.headers.get("Cookie", ""))
        morsel = cookie.get(SESSION_COOKIE_NAME)
        return morsel.value if morsel else None

    def current_user(self) -> dict | None:
        return user_for_session(self.session_token(), AUTH_DB_PATH)

    def session_cookie(self, token: str, clear: bool = False) -> str:
        cookie = SimpleCookie()
        cookie[SESSION_COOKIE_NAME] = token
        cookie[SESSION_COOKIE_NAME]["path"] = "/"
        cookie[SESSION_COOKIE_NAME]["httponly"] = True
        cookie[SESSION_COOKIE_NAME]["samesite"] = "Strict"
        cookie[SESSION_COOKIE_NAME]["max-age"] = 0 if clear else 7 * 24 * 60 * 60
        return cookie.output(header="").strip()

    def read_json_body(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise AuthError("请求格式不正确") from exc
        if length <= 0 or length > MAX_JSON_BODY_BYTES:
            raise AuthError("请求内容为空或过大")
        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise AuthError("请求 JSON 格式不正确") from exc
        if not isinstance(payload, dict):
            raise AuthError("请求 JSON 必须是对象")
        return payload

    def require_user(self, role: str | None = None) -> dict | None:
        user = self.current_user()
        if not user:
            self.send_json({"error": "请先登录", "code": "AUTH_REQUIRED"}, 401)
            return None
        if role and user.get("role") != role:
            self.send_json({"error": "权限不足", "code": "FORBIDDEN"}, 403)
            return None
        return user

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try:
            if path == "/api/auth/register":
                payload = self.read_json_body()
                verify_email_code(payload.get("email"), payload.get("emailCode"), "register", AUTH_DB_PATH)
                user = create_user(payload.get("username"), payload.get("password"), payload.get("email"), "user", AUTH_DB_PATH)
                authenticated, token = authenticate_email(payload.get("email"), payload.get("password"), AUTH_DB_PATH)
                self.send_json(
                    {"user": authenticated, "message": "注册成功"},
                    201,
                    {"Set-Cookie": self.session_cookie(token)},
                )
                return
            if path == "/api/auth/send-email-code":
                payload = self.read_json_body()
                issue_email_code(payload.get("email"), payload.get("purpose"), AUTH_DB_PATH)
                self.send_json({"message": "验证码已发送，1 小时内有效"})
                return
            if path == "/api/auth/login":
                payload = self.read_json_body()
                user, token = authenticate_email(payload.get("email"), payload.get("password"), AUTH_DB_PATH)
                self.send_json({"user": user, "message": "登录成功"}, headers={"Set-Cookie": self.session_cookie(token)})
                return
            if path == "/api/auth/logout":
                revoke_session(self.session_token(), AUTH_DB_PATH)
                self.send_json({"message": "已退出登录"}, headers={"Set-Cookie": self.session_cookie("", clear=True)})
                return
            if path == "/api/auth/change-password":
                actor = self.require_user()
                if not actor:
                    return
                payload = self.read_json_body()
                change_password(actor["id"], payload.get("currentPassword"), payload.get("newPassword"), AUTH_DB_PATH)
                self.send_json(
                    {"message": "密码已修改，请重新登录"},
                    headers={"Set-Cookie": self.session_cookie("", clear=True)},
                )
                return
            if path == "/api/admin/users/create":
                if not self.require_user("admin"):
                    return
                payload = self.read_json_body()
                if not payload.get("email"):
                    raise AuthError("请输入邮箱地址")
                created = create_user(
                    payload.get("username"), payload.get("password"), payload.get("email"), payload.get("role") or "user", AUTH_DB_PATH
                )
                self.send_json({"user": created, "message": "账户已创建"}, 201)
                return
            if path == "/api/admin/users/reset-password":
                actor = self.require_user("admin")
                if not actor:
                    return
                payload = self.read_json_body()
                user_id = int(payload.get("userId"))
                reset_password(user_id, payload.get("newPassword"), AUTH_DB_PATH)
                self.send_json({"message": "密码已重置，该账户需要重新登录"})
                return
            if path == "/api/admin/users/update":
                actor = self.require_user("admin")
                if not actor:
                    return
                payload = self.read_json_body()
                user_id = int(payload.get("userId"))
                role = payload.get("role") if "role" in payload else None
                is_active = payload.get("isActive") if "isActive" in payload else None
                if is_active is not None and not isinstance(is_active, bool):
                    raise AuthError("isActive 必须是布尔值")
                updated = update_user(user_id, role, is_active, actor["id"], AUTH_DB_PATH)
                self.send_json({"user": updated, "message": "账户已更新"})
                return
            if path == "/api/settings/theme":
                actor = self.require_user("admin")
                if not actor:
                    return
                payload = self.read_json_body()
                scheme = set_color_scheme(payload.get("scheme"), actor["id"], AUTH_DB_PATH)
                self.send_json({"scheme": scheme, "message": "全站配色已更新"})
                return
            self.send_json({"error": "接口不存在", "code": "NOT_FOUND"}, 404)
        except (AuthError, TypeError, ValueError) as exc:
            self.send_json({"error": str(exc), "code": "BAD_REQUEST"}, 400)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        if path == "/api/health":
            self.send_json(
                {
                    "status": "ok",
                    "serviceVersion": SERVICE_VERSION,
                    "updatedAt": datetime.now().isoformat(timespec="seconds"),
                }
            )
            return
        if path == "/api/auth/me":
            user = self.current_user()
            if not user:
                self.send_json({"error": "请先登录", "code": "AUTH_REQUIRED"}, 401)
            else:
                self.send_json({"user": user})
            return
        if path == "/api/admin/users":
            if not self.require_user("admin"):
                return
            self.send_json({"items": list_users(AUTH_DB_PATH)})
            return
        if path == "/api/admin/data-update-logs":
            if not self.require_user("admin"):
                return
            raw_limit = (query.get("limit") or ["100"])[0]
            self.send_json(query_data_update_logs(int(raw_limit)))
            return
        if path == "/api/settings/theme":
            if not self.require_user():
                return
            self.send_json({"scheme": get_color_scheme(AUTH_DB_PATH)})
            return
        if path.startswith("/data/") and not self.require_user():
            return
        if path.startswith("/api/") and not self.require_user():
            return
        if path == "/api/omo/daily":
            self.send_json(latest_omo_payload())
            return
        if path in ("/api/omo/transactions", "/api/central-bank/transactions"):
            self.send_json(
                {
                    "items": query_central_bank_transactions(days=TRANSACTION_HISTORY_DAYS, tool_types=TRANSACTION_TOOL_TYPES),
                    "updatedAt": datetime.now().isoformat(timespec="seconds"),
                }
            )
            return
        if path == "/api/market":
            self.send_json(market_payload())
            return
        if path == "/api/funding-rates":
            self.send_json(query_funding_rates((query.get("date") or [None])[0]))
            return
        if path == "/api/chinabond-yields":
            self.send_json(query_chinabond_yields())
            return
        if path == "/api/interbank-cd":
            self.send_json(query_interbank_cd(query_date=(query.get("date") or [None])[0]))
            return
        if path == "/api/bond-temperature":
            self.send_json(query_bond_temperature())
            return
        if path == "/api/etf-data":
            self.send_json(query_etf_data((query.get("date") or [None])[0]))
            return
        if path == "/api/primary-issuance":
            self.send_json(query_primary_issuance((query.get("date") or [None])[0]))
            return
        if path == "/api/market-data-status":
            self.send_json(query_market_data_status())
            return
        if path == "/api/market-news":
            self.send_json(load_market_news(limit=10))
            return
        if path == "/api/market-commentary":
            self.send_json(load_market_commentary(limit=7))
            return
        if path == "/api/market-views":
            self.send_json(query_market_views())
            return
        if path == "/api/central-bank/tools":
            self.send_json({"items": query_tool_summary(), "updatedAt": datetime.now().isoformat(timespec="seconds")})
            return
        if path == "/api/central-bank/net-injection":
            self.send_json(central_bank_net_injection_payload())
            return
        super().do_GET()


def central_bank_net_injection_payload() -> dict:
    tool_types = ["reverse_repo", "mlf"]
    daily = query_central_bank_window(days_before=5, days_after=5, tool_types=tool_types)
    weekly = query_central_bank_weekly(weeks=4, tool_types=tool_types)
    current = latest_current_omo_row(daily)
    by_tool = current.get("byTool") or {}
    return {
        "net_injection": current.get("value", 0),
        "byTool": by_tool,
        "date": current.get("date"),
        "daily": daily,
        "weekly": weekly,
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
    }


def main() -> None:
    init_auth_db(AUTH_DB_PATH)
    bootstrap_admin_from_env(AUTH_DB_PATH)
    server = ThreadingHTTPServer((HOST, PORT), DashboardHandler)
    print(f"Bond dashboard backend {SERVICE_VERSION}: http://{HOST}:{PORT}")
    print("API: /api/health, /api/omo/daily, /api/market")
    server.serve_forever()


if __name__ == "__main__":
    main()
