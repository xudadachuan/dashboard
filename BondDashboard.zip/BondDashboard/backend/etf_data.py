from __future__ import annotations

import json
import os
import re
from datetime import datetime
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from market_database import available_nonempty_dates, load_nonempty_snapshot, save_etf_snapshot


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT.parent / "data"
CACHE_FILE = DATA_DIR / "etf_data_cache.json"
EASTMONEY_LIST_URL = "https://push2.eastmoney.com/api/qt/clist/get"
EASTMONEY_ULIST_URL = "https://push2.eastmoney.com/api/qt/ulist.np/get"
EASTMONEY_FUND_DETAIL_URL = "https://fund.eastmoney.com/pingzhongdata/{code}.js"
IFIND_DEFAULT_FIELDS = "latest;changeRatio;change;volume;amount;totalMarketValue;mainNetInflow;mainNetInflowRatio"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BondDashboard/1.0"
NETWORK_TIMEOUT_SECONDS = 12
DETAIL_LIMIT = 12
MEMORY_TTL_SECONDS = 600

ETF_KEYWORDS = (
    "债",
    "国债",
    "政金",
    "国开",
    "地方债",
    "信用",
    "城投",
    "短融",
    "公司债",
    "可转",
    "转债",
)

EXCLUDE_KEYWORDS = ("港股", "创新药", "半导体", "科创", "A500", "恒生", "证券", "中证1000", "货币", "现金", "添益", "日利")

BOND_ETF_UNIVERSE = (
    ("511010", "SH"),
    ("511020", "SH"),
    ("511030", "SH"),
    ("511060", "SH"),
    ("511090", "SH"),
    ("511100", "SH"),
    ("511130", "SH"),
    ("511180", "SH"),
    ("511220", "SH"),
    ("511260", "SH"),
    ("511270", "SH"),
    ("511360", "SH"),
    ("511380", "SH"),
    ("511520", "SH"),
    ("511580", "SH"),
    ("159972", "SZ"),
    ("159649", "SZ"),
    ("159650", "SZ"),
    ("159651", "SZ"),
)

DASHBOARD_CATEGORY_ORDER = ("利率类", "信用类", "地方债")

_MEMORY_CACHE: tuple[datetime, dict] | None = None


def load_cache() -> dict:
    if not CACHE_FILE.exists():
        return {}
    try:
        payload = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}
    return payload if isinstance(payload, dict) else {}


def save_cache(payload: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    CACHE_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def fetch_json(url: str) -> dict:
    request = Request(url, headers={"User-Agent": USER_AGENT, "Referer": "https://quote.eastmoney.com/"})
    raw = urlopen(request, timeout=NETWORK_TIMEOUT_SECONDS).read()
    return json.loads(raw.decode("utf-8"))


def fetch_text(url: str, referer: str) -> str:
    request = Request(url, headers={"User-Agent": USER_AGENT, "Referer": referer})
    raw = urlopen(request, timeout=NETWORK_TIMEOUT_SECONDS).read()
    return raw.decode("utf-8-sig", errors="replace")


def as_number(value) -> float | None:
    if value in (None, "-", ""):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if number > -1e20 else None


def classify_bond_etf(name: str) -> str:
    if "可转" in name or "转债" in name:
        return "可转债"
    if "国债" in name:
        return "国债"
    if "政金" in name or "国开" in name or "政策" in name:
        return "政金债"
    if "地方债" in name:
        return "地方债"
    if "城投" in name:
        return "城投债"
    if "信用" in name or "公司债" in name:
        return "信用债"
    if "短融" in name or "短债" in name:
        return "短久期"
    return "债券"


def dashboard_bond_category(item: dict) -> str:
    name = str(item.get("name") or "")
    etf_type = str(item.get("type") or classify_bond_etf(name))
    if etf_type == "地方债" or "地方债" in name:
        return "地方债"
    if etf_type in {"国债", "政金债"} or any(keyword in name for keyword in ("国债", "政金", "国开", "政策")):
        return "利率类"
    return "信用类"


def is_bond_etf(name: str) -> bool:
    return any(keyword in name for keyword in ETF_KEYWORDS) and not any(keyword in name for keyword in EXCLUDE_KEYWORDS)


def yuan_to_100m(value: float | None) -> float | None:
    return round(value / 100000000, 2) if value is not None else None


def fetch_latest_nav(code: str) -> dict:
    url = EASTMONEY_FUND_DETAIL_URL.format(code=code)
    text = fetch_text(url, f"https://fund.eastmoney.com/{code}.html")
    nav_match = re.search(r"var\s+Data_netWorthTrend\s*=\s*(\[.*?\]);", text, re.S)
    if not nav_match:
        return {}
    try:
        trend = json.loads(nav_match.group(1))
    except json.JSONDecodeError:
        return {}
    if not trend:
        return {}
    latest = trend[-1]
    nav = as_number(latest.get("y"))
    timestamp = as_number(latest.get("x"))
    nav_date = datetime.fromtimestamp(timestamp / 1000).date().isoformat() if timestamp else None
    return {"nav": nav, "navDate": nav_date}


def normalize_quote_row(row: dict) -> dict:
    name = str(row.get("f14") or "")
    code = str(row.get("f12") or "")
    price = as_number(row.get("f2"))
    volume = as_number(row.get("f5"))
    amount = as_number(row.get("f6"))
    total_market_value = as_number(row.get("f20"))
    exchange = "SH" if row.get("f13") == 1 else "SZ"
    return {
        "code": code,
        "name": name,
        "exchange": exchange,
        "type": classify_bond_etf(name),
        "price": price,
        "changePct": as_number(row.get("f3")),
        "change": as_number(row.get("f4")),
        "volume": volume,
        "amount": amount,
        "amount100m": yuan_to_100m(amount),
        "totalMarketValue": total_market_value,
        "marketValue100m": yuan_to_100m(total_market_value),
        "netInflow": as_number(row.get("f62")),
        "netInflow100m": yuan_to_100m(as_number(row.get("f62"))),
        "mainFlowPct": as_number(row.get("f184")),
        "source": "eastmoney",
    }


def secid(code: str, exchange: str) -> str:
    market = "1" if exchange == "SH" else "0"
    return f"{market}.{code}"


def thscode(code: str, exchange: str) -> str:
    return f"{code}.{exchange}"


def ifind_enabled() -> bool:
    return os.environ.get("BOND_DASHBOARD_ETF_SOURCE", "").lower() in {"ifind", "ths", "同花顺"}


def ifind_login_if_configured() -> None:
    username = (
        os.environ.get("IFIND_USERNAME")
        or os.environ.get("THS_USERNAME")
        or os.environ.get("IFIND_USER")
    )
    password = (
        os.environ.get("IFIND_PASSWORD")
        or os.environ.get("THS_PASSWORD")
        or os.environ.get("IFIND_KEY")
    )
    if not username or not password:
        raise RuntimeError("iFinD credentials are not configured")
    from iFinDPy import THS_iFinDLogin

    result = THS_iFinDLogin(username, password)
    if isinstance(result, int) and result not in (0, -201):
        raise RuntimeError(f"iFinD login failed: {result}")
    if isinstance(result, dict) and result.get("errorcode") not in (0, None):
        raise RuntimeError(f"iFinD login failed: {result.get('errmsg') or result.get('errorcode')}")


def ifind_error(payload) -> str | None:
    if isinstance(payload, dict):
        code = payload.get("errorcode")
        if code not in (0, None):
            return str(payload.get("errmsg") or code)
    return None


def ifind_rows(payload) -> list[dict]:
    try:
        from iFinDPy import THS_Trans2DataFrame

        frame = THS_Trans2DataFrame(payload)
        if hasattr(frame, "to_dict"):
            return frame.to_dict("records")
    except Exception:
        pass
    data = getattr(payload, "data", None) or (payload.get("tables") if isinstance(payload, dict) else None)
    if isinstance(data, list):
        return [row for row in data if isinstance(row, dict)]
    return []


def get_any(row: dict, names: tuple[str, ...]):
    lower_row = {str(key).lower(): value for key, value in row.items()}
    for name in names:
        if name in row:
            return row[name]
        value = lower_row.get(name.lower())
        if value is not None:
            return value
    return None


def normalize_ifind_row(row: dict) -> dict:
    raw_code = str(get_any(row, ("thscode", "THSCODE", "code", "证券代码")) or "")
    code = raw_code.split(".")[0]
    exchange = raw_code.split(".")[1].upper() if "." in raw_code else ("SH" if code.startswith("5") else "SZ")
    name = str(get_any(row, ("ths_short_name", "security_name", "name", "证券简称")) or "")
    price = as_number(get_any(row, ("latest", "close", "最新价")))
    volume = as_number(get_any(row, ("volume", "成交量")))
    amount = as_number(get_any(row, ("amount", "成交额")))
    total_market_value = as_number(get_any(row, ("totalMarketValue", "mktValue", "总市值", "基金规模")))
    net_inflow = as_number(get_any(row, ("mainNetInflow", "netInflow", "主力净流入")))
    return {
        "code": code,
        "name": name,
        "exchange": exchange,
        "type": classify_bond_etf(name),
        "price": price,
        "changePct": as_number(get_any(row, ("changeRatio", "pct_chg", "涨跌幅"))),
        "change": as_number(get_any(row, ("change", "涨跌额"))),
        "volume": volume,
        "amount": amount,
        "amount100m": yuan_to_100m(amount),
        "totalMarketValue": total_market_value,
        "marketValue100m": yuan_to_100m(total_market_value),
        "netInflow": net_inflow,
        "netInflow100m": yuan_to_100m(net_inflow),
        "mainFlowPct": as_number(get_any(row, ("mainNetInflowRatio", "mainFlowPct", "主力净流入占比"))),
        "source": "ifind",
    }


def fetch_ifind_etf_quotes() -> list[dict]:
    from iFinDPy import THS_RealtimeQuotes

    ifind_login_if_configured()
    codes = ",".join(thscode(code, exchange) for code, exchange in BOND_ETF_UNIVERSE)
    fields = os.environ.get("IFIND_ETF_FIELDS", IFIND_DEFAULT_FIELDS)
    payload = THS_RealtimeQuotes(codes, fields, "")
    error = ifind_error(payload)
    if error:
        raise RuntimeError(f"iFinD ETF query failed: {error}")
    rows = ifind_rows(payload)
    items = [normalize_ifind_row(row) for row in rows]
    items = [item for item in items if item.get("code") and item.get("name")]
    if len(items) < len(BOND_ETF_UNIVERSE):
        raise RuntimeError(f"iFinD returned {len(items)} ETF item(s), expected {len(BOND_ETF_UNIVERSE)}")
    items.sort(key=lambda item: item.get("amount") or 0, reverse=True)
    return items


def fetch_seeded_etf_quotes() -> list[dict]:
    params = {
        "fltt": 2,
        "invt": 2,
        "secids": ",".join(secid(code, exchange) for code, exchange in BOND_ETF_UNIVERSE),
        "fields": "f12,f13,f14,f2,f3,f4,f5,f6,f20,f21,f62,f184",
    }
    payload = fetch_json(f"{EASTMONEY_ULIST_URL}?{urlencode(params)}")
    rows = ((payload.get("data") or {}).get("diff") or [])
    items = [normalize_quote_row(row) for row in rows if row.get("f12") and row.get("f14") and not any(keyword in str(row.get("f14")) for keyword in EXCLUDE_KEYWORDS)]
    items.sort(key=lambda item: item.get("amount") or 0, reverse=True)
    return items


def fetch_screened_etf_quotes() -> list[dict]:
    params = {
        "pn": 1,
        "pz": 2000,
        "po": 1,
        "np": 1,
        "fltt": 2,
        "invt": 2,
        "fid": "f6",
        "fs": "b:MK0021,b:MK0022,b:MK0023,b:MK0024",
        "fields": "f12,f13,f14,f2,f3,f4,f5,f6,f20,f21,f62,f184",
    }
    payload = fetch_json(f"{EASTMONEY_LIST_URL}?{urlencode(params)}")
    rows = ((payload.get("data") or {}).get("diff") or [])
    items = []
    for row in rows:
        name = str(row.get("f14") or "")
        code = str(row.get("f12") or "")
        if not code or not is_bond_etf(name):
            continue
        items.append(normalize_quote_row(row))
    items.sort(key=lambda item: item.get("amount") or 0, reverse=True)
    return items


def fetch_etf_quotes() -> list[dict]:
    if ifind_enabled():
        return fetch_ifind_etf_quotes()
    seeded = fetch_seeded_etf_quotes()
    screened = fetch_screened_etf_quotes()
    by_code = {item["code"]: item for item in seeded}
    for item in screened:
        by_code.setdefault(item["code"], item)
    items = list(by_code.values())
    items.sort(key=lambda item: item.get("amount") or 0, reverse=True)
    return items


def enrich_nav(items: list[dict]) -> None:
    for item in items[:DETAIL_LIMIT]:
        try:
            nav = fetch_latest_nav(item["code"])
        except Exception:
            nav = {}
        latest_nav = nav.get("nav")
        price = item.get("price")
        item.update(nav)
        item["premiumPct"] = round((price / latest_nav - 1) * 100, 3) if price and latest_nav else None


def estimate_subscription_redemption(item: dict, previous: dict | None) -> float | None:
    if not previous:
        return None
    current_market_value = item.get("marketValue100m")
    previous_market_value = previous.get("marketValue100m")
    change_pct = item.get("changePct")
    if current_market_value is None or previous_market_value is None or change_pct is None:
        return None
    expected_market_value = float(previous_market_value) * (1 + float(change_pct) / 100)
    return round(float(current_market_value) - expected_market_value, 2)


def build_summary(items: list[dict], previous_items: list[dict] | None = None) -> dict:
    total_amount = sum(item.get("amount") or 0 for item in items)
    total_market_value = sum(item.get("totalMarketValue") or 0 for item in items)
    previous_by_code = {item.get("code"): item for item in previous_items or [] if item.get("code")}
    by_type: dict[str, dict] = {}
    by_dashboard_type: dict[str, dict] = {
        key: {"type": key, "count": 0, "marketValue100m": 0.0, "marketValueChange100m": 0.0, "subscriptionRedemption100m": 0.0, "hasPrevious": False}
        for key in DASHBOARD_CATEGORY_ORDER
    }
    for item in items:
        bucket = by_type.setdefault(item["type"], {"type": item["type"], "count": 0, "amount100m": 0.0, "marketValue100m": 0.0})
        bucket["count"] += 1
        bucket["amount100m"] += item.get("amount100m") or 0
        bucket["marketValue100m"] += item.get("marketValue100m") or 0
        dashboard_type = dashboard_bond_category(item)
        item["dashboardType"] = dashboard_type
        dashboard_bucket = by_dashboard_type[dashboard_type]
        dashboard_bucket["count"] += 1
        dashboard_bucket["marketValue100m"] += item.get("marketValue100m") or 0
        previous = previous_by_code.get(item.get("code"))
        if previous and item.get("marketValue100m") is not None and previous.get("marketValue100m") is not None:
            item["marketValueChange100m"] = round(float(item["marketValue100m"]) - float(previous["marketValue100m"]), 2)
            dashboard_bucket["marketValueChange100m"] += item["marketValueChange100m"]
            dashboard_bucket["hasPrevious"] = True
        else:
            item["marketValueChange100m"] = None
        item["subscriptionRedemption100m"] = estimate_subscription_redemption(item, previous)
        if item["subscriptionRedemption100m"] is not None:
            dashboard_bucket["subscriptionRedemption100m"] += item["subscriptionRedemption100m"]
    categories = sorted(by_type.values(), key=lambda item: item["amount100m"], reverse=True)
    for item in categories:
        item["amount100m"] = round(item["amount100m"], 2)
        item["marketValue100m"] = round(item["marketValue100m"], 2)
    dashboard_categories = []
    for key in DASHBOARD_CATEGORY_ORDER:
        item = by_dashboard_type[key]
        if item["count"] <= 0:
            continue
        dashboard_categories.append(
            {
                "type": key,
                "count": item["count"],
                "marketValue100m": round(item["marketValue100m"], 2),
                "marketValueChange100m": round(item["marketValueChange100m"], 2) if item["hasPrevious"] else None,
                "subscriptionRedemption100m": round(item["subscriptionRedemption100m"], 2) if item["hasPrevious"] else None,
            }
        )
    return {
        "count": len(items),
        "totalAmount100m": yuan_to_100m(total_amount) or 0,
        "totalMarketValue100m": yuan_to_100m(total_market_value) or 0,
        "totalMarketValueChange100m": round(sum(item.get("marketValueChange100m") or 0 for item in items), 2) if previous_items else None,
        "totalSubscriptionRedemption100m": round(sum(item.get("subscriptionRedemption100m") or 0 for item in items), 2) if previous_items else None,
        "dashboardCategories": dashboard_categories,
        "categories": categories,
        "topAmount": items[:10],
    }


def previous_etf_items(data_date: str | None) -> list[dict]:
    if not data_date:
        return []
    dates = [value for value in available_nonempty_dates("etf_daily") if value < data_date]
    if not dates:
        return []
    payload = load_nonempty_snapshot("etf_daily", dates[-1]) or {}
    return payload.get("items") or []


def normalize_summary(payload: dict) -> dict:
    items = payload.get("items") or []
    payload["summary"] = build_summary(items, previous_etf_items(payload.get("date")))
    return payload


def validate_etf_payload_quality(payload: dict) -> None:
    summary = payload.get("summary") or {}
    total_amount = summary.get("totalAmount100m")
    if not payload.get("items"):
        raise RuntimeError("ETF payload has no items")
    if total_amount is None or float(total_amount) <= 0:
        raise RuntimeError(f"ETF payload has no trading amount: date={payload.get('date')} source={payload.get('source')}")


def fetch_etf_data() -> dict:
    items = fetch_etf_quotes()
    enrich_nav(items)
    source = "ifind" if items and all(item.get("source") == "ifind" for item in items) else "eastmoney"
    payload = {
        "date": datetime.now().date().isoformat(),
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
        "source": source,
        "sourceName": "同花顺 iFinD" if source == "ifind" else "东方财富 ETF 行情",
        "universe": "ifind-bond-etf-codes" if source == "ifind" else "seeded-bond-etf-codes+screened-etf-list",
        "items": items,
        "summary": build_summary(items, previous_etf_items(datetime.now().date().isoformat())),
    }
    validate_etf_payload_quality(payload)
    return payload


def with_available_dates(payload: dict) -> dict:
    dates = available_nonempty_dates("etf_daily")
    if dates:
        return {**payload, "availableDates": dates, "startDate": dates[0], "endDate": dates[-1]}
    return payload


def query_etf_data(query_date: str | None = None, refresh: bool = False) -> dict:
    global _MEMORY_CACHE
    if not refresh:
        stored = load_nonempty_snapshot("etf_daily", query_date)
        if stored:
            return with_available_dates(normalize_summary(stored))

    if _MEMORY_CACHE:
        cached_at, payload = _MEMORY_CACHE
        if not query_date and (datetime.now() - cached_at).total_seconds() < MEMORY_TTL_SECONDS:
            return with_available_dates(payload)
    try:
        payload = fetch_etf_data()
        save_cache(payload)
        save_etf_snapshot(payload)
        _MEMORY_CACHE = (datetime.now(), payload)
        return with_available_dates(payload)
    except Exception as exc:
        stored = load_nonempty_snapshot("etf_daily", query_date)
        if stored:
            return with_available_dates(normalize_summary({**stored, "source": "cache", "error": str(exc)}))
        fallback = load_cache()
        if fallback.get("items"):
            payload = normalize_summary({**fallback, "source": "cache", "error": str(exc)})
            save_etf_snapshot(payload)
            _MEMORY_CACHE = (datetime.now(), payload)
            return with_available_dates(payload)
        payload = {
            "date": None,
            "updatedAt": datetime.now().isoformat(timespec="seconds"),
            "source": "unavailable",
            "sourceName": "东方财富 ETF 行情",
            "items": [],
            "summary": {"count": 0, "totalAmount100m": 0, "totalMarketValue100m": 0, "categories": [], "topAmount": []},
            "error": str(exc),
        }
        _MEMORY_CACHE = (datetime.now(), payload)
        return with_available_dates(payload)


if __name__ == "__main__":
    print(json.dumps(query_etf_data(), ensure_ascii=False, indent=2))
