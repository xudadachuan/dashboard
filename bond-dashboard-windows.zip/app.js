const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => document.querySelectorAll(selector);

let currentAccount = null;
let dashboardStarted = false;
let currentColorScheme = 'warm';

async function accountRequest(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { Accept: 'application/json', ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) },
    cache: 'no-store',
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.error || `请求失败（${response.status}）`);
    error.status = response.status;
    throw error;
  }
  return payload;
}

function setAuthMessage(message = '', success = false) {
  const node = $('#authMessage');
  if (!node) return;
  node.textContent = message;
  node.style.color = success ? '#36805c' : '';
}

function showAuthGate(message = '') {
  currentAccount = null;
  clearInterval(refreshTimer);
  $('#authGate').hidden = false;
  $('#accountChip').textContent = '未登录';
  $$('.admin-only').forEach(node => { node.hidden = true; });
  if (message) setAuthMessage(message);
}

window.addEventListener('bond-auth-required', () => showAuthGate('登录状态已失效，请重新登录'));

function applyAccount(user) {
  currentAccount = user;
  $('#authGate').hidden = true;
  $('#accountChip').textContent = `${user.username} · ${user.role === 'admin' ? '管理员' : '普通用户'}`;
  setOptionalText('#profileUsername', user.username);
  setOptionalText('#profileRole', user.role === 'admin' ? '管理员' : '普通用户');
  setOptionalText('#profileEmail', user.email || '未填写');
  $$('.admin-only').forEach(node => { node.hidden = user.role !== 'admin'; });
  loadColorScheme();
  if (!dashboardStarted) {
    dashboardStarted = true;
    startDashboard();
  } else {
    scheduleRefresh(true);
  }
}

async function checkCurrentAccount() {
  try {
    const payload = await accountRequest('/api/auth/me');
    applyAccount(payload.user);
  } catch (error) {
    showAuthGate(error.status === 401 ? '' : '账户状态检查失败，请稍后重试');
  }
}

const now = new Date();
const week = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
$('#currentDate').textContent = '收盘点评 · 等待数据日';

function drawSparklines() {
  $$('.sparkline').forEach((svg, index) => {
    const values = svg.dataset.values.split(',').map(Number);
    const min = Math.min(...values), max = Math.max(...values);
    const pts = values.map((v, i) => `${i * 100 / (values.length - 1)},${52 - (v - min) / (max - min) * 40}`).join(' ');
    const color = svg.classList.contains('up-line') ? '#c76050' : '#78ad7c';
    svg.setAttribute('viewBox', '0 0 100 58');
    svg.innerHTML = `<defs><linearGradient id="fade-${index}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${color}" stop-opacity=".22"/><stop offset="1" stop-color="${color}" stop-opacity="0"/></linearGradient></defs><polygon points="${pts} 100,58 0,58" fill="url(#fade-${index})"/><polyline points="${pts}" fill="none" stroke="${color}" stroke-width="2" vector-effect="non-scaling-stroke"/>`;
  });
}

let selectedYieldCurve = 'treasury';
let currentBondYields = null;
let curveRangeStart = 0;
let curveRangeEnd = null;
const OMO_TRANSACTION_PAGE_SIZE = 10;
const OMO_NET_TOOL_TYPES = new Set(['reverse_repo', 'treasury_cash_deposit', 'gov_bond_trade']);
let omoTransactionPage = 1;
const MARKET_NEWS_PAGE_SIZE = 3;
let marketNewsPage = 1;
let marketNewsItems = [];

// 正式页面只展示接口或真实缓存；接口不可用时保留明确空状态。
const defaultSettings = { enabled: true, endpoint: location.protocol.startsWith('http') ? '/api/market' : '', interval: 60 };
function drawCurve(payload = currentBondYields || {}) {
  const svg = $('#curveChart');
  const curve = payload?.curves?.[selectedYieldCurve] || { label: selectedYieldCurve === 'cdb' ? '国开债' : '国债', points: [] };
  const points = curve.points || [];
  const totalPoints = points.length;
  const allTerms = points.map(item => item.term);
  if (curveRangeEnd === null || !Number.isFinite(Number(curveRangeEnd))) curveRangeEnd = Math.max(totalPoints - 1, 0);
  curveRangeStart = Math.min(Math.max(Number(curveRangeStart) || 0, 0), Math.max(totalPoints - 1, 0));
  curveRangeEnd = Math.min(Math.max(Number(curveRangeEnd) || 0, 0), Math.max(totalPoints - 1, 0));
  if (curveRangeStart > curveRangeEnd) [curveRangeStart, curveRangeEnd] = [curveRangeEnd, curveRangeStart];
  const visiblePoints = points.slice(curveRangeStart, curveRangeEnd + 1);
  const terms = visiblePoints.map(item => item.term);
  const today = visiblePoints.map(item => Number(item.today));
  const prior = visiblePoints.map(item => Number(item.previous));
  const values = [...today, ...prior].filter(Number.isFinite);
  const niceStep = rawStep => {
    const step = Math.max(rawStep, 0.01);
    const exponent = Math.floor(Math.log10(step));
    const base = step / 10 ** exponent;
    const niceBase = base <= 1 ? 1 : base <= 2 ? 2 : base <= 2.5 ? 2.5 : base <= 5 ? 5 : 10;
    return niceBase * 10 ** exponent;
  };
  const valueMin = values.length ? Math.min(...values) : 1;
  const valueMax = values.length ? Math.max(...values) : 2.2;
  const rawRange = Math.max(valueMax - valueMin, 0.08);
  const step = Math.min(niceStep(rawRange / 10), 0.05);
  const lower = Math.max(0, Math.floor((valueMin - step * 0.8) / step) * step);
  const upper = Math.ceil((valueMax + step * 0.8) / step) * step;
  const W = 760, H = 300, p = { l: 48, r: 22, t: 25, b: 38 }, min = lower, max = upper;
  const x = i => terms.length === 1 ? (p.l + W - p.r) / 2 : p.l + i * (W - p.l - p.r) / Math.max(terms.length - 1, 1);
  const y = v => p.t + (max - v) * (H - p.t - p.b) / (max - min);
  let html = '';
  const tickDigits = step < 0.1 ? 2 : 1;
  let tickIndex = 0;
  for (let v = min; v <= max + step / 2; v += step) {
    const tick = Number(v.toFixed(4));
    const showLabel = step >= 0.1 || tickIndex % 2 === 0;
    html += `<line x1="${p.l}" y1="${y(tick)}" x2="${W - p.r}" y2="${y(tick)}" stroke="var(--line)" opacity="${showLabel ? 1 : .45}"/>${showLabel ? `<text x="${p.l - 10}" y="${y(tick) + 4}" text-anchor="end" fill="var(--muted)" font-size="10">${tick.toFixed(tickDigits)}%</text>` : ''}`;
    tickIndex += 1;
  }
  terms.forEach((t, i) => html += `<text x="${x(i)}" y="${H - 10}" text-anchor="middle" fill="var(--muted)" font-size="10">${t}</text>`);
  const path = data => data.map((v, i) => Number.isFinite(v) ? `${i ? 'L' : 'M'}${x(i)},${y(v)}` : null).filter(Boolean).join(' ');
  const priorPath = path(prior);
  const todayPath = path(today);
  if (priorPath) html += `<path d="${priorPath}" fill="none" stroke="var(--chart-curve-prior)" stroke-width="2.4" stroke-dasharray="7 6" stroke-linecap="round" opacity=".95"/>`;
  if (todayPath) html += `<path d="${todayPath}" fill="none" stroke="var(--chart-curve-current)" stroke-width="3"/>`;
  prior.forEach((v, i) => {
    if (!Number.isFinite(v)) return;
    html += `<circle cx="${x(i)}" cy="${y(v)}" r="4" fill="var(--surface)" stroke="var(--chart-curve-prior)" stroke-width="2" opacity=".95"/>`;
  });
  today.forEach((v, i) => {
    if (!Number.isFinite(v)) return;
    html += `<circle class="curve-point" data-index="${i}" cx="${x(i)}" cy="${y(v)}" r="5" fill="var(--surface)" stroke="var(--chart-curve-current)" stroke-width="3" tabindex="0"/>`;
  });
  svg.innerHTML = html;
  $$('.curve-point').forEach(point => {
    const show = () => {
      const i = +point.dataset.index;
      const tip = $('#chartTooltip');
      const todayText = Number.isFinite(today[i]) ? `${today[i].toFixed(3)}%` : '--';
      const priorText = Number.isFinite(prior[i]) ? `${prior[i].toFixed(3)}%` : '--';
      const changeText = Number.isFinite(today[i]) && Number.isFinite(prior[i]) ? `${((today[i] - prior[i]) * 100).toFixed(1)} BP` : '--';
      tip.innerHTML = `<b>${terms[i]}</b><br>数据日 ${curve.date || '--'}：${todayText}<br>前一交易日 ${curve.previousDate || '--'}：${priorText}<br>变动 ${changeText}`;
      tip.style.display = 'block';
      tip.style.left = `${Math.min(80, point.cx.baseVal.value / W * 100)}%`;
      tip.style.top = `${Math.max(5, point.cy.baseVal.value / H * 100 - 16)}%`;
    };
    point.addEventListener('mouseenter', show);
    point.addEventListener('focus', show);
    point.addEventListener('mouseleave', () => $('#chartTooltip').style.display = 'none');
    point.addEventListener('blur', () => $('#chartTooltip').style.display = 'none');
  });
  $('#curveTitle').textContent = `${curve.label || '国债'}收益率曲线${curve.date ? ` · 数据日 ${curve.date}` : ''}`;
  const minSlider = $('#curveTermMinSlider');
  const maxSlider = $('#curveTermMaxSlider');
  const rangeSlider = $('#curveRangeSlider');
  const termSliderLabels = $('#curveTermSliderLabels');
  const rangeLabel = $('#curveWindowLabel');
  if (minSlider && maxSlider) {
    const maxIndex = Math.max(totalPoints - 1, 0);
    minSlider.min = '0';
    minSlider.max = String(maxIndex);
    minSlider.value = String(curveRangeStart);
    maxSlider.min = '0';
    maxSlider.max = String(maxIndex);
    maxSlider.value = String(curveRangeEnd);
  }
  if (rangeSlider) {
    const denominator = Math.max(totalPoints - 1, 1);
    rangeSlider.style.setProperty('--range-start', `${curveRangeStart / denominator * 100}%`);
    rangeSlider.style.setProperty('--range-end', `${curveRangeEnd / denominator * 100}%`);
  }
  if (termSliderLabels) {
    termSliderLabels.style.setProperty('--term-count', allTerms.length);
    termSliderLabels.innerHTML = allTerms.map((label, index) => {
      const active = index >= curveRangeStart && index <= curveRangeEnd;
      return `<span class="${active ? 'active' : ''}">${escapeHTML(label)}</span>`;
    }).join('');
  }
  if (rangeLabel) {
    const firstTerm = terms[0] || '--';
    const lastTerm = terms[terms.length - 1] || '--';
    rangeLabel.textContent = terms.length === totalPoints
      ? `显示全部 ${totalPoints} 个期限`
      : `显示 ${firstTerm}-${lastTerm}（${terms.length}/${totalPoints} 个期限）`;
  }
}

function currentCurveWindow(payload = currentBondYields || {}) {
  const curve = payload?.curves?.[selectedYieldCurve] || { label: selectedYieldCurve === 'cdb' ? '国开债' : '国债', points: [] };
  const points = curve.points || [];
  const totalPoints = points.length;
  const maxIndex = Math.max(totalPoints - 1, 0);
  const start = Math.min(Math.max(Number(curveRangeStart) || 0, 0), maxIndex);
  const end = Math.min(Math.max(Number(curveRangeEnd ?? maxIndex) || 0, 0), maxIndex);
  const left = Math.min(start, end);
  const right = Math.max(start, end);
  const visiblePoints = points.slice(left, right + 1);
  return { curve, points, totalPoints, visiblePoints, terms: visiblePoints.map(item => item.term) };
}

function renderCurveZoom() {
  const svg = $('#curveZoomChart');
  if (!svg) return;
  const { curve, visiblePoints, terms } = currentCurveWindow();
  const deltas = visiblePoints.map(item => {
    const today = Number(item.today);
    const prior = Number(item.previous);
    return Number.isFinite(today) && Number.isFinite(prior) ? (today - prior) * 100 : null;
  });
  const values = deltas.filter(Number.isFinite);
  if (!values.length) {
    svg.innerHTML = '<text x="490" y="220" text-anchor="middle" fill="var(--muted)" font-size="18">暂无可计算的两日差距</text>';
    return;
  }
  const maxAbs = Math.max(...values.map(value => Math.abs(value)), 0.5);
  const axis = Math.ceil(maxAbs * 10) / 10;
  const W = 980, H = 440, p = { l: 72, r: 38, t: 42, b: 72 };
  const x = i => terms.length === 1 ? (p.l + W - p.r) / 2 : p.l + i * (W - p.l - p.r) / Math.max(terms.length - 1, 1);
  const y = v => p.t + (axis - v) * (H - p.t - p.b) / (axis * 2);
  const zeroY = y(0);
  const tickStep = Math.max(0.1, Math.ceil(axis * 10 / 4) / 10);
  let html = '';
  for (let v = -axis; v <= axis + tickStep / 2; v += tickStep) {
    const tick = Number(v.toFixed(2));
    html += `<line x1="${p.l}" y1="${y(tick)}" x2="${W - p.r}" y2="${y(tick)}" stroke="var(--line)" opacity="${Math.abs(tick) < 1e-9 ? 1 : .45}"/>`;
    html += `<text x="${p.l - 12}" y="${y(tick) + 4}" text-anchor="end" fill="var(--muted)" font-size="12">${tick.toFixed(1)}</text>`;
  }
  html += `<text x="${p.l - 12}" y="${p.t - 18}" text-anchor="end" fill="var(--muted)" font-size="12">BP</text>`;
  deltas.forEach((value, i) => {
    if (!Number.isFinite(value)) return;
    const isPositive = value >= 0;
    const barWidth = Math.max(26, (W - p.l - p.r) / Math.max(terms.length, 1) * .34);
    const barX = x(i) - barWidth / 2;
    const barY = isPositive ? y(value) : zeroY;
    const barH = Math.max(3, Math.abs(y(value) - zeroY));
    html += `<rect x="${barX}" y="${barY}" width="${barWidth}" height="${barH}" rx="5" fill="${isPositive ? 'var(--chart-negative)' : 'var(--chart-positive)'}" opacity=".9"/>`;
    html += `<text x="${x(i)}" y="${isPositive ? barY - 8 : barY + barH + 18}" text-anchor="middle" fill="${isPositive ? 'var(--chart-negative)' : 'var(--chart-positive)'}" font-size="13" font-weight="700">${value >= 0 ? '+' : ''}${value.toFixed(2)}</text>`;
  });
  terms.forEach((term, i) => {
    html += `<text x="${x(i)}" y="${H - 30}" text-anchor="middle" fill="var(--muted)" font-size="13">${escapeHTML(term)}</text>`;
  });
  svg.innerHTML = html;
  setOptionalText('#curveZoomTitle', `${curve.label || '收益率'}两日差距 · ${curve.date || '--'} vs ${curve.previousDate || '--'}`);
  setOptionalText('#curveZoomHelp', '当前图展示滑杆窗口内各期限的数据日较前一交易日变化，单位 BP。正值表示收益率上行，负值表示收益率下行。');
}

let settings = { ...defaultSettings, ...JSON.parse(localStorage.getItem('bondPulseSettings') || '{}') };
let refreshTimer = null;
let mockData = {
  dr001: 1.428, dr001Change: -3.16, dr007: 1.492, r001: 1.536, gc001: 1.615,
  repoInjection: 2145, repoMaturity: 1250, repoRate: 1.40,
  omoDaily: [
    { label: '06/18', value: 1535, injection: 1985, maturity: 450 },
    { label: '06/19', value: -620, injection: 800, maturity: 1420 },
    { label: '06/20', value: 980, injection: 1800, maturity: 820 },
    { label: '06/23', value: 1125, injection: 2125, maturity: 1000 },
    { label: '06/24', value: 895, injection: 2145, maturity: 1250 }
  ],
  omoWeekly: [
    { label: '05/26-30', value: -1840, injection: 8160, maturity: 10000 },
    { label: '06/03-06', value: 4380, injection: 11280, maturity: 6900 },
    { label: '06/09-13', value: -920, injection: 7380, maturity: 8300 },
    { label: '06/16-20', value: 3075, injection: 9675, maturity: 6600 }
  ],
  omoTransactions: [
    { date: '2026-06-26', label: '06/26', toolName: '逆回购', type: '逆回购投放', amount: 2315, termDays: 7, rate: 1.40 },
    { date: '2026-06-25', label: '06/25', toolName: 'MLF', type: 'MLF投放', amount: 5000, termDays: 365 },
    { date: '2026-06-25', label: '06/25', toolName: '逆回购', type: '逆回购到期', amount: -2480, termDays: 7, rate: 1.40 },
    { date: '2026-06-24', label: '06/24', toolName: '逆回购', type: '逆回购投放', amount: 6625, termDays: 7, rate: 1.40 }
  ],
  fundingRates: {
    date: '2026-06-29',
    startDate: '2026-06-16',
    endDate: '2026-06-29',
    source: 'mock',
    metrics: {
      DR001: { value: 1.3535 },
      DR007: { value: 1.4531 },
      R007: { value: 1.5023 },
      OMO7D: { value: 1.40 }
    }
  },
  interbankCd: {
    date: '2026-07-01',
    source: 'mock',
    total: 274760,
    segments: {
      all: { count: 3, avgYield: 1.5267 },
      aaa: { count: 1, avgYield: 1.54 },
      majorBanks: { count: 1, avgYield: 1.54 },
      ratings: { AAA: { count: 1, avgYield: 1.54 } }
    },
    termBuckets: [
      { term: '1M', count: 0, amount100m: null, avgYield: null },
      { term: '3M', count: 1, amount100m: 10, avgYield: 1.54, valuationYield: 1.4025, yieldSource: 'chinabond' },
      { term: '6M', count: 0, amount100m: null, avgYield: null },
      { term: '9M', count: 0, amount100m: null, avgYield: null },
      { term: '1Y', count: 2, amount100m: 5, avgYield: 1.52, valuationYield: 1.4625, yieldSource: 'chinabond' }
    ],
    items: [
      { bondCode: '112697825', issuer: 'FuDian Bank Co.LTD', issueDate: '2026-07-01', term: '1Year', issuePrice: 98.5028, plannedAmount100m: 2, estimatedYield: 1.52 },
      { bondCode: '112697824', issuer: 'Bank of Urumuqi Co.,Ltd', issueDate: '2026-07-01', term: '1Year', issuePrice: 98.5010, plannedAmount100m: 3, estimatedYield: 1.52 },
      { bondCode: '112606137', issuer: 'Bank of Communications', issueDate: '2026-07-01', term: '3Month', issuePrice: 99.62, plannedAmount100m: 10, estimatedYield: 1.54, rating: 'AAA', segment: '国股行' }
    ]
  },
  bondTemperature: {
    date: '2026-07-01',
    bond_temp: 62,
    bond_temp_level: '偏热',
    comment: '当前为示例市场温度，正式数据更新后将使用最新缓存结果。',
    coverageWeight: 1,
    method: '仅使用中债估值数据；历史分位数法；缺失维度按可得权重归一化',
    components: {
      rate_temp: { label: '利率水位', value: 68, available: true },
      curve_temp: { label: '曲线形态', value: 61, available: true },
      funding_temp: { label: '资金面', value: 57, available: true },
      trading_temp: { label: '交易与拥挤度', value: null, available: false }
    },
    methodDetails: {
      indicators: []
    },
    history: [
      { date: '2026-06-25', bond_temp: 54.2 },
      { date: '2026-06-26', bond_temp: 57.5 },
      { date: '2026-06-29', bond_temp: 59.1 },
      { date: '2026-06-30', bond_temp: 60.8 },
      { date: '2026-07-01', bond_temp: 62.0 }
    ]
  },
  primaryIssuance: {
    date: '2026-07-16',
    source: 'dm_excel',
    sourceName: 'DM 终端 Excel',
    summary: {
      itemCount: 3,
      totalPlannedAmount100m: 2640,
      totalActualAmount100m: 2640,
      byType: [
        { bondType: '国债', count: 2, plannedAmount100m: 2600, actualAmount100m: 2600 },
        { bondType: '政策性金融债', count: 1, plannedAmount100m: 40, actualAmount100m: 40 }
      ]
    },
    items: [
      { bond_type: '国债', bond_name: '26附息国债11(续2)', bond_code: '260011X2.IB', auction_date: '2026-07-10', auction_time: '10:35-11:35', maturity: '3Y', actual_amount_100m: 1300, weighted_rate: 1.2629, marginal_rate: 1.2916, subscription_multiple: 3.65, marginal_multiple: 19.48 },
      { bond_type: '国债', bond_name: '26附息国债13(续发)', bond_code: '260013X.IB', auction_date: '2026-07-10', auction_time: '10:35-11:35', maturity: '2Y', actual_amount_100m: 1300, weighted_rate: 1.2305, marginal_rate: 1.2514, subscription_multiple: 3.56, marginal_multiple: 4.88 },
      { bond_type: '政策性金融债', bond_name: '26农发绿债01(增3)', bond_code: '2604001Z3.IB', auction_date: '2026-07-13', auction_time: '14:00-15:00', maturity: '3Y', actual_amount_100m: 40, weighted_rate: 1.2478, marginal_rate: 1.2478, subscription_multiple: 4.6, marginal_multiple: 1.61 }
    ]
  },
  etfData: {
    date: '2026-07-06',
    source: 'mock',
    sourceName: '东方财富 ETF 行情',
    summary: {
      count: 3,
      totalAmount100m: 85.2,
      totalMarketValue100m: 612.4,
      totalMarketValueChange100m: 1.34,
      totalSubscriptionRedemption100m: 1.28,
      dashboardCategories: [
        { type: '利率类', count: 1, marketValue100m: 236.1, marketValueChange100m: 0.44, subscriptionRedemption100m: 0.37 },
        { type: '信用类', count: 2, marketValue100m: 376.3, marketValueChange100m: 0.9, subscriptionRedemption100m: 0.91 }
      ],
      categories: [
        { type: '国债', count: 1, amount100m: 38.6, marketValue100m: 236.1 },
        { type: '政金债', count: 1, amount100m: 27.4, marketValue100m: 205.8 },
        { type: '可转债', count: 1, amount100m: 19.2, marketValue100m: 170.5 }
      ]
    },
    items: [
      { code: '511010', name: '国债ETF国泰', exchange: 'SH', type: '国债', price: 116.12, changePct: 0.03, amount100m: 38.6, marketValue100m: 236.1, nav: 116.08, premiumPct: 0.034, netInflow100m: 0.32 },
      { code: '511220', name: '城投债ETF', exchange: 'SH', type: '城投债', price: 102.45, changePct: -0.02, amount100m: 27.4, marketValue100m: 205.8, nav: 102.46, premiumPct: -0.01, netInflow100m: -0.08 },
      { code: '511380', name: '可转债ETF', exchange: 'SH', type: '可转债', price: 11.32, changePct: 0.18, amount100m: 19.2, marketValue100m: 170.5, nav: 11.31, premiumPct: 0.088, netInflow100m: 0.11 }
    ]
  },
  chinabondYields: {
    date: '2026-07-01',
    previousDate: '2026-06-30',
    source: 'mock',
    cards: [
      { key: 'treasury10', label: '10年国债', value: 1.7448, changeBp: 1.18 },
      { key: 'cdb10', label: '10年国开', value: 1.7935, changeBp: 1.50 },
      { key: 'treasury30', label: '30年国债', value: 2.2525, changeBp: 1.65 },
      { key: 'cdb3', label: '3年国开', value: 1.4770, changeBp: 1.57 },
      { key: 'treasury7', label: '7年国债', value: 1.5869, changeBp: 2.02 }
    ],
    curves: {
      treasury: {
        label: '国债',
        date: '2026-07-01',
        previousDate: '2026-06-30',
        points: [
          { term: '3M', today: 1.0572, previous: 1.0434 },
          { term: '6M', today: 1.0921, previous: 1.0621 },
          { term: '1Y', today: 1.1317, previous: 1.1217 },
          { term: '3Y', today: 1.3052, previous: 1.2923 },
          { term: '5Y', today: 1.4553, previous: 1.4366 },
          { term: '7Y', today: 1.5869, previous: 1.5667 },
          { term: '10Y', today: 1.7448, previous: 1.7330 },
          { term: '30Y', today: 2.2525, previous: 2.2360 }
        ]
      },
      cdb: {
        label: '国开',
        date: '2026-07-01',
        previousDate: '2026-06-30',
        points: [
          { term: '3M', today: 1.2957, previous: 1.2924 },
          { term: '6M', today: 1.3005, previous: 1.2948 },
          { term: '1Y', today: 1.3431, previous: 1.3285 },
          { term: '3Y', today: 1.4770, previous: 1.4613 },
          { term: '5Y', today: 1.5940, previous: 1.5789 },
          { term: '7Y', today: 1.7108, previous: 1.6961 },
          { term: '10Y', today: 1.7935, previous: 1.7785 },
          { term: '30Y', today: 2.3240, previous: 2.3050 }
        ]
      }
    }
  }
};
let omoPeriod = 'day';
let omoMetric = 'net';
let currentOmoData = {};

function mockMarketData() {
  const jitter = value => +(value + (Math.random() - .5) * .008).toFixed(3);
  mockData = { ...mockData, dr001: jitter(mockData.dr001), dr007: jitter(mockData.dr007), r001: jitter(mockData.r001), gc001: jitter(mockData.gc001) };
  return Promise.resolve(mockData);
}

async function fetchMarketData() {
  if (!settings.endpoint) throw new Error('数据接口未配置');
  return BondDashboardApi.getJson(settings.endpoint);
}

function formatNumber(value) {
  return Number(value).toLocaleString('zh-CN');
}

function formatRate(value) {
  if (value === null || value === undefined || value === '') return '--';
  return Number.isFinite(Number(value)) ? Number(value).toFixed(4) : '--';
}

function formatAmount100m(value, digits = 2, dashZero = false) {
  if (value === null || value === undefined || value === '') return '--';
  const number = Number(value);
  if (dashZero && Number.isFinite(number) && Math.abs(number) < 1e-9) return '--';
  return Number.isFinite(number) ? number.toFixed(digits) : '--';
}

function formatSignedAmount100m(value, digits = 2) {
  if (value === null || value === undefined || value === '') return '--';
  const number = Number(value);
  if (!Number.isFinite(number)) return '--';
  if (Math.abs(number) < 0.005) return '0.00';
  return `${number > 0 ? '+' : '−'}${Math.abs(number).toFixed(digits)}`;
}

const ETF_DASHBOARD_CATEGORY_ORDER = ['利率类', '信用类', '地方债'];

function etfDashboardCategory(item = {}) {
  const name = String(item.name || '');
  const type = String(item.type || '');
  if (type.includes('地方债') || name.includes('地方债')) return '地方债';
  if (
    type.includes('国债') || type.includes('政金') ||
    name.includes('国债') || name.includes('政金') ||
    name.includes('国开') || name.includes('政策')
  ) return '利率类';
  return '信用类';
}

function round2(value) {
  return Math.round(value * 100) / 100;
}

function estimateEtfSubscription(item, previous) {
  if (!previous) return null;
  const currentMarketValue = Number(item.marketValue100m);
  const previousMarketValue = Number(previous.marketValue100m);
  const changePct = Number(item.changePct);
  if (!Number.isFinite(currentMarketValue) || !Number.isFinite(previousMarketValue) || !Number.isFinite(changePct)) return null;
  return round2(currentMarketValue - previousMarketValue * (1 + changePct / 100));
}

function normalizeEtfDashboardPayload(payload, previousPayload = null) {
  const data = payload && typeof payload === 'object' ? payload : {};
  const items = Array.isArray(data.items) ? data.items : [];
  const previousItems = Array.isArray(previousPayload?.items) ? previousPayload.items : [];
  const previousByCode = new Map(previousItems.filter(item => item?.code).map(item => [String(item.code), item]));
  const buckets = Object.fromEntries(ETF_DASHBOARD_CATEGORY_ORDER.map(type => [type, {
    type,
    count: 0,
    marketValue100m: 0,
    marketValueChange100m: 0,
    subscriptionRedemption100m: 0,
    hasMarketValueChange: false,
    hasSubscription: false
  }]));

  items.forEach(item => {
    const dashboardType = item.dashboardType || etfDashboardCategory(item);
    item.dashboardType = dashboardType;
    const bucket = buckets[dashboardType] || buckets['信用类'];
    bucket.count += 1;
    bucket.marketValue100m += Number(item.marketValue100m) || 0;
    const previous = previousByCode.get(String(item.code || ''));
    let marketValueChange = Number(item.marketValueChange100m);
    if (!Number.isFinite(marketValueChange) && previous) {
      const currentMarketValue = Number(item.marketValue100m);
      const previousMarketValue = Number(previous.marketValue100m);
      if (Number.isFinite(currentMarketValue) && Number.isFinite(previousMarketValue)) {
        marketValueChange = round2(currentMarketValue - previousMarketValue);
        item.marketValueChange100m = marketValueChange;
      }
    }
    if (Number.isFinite(marketValueChange)) {
      bucket.marketValueChange100m += marketValueChange;
      bucket.hasMarketValueChange = true;
    }
    let subscription = Number(item.subscriptionRedemption100m);
    if (!Number.isFinite(subscription)) {
      subscription = estimateEtfSubscription(item, previous);
      if (subscription !== null) item.subscriptionRedemption100m = subscription;
    }
    if (Number.isFinite(subscription)) {
      bucket.subscriptionRedemption100m += subscription;
      bucket.hasSubscription = true;
    }
  });

  const computedCategories = ETF_DASHBOARD_CATEGORY_ORDER
    .map(type => buckets[type])
    .filter(item => item.count > 0)
    .map(item => ({
      type: item.type,
      count: item.count,
      marketValue100m: round2(item.marketValue100m),
      marketValueChange100m: item.hasMarketValueChange ? round2(item.marketValueChange100m) : null,
      subscriptionRedemption100m: item.hasSubscription ? round2(item.subscriptionRedemption100m) : null
    }));
  const summary = data.summary || {};
  const hasDashboardCategories = Array.isArray(summary.dashboardCategories) && summary.dashboardCategories.length;
  data.summary = {
    ...summary,
    count: summary.count ?? items.length,
    dashboardCategories: hasDashboardCategories ? summary.dashboardCategories : computedCategories,
    totalMarketValueChange100m: summary.totalMarketValueChange100m ?? (
      computedCategories.some(item => Number.isFinite(Number(item.marketValueChange100m)))
        ? round2(computedCategories.reduce((sum, item) => sum + (Number(item.marketValueChange100m) || 0), 0))
        : null
    ),
    totalSubscriptionRedemption100m: summary.totalSubscriptionRedemption100m ?? (
      computedCategories.some(item => Number.isFinite(Number(item.subscriptionRedemption100m)))
        ? round2(computedCategories.reduce((sum, item) => sum + (Number(item.subscriptionRedemption100m) || 0), 0))
        : null
    )
  };
  return data;
}

function etfPayloadNeedsPrevious(payload) {
  const summary = payload?.summary || {};
  if (summary.totalMarketValueChange100m === null || summary.totalMarketValueChange100m === undefined) return true;
  if (summary.totalSubscriptionRedemption100m === null || summary.totalSubscriptionRedemption100m === undefined) return true;
  return !Array.isArray(summary.dashboardCategories) || !summary.dashboardCategories.length;
}

function formatChangeBp(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return '--';
  if (Math.abs(number) < 0.005) return '0.00 BP';
  return `${number > 0 ? '+' : '−'}${Math.abs(number).toFixed(2)} BP`;
}

function changeClass(value) {
  const number = Number(value);
  if (!Number.isFinite(number) || Math.abs(number) < 0.005) return '';
  return number > 0 ? 'up' : 'down';
}

function localTodayIso() {
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

function formatDateLabel(value) {
  if (!value) return '--';
  const text = String(value);
  const match = text.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return text;
  return `${match[1]}年${Number(match[2])}月${Number(match[3])}日`;
}

function formatShortDate(value) {
  if (!value) return '--';
  const text = String(value);
  const match = text.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (match) return `${match[2]}/${match[3]}`;
  return text;
}

function formatDateTimeLabel(value) {
  if (!value) return '--';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false });
}

function isTodayIsoDate(value) {
  return String(value || '') === localTodayIso();
}

function isWeekendDate(value) {
  if (!value) return false;
  const date = new Date(`${value}T00:00:00`);
  const day = date.getDay();
  return day === 0 || day === 6;
}

function rememberFundingBusinessDate(value) {
  if (value && !isWeekendDate(value)) $('#fundingRateDate').dataset.lastBusinessDate = value;
}

function setOptionalHTML(selector, value) {
  const node = $(selector);
  if (node) node.innerHTML = value;
}

function setOptionalText(selector, value) {
  const node = $(selector);
  if (node) node.textContent = value;
}

function setOptionalClass(selector, value) {
  const node = $(selector);
  if (node) node.className = value;
}

function renderFundingRates(payload) {
  const data = payload && payload.metrics ? payload : { metrics: {}, source: 'unavailable' };
  const metric = code => data.metrics?.[code] || {};
  const anomalies = [];
  const renderMetric = (selector, code) => {
    const item = metric(code);
    const change = item.changeBp;
    const changeText = formatChangeBp(change);
    const changeHtml = changeText === '--' ? '' : `<em class="${changeClass(change)}">${changeText}</em>`;
    const rate = formatRate(item.value);
    $(selector).innerHTML = rate === '--' ? '<span class="pending-value">-- 待接入</span>' : `${rate}<small>%</small>${changeHtml}`;
    markRateAnomaly($(selector), change);
    if (Number.isFinite(Number(change)) && Math.abs(Number(change)) > 20) anomalies.push(`${code} ${formatChangeBp(change)}`);
  };
  renderMetric('#priceDr001', 'DR001');
  renderMetric('#priceDr007', 'DR007');
  renderMetric('#priceR007', 'R007');
  renderMetric('#priceOmo7d', 'OMO7D');
  renderVolatilityAlert($('#priceDr001')?.closest('.panel'), anomalies);
  if (data.date) {
    $('#fundingRateDate').value = data.date;
    rememberFundingBusinessDate(data.date);
  }
  if (data.startDate) $('#fundingRateDate').min = data.startDate;
  if (data.endDate) $('#fundingRateDate').max = data.endDate;
  $('#fundingRateDate').setCustomValidity('');
  const source = data.source === 'cache' ? '缓存' : data.source === 'unavailable' ? '暂不可用' : '中国货币网';
  const fallbackNote = data.asOfFallback && data.requestedDate ? ' · 最近可得' : '';
  $('#fundingRateMeta').textContent = `${source} · ${data.date || '--'}${fallbackNote}`;
}

function renderChinabondYields(payload) {
  const data = payload && payload.curves ? payload : { cards: [], curves: {} };
  currentBondYields = data;
  const idMap = {
    treasury10: ['#metricTreasury10', '#metricTreasury10Change'],
    cdb10: ['#metricCdb10', '#metricCdb10Change'],
    treasury30: ['#metricTreasury30', '#metricTreasury30Change'],
    cdb3: ['#metricCdb3', '#metricCdb3Change'],
    treasury7: ['#metricTreasury7', '#metricTreasury7Change'],
  };
  (data.cards || []).forEach(card => {
    const [valueSelector, changeSelector] = idMap[card.key] || [];
    if (!valueSelector || !changeSelector) return;
    setOptionalHTML(valueSelector, `${formatRate(card.value)}<span>%</span>`);
    const change = Number(card.changeBp);
    const changeNode = $(changeSelector);
    if (changeNode) {
      changeNode.textContent = Number.isFinite(change) ? `${change >= 0 ? '↑' : '↓'} ${Math.abs(change).toFixed(2)} BP` : '-- BP';
      changeNode.className = change >= 0 ? 'up' : 'down';
    }
    markRateAnomaly($(valueSelector), change);
    const cardNode = $(valueSelector)?.closest('.metric-card');
    renderVolatilityAlert(cardNode, Number.isFinite(change) && Math.abs(change) > 20 ? [`${card.label || card.key} ${formatChangeBp(change)}`] : []);
  });
  drawCurve(data);
}

function renderInterbankCd(payload) {
  const data = payload && Array.isArray(payload.items) ? payload : { items: [], termBuckets: [], source: 'unavailable' };
  const items = data.items || [];
  const termBuckets = data.termBuckets || [];
  const totalAmount = termBuckets.reduce((sum, item) => sum + (Number(item.amount100m) || 0), 0);
  const weightedYield = InterbankCdUi.weightedValuationYield(termBuckets);
  const dateInput = $('#interbankCdSelectDate');
  if (dateInput) {
    if (data.date) dateInput.value = data.date;
    if (data.startDate) dateInput.min = data.startDate;
    if (data.endDate) dateInput.max = data.endDate;
  }
  $('#interbankCdCount').textContent = `${items.length || '--'}只`;
  $('#interbankCdYield').innerHTML = `${formatRate(weightedYield)}<small>%</small>`;
  $('#interbankCdList').innerHTML = termBuckets.map(item => `
    <div class="interbank-cd-term">
      <span>${escapeHTML(item.term || '--')}</span>
      <b>${item.count || 0}只</b>
      <em>${Number.isFinite(Number(item.amount100m)) ? `${formatNumber(item.amount100m)}亿` : '--'}</em>
      <strong>${formatRate(item.valuationYield)}%</strong>
    </div>
  `).join('') || '<div class="interbank-cd-empty">暂无同业存单期限数据</div>';
  const rows = $('#interbankCdRows');
  if (rows) {
    rows.innerHTML = items.slice(0, 30).map(item => `<tr>
      <td><strong>${escapeHTML(item.issueDate || data.date || '--')}</strong><small>${escapeHTML(item.bondCode || item.bondDefinedCode || '--')}</small></td>
      <td>${escapeHTML(item.issuer || '--')}</td>
      <td>${escapeHTML(item.term || '--')}</td>
      <td>${formatAmount100m(item.plannedAmount100m ?? item.actualAmount100m)}亿</td>
      <td>${formatRate(item.valuationYield)}%</td>
      <td>${escapeHTML(item.rating || item.segment || '--')}</td>
    </tr>`).join('') || '<tr><td colspan="6">暂无同业存单明细</td></tr>';
  }
  const issuanceFallback = ['cache', 'unavailable'].includes(data.issuanceSource || data.source) ? '（最近可得）' : '';
  const valuationFallback = data.valuationSource !== 'chinabond' ? '（最近可得）' : '';
  $('#interbankCdMeta').textContent = `中债估值日 ${data.valuationDate || '--'}${valuationFallback} · 发行数据日 ${data.issuanceDate || data.date || '--'}${issuanceFallback} · 期限规模合计 ${totalAmount ? formatNumber(totalAmount) : '--'}亿`;
}

function renderBondTemperature(payload) {
  const data = payload && typeof payload === 'object' ? payload : {};
  const value = Number(data.bond_temp);
  const displayValue = Number.isFinite(value) ? Math.round(value) : '--';
  const level = data.bond_temp_level || data.level || '--';
  const progress = Number.isFinite(value) ? Math.max(0, Math.min(100, value)) : 0;
  setOptionalText('#bondTempValue', displayValue);
  setOptionalText('#bondTempLevel', level);
  const gauge = $('#bondTempGauge');
  if (gauge) {
    gauge.style.setProperty('--temp-progress', `${progress}%`);
    gauge.style.setProperty('--temp-angle', `${-90 + progress * 1.8}deg`);
    gauge.setAttribute('aria-label', `市场温度${displayValue}，${level}`);
  }
  setOptionalText('#bondTempDate', data.date || '--');
  const components = data.components || {};
  const items = ['rate_temp', 'funding_temp', 'curve_temp', 'trading_temp']
    .map(key => components[key])
    .filter(item => item && item.available !== false && Number.isFinite(Number(item.value)));
  const breakdown = $('#bondTempBreakdown');
  if (breakdown) {
    breakdown.innerHTML = items.map(item => {
      const itemValue = Number(item.value);
      return `<div><span>${escapeHTML(item.label || '--')}</span><strong>${itemValue.toFixed(1)}</strong></div>`;
    }).join('') || '<div class="temperature-empty">暂无可用分项</div>';
  }
  const detailIndicators = Array.isArray(data.methodDetails?.indicators) ? data.methodDetails.indicators : [];
  const rows = $('#bondTempRows');
  if (rows) {
    rows.innerHTML = detailIndicators.map(item => {
      const itemValue = Number(item.value);
      const score = Number(item.score);
      return `<tr>
        <td>${escapeHTML(item.sourceLabel || '--')}</td>
        <td>${escapeHTML(item.label || '--')}</td>
        <td>${Number.isFinite(itemValue) ? `${itemValue.toFixed(2)}${escapeHTML(item.unit || '')}` : '--'}</td>
        <td>${Number.isFinite(score) ? score.toFixed(1) : '--'}</td>
        <td>${escapeHTML(item.groupLabel || '--')}</td>
        <td>${item.available ? '可用并入模' : '数据不足'}</td>
      </tr>`;
    }).join('') || '<tr><td colspan="6">当前可得历史样本不足。</td></tr>';
  }
  setOptionalText('#bondTempComment', data.comment || data.signal || '当前数据不足，暂无法计算债市温度。');
}

function renderBondTempTrend(payload) {
  const data = payload && typeof payload === 'object' ? payload : {};
  const history = (Array.isArray(data.history) ? data.history : [])
    .filter(item => Number.isFinite(Number(item.bond_temp)))
    .slice(-5);
  const chart = $('#bondTempTrendChart');
  if (!chart) return;
  if (!history.length) {
    chart.innerHTML = '<div class="temperature-empty">暂无真实温度历史</div>';
    return;
  }
  chart.innerHTML = history.map(item => {
    const value = Number(item.bond_temp);
    return `<div class="temp-trend-column">
      <span>${value.toFixed(1)}</span>
      <i style="height:${Math.max(8, value)}%"></i>
      <small>${escapeHTML(String(item.date || '').slice(5) || '--')}</small>
    </div>`;
  }).join('');
}

function renderPrimaryIssuance(payload) {
  const data = payload && typeof payload === 'object' ? payload : { items: [], summary: {} };
  const summary = data.summary || {};
  const items = Array.isArray(data.items) ? data.items : [];
  const emptyState = $('#primaryIssuanceEmpty');
  if (emptyState) emptyState.hidden = items.length > 0;
  const byType = Array.isArray(summary.byType) ? summary.byType : [];
  setOptionalText('#primaryIssuanceDate', data.date ? `数据日 ${data.date}` : '等待 Excel');
  setOptionalText('#primaryIssuanceStatDate', summary.auctionDateRange || data.date || '--');
  setOptionalText('#primaryIssuanceSourceName', data.sourceName || data.source || '--');
  setOptionalText('#primaryIssuanceCount', summary.itemCount ?? items.length ?? '--');
  setOptionalHTML('#primaryIssuanceActual', `${formatAmount100m(summary.totalActualAmount100m ?? summary.totalAmount100m, 0)}<small>亿元</small>`);
  setOptionalHTML('#primaryIssuancePlanned', `${formatAmount100m(summary.totalPlannedAmount100m, 0)}<small>亿元</small>`);

  const typeList = $('#primaryIssuanceTypeList');
  if (typeList) {
    const maxAmount = Math.max(...byType.map(item => Number(item.actualAmount100m || item.amount100m) || 0), 1);
    typeList.innerHTML = byType.map(item => {
      const amount = Number(item.actualAmount100m || item.amount100m) || 0;
      const width = Math.max(4, amount / maxAmount * 100);
      return `<div class="primary-type-item">
        <span>${escapeHTML(item.bondType || '--')}</span>
        <b>${item.count || 0}只</b>
        <i><em style="width:${width}%"></em></i>
        <strong>${formatAmount100m(amount, 0)}亿元</strong>
      </div>`;
    }).join('') || '<div class="etf-empty">暂无一级发行分类数据</div>';
  }

  const rows = $('#primaryIssuanceRows');
  if (!rows) return;
  rows.innerHTML = items.map(item => {
    const weightedRate = Number(item.weighted_rate);
    const marginalRate = Number(item.marginal_rate);
    const multiple = Number(item.subscription_multiple);
    return `<tr>
      <td><strong>${escapeHTML(item.bond_name || '--')}</strong><small>${escapeHTML(item.bond_code || '--')}</small></td>
      <td>${escapeHTML(item.bond_type || '--')}</td>
      <td>${escapeHTML(item.auction_date || '--')}<small>${escapeHTML(item.auction_time || '')}</small></td>
      <td>${escapeHTML(item.maturity || '--')}</td>
      <td>${formatAmount100m(item.actual_amount_100m, 0)}亿</td>
      <td>${Number.isFinite(weightedRate) ? weightedRate.toFixed(4) + '%' : '--'}</td>
      <td>${Number.isFinite(marginalRate) ? marginalRate.toFixed(4) + '%' : '--'}</td>
      <td>${Number.isFinite(multiple) ? multiple.toFixed(2) : '--'}</td>
    </tr>`;
  }).join('') || '<tr><td colspan="8">暂无国债和政策性金融债发行数据</td></tr>';
}

function renderEtfData(payload) {
  const data = normalizeEtfDashboardPayload(payload && typeof payload === 'object' ? payload : mockData.etfData);
  const summary = data.summary || {};
  const items = Array.isArray(data.items) ? data.items : [];
  const dateInput = $('#etfDataSelectDate');
  if (dateInput) {
    if (data.date) dateInput.value = data.date;
    if (data.startDate) dateInput.min = data.startDate;
    if (data.endDate) dateInput.max = data.endDate;
  }
  setOptionalText('#etfTotalCount', summary.count ?? items.length ?? '--');
  setOptionalHTML('#etfTotalAmount', `${formatSignedAmount100m(summary.totalMarketValueChange100m)}<small>亿元</small>`);
  setOptionalHTML('#etfTotalMarketValue', `${formatSignedAmount100m(summary.totalSubscriptionRedemption100m)}<small>亿元</small>`);
  setOptionalText('#etfSourceName', data.source === 'cache' ? '缓存数据' : data.sourceName || data.source || '--');

  const categories = Array.isArray(summary.dashboardCategories) && summary.dashboardCategories.length
    ? summary.dashboardCategories
    : (Array.isArray(summary.categories) ? summary.categories : []);
  const categoryList = $('#etfCategoryList');
  if (categoryList) {
    categoryList.innerHTML = categories.slice(0, 3).map(item => {
      const scaleChange = Number(item.marketValueChange100m);
      const subscription = Number(item.subscriptionRedemption100m);
      const hasScaleChange = Number.isFinite(scaleChange);
      const hasSubscription = Number.isFinite(subscription);
      return `<div class="etf-category-item">
        <span>${escapeHTML(item.type || '--')}</span>
        <b>${item.count || 0}只</b>
        <strong class="${hasScaleChange ? changeClass(scaleChange) : ''}">规模变化 ${hasScaleChange ? formatSignedAmount100m(scaleChange) : '--'}亿元</strong>
        <em class="${hasSubscription ? changeClass(subscription) : ''}">申购赎回 ${hasSubscription ? formatSignedAmount100m(subscription) : '--'}亿元</em>
      </div>`;
    }).join('') || '<div class="etf-empty">暂无分类数据</div>';
  }

  const rows = $('#etfDataRows');
  if (!rows) return;
  rows.innerHTML = items.slice(0, 12).map(item => {
    const change = Number(item.changePct);
    const premium = Number(item.premiumPct);
    const inflow = Number(item.netInflow100m);
    const formatZeroDash = (value, digits = 2) => formatAmount100m(value, digits, true);
    const formatZeroDashAmount = (value, digits = 2) => {
      const text = formatZeroDash(value, digits);
      return text === '--' ? '--' : `${text}亿`;
    };
    const formatPercentZeroDash = (value, digits = 2, signed = false) => {
      const number = Number(value);
      if (!Number.isFinite(number) || Math.abs(number) < 1e-9) return '--';
      return `${signed && number >= 0 ? '+' : ''}${number.toFixed(digits)}%`;
    };
    return `<tr>
      <td><strong>${escapeHTML(item.name || '--')}</strong><small>${escapeHTML(item.code || '--')}.${escapeHTML(item.exchange || '--')}</small></td>
      <td>${escapeHTML(item.type || '--')}</td>
      <td>${formatZeroDash(item.price, 4)}</td>
      <td class="${changeClass(change)}">${formatPercentZeroDash(change, 2, true)}</td>
      <td>${formatZeroDashAmount(item.amount100m)}</td>
      <td>${formatZeroDashAmount(item.marketValue100m)}</td>
      <td>${formatZeroDash(item.nav, 4)}</td>
      <td class="${changeClass(premium)}">${formatPercentZeroDash(premium, 3, true)}</td>
      <td class="${changeClass(inflow)}">${formatZeroDash(inflow)}${Math.abs(inflow) < 1e-9 || !Number.isFinite(inflow) ? '' : '亿'}</td>
    </tr>`;
  }).join('') || '<tr><td colspan="9">暂无债券 ETF 数据</td></tr>';
}

function renderAiSummary(summary) {
  if (!summary || typeof summary !== 'object') return;
  const headline = String(summary.headline || '').trim();
  const text = String(summary.summary || '').trim();
  if (headline) $('#aiMarketHeadline').textContent = headline;
  if (text) $('#aiMarketSummary').textContent = text;
  if (summary.date) $('#currentDate').textContent = `上一交易日收盘点评 · ${formatDateLabel(summary.date)}`;
  const stamp = [summary.date, summary.update_time].filter(Boolean).join(' · ');
  if (stamp) $('#dataModeLabel').textContent = `收盘点评口径 · ${stamp}`;
}

async function loadAiSummary() {
  try {
    const response = await fetch(`data/ai_summary.json?t=${Date.now()}`, { headers: { Accept: 'application/json' }, cache: 'no-store' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    renderAiSummary(await response.json());
  } catch (error) {
    console.warn('AI summary unavailable:', error);
  }
}

async function fetchFundingRates(date) {
  return BondDashboardApi.fetchFundingRates(date);
}

async function fetchInterbankCd(date) {
  return BondDashboardApi.fetchInterbankCd(date);
}

async function fetchEtfData(date) {
  return BondDashboardApi.fetchEtfData(date);
}

function renderOmoChart() {
  const source = omoPeriod === 'day' ? currentOmoData.omoDaily : currentOmoData.omoWeekly;
  const rawData = Array.isArray(source) ? source : [];
  if (!rawData.length) {
    $('#omoPeriodLabel').textContent = '暂无真实数据';
    $('#omoPeriodTotal').innerHTML = '-- <small>亿元</small>';
    $('#omoChart').innerHTML = '<div class="empty-state">公开市场操作数据暂不可用</div>';
    return;
  }
  const chartData = rawData.map(item => {
    const injection = Number(item.injection ?? Math.max(Number(item.value), 0));
    const maturity = Number(item.maturity ?? Math.max(-Number(item.value), 0));
    const net = Number(item.value ?? injection - maturity);
    return { ...item, injection, maturity, net, isFuture: Boolean(item.isFuture) };
  });
  const visibleData = omoPeriod === 'day'
    ? chartData.filter(item => !item.isFuture).slice(-5)
    : chartData.slice(-4);

  const renderNetBars = (items, label) => {
    const maxAbs = Math.max(...items.map(item => Math.abs(item.net)), 1);
    const total = items.reduce((sum, item) => sum + item.net, 0);
    $('#omoPeriodLabel').textContent = label;
    $('#omoPeriodTotal').innerHTML = `${total >= 0 ? '+' : '−'}${formatNumber(Math.abs(total))} <small>亿元</small>`;
    $('#omoPeriodTotal').className = total >= 0 ? 'positive-text' : 'negative-text';
    $('#omoChart').innerHTML = items.map(item => {
      const value = Number(item.net);
      const height = Math.max(4, Math.abs(value) / maxAbs * 67);
      const isPositive = value >= 0;
      return `<div class="omo-column">
        <span class="omo-value ${isPositive ? 'positive-text' : 'negative-text'}" style="${isPositive ? `bottom:calc(50% + ${height}px)` : `top:calc(50% + ${height}px)`}">${isPositive ? '+' : '−'}${formatNumber(Math.abs(value))}</span>
        <i class="omo-bar ${isPositive ? 'positive' : 'negative'}" style="height:${height}px;${isPositive ? 'bottom:50%' : 'top:50%'}"></i>
        <small>${escapeHTML(item.label)}</small>
      </div>`;
    }).join('');
  };

  if (omoMetric === 'future-net') {
    const futureItems = chartData.filter(item => item.isFuture).slice(0, 5);
    renderNetBars(futureItems, '未来5日累计净额');
    return;
  }

  if (omoMetric === 'flow') {
    const maxAbs = Math.max(...visibleData.flatMap(item => [Math.abs(item.injection), Math.abs(item.maturity)]), 1);
    const totalInjection = visibleData.reduce((sum, item) => sum + item.injection, 0);
    const totalMaturity = visibleData.reduce((sum, item) => sum + item.maturity, 0);
    $('#omoPeriodLabel').textContent = `${omoPeriod === 'day' ? '近5日' : '近4周'}累计投放/到期`;
    $('#omoPeriodTotal').innerHTML = `<span class="positive-text">投放 ${formatNumber(totalInjection)}</span><span class="negative-text">到期/回笼 ${formatNumber(totalMaturity)}</span><small>亿元</small>`;
    $('#omoPeriodTotal').className = 'omo-flow-total';
    $('#omoChart').innerHTML = visibleData.map(item => {
      const injectionHeight = Math.max(4, Math.abs(item.injection) / maxAbs * 67);
      const maturityHeight = Math.max(4, Math.abs(item.maturity) / maxAbs * 67);
      return `<div class="omo-column omo-column-flow">
        <span class="omo-value omo-value-injection positive-text" style="bottom:calc(50% + ${injectionHeight}px)">${formatNumber(item.injection)}</span>
        <span class="omo-value omo-value-maturity negative-text" style="top:calc(50% + ${maturityHeight}px)">${formatNumber(item.maturity)}</span>
        <i class="omo-bar omo-bar-flow positive" style="height:${injectionHeight}px;bottom:50%"></i>
        <i class="omo-bar omo-bar-flow negative" style="height:${maturityHeight}px;top:50%"></i>
        <small>${escapeHTML(item.label)}</small>
      </div>`;
    }).join('');
    return;
  }

  renderNetBars(visibleData, `${omoPeriod === 'day' ? '近5日' : '近4周'}累计净额`);
}
function renderOmoTransactions() {
  const source = currentOmoData.omoTransactions;
  const data = Array.isArray(source) ? source : [];
  const tbody = $('#omoTransactionRows');
  if (!tbody) return;
  const totalPages = Math.max(1, Math.ceil(data.length / OMO_TRANSACTION_PAGE_SIZE));
  omoTransactionPage = Math.min(Math.max(1, omoTransactionPage), totalPages);
  const start = (omoTransactionPage - 1) * OMO_TRANSACTION_PAGE_SIZE;
  const pageItems = data.slice(start, start + OMO_TRANSACTION_PAGE_SIZE);
  tbody.innerHTML = pageItems.map(item => {
    const amount = Number(item.amount);
    const sign = amount >= 0 ? '+' : '−';
    const termDays = Number(item.termDays);
    const toolName = item.toolName || item.tool || '';
    const isOvernightReverseRepo = termDays === 1 && String(toolName).includes('逆回购');
    const term = Number.isFinite(termDays) ? `${termDays}天` : '--';
    const displayToolName = isOvernightReverseRepo ? '隔夜逆回购' : toolName;
    const displayType = isOvernightReverseRepo ? String(item.type || '公开市场操作').replace('逆回购', '隔夜逆回购') : (item.type || '公开市场操作');
    const inferredTool = item.tool || (String(toolName).includes('逆回购') && !String(toolName).includes('买断式') ? 'reverse_repo' : '');
    const includedInNet = OMO_NET_TOOL_TYPES.has(inferredTool);
    return `<tr>
      <td>${escapeHTML(item.label || item.date || '--')}</td>
      <td>${escapeHTML(displayToolName || '--')}</td>
      <td><span class="transaction-type">${escapeHTML(displayType)}</span></td>
      <td>${term}</td>
      <td class="${amount >= 0 ? 'positive-text' : 'negative-text'}">${sign}${formatNumber(Math.abs(amount))}</td>
      <td><span class="net-scope ${includedInNet ? 'included' : 'excluded'}">${includedInNet ? '计入' : '不计入'}</span></td>
    </tr>`;
  }).join('');
  const summary = $('#omoTransactionPageSummary');
  if (summary) summary.textContent = `第 ${omoTransactionPage} / ${totalPages} 页 · 共 ${data.length} 条`;
  const prev = $('#omoTransactionPrev');
  const next = $('#omoTransactionNext');
  if (prev) prev.disabled = omoTransactionPage <= 1;
  if (next) next.disabled = omoTransactionPage >= totalPages;
}

function renderBroadCentralBank(tools, netPayload) {
  const labels = {
    reverse_repo: '逆回购', mlf: 'MLF', treasury_cash_deposit: '国库现金定存',
    gov_bond_trade: '国债买卖', slf: 'SLF', psl: 'PSL',
  };
  const items = Array.isArray(tools) ? tools : [];
  const byTool = netPayload?.byTool || {};
  setOptionalText('#broadCentralBankDate', netPayload?.date || '--');
  const net = Number(netPayload?.net_injection);
  setOptionalHTML('#broadCentralBankNet', `${Number.isFinite(net) ? (net >= 0 ? '+' : '') + formatNumber(net) : '--'}<small>亿元</small>`);
  const rows = $('#centralBankToolRows');
  if (!rows) return;
  rows.innerHTML = items.map(item => {
    const contribution = Number(byTool[item.tool_type]?.net);
    return `<tr>
      <td><strong>${escapeHTML(labels[item.tool_type] || item.tool_type)}</strong></td>
      <td>${Number(item.count) || 0}</td><td>${escapeHTML(item.latest_date || '--')}</td>
      <td>${formatNumber(Number(item.total_injection) || 0)}亿</td><td>${formatNumber(Number(item.total_withdrawal) || 0)}亿</td>
      <td class="${contribution >= 0 ? 'positive-text' : 'negative-text'}">${Number.isFinite(contribution) ? `${contribution >= 0 ? '+' : '−'}${formatNumber(Math.abs(contribution))}亿` : '--'}</td>
    </tr>`;
  }).join('') || '<tr><td colspan="6">暂无央行工具数据</td></tr>';
}

function updateMarketUI(data) {
  const renderTopRate = (selector, value) => setOptionalHTML(selector, value == null ? '--<small>待接入</small>' : `${Number(value).toFixed(3)}<small>%</small>`);
  renderTopRate('#dr001Value', data.dr001);
  renderTopRate('#dr007Value', data.dr007);
  renderTopRate('#r001Value', data.r001);
  renderTopRate('#gc001Value', data.gc001);
  if (Number.isFinite(Number(data.dr001Change))) {
    const change = Number(data.dr001Change);
    setOptionalText('#dr001Change', `${change > 0 ? '+' : '−'}${Math.abs(change).toFixed(2)} BP`);
    setOptionalClass('#dr001Change', change > 0 ? 'up' : 'down');
  }
  const injection = Number(data.repoInjection), maturity = Number(data.repoMaturity);
  const latestOmoRow = Array.isArray(data.omoDaily) && data.omoDaily.length ? data.omoDaily[data.omoDaily.length - 1] : null;
  const omoDate = data.omoDate || latestOmoRow?.date || '';
  const omoLabelPrefix = omoDate ? (isTodayIsoDate(omoDate) ? '今日' : `${formatShortDate(omoDate)}公告`) : '最新公告';
  setOptionalText('#repoInjectionLabel', `${omoLabelPrefix}投放`);
  setOptionalText('#repoMaturityLabel', `${omoLabelPrefix}到期`);
  $('#repoInjection').textContent = `${formatNumber(injection)}亿`;
  $('#repoMaturity').textContent = `${formatNumber(maturity)}亿`;
  setOptionalText('#omoUpdatedAt', `更新时间 ${formatDateTimeLabel(data.omoUpdatedAt || data.updatedAt)}`);
  currentOmoData = data;
  omoTransactionPage = 1;
  renderOmoChart();
  renderOmoTransactions();
  renderBroadCentralBank(data.centralBankTools, data.centralBankNetInjection);
  renderChinabondYields(data.chinabondYields);
  renderFundingRates(data.fundingRates);
  renderInterbankCd(data.interbankCd);
  renderBondTemperature(data.bondTemperature);
  renderBondTempTrend(data.bondTemperature);
  renderPrimaryIssuance(data.primaryIssuance);
  renderEtfData(data.etfData);
  if (etfPayloadNeedsPrevious(data.etfData) && data.etfData?.date) {
    fetchEtfData(data.etfData.date).then(renderEtfData).catch(() => {});
  }
  renderNews(data.marketNews);
  renderMarketCommentary(data.marketCommentary);
  renderMarketDataStatus(data.marketDataStatus);
  applyTradingDayStatus(data.tradingDay || data.marketDataStatus?.tradingDay);
  applyAllDataStamps(data);
  $('#lastUpdateTime').textContent = new Date().toLocaleTimeString('zh-CN', { hour12: false });
  $('#dataModeLabel').textContent = '真实数据 / 最近缓存';
  loadAiSummary();
}

async function refreshMarketData() {
  document.body.classList.add('data-loading');
  try {
    const status = await BondDashboardApi.getJson('/api/market-data-status');
    renderMarketDataStatus(status);
    applyTradingDayStatus(status.tradingDay);
    if (status.is_updating) {
      $('#dataModeLabel').textContent = '数据更新中，请稍后重试';
      return;
    }
    updateMarketUI(await fetchMarketData());
  } catch (error) {
    $('#dataModeLabel').textContent = `数据不可用：${error.message}`;
    renderMarketDataStatus({ source_health: {}, is_updating: false, unavailable: true });
  } finally {
    document.body.classList.remove('data-loading');
  }
}

function markRateAnomaly(node, change) {
  if (!node) return;
  node.classList.remove('rate-anomaly-up', 'rate-anomaly-down');
  const value = Number(change);
  if (!Number.isFinite(value) || Math.abs(value) <= 20) return;
  node.classList.add(value > 0 ? 'rate-anomaly-up' : 'rate-anomaly-down');
}

function renderVolatilityAlert(container, messages) {
  if (!container) return;
  let alert = container.querySelector('.volatility-alert');
  if (!messages.length) {
    alert?.remove();
    return;
  }
  if (!alert) {
    alert = document.createElement('div');
    alert.className = 'volatility-alert';
    (container.querySelector('.panel-heading,.metric-head') || container).after(alert);
  }
  alert.textContent = `⚠️ 注意：${messages.join('、')}，今日波动较大`;
}

function applyTradingDayStatus(status) {
  const banner = $('#holidayBanner');
  if (!banner) return;
  const isHoliday = status && status.isTradingDay === false;
  banner.hidden = !isHoliday;
  if (isHoliday) banner.textContent = `📅 今日非银行间交易日，以下为最近交易日（${status.latestTradingDay || '--'}）数据`;
}

function applyDataStamp(container, value) {
  if (!container) return;
  const target = container.querySelector('.panel-heading,.metric-head') || container;
  let stamp = target.querySelector('.data-stamp');
  if (!stamp) {
    stamp = document.createElement('span');
    stamp.className = 'data-stamp';
    target.appendChild(stamp);
  }
  const parsed = value ? new Date(value) : null;
  const valid = parsed && !Number.isNaN(parsed.getTime());
  stamp.textContent = `📅 数据时间：${valid ? parsed.toLocaleString('zh-CN', { year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', hour12:false }) : '--'}`;
  stamp.classList.toggle('stale', Boolean(valid && Date.now() - parsed.getTime() > 4 * 60 * 60 * 1000));
}

function applyAllDataStamps(data) {
  const sources = data.marketDataStatus?.sources || {};
  const stampValue = (payload, sourceKey) => payload?.updatedAt || sources[sourceKey]?.updatedAt || sources[sourceKey]?.fileUpdatedAt || data.updatedAt;
  $$('.metric-card').forEach(node => applyDataStamp(node, stampValue(data.chinabondYields, 'chinabond_yields')));
  applyDataStamp($('#curve'), stampValue(data.chinabondYields, 'chinabond_yields'));
  applyDataStamp($('#sentiment'), stampValue(data.bondTemperature, 'bond_temperature'));
  applyDataStamp($('#omoPanel'), data.omoUpdatedAt || data.updatedAt);
  applyDataStamp($('#fundingPanel'), stampValue(data.fundingRates, 'funding_rates'));
  applyDataStamp($('#news'), stampValue(data.marketNews, 'market_news'));
  applyDataStamp($('#primaryIssuance'), stampValue(data.primaryIssuance, 'primary_issuance'));
  applyDataStamp($('#etfData'), stampValue(data.etfData, 'etf_data'));
}

function renderMarketCommentary(payload) {
  const items = Array.isArray(payload) ? payload : (Array.isArray(payload?.daily) ? payload.daily : []);
  const item = items[0];
  const panel = $('#marketCommentary');
  if (!panel) return;
  panel.hidden = !item;
  if (!item) return;
  setOptionalText('#marketCommentaryDate', item.date || '--');
  setOptionalText('#marketCommentaryTitle', item.title || '市场点评');
  setOptionalText('#marketCommentarySummary', item.summary || '--');
}

function renderMarketDataStatus(status = {}) {
  const banner = $('#globalDataBanner');
  const indicator = $('.market-status');
  if (!banner) return;
  if (currentAccount?.role !== 'admin') {
    banner.hidden = true;
    indicator?.classList.remove('admin-alert');
    return;
  }
  const unhealthy = Object.entries(status.source_health || {}).filter(([, item]) => item.status !== 'healthy');
  indicator?.classList.toggle('admin-alert', Boolean(status.unavailable || unhealthy.length));
  if (status.is_updating) {
    banner.hidden = false;
    banner.className = 'global-data-banner updating';
    banner.textContent = `数据正在更新（${Object.keys(status.update_jobs || {}).join('、') || '后台任务'}），本页暂保留上一版缓存。`;
    return;
  }
  if (status.unavailable || unhealthy.length) {
    banner.hidden = false;
    banner.className = 'global-data-banner error';
    const labels = unhealthy.slice(0, 5).map(([name, item]) => `${name}：${item.message}`).join('；');
    banner.textContent = status.unavailable ? '无法读取数据服务，请检查本地后端是否已启动。' : `数据源健康提醒：${labels}${unhealthy.length > 5 ? `；另有 ${unhealthy.length - 5} 项` : ''}`;
    return;
  }
  banner.hidden = true;
}

function scheduleRefresh(runImmediately = true) {
  clearInterval(refreshTimer);
  if (runImmediately) refreshMarketData();
  if (settings.enabled) refreshTimer = setInterval(refreshMarketData, settings.interval * 1000);
}

function escapeHTML(value) {
  return String(value).replace(/[&<>'"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[char]);
}

function normalizeMarketNewsItems(payload) {
  if (payload && typeof payload === 'object') {
    const items = Array.isArray(payload.items) ? payload.items : [];
    return items.map((item, index) => ({
      id: item.id || item.date || `news-${index}`,
      category: item.category || '市场消息',
      title: item.title || '--',
      summary: item.summary || '',
      sourceName: item.sourceName || item.source_name || '公开来源',
      sourceUrl: item.sourceUrl || item.source_url || '',
      time: item.publishedAt || item.createdAt || item.date || new Date().toISOString(),
    })).filter(item => /^https?:\/\//i.test(item.sourceUrl));
  }
  return [];
}

function renderMarketNewsPage() {
  const pageState = MarketNewsUI.paginate(marketNewsItems, marketNewsPage, MARKET_NEWS_PAGE_SIZE);
  marketNewsPage = pageState.page;
  const list = $('#newsList');
  list.innerHTML = pageState.items.map(item => `
    <article class="news-item">
      <div class="news-meta"><span class="news-category">${escapeHTML(item.category)}</span><time>${new Date(item.time).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })}</time></div>
      <h4>${escapeHTML(item.title)}</h4><p>${escapeHTML(item.summary)}</p>
      <a class="news-source-link" href="${escapeHTML(item.sourceUrl)}" target="_blank" rel="noopener noreferrer">${escapeHTML(item.sourceName)} · 查看原文</a>
    </article>`).join('');
  $('#newsEmpty').hidden = pageState.totalItems > 0;
  $('#newsPagination').hidden = pageState.totalItems <= MARKET_NEWS_PAGE_SIZE;
  $('#newsPageSummary').textContent = `第 ${pageState.page} / ${pageState.totalPages} 页 · 共 ${pageState.totalItems} 条`;
  $('#newsPrev').disabled = pageState.page <= 1;
  $('#newsNext').disabled = pageState.page >= pageState.totalPages;
}

function renderNews(payload) {
  const sortedItems = normalizeMarketNewsItems(payload)
    .sort((a, b) => new Date(b.time) - new Date(a.time));
  const latestTime = Math.max(...sortedItems.map(item => new Date(item.time).getTime()).filter(Number.isFinite));
  const cutoff = new Date(Number.isFinite(latestTime) ? latestTime : Date.now());
  cutoff.setDate(cutoff.getDate() - 5);
  marketNewsItems = sortedItems
    .filter(item => {
      const time = new Date(item.time);
      return Number.isNaN(time.getTime()) || time >= cutoff;
    })
    .slice(0, 10);
  renderMarketNewsPage();
}

async function loadMarketNews() {
  if (!settings.endpoint) {
    renderNews({ items: [] });
    return;
  }
  try {
    renderNews(await BondDashboardApi.fetchMarketNews());
  } catch (error) {
    console.warn('Market news unavailable:', error);
    renderNews({ items: [] });
  }
}

$('#newsPrev')?.addEventListener('click', () => {
  marketNewsPage -= 1;
  renderMarketNewsPage();
});

$('#newsNext')?.addEventListener('click', () => {
  marketNewsPage += 1;
  renderMarketNewsPage();
});

$('#dataSettingsButton').addEventListener('click', () => {
  $('#autoRefreshEnabled').checked = settings.enabled;
  $('#apiEndpoint').value = settings.endpoint;
  $('#refreshInterval').value = String(settings.interval);
  $('#settingsDialog').showModal();
});
$('#saveSettingsButton').addEventListener('click', event => {
  event.preventDefault();
  settings = { enabled: $('#autoRefreshEnabled').checked, endpoint: $('#apiEndpoint').value.trim(), interval: Number($('#refreshInterval').value) };
  localStorage.setItem('bondPulseSettings', JSON.stringify(settings));
  $('#settingsDialog').close();
  scheduleRefresh(true);
});
$('#adminUsersButton')?.addEventListener('click', async () => {
  $('#adminUsersDialog')?.showModal();
  await loadAdminUsers();
});
$('#adminLogsButton')?.addEventListener('click', async () => {
  $('#adminLogsDialog')?.showModal();
  await loadAdminLogs();
});
$('#adminThemeButton')?.addEventListener('click', () => openAdminTheme());
$('#accountChip')?.addEventListener('click', () => {
  if (!currentAccount) return;
  setOptionalText('#profileUsername', currentAccount.username);
  setOptionalText('#profileRole', currentAccount.role === 'admin' ? '管理员' : '普通用户');
  setOptionalText('#profileEmail', currentAccount.email || '未填写');
  $('#changePasswordMessage').textContent = '';
  $('#accountProfileDialog')?.showModal();
});
$('#profileAdminUsersButton')?.addEventListener('click', async () => {
  $('#accountProfileDialog')?.close();
  $('#adminUsersDialog')?.showModal();
  await loadAdminUsers();
});
$('#profileAdminLogsButton')?.addEventListener('click', async () => {
  $('#accountProfileDialog')?.close();
  $('#adminLogsDialog')?.showModal();
  await loadAdminLogs();
});
$('#profileAdminThemeButton')?.addEventListener('click', () => {
  $('#accountProfileDialog')?.close();
  openAdminTheme();
});
$('#curveChartOpenTarget')?.addEventListener('click', () => {
  renderCurveZoom();
  $('#curveZoomDialog')?.showModal();
});
$('#curveChartOpenTarget')?.addEventListener('keydown', event => {
  if (event.key !== 'Enter' && event.key !== ' ') return;
  event.preventDefault();
  renderCurveZoom();
  $('#curveZoomDialog')?.showModal();
});
$$('.detail-open-button').forEach(button => button.addEventListener('click', () => {
  const dialog = document.getElementById(button.dataset.dialog);
  if (dialog?.showModal) dialog.showModal();
}));
$$('[data-close-dialog]').forEach(button => button.addEventListener('click', () => {
  document.getElementById(button.dataset.closeDialog)?.close();
}));

const sidebarCollapsed = localStorage.getItem('bondPulseSidebarCollapsed') === 'true';
if (sidebarCollapsed) {
  document.body.classList.add('sidebar-collapsed');
  $('#sidebarToggleButton')?.setAttribute('aria-pressed', 'true');
  $('#sidebarToggleButton')?.setAttribute('aria-label', '展开侧边栏');
}

$('#themeButton').addEventListener('click', () => document.body.classList.toggle('dark'));
$('#sidebarToggleButton')?.addEventListener('click', event => {
  event.stopPropagation();
  const collapsed = document.body.classList.toggle('sidebar-collapsed');
  localStorage.setItem('bondPulseSidebarCollapsed', String(collapsed));
  $('#sidebarToggleButton').setAttribute('aria-pressed', String(collapsed));
  $('#sidebarToggleButton').setAttribute('aria-label', collapsed ? '展开侧边栏' : '收起侧边栏');
});
$('#sidebar')?.addEventListener('click', event => {
  if (!document.body.classList.contains('sidebar-collapsed')) return;
  event.preventDefault();
  document.body.classList.remove('sidebar-collapsed');
  localStorage.setItem('bondPulseSidebarCollapsed', 'false');
  $('#sidebarToggleButton')?.setAttribute('aria-pressed', 'false');
  $('#sidebarToggleButton')?.setAttribute('aria-label', '收起侧边栏');
});
$('#menuButton').addEventListener('click', () => { const open = $('#sidebar').classList.toggle('open'); $('#mobileOverlay').classList.toggle('visible', open); $('#menuButton').setAttribute('aria-expanded', open); });
$('#mobileOverlay').addEventListener('click', () => { $('#sidebar').classList.remove('open'); $('#mobileOverlay').classList.remove('visible'); });
$$('.main-nav a').forEach(a => a.addEventListener('click', () => { $$('.main-nav a').forEach(x => x.classList.remove('active')); a.classList.add('active'); $('#sidebar').classList.remove('open'); $('#mobileOverlay').classList.remove('visible'); }));
$$('.segmented button').forEach(button => button.addEventListener('click', () => { $$('.segmented button').forEach(x => x.classList.remove('active')); button.classList.add('active'); }));
$$('.curve-switch button').forEach(button => button.addEventListener('click', () => {
  $$('.curve-switch button').forEach(item => item.classList.remove('active'));
  button.classList.add('active');
  selectedYieldCurve = button.dataset.curve || 'treasury';
  curveRangeStart = 0;
  curveRangeEnd = null;
  drawCurve();
}));
$('#curveTermMinSlider')?.addEventListener('input', event => {
  const maxValue = Number($('#curveTermMaxSlider')?.value ?? event.target.max) || 0;
  curveRangeStart = Math.min(Number(event.target.value) || 0, maxValue);
  event.target.value = String(curveRangeStart);
  drawCurve();
});
$('#curveTermMaxSlider')?.addEventListener('input', event => {
  const minValue = Number($('#curveTermMinSlider')?.value ?? 0) || 0;
  curveRangeEnd = Math.max(Number(event.target.value) || 0, minValue);
  event.target.value = String(curveRangeEnd);
  drawCurve();
});
$$('.omo-switch button').forEach(button => button.addEventListener('click', () => {
  $$('.omo-switch button').forEach(item => item.classList.remove('active'));
  button.classList.add('active');
  omoPeriod = button.dataset.period;
  if (omoPeriod === 'week' && omoMetric === 'future-net') {
    omoMetric = 'net';
    $('#omoMetricSelect').value = 'net';
  }
  renderOmoChart();
}));
$('#omoMetricSelect').addEventListener('change', event => {
  omoMetric = event.target.value;
  if (omoMetric === 'future-net') {
    omoPeriod = 'day';
    $$('.omo-switch button').forEach(item => item.classList.toggle('active', item.dataset.period === 'day'));
  }
  renderOmoChart();
});
$('#omoTransactionPrev')?.addEventListener('click', () => {
  omoTransactionPage -= 1;
  renderOmoTransactions();
});
$('#omoTransactionNext')?.addEventListener('click', () => {
  omoTransactionPage += 1;
  renderOmoTransactions();
});
$('#fundingRateDate').addEventListener('change', async event => {
  if (isWeekendDate(event.target.value)) {
    event.target.setCustomValidity('周六日不可选，请选择工作日。');
    event.target.reportValidity();
    $('#fundingRateMeta').textContent = '周六日不可选';
    event.target.value = event.target.dataset.lastBusinessDate || '';
    return;
  }
  event.target.setCustomValidity('');
  rememberFundingBusinessDate(event.target.value);
  $('#fundingRateMeta').textContent = '正在更新…';
  try {
    renderFundingRates(await fetchFundingRates(event.target.value));
  } catch (error) {
    $('#fundingRateMeta').textContent = `更新失败：${error.message}`;
  }
});
$('#interbankCdSelectDate')?.addEventListener('change', async event => {
  $('#interbankCdMeta').textContent = '正在更新...';
  try {
    renderInterbankCd(await fetchInterbankCd(event.target.value));
  } catch (error) {
    $('#interbankCdMeta').textContent = `更新失败：${error.message}`;
  }
});
$('#etfDataSelectDate')?.addEventListener('change', async event => {
  setOptionalText('#etfSourceName', '正在更新...');
  try {
    renderEtfData(await fetchEtfData(event.target.value));
  } catch (error) {
    setOptionalText('#etfSourceName', `更新失败：${error.message}`);
  }
});

$$('[data-auth-tab]').forEach(button => button.addEventListener('click', () => {
  const tab = button.dataset.authTab;
  $$('[data-auth-tab]').forEach(item => {
    const active = item.dataset.authTab === tab;
    item.classList.toggle('active', active);
    item.setAttribute('aria-selected', String(active));
  });
  $('#loginForm').hidden = tab !== 'login';
  $('#registerForm').hidden = tab !== 'register';
  $('#authTitle').textContent = tab === 'register' ? '创建普通用户账户' : '登录债市脉搏';
  setAuthMessage();
}));

function startCodeCountdown(button, seconds = 60) {
  let remaining = seconds;
  button.disabled = true;
  button.textContent = `${remaining} 秒后重发`;
  const timer = setInterval(() => {
    remaining -= 1;
    if (remaining <= 0) {
      clearInterval(timer);
      button.disabled = false;
      button.textContent = '获取验证码';
      return;
    }
    button.textContent = `${remaining} 秒后重发`;
  }, 1000);
}

async function sendEmailCode(button, email, purpose) {
  if (!email || !email.includes('@')) {
    setAuthMessage('请先输入正确的邮箱地址');
    return;
  }
  button.disabled = true;
  button.textContent = '正在发送…';
  try {
    const payload = await accountRequest('/api/auth/send-email-code', {
      method: 'POST',
      body: JSON.stringify({ email, purpose }),
    });
    setAuthMessage(payload.message, true);
    startCodeCountdown(button);
  } catch (error) {
    button.disabled = false;
    button.textContent = '获取验证码';
    setAuthMessage(error.message);
  }
}

$('#sendRegisterCodeButton')?.addEventListener('click', () => {
  sendEmailCode($('#sendRegisterCodeButton'), $('#registerEmail').value.trim(), 'register');
});

$('#loginForm')?.addEventListener('submit', async event => {
  event.preventDefault();
  setAuthMessage('正在登录…', true);
  try {
    const payload = await accountRequest('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: $('#loginEmail').value.trim(), password: $('#loginPassword').value }),
    });
    $('#loginForm').reset();
    applyAccount(payload.user);
  } catch (error) {
    setAuthMessage(error.message);
  }
});

$('#registerForm')?.addEventListener('submit', async event => {
  event.preventDefault();
  if ($('#registerPassword').value !== $('#registerPasswordConfirm').value) {
    setAuthMessage('两次输入的密码不一致');
    return;
  }
  setAuthMessage('正在创建账户…', true);
  try {
    const payload = await accountRequest('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({
        username: $('#registerUsername').value.trim(),
        email: $('#registerEmail').value.trim(),
        emailCode: $('#registerEmailCode').value.trim(),
        password: $('#registerPassword').value,
      }),
    });
    $('#registerForm').reset();
    applyAccount(payload.user);
  } catch (error) {
    setAuthMessage(error.message);
  }
});

$('#logoutButton')?.addEventListener('click', async () => {
  try { await accountRequest('/api/auth/logout', { method: 'POST' }); } catch (error) { /* Clear the local view even if the session already expired. */ }
  showAuthGate('已安全退出', true);
});

$('#changePasswordForm')?.addEventListener('submit', async event => {
  event.preventDefault();
  const message = $('#changePasswordMessage');
  message.className = 'form-message';
  if ($('#newPassword').value !== $('#newPasswordConfirm').value) {
    message.textContent = '两次输入的新密码不一致';
    return;
  }
  message.textContent = '正在保存…';
  try {
    await accountRequest('/api/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword: $('#currentPassword').value, newPassword: $('#newPassword').value }),
    });
    $('#changePasswordForm').reset();
    $('#accountProfileDialog')?.close();
    showAuthGate('密码已修改，请使用新密码重新登录');
  } catch (error) {
    message.textContent = error.message;
  }
});

$('#adminCreateUserForm')?.addEventListener('submit', async event => {
  event.preventDefault();
  const status = $('#adminUsersStatus');
  status.className = 'admin-users-status';
  status.textContent = '正在创建账户…';
  try {
    await accountRequest('/api/admin/users/create', {
      method: 'POST',
      body: JSON.stringify({
        username: $('#adminCreateUsername').value.trim(),
        email: $('#adminCreateEmail').value.trim(),
        password: $('#adminCreatePassword').value,
        role: $('#adminCreateRole').value,
      }),
    });
    $('#adminCreateUserForm').reset();
    await loadAdminUsers();
    status.textContent = '账户创建成功';
  } catch (error) {
    status.className = 'admin-users-status error';
    status.textContent = error.message;
  }
});

async function loadAdminUsers() {
  const status = $('#adminUsersStatus');
  const rows = $('#adminUsersRows');
  if (!status || !rows) return;
  status.className = 'admin-users-status';
  status.textContent = '正在加载账户…';
  try {
    const payload = await accountRequest('/api/admin/users');
    rows.innerHTML = payload.items.map(user => `
      <tr data-user-id="${user.id}">
        <td><strong>${escapeHTML(user.username)}</strong><small>${user.id === currentAccount?.id ? '当前账户' : `ID ${user.id}`}</small></td>
        <td>${escapeHTML(user.email || '--')}</td>
        <td><select class="role-select" data-user-role ${user.id === currentAccount?.id ? 'disabled' : ''}><option value="user" ${user.role === 'user' ? 'selected' : ''}>普通用户</option><option value="admin" ${user.role === 'admin' ? 'selected' : ''}>管理员</option></select></td>
        <td><span class="user-status ${user.isActive ? '' : 'disabled'}">${user.isActive ? '启用' : '停用'}</span></td>
        <td>${escapeHTML(user.lastLoginAt ? new Date(user.lastLoginAt).toLocaleString('zh-CN') : '从未登录')}</td>
        <td><div class="admin-user-actions"><button type="button" data-reset-user data-username="${escapeHTML(user.username)}">重置密码</button><button type="button" data-toggle-user ${user.id === currentAccount?.id ? 'disabled' : ''}>${user.isActive ? '停用' : '启用'}</button></div></td>
      </tr>
    `).join('') || '<tr><td colspan="6">暂无账户</td></tr>';
    status.textContent = `共 ${payload.items.length} 个账户`;
  } catch (error) {
    status.className = 'admin-users-status error';
    status.textContent = error.message;
  }
}

async function loadAdminLogs() {
  const status = $('#adminLogsStatus');
  const rows = $('#adminLogsRows');
  if (!status || !rows) return;
  status.className = 'admin-users-status';
  status.textContent = '正在加载日志…';
  try {
    const payload = await accountRequest('/api/admin/data-update-logs?limit=30');
    const statusLabels = { success: '完整', partial: '部分完整', failed: '失败', running: '运行中' };
    rows.innerHTML = payload.items.map(item => `
      <tr>
        <td><strong>${escapeHTML(new Date(item.startedAt).toLocaleString('zh-CN'))}</strong><small>${escapeHTML(item.requestId)}</small></td>
        <td>${escapeHTML(item.dataDate || '--')}</td>
        <td><span class="data-run-status ${escapeHTML(item.status)}">${escapeHTML(statusLabels[item.status] || item.status)}</span></td>
        <td><div class="completeness-cell"><b>${item.completeness}%</b><span><i style="width:${item.completeness}%"></i></span><small>${item.completeCount}/${item.knownCount} 个已知模块</small></div></td>
        <td>${escapeHTML(item.modules.filter(module => module.status === 'incomplete').map(module => module.name).join('、') || '--')}</td>
        <td>${escapeHTML(item.error || (item.errors && item.errors !== '-' ? item.errors : '--'))}</td>
      </tr>
    `).join('') || '<tr><td colspan="6">暂无日志</td></tr>';
    status.textContent = `最近 ${payload.items.length} 个更新日（每日仅显示最后一次）`;
  } catch (error) {
    status.className = 'admin-users-status error';
    status.textContent = error.message;
  }
}

$('#refreshAdminLogsButton')?.addEventListener('click', loadAdminLogs);

function applyColorScheme(scheme) {
  currentColorScheme = ['warm', 'forest', 'ocean', 'graphite'].includes(scheme) ? scheme : 'warm';
  document.body.dataset.colorScheme = currentColorScheme;
}

async function loadColorScheme() {
  try {
    const payload = await accountRequest('/api/settings/theme');
    applyColorScheme(payload.scheme);
  } catch (error) {
    applyColorScheme('warm');
  }
}

function openAdminTheme() {
  const input = $(`input[name="colorScheme"][value="${currentColorScheme}"]`);
  if (input) input.checked = true;
  $('#adminThemeMessage').className = 'form-message';
  $('#adminThemeMessage').textContent = '';
  $('#adminThemeDialog')?.showModal();
}

$('#adminThemeForm')?.addEventListener('submit', async event => {
  event.preventDefault();
  const message = $('#adminThemeMessage');
  const selected = $('input[name="colorScheme"]:checked')?.value;
  message.textContent = '正在保存…';
  try {
    const payload = await accountRequest('/api/settings/theme', {
      method: 'POST',
      body: JSON.stringify({ scheme: selected }),
    });
    applyColorScheme(payload.scheme);
    message.className = 'form-message success';
    message.textContent = payload.message;
    setTimeout(() => $('#adminThemeDialog')?.close(), 450);
  } catch (error) {
    message.className = 'form-message';
    message.textContent = error.message;
  }
});

async function updateAdminUser(userId, changes) {
  const status = $('#adminUsersStatus');
  status.className = 'admin-users-status';
  status.textContent = '正在保存…';
  try {
    await accountRequest('/api/admin/users/update', { method: 'POST', body: JSON.stringify({ userId, ...changes }) });
    await loadAdminUsers();
  } catch (error) {
    status.className = 'admin-users-status error';
    status.textContent = error.message;
    await loadAdminUsers();
  }
}

$('#adminUsersRows')?.addEventListener('change', event => {
  if (!event.target.matches('[data-user-role]')) return;
  const row = event.target.closest('[data-user-id]');
  updateAdminUser(Number(row.dataset.userId), { role: event.target.value });
});

$('#adminUsersRows')?.addEventListener('click', event => {
  const resetButton = event.target.closest('[data-reset-user]');
  if (resetButton) {
    const row = resetButton.closest('[data-user-id]');
    $('#resetPasswordUserId').value = row.dataset.userId;
    $('#resetPasswordUsername').textContent = resetButton.dataset.username;
    $('#resetPasswordMessage').textContent = '';
    $('#resetPasswordDialog')?.showModal();
    return;
  }
  const button = event.target.closest('[data-toggle-user]');
  if (!button) return;
  const row = button.closest('[data-user-id]');
  const enabled = !row.querySelector('.user-status').classList.contains('disabled');
  updateAdminUser(Number(row.dataset.userId), { isActive: !enabled });
});

$('#resetPasswordForm')?.addEventListener('submit', async event => {
  event.preventDefault();
  const message = $('#resetPasswordMessage');
  message.className = 'form-message';
  if ($('#resetPasswordValue').value !== $('#resetPasswordConfirm').value) {
    message.textContent = '两次输入的新密码不一致';
    return;
  }
  message.textContent = '正在重置…';
  try {
    await accountRequest('/api/admin/users/reset-password', {
      method: 'POST',
      body: JSON.stringify({ userId: Number($('#resetPasswordUserId').value), newPassword: $('#resetPasswordValue').value }),
    });
    $('#resetPasswordForm').reset();
    $('#resetPasswordDialog')?.close();
    const status = $('#adminUsersStatus');
    status.className = 'admin-users-status';
    status.textContent = '密码已重置，该账户需要重新登录';
  } catch (error) {
    message.textContent = error.message;
  }
});

function startDashboard() {
  drawSparklines();
  loadAiSummary();
  renderChinabondYields({});
  loadMarketNews();
  renderFundingRates({});
  renderInterbankCd({ items: [] });
  renderBondTemperature({});
  renderBondTempTrend();
  renderPrimaryIssuance({ items: [], summary: {} });
  renderEtfData({ items: [], summary: {} });
  renderOmoChart();
  renderOmoTransactions();
  renderBroadCentralBank([], {});
  scheduleRefresh(true);
}

checkCurrentAccount();
