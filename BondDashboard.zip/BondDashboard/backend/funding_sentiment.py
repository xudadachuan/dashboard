from __future__ import annotations

import json
from datetime import date, datetime
from pathlib import Path

from chinabond_ncd import query_ncd_valuation
from pboc_omo_crawler import query_omo_daily


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT.parent / "data"
OUTPUT_FILE = DATA_DIR / "funding_sentiment_index.json"
FUNDING_CACHE_FILE = DATA_DIR / "funding_rates_cache.json"
NCD_CACHE_FILE = DATA_DIR / "chinabond_ncd_valuation_cache.json"
OMO_PAYLOAD_FILE = DATA_DIR / "pboc_omo_payload.json"

BASELINE = 50.0
COMPONENTS = (
    ("DR007-7天逆回购", "dr007_omo7d", 0.35, "资金利率高于政策利率越多，资金面越紧。"),
    ("R007-DR007", "r007_dr007", 0.25, "非银融资成本相对存款类机构越高，结构性紧张越强。"),
    ("DR001-DR007", "dr001_dr007", 0.15, "隔夜资金相对7天资金上行，反映短端压力抬升。"),
    ("同业存单-DR007", "ncd_dr007", 0.12, "同业存单收益率偏高，反映银行负债端压力。"),
    ("央行投放/回笼差额", "net_injection", -0.002, "公开市场投放大于回笼时缓和资金紧张，回笼大于投放时推高紧张度。"),
)


def _load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def _number(value) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _label(value: float) -> str:
    if value >= 65:
        return "偏紧"
    if value <= 35:
        return "偏松"
    return "均衡"


def _latest_funding_rates() -> dict:
    cache = _load_json(FUNDING_CACHE_FILE, {})
    latest = cache.get("__latest__") if isinstance(cache, dict) else None
    return latest if isinstance(latest, dict) else {}


def _latest_omo_on_or_before(as_of: str) -> dict:
    payload = _load_json(OMO_PAYLOAD_FILE, {})
    rows = payload.get("omoDaily") if isinstance(payload, dict) else []
    eligible = [row for row in rows if isinstance(row, dict) and str(row.get("date") or "") <= as_of]
    if eligible:
        return max(eligible, key=lambda row: str(row.get("date")))
    try:
        rows = query_omo_daily(days=1, as_of=date.fromisoformat(as_of))
    except (OSError, ValueError):
        return {}
    return rows[-1] if rows else {}


def build_funding_sentiment(
    funding_rates: dict | None = None,
    ncd_valuation: dict | None = None,
    omo_row: dict | None = None,
    previous: dict | None = None,
    updated_at: str | None = None,
) -> dict:
    """Calculate the index from the latest compatible daily observations.

    The historical implementation used a neutral value of 50 and the fixed
    component weights below.  Keeping the calculation explicit makes daily
    results reproducible and avoids treating a missing source as a zero.
    """
    funding_rates = funding_rates or _latest_funding_rates()
    rate_date = str(funding_rates.get("date") or "")
    if not rate_date:
        raise ValueError("Funding-rate date is unavailable")
    ncd_valuation = ncd_valuation or _load_json(NCD_CACHE_FILE, {})
    omo_row = omo_row or _latest_omo_on_or_before(rate_date)
    metrics = funding_rates.get("metrics") or {}
    dr001 = _number((metrics.get("DR001") or {}).get("value"))
    dr007 = _number((metrics.get("DR007") or {}).get("value"))
    r007 = _number((metrics.get("R007") or {}).get("value"))
    omo7d = _number((metrics.get("OMO7D") or {}).get("value"))
    ncd3m = _number((ncd_valuation.get("termYields") or {}).get("3M"))
    net_injection = _number(omo_row.get("value"))
    if any(value is None for value in (dr001, dr007, r007, omo7d, ncd3m, net_injection)):
        raise ValueError("Funding-sentiment inputs are incomplete")

    raw_values = {
        "dr007_omo7d": (dr007 - omo7d) * 100,
        "r007_dr007": (r007 - dr007) * 100,
        "dr001_dr007": (dr001 - dr007) * 100,
        "ncd_dr007": (ncd3m - dr007) * 100,
        "net_injection": net_injection,
    }
    component_rows = []
    score = BASELINE
    for name, key, weight, description in COMPONENTS:
        raw_value = raw_values[key]
        impact = round(raw_value * weight, 2)
        score += impact
        component_rows.append({"name": name, "value": round(raw_value, 2), "impact": impact, "description": description})
    score = round(max(0, min(100, score)), 1)
    timestamp = updated_at or datetime.now().isoformat(timespec="seconds")
    history = list((previous or {}).get("history") or [])
    history = [item for item in history if item.get("date") != rate_date]
    history.append({"date": rate_date, "value": score, "label": _label(score), "updatedAt": timestamp})
    history = sorted(history, key=lambda item: str(item.get("date") or ""))[-750:]
    return {
        "date": rate_date,
        "value": score,
        "label": _label(score),
        "components": component_rows,
        "inputs": {
            "dr001": dr001,
            "dr007": dr007,
            "r007": r007,
            "omo7d": omo7d,
            "interbankCdYield": ncd3m,
            "netInjection": net_injection,
            "netInjectionDate": omo_row.get("date"),
            "fundingRateDate": rate_date,
            "interbankCdDate": ncd_valuation.get("date"),
        },
        "method": "以50为均衡，综合DR/R利率相对政策利率、非银溢价、隔夜压力、同业存单负债成本和央行投放/回笼差额计算；0-100递增表示资金面更紧。",
        "source": "calculated",
        "updatedAt": timestamp,
        "history": history,
    }


def save_funding_sentiment() -> dict:
    previous = _load_json(OUTPUT_FILE, {})
    payload = build_funding_sentiment(previous=previous)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload


def cached_funding_rate_payloads() -> list[dict]:
    """Return one funding-rate payload per actual data date from the cache."""
    cache = _load_json(FUNDING_CACHE_FILE, {})
    by_date: dict[str, dict] = {}
    for key, payload in (cache.items() if isinstance(cache, dict) else []):
        if not isinstance(payload, dict):
            continue
        data_date = str(payload.get("date") or key)
        if len(data_date) == 10 and data_date[:4].isdigit():
            by_date[data_date] = payload
    return [by_date[key] for key in sorted(by_date)]


def backfill_funding_sentiment() -> dict:
    """Backfill all cached funding-rate dates with same-day NCD valuations.

    A ChinaBond request may return a prior business day for a non-trading date.
    Such responses are intentionally not mixed into the requested date.
    """
    previous = _load_json(OUTPUT_FILE, {})
    completed: list[str] = []
    skipped: list[dict] = []
    for funding_rates in cached_funding_rate_payloads():
        rate_date = str(funding_rates.get("date") or "")
        omo_row = _latest_omo_on_or_before(rate_date)
        try:
            ncd_valuation = query_ncd_valuation(rate_date, refresh=True)
            if ncd_valuation.get("date") != rate_date:
                skipped.append({"date": rate_date, "reason": "NCD valuation unavailable for the same date"})
                continue
            previous = build_funding_sentiment(
                funding_rates=funding_rates,
                ncd_valuation=ncd_valuation,
                omo_row=omo_row,
                previous=previous,
            )
            completed.append(rate_date)
        except (OSError, ValueError, RuntimeError) as exc:
            skipped.append({"date": rate_date, "reason": str(exc)})
    if completed:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        OUTPUT_FILE.write_text(json.dumps(previous, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"completed": completed, "skipped": skipped, "payload": previous}


if __name__ == "__main__":
    print(json.dumps(save_funding_sentiment(), ensure_ascii=False, indent=2))
