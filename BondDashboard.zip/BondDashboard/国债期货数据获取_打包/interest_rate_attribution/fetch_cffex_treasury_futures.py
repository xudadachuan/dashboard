from __future__ import annotations

"""获取中金所官方国债期货日行情、可交割券和毛基差前两名。

示例：

    D:\\anaconda\\python.exe .\\interest_rate_attribution\\fetch_cffex_treasury_futures.py `
      --start 2026-08-01 `
      --end 2026-08-15 `
      --output-dir .\\interest_rate_attribution\\outputs\\cffex_futures_20260815

如果另外准备了现券价格 CSV（至少包含 ``trade_date,bond_code,clean_price``），
或传入已有因子归因输出目录，脚本会生成每日毛基差排名；没有现券价格时
仍保存官方行情和可交割映射，并将 CTD 排名标记为 ``DEFERRED``。
"""

import argparse
import json
from pathlib import Path
import sys

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parent
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from interest_rate_attribution.adapters.cffex import CFFEXClient, empty_daily, empty_deliverable_mapping
from interest_rate_attribution.adapters.ctd_inputs import (
    build_ctd_coverage_qc,
    load_factor_attribution_inputs,
    normalize_bond_prices,
)
from interest_rate_attribution.futures.ctd import build_gross_basis_candidates, rank_ctd_top2


def _write_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, encoding="utf-8-sig")


def _load_bond_prices(path: Path) -> pd.DataFrame:
    return normalize_bond_prices(pd.read_csv(path))


def run(
    start: str,
    end: str,
    output_dir: Path,
    base_url: str,
    refresh: bool,
    min_interval: float,
    bond_prices_path: Path | None,
    factor_attribution_dir: Path | None = None,
    cashflow_path: Path | None = None,
    funding_path: Path | None = None,
    risk_path: Path | None = None,
) -> int:
    output_dir.mkdir(parents=True, exist_ok=True)
    client = CFFEXClient(
        base_url=base_url,
        raw_cache_dir=output_dir / "raw",
        min_interval=min_interval,
    )
    summary: dict[str, object] = {
        "source": "CFFEX_OFFICIAL",
        "start": start,
        "end": end,
        "base_url": base_url,
        "products": ["TS", "TF", "T", "TL"],
        "refresh": refresh,
    }
    try:
        daily, daily_qc = client.fetch_daily_quotes(start, end, refresh=refresh)
        mapping, mapping_qc = client.fetch_deliverable_mapping(refresh=refresh)
    finally:
        client.close()

    _write_csv(daily if not daily.empty else empty_daily(), output_dir / "futures_daily_cffex.csv")
    _write_csv(mapping if not mapping.empty else empty_deliverable_mapping(), output_dir / "deliverable_bond_mapping_cffex.csv")

    qc = pd.concat([daily_qc, mapping_qc], ignore_index=True, sort=False)
    _write_csv(qc, output_dir / "cffex_acquisition_qc.csv")
    _write_csv(pd.DataFrame([record.as_dict() for record in client.records]), output_dir / "cffex_request_audit.csv")

    summary["daily_rows"] = len(daily)
    summary["daily_dates"] = int(daily["trade_date"].nunique()) if not daily.empty else 0
    summary["mapping_rows"] = len(mapping)
    summary["daily_status"] = "EXACT" if not daily.empty else "DEFERRED"
    summary["mapping_status"] = "EXACT" if not mapping.empty else "DEFERRED"

    bond_prices = pd.DataFrame()
    risk_analytics = pd.DataFrame()
    candidates = pd.DataFrame(
        columns=[
            "trade_date", "contract_code", "bond_code", "clean_price",
            "dirty_price", "settlement", "conversion_factor", "gross_basis",
            "price_type", "calculation_status",
        ]
    )
    price_source = ""
    if factor_attribution_dir is not None:
        bundle = load_factor_attribution_inputs(
            factor_attribution_dir,
            cashflow_path=cashflow_path,
            funding_path=funding_path,
            risk_path=risk_path,
        )
        bond_prices = bundle["bond_prices"]
        risk_analytics = bundle["risk_analytics"]
        price_source = str(bundle["price_path"])
    elif bond_prices_path is not None:
        bond_prices = _load_bond_prices(bond_prices_path)
        price_source = str(bond_prices_path)

    if bond_prices.empty:
        ctd_top2 = pd.DataFrame(
            columns=[
                "trade_date", "contract_code", "ctd_rank", "bond_code",
                "gross_basis", "net_basis", "irr", "dv01", "price_type",
                "selection_method", "duplicate_input_count", "calculation_status",
            ]
        )
        coverage = pd.DataFrame(
            columns=[
                "trade_date", "contract_code", "eligible_bond_count",
                "priced_bond_count", "price_coverage", "top2_available", "status",
            ]
        )
        summary["ctd_status"] = "DEFERRED"
        summary["ctd_message"] = "缺少现券净价/全价，官方 CFFEX 数据本身不包含现券价格"
    else:
        candidates = build_gross_basis_candidates(bond_prices, daily, mapping)
        if not risk_analytics.empty and not candidates.empty:
            risk_columns = [column for column in ("trade_date", "bond_code", "dv01") if column in risk_analytics.columns]
            if len(risk_columns) == 3:
                candidates = candidates.merge(
                    risk_analytics[risk_columns],
                    on=["trade_date", "bond_code"],
                    how="left",
                    validate="many_to_one",
                )
        ctd_top2 = rank_ctd_top2(candidates, rank_column="gross_basis")
        coverage = build_ctd_coverage_qc(candidates, mapping, daily) if not candidates.empty else pd.DataFrame()
        complete_groups = bool(not coverage.empty and coverage["top2_available"].all())
        summary["ctd_status"] = "ESTIMATED" if complete_groups else ("WARN" if not ctd_top2.empty else "DEFERRED")
        summary["ctd_message"] = (
            "按毛基差排名；尚未扣除票息、融资成本和交割日应计利息"
            if complete_groups
            else "现券价格覆盖不完整，已输出可用候选但未宣称全量 CTD 前两名"
        )
    summary["ctd_price_source"] = price_source
    summary["ctd_eligible_bond_count"] = int(mapping["bond_code"].nunique()) if not mapping.empty else 0
    summary["ctd_priced_bond_count"] = int(
        bond_prices.loc[bond_prices["bond_code"].isin(mapping["bond_code"]), "bond_code"].nunique()
        if not bond_prices.empty and not mapping.empty else 0
    )
    if not coverage.empty:
        summary["ctd_groups"] = len(coverage)
        summary["ctd_top2_groups"] = int(coverage["top2_available"].sum())
    else:
        summary["ctd_groups"] = 0
        summary["ctd_top2_groups"] = 0
    _write_csv(candidates, output_dir / "ctd_candidate_gross_basis.csv")
    _write_csv(coverage, output_dir / "ctd_coverage_qc.csv")
    _write_csv(ctd_top2, output_dir / "ctd_daily_top2.csv")

    summary["output_files"] = [
        "futures_daily_cffex.csv",
        "deliverable_bond_mapping_cffex.csv",
        "cffex_acquisition_qc.csv",
        "cffex_request_audit.csv",
        "ctd_candidate_gross_basis.csv",
        "ctd_coverage_qc.csv",
        "ctd_daily_top2.csv",
    ]
    (output_dir / "run_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, default=str), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2, default=str))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="获取中金所官方国债期货日行情和可交割券")
    parser.add_argument("--start", required=True, help="开始日期 YYYY-MM-DD")
    parser.add_argument("--end", required=True, help="结束日期 YYYY-MM-DD")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--base-url", default="http://www.cffex.com.cn")
    parser.add_argument("--refresh", action="store_true", help="忽略原始缓存重新抓取")
    parser.add_argument("--min-interval", type=float, default=0.25, help="请求间隔秒数")
    parser.add_argument("--bond-prices", type=Path, default=None, help="现券价格 CSV；至少含 trade_date,bond_code,clean_price")
    parser.add_argument(
        "--factor-attribution-dir",
        type=Path,
        default=None,
        help="已有因子归因输出目录；自动读取 position_daily/risk_analytics 等文件",
    )
    parser.add_argument("--cashflow-path", type=Path, default=None, help="可选：债券每百元现金流 CSV")
    parser.add_argument("--funding-path", type=Path, default=None, help="可选：资金利率 CSV")
    parser.add_argument("--risk-path", type=Path, default=None, help="可选：风险分析 CSV，至少含 trade_date,bond_code,dv01")
    args = parser.parse_args(argv)
    if pd.Timestamp(args.start) > pd.Timestamp(args.end):
        parser.error("--start 不能晚于 --end")
    if args.bond_prices is not None and args.factor_attribution_dir is not None:
        parser.error("--bond-prices 与 --factor-attribution-dir 二选一")
    return run(
        args.start,
        args.end,
        Path(args.output_dir),
        args.base_url,
        args.refresh,
        args.min_interval,
        args.bond_prices,
        args.factor_attribution_dir,
        args.cashflow_path,
        args.funding_path,
        args.risk_path,
    )


if __name__ == "__main__":
    raise SystemExit(main())
