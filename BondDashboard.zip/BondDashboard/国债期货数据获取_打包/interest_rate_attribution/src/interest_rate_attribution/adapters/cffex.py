from __future__ import annotations

"""中国金融期货交易所国债期货公开数据适配器。

官方页面 ``/cn/kjggzxx.html`` 由前端脚本动态请求数据，本模块直接复用
页面使用的 XML/CSV 端点，而不是解析展示页面。只访问中金所官方域名，
逐个交易日请求，带本地原始缓存、超时、重试和简单限速。

当前覆盖：
- 交易日历：``/sj/jyrl/YYYYMM/index_6782.xml``；
- 日行情：``/sj/hqsj/rtj/YYYYMM/DD/index.xml``；
- 可交割国债与转换因子：``/sj/jgsj/jgqsj/index_6882.csv``。

中金所可交割 CSV 不提供现券价格，因此本模块不在缺少现券价格时伪造
CTD；CTD 排名由 ``futures.ctd`` 在具备现券价格后完成。
"""

from dataclasses import dataclass, replace
from datetime import datetime
from io import StringIO
import hashlib
from pathlib import Path
import random
import time
from typing import Any, Callable, Iterable
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd
import requests


CFFEX_BASE_URL = "http://www.cffex.com.cn"
PRODUCTS = ("TS", "TF", "T", "TL")

CONTRACT_MASTER_COLUMNS = [
    "contract_code", "product_code", "instrument_id", "bond_code", "bond_code_ib",
    "bond_code_sh", "bond_code_sz", "bond_name", "maturity_date", "coupon_rate",
    "conversion_factor", "mapping_effective_from", "mapping_effective_to",
    "source", "source_url", "retrieved_at", "calculation_status",
]

DAILY_COLUMNS = [
    "trade_date", "contract_code", "product_code", "instrument_id", "open",
    "high", "low", "close", "pre_settlement", "settlement", "volume",
    "turnover", "open_interest", "pre_open_interest", "open_interest_change",
    "settlement_if", "price_type", "source", "source_url", "retrieved_at",
    "calculation_status",
]


class CFFEXHTTPError(RuntimeError):
    """官方端点不可用、返回错误页面或数据格式异常。"""


class CFFEXNotFound(CFFEXHTTPError):
    """中金所用 HTTP 200 返回的站内 404 页面。"""


@dataclass(frozen=True)
class CFFEXRequestRecord:
    endpoint: str
    url: str
    status: str
    http_status: int | None
    row_count: int
    cache_path: str
    message: str
    retrieved_at: str

    def as_dict(self) -> dict[str, object]:
        return {
            "endpoint": self.endpoint,
            "url": self.url,
            "status": self.status,
            "http_status": self.http_status,
            "row_count": self.row_count,
            "cache_path": self.cache_path,
            "message": self.message,
            "retrieved_at": self.retrieved_at,
        }


def _now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _tag_name(tag: str) -> str:
    return str(tag).rsplit("}", 1)[-1].lower()


def _text(node: ET.Element, name: str) -> str:
    for child in node.iter():
        if _tag_name(child.tag) == name.lower():
            return (child.text or "").strip()
    return ""


def _number(value: object) -> float:
    text = "" if value is None else str(value).strip()
    if not text or text.lower() in {"null", "nan", "--", "-"}:
        return float("nan")
    return float(text.replace(",", ""))


def _date8(value: object) -> str:
    text = "" if value is None else str(value).strip()
    if len(text) == 8 and text.isdigit():
        return f"{text[:4]}-{text[4:6]}-{text[6:]}"
    parsed = pd.to_datetime(text, errors="coerce")
    return "" if pd.isna(parsed) else parsed.strftime("%Y-%m-%d")


def _month_keys(start: str, end: str) -> list[str]:
    first = pd.Timestamp(start).to_period("M")
    last = pd.Timestamp(end).to_period("M")
    keys: list[str] = []
    current = first
    while current <= last:
        keys.append(str(current).replace("-", ""))
        current += 1
    return keys


def _safe_name(value: str) -> str:
    return "".join(ch if ch.isalnum() or ch in {".", "-", "_"} else "_" for ch in value)


def _decode_text(payload: bytes) -> str:
    """按官方文件实际编码解码，UTF-8 优先，GB18030 作为兼容回退。"""
    for encoding in ("utf-8-sig", "gb18030"):
        try:
            return payload.decode(encoding)
        except UnicodeDecodeError:
            continue
    return payload.decode("utf-8", errors="replace")


def _looks_like_cffex_error(payload: bytes) -> bool:
    text = _decode_text(payload)[:5000]
    return "网页错误" in text or "404_1.gif" in text or "您要查看的网页可能已被删除" in text


def parse_calendar_xml(payload: bytes) -> list[str]:
    root = ET.fromstring(payload)
    days: set[str] = set()
    for node in root.iter():
        if _tag_name(node.tag) != "doc":
            continue
        day = _text(node, "pubdate")
        parsed = pd.to_datetime(day, errors="coerce")
        if not pd.isna(parsed):
            days.add(parsed.strftime("%Y-%m-%d"))
    return sorted(days)


def parse_daily_xml(payload: bytes, products: Iterable[str] = PRODUCTS) -> pd.DataFrame:
    root = ET.fromstring(payload)
    allowed = {str(item).upper() for item in products}
    rows: list[dict[str, object]] = []
    for node in root.iter():
        if _tag_name(node.tag) != "dailydata":
            continue
        product = _text(node, "productid").upper()
        instrument = _text(node, "instrumentid").upper()
        if product not in allowed or not instrument:
            continue
        contract_code = instrument if instrument.endswith(".CFE") else f"{instrument}.CFE"
        settlement = _number(_text(node, "settlementprice"))
        settlement_if = _number(_text(node, "settlementpriceif"))
        used_proxy = pd.isna(settlement) and not pd.isna(settlement_if)
        if used_proxy:
            settlement = settlement_if
        pre_oi = _number(_text(node, "preopeninterest"))
        oi = _number(_text(node, "openinterest"))
        rows.append(
            {
                "trade_date": _date8(_text(node, "tradingday")),
                "contract_code": contract_code,
                "product_code": product,
                "instrument_id": instrument,
                "open": _number(_text(node, "openprice")),
                "high": _number(_text(node, "highestprice")),
                "low": _number(_text(node, "lowestprice")),
                "close": _number(_text(node, "closeprice")),
                "pre_settlement": _number(_text(node, "presettlementprice")),
                "settlement": settlement,
                "volume": _number(_text(node, "volume")),
                "turnover": _number(_text(node, "turnover")),
                "open_interest": oi,
                "pre_open_interest": pre_oi,
                "open_interest_change": oi - pre_oi if not pd.isna(oi) and not pd.isna(pre_oi) else np.nan,
                "settlement_if": settlement_if,
                "price_type": "SETTLEMENT_IF_PROXY" if used_proxy else "SETTLEMENT",
                "calculation_status": "ESTIMATED" if used_proxy else "EXACT",
            }
        )
    return pd.DataFrame(rows, columns=DAILY_COLUMNS[:17] + ["calculation_status"])


def parse_deliverable_csv(payload: bytes, retrieved_at: str | None = None) -> pd.DataFrame:
    text = _decode_text(payload)
    raw = pd.read_csv(
        StringIO(text),
        header=None,
        names=[
            "bond_name", "bond_code_ib", "bond_code_sh", "bond_code_sz",
            "maturity_date", "coupon_rate", "conversion_factor", "instrument_id",
            "product_code",
        ],
        dtype=str,
        keep_default_na=False,
    )
    raw = raw.replace({"": np.nan}).dropna(how="all")
    if not raw.empty and str(raw.iloc[0, 0]).strip() in {"国债全称", "bond_name"}:
        raw = raw.iloc[1:].copy()
    for col in ("bond_code_ib", "bond_code_sh", "bond_code_sz", "instrument_id", "product_code"):
        raw[col] = raw[col].astype(str).str.strip().str.upper()
    raw["product_code"] = raw["product_code"].str.upper()
    raw = raw[raw["product_code"].isin(PRODUCTS)].copy()
    raw["instrument_id"] = raw["instrument_id"].str.replace(r"\.CFE$", "", regex=True)
    raw["contract_code"] = raw["instrument_id"] + ".CFE"
    raw["bond_code"] = raw["bond_code_ib"].where(raw["bond_code_ib"].ne("NAN"), raw["bond_code_sh"])
    raw["bond_code"] = raw["bond_code"].astype(str).str.replace("nan", "", case=False) + ".IB"
    raw["maturity_date"] = raw["maturity_date"].map(_date8)
    raw["coupon_rate"] = pd.to_numeric(raw["coupon_rate"], errors="coerce")
    raw["conversion_factor"] = pd.to_numeric(raw["conversion_factor"], errors="coerce")
    retrieved = retrieved_at or _now()
    out = raw.assign(
        mapping_effective_from=retrieved[:10],
        mapping_effective_to="",
        source="CFFEX_OFFICIAL",
        source_url=f"{CFFEX_BASE_URL}/sj/jgsj/jgqsj/index_6882.csv",
        retrieved_at=retrieved,
        calculation_status="EXACT",
    )
    return out[CONTRACT_MASTER_COLUMNS].reset_index(drop=True)


class CFFEXClient:
    """带缓存、限速和错误页面识别的中金所 HTTP 客户端。"""

    def __init__(
        self,
        base_url: str = CFFEX_BASE_URL,
        raw_cache_dir: Path | str | None = None,
        session: Any | None = None,
        timeout: tuple[float, float] = (10.0, 30.0),
        retries: int = 3,
        min_interval: float = 0.25,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.raw_cache_dir = Path(raw_cache_dir) if raw_cache_dir is not None else None
        self.session = session or requests.Session()
        self.session.headers.update(
            {
                "User-Agent": "interest-rate-attribution/0.1 (+official-cffex-source)",
                "Accept": "application/xml,text/csv,text/plain,*/*;q=0.5",
                "Referer": f"{self.base_url}/cn/kjggzxx.html",
            }
        )
        self.timeout = timeout
        self.retries = max(1, int(retries))
        self.min_interval = max(0.0, float(min_interval))
        self.sleep = sleep
        self._last_request = 0.0
        self.records: list[CFFEXRequestRecord] = []

    def _cache_path(self, endpoint: str, key: str, suffix: str) -> Path | None:
        if self.raw_cache_dir is None:
            return None
        return self.raw_cache_dir / endpoint / f"{_safe_name(key)}{suffix}"

    def _annotate_last_record(self, endpoint: str, url: str, row_count: int, message: str = "") -> None:
        """将解析后的行数回填到最近一次请求审计记录。"""
        clean_url = url.split("?", 1)[0]
        for index in range(len(self.records) - 1, -1, -1):
            record = self.records[index]
            if record.endpoint == endpoint and record.url == clean_url:
                self.records[index] = replace(
                    record,
                    row_count=int(row_count),
                    message=message or record.message,
                )
                return

    def _get_bytes(
        self,
        endpoint: str,
        path: str,
        cache_key: str,
        suffix: str,
        refresh: bool = False,
    ) -> tuple[bytes, str, str]:
        cache_path = self._cache_path(endpoint, cache_key, suffix)
        if cache_path is not None and cache_path.exists() and not refresh:
            payload = cache_path.read_bytes()
            self.records.append(
                CFFEXRequestRecord(
                    endpoint=endpoint,
                    url=f"{self.base_url}{path}".split("?", 1)[0],
                    status="CACHE",
                    http_status=None,
                    row_count=0,
                    cache_path=str(cache_path),
                    message="",
                    retrieved_at=_now(),
                )
            )
            return payload, str(cache_path), "CACHE"
        url = f"{self.base_url}{path}"
        last_error = ""
        for attempt in range(self.retries):
            elapsed = time.monotonic() - self._last_request
            if elapsed < self.min_interval:
                self.sleep(self.min_interval - elapsed)
            try:
                response = self.session.get(url, timeout=self.timeout)
                self._last_request = time.monotonic()
                status_code = int(getattr(response, "status_code", 200))
                payload = bytes(getattr(response, "content", b""))
                if status_code in {429, 500, 502, 503, 504}:
                    raise CFFEXHTTPError(f"HTTP {status_code}")
                if status_code != 200:
                    raise CFFEXHTTPError(f"HTTP {status_code}")
                if _looks_like_cffex_error(payload):
                    raise CFFEXNotFound(f"official endpoint returned an error page: {url}")
                if cache_path is not None:
                    cache_path.parent.mkdir(parents=True, exist_ok=True)
                    cache_path.write_bytes(payload)
                self.records.append(
                    CFFEXRequestRecord(
                        endpoint=endpoint,
                        url=url.split("?", 1)[0],
                        status="FETCH",
                        http_status=status_code,
                        row_count=0,
                        cache_path=str(cache_path or ""),
                        message="",
                        retrieved_at=_now(),
                    )
                )
                return payload, str(cache_path or ""), "FETCH"
            except CFFEXNotFound:
                raise
            except Exception as exc:  # noqa: BLE001
                last_error = f"{type(exc).__name__}: {exc}"
                if attempt + 1 < self.retries:
                    self.sleep(min(8.0, 0.5 * (2**attempt) + random.random() * 0.2))
        raise CFFEXHTTPError(last_error or f"request failed: {url}")

    def close(self) -> None:
        close = getattr(self.session, "close", None)
        if callable(close):
            close()

    def fetch_calendar(self, start: str, end: str, refresh: bool = False) -> tuple[list[str], pd.DataFrame]:
        days: set[str] = set()
        qc: list[dict[str, object]] = []
        for month in _month_keys(start, end):
            path = f"/sj/jyrl/{month}/index_6782.xml"
            try:
                payload, cache_path, mode = self._get_bytes("calendar", path, month, ".xml", refresh)
                parsed = parse_calendar_xml(payload)
                self._annotate_last_record("calendar", self.base_url + path, len(parsed))
                days.update(day for day in parsed if str(start) <= day <= str(end))
                qc.append({"endpoint": "calendar", "period": month, "status": "PASS", "row_count": len(parsed), "message": mode, "source_url": self.base_url + path, "cache_path": cache_path})
            except Exception as exc:  # noqa: BLE001
                qc.append({"endpoint": "calendar", "period": month, "status": "DEFERRED", "row_count": 0, "message": str(exc), "source_url": self.base_url + path, "cache_path": ""})
        return sorted(days), pd.DataFrame(qc)

    def fetch_daily_quotes(self, start: str, end: str, refresh: bool = False) -> tuple[pd.DataFrame, pd.DataFrame]:
        # ``index_6782.xml`` 是中金所页面的公告/日历展示数据，并不保证每个
        # 交易日都有一条记录。不能用它过滤行情日期；工作日逐日探测，遇到
        # 中金所返回的站内 404 页面时再判定为非交易日。
        _, calendar_qc = self.fetch_calendar(start, end, refresh=refresh)
        candidate_days = [
            stamp.strftime("%Y-%m-%d")
            for stamp in pd.date_range(start, end, freq="D")
            if stamp.weekday() < 5
        ]
        rows: list[pd.DataFrame] = []
        qc = calendar_qc.to_dict("records")
        for day in candidate_days:
            stamp = pd.Timestamp(day)
            ym = stamp.strftime("%Y%m")
            path = f"/sj/hqsj/rtj/{ym}/{stamp.strftime('%d')}/index.xml?id=1"
            try:
                payload, cache_path, mode = self._get_bytes("daily", path, day, ".xml", refresh)
                frame = parse_daily_xml(payload)
                self._annotate_last_record("daily", self.base_url + path, len(frame))
                if not frame.empty:
                    frame["source"] = "CFFEX_OFFICIAL"
                    frame["source_url"] = self.base_url + path.split("?", 1)[0]
                    frame["retrieved_at"] = _now()
                    rows.append(frame)
                qc.append({"endpoint": "daily", "period": day, "status": "PASS" if not frame.empty else "DEFERRED", "row_count": len(frame), "message": mode, "source_url": self.base_url + path.split("?", 1)[0], "cache_path": cache_path})
            except Exception as exc:  # noqa: BLE001
                qc.append({"endpoint": "daily", "period": day, "status": "DEFERRED", "row_count": 0, "message": str(exc), "source_url": self.base_url + path.split("?", 1)[0], "cache_path": ""})
        daily = pd.concat(rows, ignore_index=True) if rows else pd.DataFrame(columns=DAILY_COLUMNS)
        if not daily.empty:
            daily = daily.reindex(columns=DAILY_COLUMNS)
            daily = daily.sort_values(["trade_date", "product_code", "contract_code"]).drop_duplicates(["trade_date", "contract_code"], keep="last").reset_index(drop=True)
        return daily, pd.DataFrame(qc)

    def fetch_deliverable_mapping(self, refresh: bool = False) -> tuple[pd.DataFrame, pd.DataFrame]:
        path = "/sj/jgsj/jgqsj/index_6882.csv"
        try:
            payload, cache_path, mode = self._get_bytes("deliverable", path, "index_6882", ".csv", refresh)
            retrieved = _now()
            mapping = parse_deliverable_csv(payload, retrieved_at=retrieved)
            self._annotate_last_record("deliverable", self.base_url + path, len(mapping))
            dup = mapping.duplicated(["contract_code", "bond_code"], keep=False)
            conflicting = mapping.loc[dup].groupby(["contract_code", "bond_code"])["conversion_factor"].nunique()
            conflict_count = int((conflicting > 1).sum())
            qc = pd.DataFrame([{
                "endpoint": "deliverable",
                "period": retrieved[:10],
                "status": "FAIL" if conflict_count else ("PASS" if not mapping.empty else "DEFERRED"),
                "row_count": len(mapping),
                "message": f"{mode}; conflicting_keys={conflict_count}",
                "source_url": self.base_url + path,
                "cache_path": cache_path,
            }])
            return mapping, qc
        except Exception as exc:  # noqa: BLE001
            return pd.DataFrame(columns=CONTRACT_MASTER_COLUMNS), pd.DataFrame([{
                "endpoint": "deliverable", "period": _now()[:10], "status": "DEFERRED",
                "row_count": 0, "message": str(exc), "source_url": self.base_url + path, "cache_path": "",
            }])


def empty_daily() -> pd.DataFrame:
    return pd.DataFrame(columns=DAILY_COLUMNS)


def empty_deliverable_mapping() -> pd.DataFrame:
    return pd.DataFrame(columns=CONTRACT_MASTER_COLUMNS)
