from __future__ import annotations

"""将因子归因产物整理为 CTD 计算输入。

因子归因的 iFinD 输出以 ``valuation_date``/``bond_id`` 为主键，
中金所数据以 ``trade_date``/``bond_code`` 为主键。本模块只做字段
标准化和覆盖率检查，不在缺失债券价格时填充零值。
"""

from pathlib import Path

import numpy as np
import pandas as pd


def _first_existing(root: Path, names: tuple[str, ...]) -> Path | None:
    candidates: list[Path] = []
    for name in names:
        candidates.extend((root / name, root / "acquired" / name))
    return next((path for path in candidates if path.exists()), None)


def _canonical_bond_code(value: object) -> str:
    text = "" if value is None else str(value).strip().upper()
    if text in {"", "NAN", "NONE", "<NA>"}:
        return ""
    if text.endswith((".IB", ".SH", ".SZ")):
        return text
    return f"{text}.IB"


def _rename_aliases(frame: pd.DataFrame, aliases: dict[str, tuple[str, ...]]) -> pd.DataFrame:
    out = frame.copy()
    rename: dict[str, str] = {}
    for target, candidates in aliases.items():
        if target in out.columns:
            continue
        source = next((column for column in candidates if column in out.columns), None)
        if source is not None:
            rename[source] = target
    return out.rename(columns=rename)


def normalize_bond_prices(frame: pd.DataFrame) -> pd.DataFrame:
    """规范化现券日度净价/全价数据。"""
    out = _rename_aliases(
        frame,
        {
            "trade_date": ("valuation_date", "date", "time"),
            "bond_code": ("bond_id", "thscode", "ths_bond_code_bond"),
            "clean_price": ("ths_evaluate_net_price_cb_bond",),
            "dirty_price": ("ths_valuate_full_price_cb_bond",),
            "accrued_interest": ("ths_analysis_accrued_interest_bond",),
            "ytm": ("ths_ytm_bond",),
            "dv01": ("ths_base_point_value_bond",),
        },
    )
    required = {"trade_date", "bond_code", "clean_price"}
    missing = required - set(out.columns)
    if missing:
        raise ValueError(f"现券价格数据缺少列: {sorted(missing)}")
    out["trade_date"] = pd.to_datetime(out["trade_date"], errors="coerce").dt.normalize()
    out["bond_code"] = out["bond_code"].map(_canonical_bond_code)
    for column in ("clean_price", "dirty_price", "accrued_interest", "ytm", "dv01"):
        if column in out.columns:
            out[column] = pd.to_numeric(out[column], errors="coerce")
    if "price_type" not in out.columns:
        out["price_type"] = "VALUATION_PRICE"
    out["price_type"] = out["price_type"].fillna("VALUATION_PRICE").astype(str).str.upper()
    out = out.loc[
        out["trade_date"].notna()
        & out["bond_code"].ne("")
        & out["clean_price"].notna()
    ].copy()
    return out.drop_duplicates(["trade_date", "bond_code"], keep="last").reset_index(drop=True)


def normalize_risk_analytics(frame: pd.DataFrame) -> pd.DataFrame:
    """规范化债券 DV01/久期数据，供 CTD DV01 和覆盖率质检使用。"""
    out = _rename_aliases(
        frame,
        {
            "trade_date": ("valuation_date", "date", "time"),
            "bond_code": ("bond_id", "thscode", "ths_bond_code_bond"),
        },
    )
    required = {"trade_date", "bond_code"}
    missing = required - set(out.columns)
    if missing:
        raise ValueError(f"风险数据缺少列: {sorted(missing)}")
    out["trade_date"] = pd.to_datetime(out["trade_date"], errors="coerce").dt.normalize()
    out["bond_code"] = out["bond_code"].map(_canonical_bond_code)
    for column in ("dv01", "modified_duration", "convexity"):
        if column in out.columns:
            out[column] = pd.to_numeric(out[column], errors="coerce")
    return out.drop_duplicates(["trade_date", "bond_code"], keep="last").reset_index(drop=True)


def normalize_cashflows(frame: pd.DataFrame) -> pd.DataFrame:
    """统一现有 ``bond_cashflow_schedule_per_100`` 的字段名。"""
    out = _rename_aliases(
        frame,
        {
            "bond_code": ("bond_id", "thscode"),
            "cashflow_date": ("payment_date", "date"),
            "coupon_cashflow": ("coupon_per_100",),
            "principal_cashflow": ("principal_per_100",),
        },
    )
    required = {"bond_code", "cashflow_date", "coupon_cashflow", "principal_cashflow"}
    missing = required - set(out.columns)
    if missing:
        raise ValueError(f"现金流数据缺少列: {sorted(missing)}")
    out["bond_code"] = out["bond_code"].map(_canonical_bond_code)
    out["cashflow_date"] = pd.to_datetime(out["cashflow_date"], errors="coerce").dt.normalize()
    for column in ("coupon_cashflow", "principal_cashflow", "accrued_interest"):
        if column in out.columns:
            out[column] = pd.to_numeric(out[column], errors="coerce")
    return out.dropna(subset=["cashflow_date"]).reset_index(drop=True)


def load_factor_attribution_inputs(
    root: Path,
    cashflow_path: Path | None = None,
    funding_path: Path | None = None,
    risk_path: Path | None = None,
) -> dict[str, pd.DataFrame | str]:
    """读取因子归因目录中的现券、风险、现金流和资金利率文件。

    只要求现券价格文件存在；其余文件缺失时返回空表，交由上层按口径
    标记为 ``DEFERRED`` 或 ``ESTIMATED``。
    """
    root = Path(root)
    price_path = _first_existing(root, ("position_daily.csv", "bond_daily.csv", "ifind_raw_snapshot.csv"))
    if price_path is None:
        raise FileNotFoundError(f"未找到现券价格文件: {root}")
    prices = normalize_bond_prices(pd.read_csv(price_path))

    resolved_risk_path = risk_path or _first_existing(root, ("risk_analytics.csv", "ifind_raw_risk.csv"))
    risk = normalize_risk_analytics(pd.read_csv(resolved_risk_path)) if resolved_risk_path else pd.DataFrame()

    resolved_cashflow_path = cashflow_path or _first_existing(root, ("bond_cashflow_schedule_per_100.csv", "cashflow_schedule.csv", "cashflow_daily.csv"))
    cashflows = normalize_cashflows(pd.read_csv(resolved_cashflow_path)) if resolved_cashflow_path else pd.DataFrame()

    resolved_funding_path = funding_path or _first_existing(root, ("funding_market_fixing_daily.csv", "funding_market_daily.csv", "funding_factor_daily.csv"))
    funding = pd.read_csv(resolved_funding_path) if resolved_funding_path else pd.DataFrame()
    if not funding.empty:
        date_column = next((c for c in ("valuation_date", "trade_date", "date") if c in funding.columns), None)
        if date_column:
            funding = funding.rename(columns={date_column: "trade_date"})
            funding["trade_date"] = pd.to_datetime(funding["trade_date"], errors="coerce").dt.normalize()

    return {
        "bond_prices": prices,
        "risk_analytics": risk,
        "cashflows": cashflows,
        "funding": funding,
        "price_path": str(price_path),
        "risk_path": str(resolved_risk_path or ""),
        "cashflow_path": str(resolved_cashflow_path or ""),
        "funding_path": str(resolved_funding_path or ""),
    }


def build_ctd_coverage_qc(
    candidates: pd.DataFrame,
    mapping: pd.DataFrame,
    daily: pd.DataFrame,
) -> pd.DataFrame:
    """统计每个交易日/合约的可交割券、价格覆盖和前两名可用性。"""
    groups = daily[["trade_date", "contract_code"]].drop_duplicates().copy()
    groups["trade_date"] = pd.to_datetime(groups["trade_date"], errors="coerce").dt.normalize()
    eligible = mapping.groupby("contract_code")["bond_code"].nunique().rename("eligible_bond_count")
    candidate_frame = candidates.copy()
    candidate_frame["trade_date"] = pd.to_datetime(candidate_frame["trade_date"], errors="coerce").dt.normalize()
    priced = (
        candidate_frame.groupby(["trade_date", "contract_code"])["bond_code"]
        .nunique()
        .rename("priced_bond_count")
    )
    out = groups.merge(eligible, on="contract_code", how="left").merge(
        priced, on=["trade_date", "contract_code"], how="left"
    )
    out["eligible_bond_count"] = out["eligible_bond_count"].fillna(0).astype(int)
    out["priced_bond_count"] = out["priced_bond_count"].fillna(0).astype(int)
    out["price_coverage"] = np.where(
        out["eligible_bond_count"] > 0,
        out["priced_bond_count"] / out["eligible_bond_count"],
        np.nan,
    )
    out["top2_available"] = out["priced_bond_count"].ge(2)
    out["status"] = np.select(
        [out["priced_bond_count"].ge(2), out["priced_bond_count"].gt(0)],
        ["PASS", "WARN"],
        default="DEFERRED",
    )
    return out.sort_values(["trade_date", "contract_code"]).reset_index(drop=True)
