# 债市脉搏（Bond Dashboard）

债市脉搏是部署在 Windows 服务器上的债券市场数据看板。后端聚合各数据源、保存最近有效缓存并通过登录保护的 API 提供数据；前端按模块显示各自最新可用日期，因此单个数据源延迟或失败不会使整页空白。

## 功能与数据

- 收益率曲线、资金利率、同业存单、公开市场操作、债市温度、债券 ETF、市场消息、AI 摘要和一级发行。
- 账户注册、登录、管理员账户管理。
- 一级发行从 DM 终端 Excel 导入；ETF、利率和公开市场等数据按计划任务刷新。
- 数据源异常时保留该模块最近有效缓存；界面会继续显示其他模块的最新数据。

## 债市温度口径

债市温度是透明的 0–100 综合指标，不等同于涨跌预测或投资建议。页面“查看温度明细”会展示当日各组得分、权重和实时合成公式。

- 组间基础权重：利率水位 35%、资金面 30%、曲线与利差 20%、交易与拥挤度 15%。
- 利率、资金和曲线利差反映**市场环境**，得分会向中性值 50 收敛，避免仅因低收益率或低资金利率而把市场判定为过热。
- 交易与拥挤度是情绪确认项，成交、持仓和价格动量等数据完整时保留原始敏感度；整组缺失时按中性值 50 计入，不会放大其他三组。
- 组内仅用有效指标、按其原始权重比例重新归一；当日指标值为 0 时视为不可用，不用历史值补齐，也不参与当日计算。每组和总体仍须通过覆盖门槛。
- 展示温度对原始温度做平滑处理，因此“原始温度”和卡片展示值可能有小幅差异。

## 目录

```text
frontend/               页面（HTML、CSS、JavaScript）
backend/                API、认证、数据计算和更新任务
data/                   SQLite、缓存和 DM 一级发行输入/导出文件
logs/                   自动更新日志
deploy/windows/         Windows 服务、Caddy 和计划任务安装脚本
```

`data/`、`logs/` 和 `.env` 是运行状态。升级前请备份；不要提交真实 `.env`、账户、密码或 API Key。

## 访问与启动

后端只监听本机 `127.0.0.1:8765`，Caddy 负责对外 HTTP 访问。首次部署请以管理员 PowerShell 运行：

```powershell
Set-ExecutionPolicy -Scope Process Bypass
C:\BondDashboard\deploy\windows\install.ps1
```

本机健康检查：

```powershell
Invoke-RestMethod http://127.0.0.1:8765/api/health
```

浏览器页面更新未生效时使用 `Ctrl + F5` 强制刷新缓存。

## 自动更新

| 计划任务 | 时间（北京时间） | 内容 |
| --- | --- | --- |
| `BondDashboard_PBOC_OMO_Update` | 09:35 | 公开市场操作、央行工具、交易日历 |
| `BondDashboard_Market_Data_Update` | 17:00 | 资金利率、收益率、同业存单、温度、市场消息、一级发行 |
| `BondDashboard_AI_Summary_Update` | 18:01 | AI 摘要与每日市场点评 |
| `BondDashboard_ETF_Data_Update` | 21:00 | 债券 ETF 行情 |
| `BondDashboard_Backend`、`BondDashboard_Caddy` | 开机 | API 服务与反向代理 |

计划任务更新失败或上游数据尚未发布时，系统保留最近有效缓存。遗留超过 3 小时的“更新中”状态会自动清除，避免页面长期显示更新中。

国债期货自动更新优先运行 `python treasury_futures_cffex_fetch.py` 获取中金所官方日行情，再运行 `python treasury_futures_cffex_enrich.py` 获取官方可交割券和转换因子；官方端点连续不可用时才回退 `treasury_futures_eastmoney_fetch.py`。完整缺口见 [国债期货缺失数据清单.md](国债期货缺失数据清单.md)。

检查任务状态：

```powershell
Get-ScheduledTask -TaskName 'BondDashboard_*' | Select-Object TaskName, State
Get-ScheduledTaskInfo -TaskName BondDashboard_Market_Data_Update
```

## 一级发行（DM）

DM Excel 放入：

```text
C:\BondDashboard\data\primary_issuance_excel\input\
```

DM 日度 Excel 应覆盖**今天前 4 天至后 7 天**的招标窗口；首次建库和每日增量均按这一窗口合并。例如：

```text
一级发行-国债政金债发行 2026-08-13.xlsx
```

系统首次运行会自动执行 `baseline` 建库；以后 17:00 自动任务只选择文件内数据日期为当天的 Excel，按 `(债券代码, 招标日期)` 合并到 SQLite，按文件 SHA-256 去重，并将每次插入、更新、跳过、过滤和错误写入 `primary_issuance_merge_log` 及市场更新日志。最后输出招标日为前 4 天至后 7 天的数据。当天文件暂缺时保留最近有效数据日，并从已合并底库重建该窗口。

完整操作说明见 [DM_一级发行Excel下载说明.md](DM_一级发行Excel下载说明.md)。查询当前导入结果：

```powershell
Set-Location C:\BondDashboard\backend
python primary_issuance_merge.py --daily
python primary_issuance_merge.py --query
```

## 国债期货与移仓预警

国债期货板块位于 ETF 上方，覆盖 TS、TF、T、TL，展示官方开高低收、结算价、持仓变化、成交/持仓主力、连续 3 日稳定主力、新合约 5 日成交占比、T-N 市场移仓预警，并显示可交割券覆盖和 CTD 数据状态。

授权行情 CSV 放入 `data\treasury_futures\input\`，文件名使用 `treasury_futures_YYYY-MM-DD.csv`。至少包含：

```csv
date,product,contract,last_trading_date,trading_days_to_last,open,high,low,close,previous_close,settlement,settlement_if,volume,turnover,open_interest,pre_open_interest,open_interest_change,price_type,source,source_url,retrieved_at,calculation_status,ctd_code,conversion_factor,ctd_dirty_price,ctd_dv01,basis,irr
```

定时市场更新会自动抓取最近有效官方交易日并保留历史；当前仅提供只读市场移仓提醒。中金所公开数据不包含现券价格，因此 CTD、净基差、IRR 和账户调仓在数据未齐时明确显示为待补，不生成调仓手数或自动交易指令。详见 [国债期货缺失数据清单.md](国债期货缺失数据清单.md)。

```powershell
Set-Location C:\BondDashboard\backend
python treasury_futures_cffex_fetch.py
python treasury_futures_cffex_enrich.py
python treasury_futures.py
```

## 手动更新全部数据

完整的可复制 PowerShell 命令见 [全部数据手动更新命令.md](全部数据手动更新命令.md)。它会按顺序更新公开市场、市场数据与一级发行、ETF、AI 摘要及市场点评。

更新后可检查：

```powershell
Set-Location C:\BondDashboard\backend
python primary_issuance_merge.py --query
Invoke-RestMethod http://127.0.0.1:8765/api/health
Get-Content ..\logs\market_data_update_$(Get-Date -Format 'yyyy-MM-dd').log -Tail 80
```

## 配置与安全

主要变量见 `.env.example`：

- `BOND_DASHBOARD_HOST`、`BOND_DASHBOARD_PORT`：服务监听配置。
- `BOND_DASHBOARD_AUTH_DB_PATH`：账户数据库路径。
- `BOND_DASHBOARD_ADMIN_*`：首次启动管理员账户。
- `DEEPSEEK_API_KEY`：AI 摘要与点评（可选；不可用时保留已有内容或使用回退结果）。
- `IFIND_USERNAME`、`IFIND_PASSWORD`：iFinD ETF 数据源（可选；默认可回退至东方财富）。

受保护 API 必须登录后才能访问；前端不直接公开 `data/` 文件。云服务器仅对公网开放 HTTP/HTTPS，后端端口 `8765` 不应在安全组中对外开放。详细 Windows 环境与网络配置见 [WINDOWS_SERVER_ENVIRONMENT.md](WINDOWS_SERVER_ENVIRONMENT.md)。

## 故障排查

| 现象 | 处理 |
| --- | --- |
| 页面显示旧日期 | 先看每个面板自身日期；不同来源发布时间不同。若超过 5 天未更新，查看对应日志。 |
| 页面显示“更新中” | 正常更新期间保留数据；超过 3 小时会自动解除。也可重启后端后重新加载页面。 |
| 一级发行未更新 | 确认 DM 当日增量文件在 input 目录且内部数据日期正确，再运行 `python primary_issuance_merge.py --daily`；查看 `primary_issuance_merge_log` 和市场更新日志。 |
| ETF 更新失败 | 实时源不可用时会保留最近有效 ETF 缓存；查看 `logs\etf_data_update_*.log`。 |
| API 不可用 | 检查 `BondDashboard_Backend` 和 `BondDashboard_Caddy` 是否运行，再请求 `/api/health`。 |
