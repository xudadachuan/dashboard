from __future__ import annotations

import json
import os
import sqlite3
from datetime import date, datetime, time
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT.parent / "data"
DB_PATH = DATA_DIR / "bond_market.db"


def connect(db_path: Path = DB_PATH) -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("pragma journal_mode=wal")
    return conn


def ensure_market_data_schema(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS market_payload_snapshots (
            dataset TEXT NOT NULL,
            data_date TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            source TEXT,
            updated_at TEXT NOT NULL,
            PRIMARY KEY (dataset, data_date)
        )
        """
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_market_payload_dataset_date ON market_payload_snapshots(dataset, data_date)")
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS market_commentary_daily (
            commentary_date TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            summary TEXT NOT NULL,
            tone TEXT NOT NULL,
            risk_level TEXT NOT NULL,
            source TEXT NOT NULL,
            model TEXT,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS market_commentary_weekly (
            week_end_date TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            summary TEXT NOT NULL,
            tone TEXT NOT NULL,
            risk_level TEXT NOT NULL,
            source TEXT NOT NULL,
            model TEXT,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS market_news_daily (
            news_date TEXT NOT NULL,
            news_id TEXT NOT NULL,
            category TEXT NOT NULL,
            title TEXT NOT NULL,
            summary TEXT NOT NULL,
            source_name TEXT NOT NULL,
            source_url TEXT,
            published_at TEXT,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            PRIMARY KEY (news_date, news_id)
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS interbank_cd_daily (
            data_date TEXT PRIMARY KEY,
            payload_json TEXT NOT NULL,
            source TEXT,
            updated_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS interbank_cd_items (
            data_date TEXT NOT NULL,
            bond_code TEXT NOT NULL,
            issuer TEXT,
            issue_date TEXT,
            maturity_date TEXT,
            term TEXT,
            issue_price REAL,
            planned_amount_100m REAL,
            actual_amount_100m REAL,
            coupon_type TEXT,
            coupon_rate REAL,
            estimated_yield REAL,
            rating TEXT,
            segment TEXT,
            is_major_bank INTEGER,
            bond_defined_code TEXT,
            payload_json TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            PRIMARY KEY (data_date, bond_code)
        )
        """
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_interbank_cd_items_date ON interbank_cd_items(data_date)")
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS etf_daily (
            data_date TEXT PRIMARY KEY,
            payload_json TEXT NOT NULL,
            source TEXT,
            updated_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS etf_items (
            data_date TEXT NOT NULL,
            code TEXT NOT NULL,
            name TEXT,
            exchange TEXT,
            etf_type TEXT,
            price REAL,
            change_pct REAL,
            amount_100m REAL,
            market_value_100m REAL,
            nav REAL,
            premium_pct REAL,
            net_inflow_100m REAL,
            payload_json TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            PRIMARY KEY (data_date, code)
        )
        """
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_etf_items_date ON etf_items(data_date)")

    # DM 一级发行合并库。旧版本如曾使用同名暂存表，则保留为 legacy 表，
    # 再由一个月基线 Excel 重建规范化数据。
    primary_columns = {
        row["name"]
        for row in conn.execute("PRAGMA table_info(primary_issuance_items)").fetchall()
    }
    if primary_columns and not {"bond_code", "auction_date"}.issubset(primary_columns):
        conn.execute("DROP INDEX IF EXISTS idx_primary_issuance_items_date")
        conn.execute("DROP INDEX IF EXISTS idx_primary_issuance_items_auction")
        legacy_name = "primary_issuance_items_legacy_v1"
        legacy_exists = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", (legacy_name,)
        ).fetchone()
        if legacy_exists:
            conn.execute("DROP TABLE primary_issuance_items")
        else:
            conn.execute(f"ALTER TABLE primary_issuance_items RENAME TO {legacy_name}")
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS primary_issuance_items (
            bond_code TEXT NOT NULL,
            auction_date TEXT NOT NULL,
            bond_name TEXT, bond_type TEXT, auction_time TEXT, maturity TEXT,
            planned_amount_100m REAL, actual_amount_100m REAL,
            weighted_rate REAL, marginal_rate REAL, coupon_rate REAL,
            subscription_multiple REAL, marginal_multiple REAL,
            underwriting_fee_bp REAL, payment_date TEXT, listing_date TEXT,
            interest_start_date TEXT, fee REAL, data_date TEXT,
            source_file TEXT, source_hash TEXT, row_index INTEGER,
            payload_json TEXT NOT NULL, updated_at TEXT NOT NULL,
            PRIMARY KEY (bond_code, auction_date)
        )
        """
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_primary_issuance_items_date ON primary_issuance_items(data_date)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_primary_issuance_items_auction ON primary_issuance_items(auction_date)")
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS primary_issuance_daily (
            data_date TEXT PRIMARY KEY, payload_json TEXT NOT NULL,
            source TEXT, source_hash TEXT, updated_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS primary_issuance_merge_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT, run_at TEXT NOT NULL,
            mode TEXT NOT NULL, source_file TEXT, source_hash TEXT,
            window_start TEXT, window_end TEXT, rows_parsed INTEGER,
            rows_inserted INTEGER, rows_updated INTEGER, rows_skipped INTEGER,
            rows_filtered INTEGER, error TEXT
        )
        """
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_primary_issuance_merge_log_run ON primary_issuance_merge_log(run_at)")



def init_market_data_db() -> None:
    with connect() as conn:
        ensure_market_data_schema(conn)


def _json(payload: dict) -> str:
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def _is_future_date(value: str | None) -> bool:
    if not value:
        return False
    try:
        return date.fromisoformat(str(value)) > date.today()
    except ValueError:
        return False


def _is_official_write_date(value: str | None) -> bool:
    if os.environ.get("BOND_DASHBOARD_FORCE_WRITE") == "1":
        return bool(value) and not _is_future_date(value)
    if not value:
        return False
    try:
        parsed = date.fromisoformat(str(value))
    except ValueError:
        return False
    if parsed > date.today():
        return False
    if parsed == date.today() and datetime.now().hour < 17:
        return False
    return True


def _is_official_etf_write_date(value: str | None) -> bool:
    if os.environ.get("BOND_DASHBOARD_FORCE_WRITE") == "1":
        return bool(value) and not _is_future_date(value)
    if not value:
        return False
    try:
        parsed = date.fromisoformat(str(value))
    except ValueError:
        return False
    if parsed > date.today():
        return False
    if parsed == date.today() and datetime.now().time() < time(21, 5):
        return False
    return True


def save_interbank_cd_snapshot(payload: dict) -> None:
    data_date = payload.get("date")
    if not _is_official_write_date(str(data_date)):
        return
    updated_at = datetime.now().isoformat(timespec="seconds")
    with connect() as conn:
        ensure_market_data_schema(conn)
        conn.execute(
            """
            INSERT INTO interbank_cd_daily(data_date, payload_json, source, updated_at)
            VALUES(?, ?, ?, ?)
            ON CONFLICT(data_date) DO UPDATE SET
                payload_json=excluded.payload_json,
                source=excluded.source,
                updated_at=excluded.updated_at
            """,
            (data_date, _json(payload), payload.get("source"), updated_at),
        )
        for item in payload.get("items") or []:
            if not item.get("bondCode"):
                continue
            conn.execute(
                """
                INSERT INTO interbank_cd_items(
                    data_date, bond_code, issuer, issue_date, maturity_date, term,
                    issue_price, planned_amount_100m, actual_amount_100m,
                    coupon_type, coupon_rate, estimated_yield, rating, segment,
                    is_major_bank, bond_defined_code, payload_json, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(data_date, bond_code) DO UPDATE SET
                    issuer=excluded.issuer,
                    issue_date=excluded.issue_date,
                    maturity_date=excluded.maturity_date,
                    term=excluded.term,
                    issue_price=excluded.issue_price,
                    planned_amount_100m=excluded.planned_amount_100m,
                    actual_amount_100m=excluded.actual_amount_100m,
                    coupon_type=excluded.coupon_type,
                    coupon_rate=excluded.coupon_rate,
                    estimated_yield=excluded.estimated_yield,
                    rating=excluded.rating,
                    segment=excluded.segment,
                    is_major_bank=excluded.is_major_bank,
                    bond_defined_code=excluded.bond_defined_code,
                    payload_json=excluded.payload_json,
                    updated_at=excluded.updated_at
                """,
                (
                    data_date,
                    item.get("bondCode"),
                    item.get("issuer"),
                    item.get("issueDate"),
                    item.get("maturityDate"),
                    item.get("term"),
                    item.get("issuePrice"),
                    item.get("plannedAmount100m"),
                    item.get("actualAmount100m"),
                    item.get("couponType"),
                    item.get("couponRate"),
                    item.get("estimatedYield"),
                    item.get("rating"),
                    item.get("segment"),
                    1 if item.get("isMajorBank") else 0,
                    item.get("bondDefinedCode"),
                    _json(item),
                    updated_at,
                ),
            )


def save_payload_snapshot(dataset: str, payload: dict, data_date: str | None = None) -> None:
    date_value = data_date or payload.get("date")
    if not dataset or not _is_official_write_date(str(date_value)):
        return
    updated_at = datetime.now().isoformat(timespec="seconds")
    with connect() as conn:
        ensure_market_data_schema(conn)
        conn.execute(
            """
            INSERT INTO market_payload_snapshots(dataset, data_date, payload_json, source, updated_at)
            VALUES(?, ?, ?, ?, ?)
            ON CONFLICT(dataset, data_date) DO UPDATE SET
                payload_json=excluded.payload_json,
                source=excluded.source,
                updated_at=excluded.updated_at
            """,
            (dataset, date_value, _json(payload), payload.get("source"), updated_at),
        )


def payload_available_dates(dataset: str) -> list[str]:
    with connect() as conn:
        ensure_market_data_schema(conn)
        rows = conn.execute(
            """
            SELECT data_date
            FROM market_payload_snapshots
            WHERE dataset = ?
            ORDER BY data_date
            """,
            (dataset,),
        ).fetchall()
    return [row["data_date"] for row in rows]


def load_payload_snapshot(dataset: str, requested_date: str | None = None) -> dict | None:
    with connect() as conn:
        ensure_market_data_schema(conn)
        if requested_date:
            row = conn.execute(
                """
                SELECT payload_json
                FROM market_payload_snapshots
                WHERE dataset = ? AND data_date = ?
                """,
                (dataset, requested_date),
            ).fetchone()
            if row:
                payload = json.loads(row["payload_json"])
                payload["requestedDate"] = requested_date
                return payload
            row = conn.execute(
                """
                SELECT payload_json
                FROM market_payload_snapshots
                WHERE dataset = ? AND data_date <= ?
                ORDER BY data_date DESC
                LIMIT 1
                """,
                (dataset, requested_date),
            ).fetchone()
            if row:
                payload = json.loads(row["payload_json"])
                payload["requestedDate"] = requested_date
                payload["asOfFallback"] = True
                return payload
        row = conn.execute(
            """
            SELECT payload_json
            FROM market_payload_snapshots
            WHERE dataset = ?
            ORDER BY data_date DESC
            LIMIT 1
            """,
            (dataset,),
        ).fetchone()
        return json.loads(row["payload_json"]) if row else None


def save_daily_commentary(payload: dict, keep_days: int = 7) -> None:
    commentary_date = payload.get("date")
    if not _is_official_write_date(str(commentary_date)):
        return
    created_at = datetime.now().isoformat(timespec="seconds")
    with connect() as conn:
        ensure_market_data_schema(conn)
        conn.execute(
            """
            INSERT INTO market_commentary_daily(
                commentary_date, title, summary, tone, risk_level, source, model, payload_json, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(commentary_date) DO UPDATE SET
                title=excluded.title,
                summary=excluded.summary,
                tone=excluded.tone,
                risk_level=excluded.risk_level,
                source=excluded.source,
                model=excluded.model,
                payload_json=excluded.payload_json,
                created_at=excluded.created_at
            """,
            (
                commentary_date,
                payload.get("title") or payload.get("headline") or "收盘点评",
                payload.get("summary") or "",
                payload.get("tone") or "neutral",
                payload.get("risk_level") or "low",
                payload.get("source") or "fallback",
                payload.get("model"),
                _json(payload),
                created_at,
            ),
        )
        rows = conn.execute(
            """
            SELECT commentary_date
            FROM market_commentary_daily
            ORDER BY commentary_date DESC
            LIMIT -1 OFFSET ?
            """,
            (keep_days,),
        ).fetchall()
        if rows:
            conn.executemany(
                "DELETE FROM market_commentary_daily WHERE commentary_date = ?",
                [(row["commentary_date"],) for row in rows],
            )


def save_weekly_commentary(payload: dict) -> None:
    week_end_date = payload.get("weekEndDate") or payload.get("date")
    if not week_end_date:
        return
    created_at = datetime.now().isoformat(timespec="seconds")
    with connect() as conn:
        ensure_market_data_schema(conn)
        conn.execute(
            """
            INSERT INTO market_commentary_weekly(
                week_end_date, title, summary, tone, risk_level, source, model, payload_json, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(week_end_date) DO UPDATE SET
                title=excluded.title,
                summary=excluded.summary,
                tone=excluded.tone,
                risk_level=excluded.risk_level,
                source=excluded.source,
                model=excluded.model,
                payload_json=excluded.payload_json,
                created_at=excluded.created_at
            """,
            (
                week_end_date,
                payload.get("title") or "周度复盘",
                payload.get("summary") or "",
                payload.get("tone") or "neutral",
                payload.get("risk_level") or "low",
                payload.get("source") or "fallback",
                payload.get("model"),
                _json(payload),
                created_at,
            ),
        )


def load_market_commentary(limit: int = 7) -> dict:
    with connect() as conn:
        ensure_market_data_schema(conn)
        daily_rows = conn.execute(
            """
            SELECT payload_json
            FROM market_commentary_daily
            ORDER BY commentary_date DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        weekly_row = conn.execute(
            """
            SELECT payload_json
            FROM market_commentary_weekly
            ORDER BY week_end_date DESC
            LIMIT 1
            """
        ).fetchone()
    return {
        "daily": [json.loads(row["payload_json"]) for row in daily_rows],
        "weekly": json.loads(weekly_row["payload_json"]) if weekly_row else None,
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
    }


MAX_DAILY_MARKET_NEWS = 10
DISALLOWED_MARKET_NEWS_SOURCES = {
    "local_temperature",
    "local_tool_summary",
    "local_market_views",
}


def _is_valid_online_market_news(item: dict) -> bool:
    source_url = str(item.get("sourceUrl") or item.get("source_url") or "").strip().lower()
    source = str(item.get("source") or "").strip()
    text = f"{item.get('title') or ''} {item.get('summary') or ''}"
    is_treasury_issuance = any(term in text for term in ("国债", "特别国债")) and any(
        term in text for term in ("发行", "续发行", "招标")
    )
    return (
        source_url.startswith(("https://", "http://"))
        and source not in DISALLOWED_MARKET_NEWS_SOURCES
        and not is_treasury_issuance
    )


def purge_invalid_market_news(conn: sqlite3.Connection) -> int:
    rows = conn.execute(
        "SELECT news_date, news_id, payload_json FROM market_news_daily"
    ).fetchall()
    invalid_keys: list[tuple[str, str]] = []
    for row in rows:
        try:
            payload = json.loads(row["payload_json"])
        except (TypeError, json.JSONDecodeError):
            payload = {}
        if not _is_valid_online_market_news(payload):
            invalid_keys.append((row["news_date"], row["news_id"]))
    if invalid_keys:
        conn.executemany(
            "DELETE FROM market_news_daily WHERE news_date = ? AND news_id = ?",
            invalid_keys,
        )
    return len(invalid_keys)


def save_market_news(news_date: str, items: list[dict], keep_days: int = 5) -> None:
    if not _is_official_write_date(str(news_date)):
        return
    created_at = datetime.now().isoformat(timespec="seconds")
    with connect() as conn:
        ensure_market_data_schema(conn)
        purge_invalid_market_news(conn)
        conn.execute("DELETE FROM market_news_daily WHERE news_date = ?", (news_date,))
        valid_items = [item for item in items if _is_valid_online_market_news(item)]
        for index, item in enumerate(valid_items[:MAX_DAILY_MARKET_NEWS], start=1):
            news_id = item.get("id") or f"{news_date}-{index:02d}"
            payload = {**item, "id": news_id, "date": news_date}
            conn.execute(
                """
                INSERT INTO market_news_daily(
                    news_date, news_id, category, title, summary, source_name,
                    source_url, published_at, payload_json, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(news_date, news_id) DO UPDATE SET
                    category=excluded.category,
                    title=excluded.title,
                    summary=excluded.summary,
                    source_name=excluded.source_name,
                    source_url=excluded.source_url,
                    published_at=excluded.published_at,
                    payload_json=excluded.payload_json,
                    created_at=excluded.created_at
                """,
                (
                    news_date,
                    news_id,
                    payload.get("category") or "市场消息",
                    payload.get("title") or "--",
                    payload.get("summary") or "",
                    payload.get("sourceName") or payload.get("source_name") or "公开来源",
                    payload.get("sourceUrl") or payload.get("source_url"),
                    payload.get("publishedAt") or payload.get("published_at"),
                    _json(payload),
                    created_at,
                ),
            )
        rows = conn.execute(
            """
            SELECT DISTINCT news_date
            FROM market_news_daily
            ORDER BY news_date DESC
            LIMIT -1 OFFSET ?
            """,
            (keep_days,),
        ).fetchall()
        for row in rows:
            conn.execute("DELETE FROM market_news_daily WHERE news_date = ?", (row["news_date"],))


def load_market_news(limit: int = MAX_DAILY_MARKET_NEWS) -> dict:
    with connect() as conn:
        ensure_market_data_schema(conn)
        purge_invalid_market_news(conn)
        rows = conn.execute(
            """
            SELECT payload_json
            FROM market_news_daily
            ORDER BY news_date DESC, news_id ASC
            LIMIT ?
            """,
            (max(0, int(limit)),),
        ).fetchall()
    return {
        "items": [json.loads(row["payload_json"]) for row in rows],
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
    }


def save_etf_snapshot(payload: dict) -> None:
    data_date = payload.get("date")
    if not _is_official_etf_write_date(str(data_date)):
        return
    updated_at = datetime.now().isoformat(timespec="seconds")
    with connect() as conn:
        ensure_market_data_schema(conn)
        conn.execute(
            """
            INSERT INTO etf_daily(data_date, payload_json, source, updated_at)
            VALUES(?, ?, ?, ?)
            ON CONFLICT(data_date) DO UPDATE SET
                payload_json=excluded.payload_json,
                source=excluded.source,
                updated_at=excluded.updated_at
            """,
            (data_date, _json(payload), payload.get("source"), updated_at),
        )
        for item in payload.get("items") or []:
            if not item.get("code"):
                continue
            conn.execute(
                """
                INSERT INTO etf_items(
                    data_date, code, name, exchange, etf_type, price, change_pct,
                    amount_100m, market_value_100m, nav, premium_pct,
                    net_inflow_100m, payload_json, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(data_date, code) DO UPDATE SET
                    name=excluded.name,
                    exchange=excluded.exchange,
                    etf_type=excluded.etf_type,
                    price=excluded.price,
                    change_pct=excluded.change_pct,
                    amount_100m=excluded.amount_100m,
                    market_value_100m=excluded.market_value_100m,
                    nav=excluded.nav,
                    premium_pct=excluded.premium_pct,
                    net_inflow_100m=excluded.net_inflow_100m,
                    payload_json=excluded.payload_json,
                    updated_at=excluded.updated_at
                """,
                (
                    data_date,
                    item.get("code"),
                    item.get("name"),
                    item.get("exchange"),
                    item.get("type"),
                    item.get("price"),
                    item.get("changePct"),
                    item.get("amount100m"),
                    item.get("marketValue100m"),
                    item.get("nav"),
                    item.get("premiumPct"),
                    item.get("netInflow100m"),
                    _json(item),
                    updated_at,
                ),
            )


def available_dates(table: str) -> list[str]:
    if table not in {"interbank_cd_daily", "etf_daily"}:
        raise ValueError(f"unsupported table: {table}")
    with connect() as conn:
        ensure_market_data_schema(conn)
        rows = conn.execute(f"SELECT data_date FROM {table} ORDER BY data_date").fetchall()
    return [row["data_date"] for row in rows]


def load_snapshot(table: str, requested_date: str | None = None) -> dict | None:
    if table not in {"interbank_cd_daily", "etf_daily"}:
        raise ValueError(f"unsupported table: {table}")
    with connect() as conn:
        ensure_market_data_schema(conn)
        if requested_date:
            row = conn.execute(f"SELECT payload_json FROM {table} WHERE data_date = ?", (requested_date,)).fetchone()
            if row:
                payload = json.loads(row["payload_json"])
                payload["requestedDate"] = requested_date
                return payload
            row = conn.execute(
                f"SELECT data_date, payload_json FROM {table} WHERE data_date <= ? ORDER BY data_date DESC LIMIT 1",
                (requested_date,),
            ).fetchone()
            if row:
                payload = json.loads(row["payload_json"])
                payload["requestedDate"] = requested_date
                payload["asOfFallback"] = True
                return payload
        row = conn.execute(f"SELECT payload_json FROM {table} ORDER BY data_date DESC LIMIT 1").fetchone()
        return json.loads(row["payload_json"]) if row else None


def available_nonempty_dates(table: str) -> list[str]:
    """Return only snapshot dates whose payload still contains displayable rows."""
    if table not in {"interbank_cd_daily", "etf_daily", "primary_issuance_daily"}:
        raise ValueError(f"unsupported table: {table}")
    with connect() as conn:
        ensure_market_data_schema(conn)
        rows = conn.execute(
            f"SELECT data_date, payload_json FROM {table} ORDER BY data_date"
        ).fetchall()
    dates: list[str] = []
    for row in rows:
        try:
            payload = json.loads(row["payload_json"])
        except (TypeError, json.JSONDecodeError):
            continue
        if isinstance(payload.get("items"), list) and payload["items"]:
            dates.append(row["data_date"])
    return dates


def load_nonempty_snapshot(table: str, requested_date: str | None = None) -> dict | None:
    """Load the latest non-empty snapshot, optionally as-of a requested date."""
    if table not in {"interbank_cd_daily", "etf_daily", "primary_issuance_daily"}:
        raise ValueError(f"unsupported table: {table}")
    with connect() as conn:
        ensure_market_data_schema(conn)
        if requested_date:
            rows = conn.execute(
                f"SELECT data_date, payload_json FROM {table} WHERE data_date <= ? ORDER BY data_date DESC",
                (requested_date,),
            ).fetchall()
        else:
            rows = conn.execute(
                f"SELECT data_date, payload_json FROM {table} ORDER BY data_date DESC"
            ).fetchall()
    for row in rows:
        try:
            payload = json.loads(row["payload_json"])
        except (TypeError, json.JSONDecodeError):
            continue
        if not isinstance(payload.get("items"), list) or not payload["items"]:
            continue
        if requested_date:
            payload["requestedDate"] = requested_date
            if row["data_date"] != requested_date:
                payload["asOfFallback"] = True
        return payload
    return None


def save_primary_issuance_items(
    conn: sqlite3.Connection, items: list[dict], data_date: str,
    source_hash: str, source_file: str,
) -> tuple[int, int, int]:
    """Upsert DM rows by (bond code, auction date)."""
    now = datetime.now().isoformat(timespec="seconds")
    inserted = updated = filtered = 0
    for item in items:
        bond_code = item.get("bond_code")
        auction_date = item.get("auction_date")
        if not bond_code or not auction_date:
            filtered += 1
            continue
        exists = conn.execute(
            "SELECT 1 FROM primary_issuance_items WHERE bond_code = ? AND auction_date = ?",
            (bond_code, auction_date),
        ).fetchone()
        inserted += int(exists is None)
        updated += int(exists is not None)
        conn.execute(
            """
            INSERT INTO primary_issuance_items(
                bond_code, auction_date, bond_name, bond_type, auction_time,
                maturity, planned_amount_100m, actual_amount_100m,
                weighted_rate, marginal_rate, coupon_rate,
                subscription_multiple, marginal_multiple, underwriting_fee_bp,
                payment_date, listing_date, interest_start_date, fee, data_date,
                source_file, source_hash, row_index, payload_json, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(bond_code, auction_date) DO UPDATE SET
                bond_name=excluded.bond_name, bond_type=excluded.bond_type,
                auction_time=excluded.auction_time, maturity=excluded.maturity,
                planned_amount_100m=excluded.planned_amount_100m,
                actual_amount_100m=excluded.actual_amount_100m,
                weighted_rate=excluded.weighted_rate, marginal_rate=excluded.marginal_rate,
                coupon_rate=excluded.coupon_rate,
                subscription_multiple=excluded.subscription_multiple,
                marginal_multiple=excluded.marginal_multiple,
                underwriting_fee_bp=excluded.underwriting_fee_bp,
                payment_date=excluded.payment_date, listing_date=excluded.listing_date,
                interest_start_date=excluded.interest_start_date, fee=excluded.fee,
                data_date=excluded.data_date, source_file=excluded.source_file,
                source_hash=excluded.source_hash, row_index=excluded.row_index,
                payload_json=excluded.payload_json, updated_at=excluded.updated_at
            """,
            (
                bond_code, auction_date, item.get("bond_name"), item.get("bond_type"),
                item.get("auction_time"), item.get("maturity"),
                item.get("planned_amount_100m"), item.get("actual_amount_100m"),
                item.get("weighted_rate"), item.get("marginal_rate"), item.get("coupon_rate"),
                item.get("subscription_multiple"), item.get("marginal_multiple"),
                item.get("underwriting_fee_bp"), item.get("payment_date"),
                item.get("listing_date"), item.get("interest_start_date"), item.get("fee"),
                data_date, source_file, source_hash, item.get("row_index"), _json(item), now,
            ),
        )
    return inserted, updated, filtered


def load_primary_issuance_items(conn: sqlite3.Connection, window_start: str, window_end: str) -> list[dict]:
    rows = conn.execute(
        "SELECT payload_json FROM primary_issuance_items WHERE auction_date BETWEEN ? AND ? ORDER BY auction_date, bond_code",
        (window_start, window_end),
    ).fetchall()
    return [json.loads(row["payload_json"]) for row in rows]


def save_primary_issuance_daily(payload: dict) -> None:
    data_date = payload.get("date")
    if not data_date:
        return
    with connect() as conn:
        ensure_market_data_schema(conn)
        conn.execute(
            """INSERT INTO primary_issuance_daily(data_date, payload_json, source, source_hash, updated_at)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(data_date) DO UPDATE SET payload_json=excluded.payload_json,
               source=excluded.source, source_hash=excluded.source_hash, updated_at=excluded.updated_at""",
            (data_date, _json(payload), payload.get("source"), payload.get("sourceHash"),
             datetime.now().isoformat(timespec="seconds")),
        )


def load_primary_issuance_daily(data_date: str | None = None) -> dict | None:
    return load_nonempty_snapshot("primary_issuance_daily", data_date)


def primary_issuance_processed_hashes(conn: sqlite3.Connection) -> set[str]:
    rows = conn.execute(
        "SELECT DISTINCT source_hash FROM primary_issuance_merge_log WHERE error IS NULL AND source_hash IS NOT NULL"
    ).fetchall()
    return {row["source_hash"] for row in rows}


def primary_issuance_has_baseline(conn: sqlite3.Connection) -> bool:
    return conn.execute(
        "SELECT 1 FROM primary_issuance_merge_log "
        "WHERE mode = 'baseline' AND error IS NULL AND source_hash IS NOT NULL LIMIT 1"
    ).fetchone() is not None


def save_primary_issuance_merge_log(conn: sqlite3.Connection, entry: dict) -> None:
    conn.execute(
        """INSERT INTO primary_issuance_merge_log(
           run_at, mode, source_file, source_hash, window_start, window_end,
           rows_parsed, rows_inserted, rows_updated, rows_skipped, rows_filtered, error
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        tuple(entry.get(key) for key in (
            "run_at", "mode", "source_file", "source_hash", "window_start", "window_end",
            "rows_parsed", "rows_inserted", "rows_updated", "rows_skipped", "rows_filtered", "error",
        )),
    )


if __name__ == "__main__":
    init_market_data_db()
    print(json.dumps({"database": str(DB_PATH), "status": "ok"}, ensure_ascii=False))
