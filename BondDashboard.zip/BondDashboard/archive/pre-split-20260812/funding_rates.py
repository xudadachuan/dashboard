from __future__ import annotations

import json
import sqlite3
from datetime import date, datetime
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from market_database import load_payload_snapshot, payload_available_dates, save_payload_snapshot


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
DB_PATH = DATA_DIR / "bond_market.db"
CACHE_FILE = DATA_DIR / "funding_rates_cache.json"
CHINAMONEY_URL = "https://www.chinamoney.com.cn/ags/ms/cm-u-dlrp/PrDlyBltn"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BondDashboard/1.0"
NETWORK_TIMEOUT_SECONDS = 8
MEMORY_TTL_SECONDS = 600
_MEMORY_CACHE: dict[str, tuple[datetime, dict]] = {}


def load_cache() -> dict:
    if not CACHE_FILE.exists():
        return {}
    try:
        payload = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}
    return payload if isinstance(payload, dict) else {}


def save_cache(cache: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    CACHE_FILE.write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding="utf-8")


def parse_float(value) -> float | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text or text == "---":
        return None
    try:
        return float(text.replace(",", ""))
    except ValueError:
        return None


def post_chinamoney(index_type: str, search_date: str | None = None, lang: str = "cn") -> dict:
    body = {"lang": lang, "indexType": index_type}
    if search_date:
        body["searchDate"] = search_date
    data = urlencode(body).encode("utf-8")
    request = Request(
        CHINAMONEY_URL,
        data=data,
        headers={
            "User-Agent": USER_AGENT,
            "Referer": "https://www.chinamoney.com.cn/chinese/mtdexdaily/",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        },
        method="POST",
    )
    raw = urlopen(request, timeout=NETWORK_TIMEOUT_SECONDS).read()
    return json.loads(raw.decode("utf-8"))


def records_by_code(records: list[dict]) -> dict[str, dict]:
    return {str(item.get("instrmntCd", "")).upper(): item for item in records}


def latest_repo_rate(as_of: str | None = None, db_path: Path = DB_PATH) -> float | None:
    params: list[str] = []
    where = "WHERE rate IS NOT NULL"
    if as_of:
        where += " AND operation_date <= ?"
        params.append(as_of)
    with sqlite3.connect(db_path) as conn:
        row = conn.execute(
            f"""
            SELECT rate
            FROM omo_operations
            {where}
            ORDER BY operation_date DESC, id DESC
            LIMIT 1
            """,
            params,
        ).fetchone()
    return float(row[0]) if row and row[0] is not None else None


def extract_payload(market_payload: dict, dr_payload: dict, requested_date: str | None = None) -> dict:
    market_records = records_by_code(market_payload.get("records") or [])
    dr_records = records_by_code(dr_payload.get("records") or [])
    data = dr_payload.get("data") or market_payload.get("data") or {}
    actual_date = data.get("lastDate") or requested_date or date.today().isoformat()

    def metric(source: dict[str, dict], code: str) -> dict:
        row = source.get(code, {})
        return {
            "code": code,
            "value": parse_float(row.get("wghtdAvgRepoRate")),
            "close": parse_float(row.get("clsngRepoRate")),
            "volume": parse_float(row.get("trdVol")),
        }

    metrics = {
        "DR001": metric(dr_records, "DR001"),
        "DR007": metric(dr_records, "DR007"),
        "R007": metric(market_records, "R007"),
        "OMO7D": {
            "code": "OMO7D",
            "value": latest_repo_rate(actual_date),
            "close": None,
            "volume": None,
        },
    }

    return {
        "date": actual_date,
        "requestedDate": requested_date,
        "startDate": data.get("startDate"),
        "endDate": data.get("endDate"),
        "metrics": metrics,
        "source": "chinamoney",
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
    }


def has_required_rates(payload: dict) -> bool:
    metrics = payload.get("metrics") or {}
    return all((metrics.get(code) or {}).get("value") is not None for code in ("DR001", "DR007", "R007"))


def _numeric(value) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number


def _previous_available_date(dates: list[str], current_date: str | None) -> str | None:
    if not current_date:
        return None
    previous_dates = [value for value in dates if value < current_date]
    return previous_dates[-1] if previous_dates else None


def _with_previous_changes(payload: dict, previous_payload: dict | None) -> dict:
    metrics = {
        code: dict(metric)
        for code, metric in (payload.get("metrics") or {}).items()
    }
    previous_metrics = (previous_payload or {}).get("metrics") or {}
    for code, metric in metrics.items():
        current = _numeric(metric.get("value"))
        previous = _numeric((previous_metrics.get(code) or {}).get("value"))
        metric["changeBp"] = round((current - previous) * 100, 2) if current is not None and previous is not None else None
    return {**payload, "metrics": metrics}


def with_available_dates(payload: dict) -> dict:
    dates = payload_available_dates("funding_rates")
    current_date = str(payload.get("date") or "")
    previous_date = _previous_available_date(dates, current_date)
    previous_payload = load_payload_snapshot("funding_rates", previous_date) if previous_date else None
    enriched = _with_previous_changes(payload, previous_payload)
    if dates:
        return {**enriched, "availableDates": dates, "startDate": dates[0], "endDate": dates[-1]}
    return enriched


def fetch_funding_rates(search_date: str | None = None) -> dict:
    market_payload = post_chinamoney("markVOList", search_date=search_date, lang="cn")
    dr_payload = post_chinamoney("markInterBankVOList", search_date=search_date, lang="en")
    return extract_payload(market_payload, dr_payload, requested_date=search_date)


def query_funding_rates(search_date: str | None = None, refresh: bool = False) -> dict:
    if not refresh:
        stored = load_payload_snapshot("funding_rates", search_date)
        if stored:
            return with_available_dates(stored)

    memory_key = search_date or "__latest__"
    memory_hit = _MEMORY_CACHE.get(memory_key)
    if memory_hit:
        cached_at, payload = memory_hit
        if (datetime.now() - cached_at).total_seconds() < MEMORY_TTL_SECONDS:
            return with_available_dates(payload)

    cache = load_cache()
    cache_key = search_date or "__latest__"
    try:
        payload = fetch_funding_rates(search_date)
        if search_date and not has_required_rates(payload):
            latest_payload = fetch_funding_rates(None)
            if has_required_rates(latest_payload):
                payload = {
                    **latest_payload,
                    "requestedDate": search_date,
                    "asOfFallback": True,
                }
        if not has_required_rates(payload):
            raise RuntimeError(f"No funding-rate records for {search_date or 'latest'}")
        cache[cache_key] = payload
        if search_date:
            cache[payload["date"]] = payload
        else:
            cache["__latest__"] = payload
            cache[payload["date"]] = payload
        save_cache(cache)
        save_payload_snapshot("funding_rates", payload)
        _MEMORY_CACHE[memory_key] = (datetime.now(), payload)
        _MEMORY_CACHE[payload["date"]] = (datetime.now(), payload)
        return with_available_dates(payload)
    except Exception as exc:
        stored = load_payload_snapshot("funding_rates", search_date)
        if stored:
            payload = {**stored, "source": "cache", "error": str(exc)}
            _MEMORY_CACHE[memory_key] = (datetime.now(), payload)
            return with_available_dates(payload)
        fallback = cache.get(cache_key) or cache.get("__latest__")
        if fallback:
            payload = {**fallback, "source": "cache", "error": str(exc)}
            if has_required_rates(payload):
                save_payload_snapshot("funding_rates", payload)
            _MEMORY_CACHE[memory_key] = (datetime.now(), payload)
            return with_available_dates(payload)
        payload = {
            "date": search_date or date.today().isoformat(),
            "requestedDate": search_date,
            "startDate": None,
            "endDate": None,
            "metrics": {
                "DR001": {"code": "DR001", "value": None, "close": None, "volume": None},
                "DR007": {"code": "DR007", "value": None, "close": None, "volume": None},
                "R007": {"code": "R007", "value": None, "close": None, "volume": None},
                "OMO7D": {"code": "OMO7D", "value": latest_repo_rate(search_date), "close": None, "volume": None},
            },
            "source": "unavailable",
            "error": str(exc),
            "updatedAt": datetime.now().isoformat(timespec="seconds"),
        }
        _MEMORY_CACHE[memory_key] = (datetime.now(), payload)
        return with_available_dates(payload)
