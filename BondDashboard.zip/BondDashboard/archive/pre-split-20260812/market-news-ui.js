(function initMarketNewsUI(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.MarketNewsUI = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function createMarketNewsUI() {
  function paginate(items, requestedPage = 1, pageSize = 3) {
    const source = Array.isArray(items) ? items : [];
    const size = Math.max(1, Number(pageSize) || 3);
    const totalItems = source.length;
    const totalPages = Math.max(1, Math.ceil(totalItems / size));
    const page = Math.min(Math.max(1, Number(requestedPage) || 1), totalPages);
    const start = (page - 1) * size;
    return {
      items: source.slice(start, start + size),
      page,
      totalPages,
      totalItems,
    };
  }

  return { paginate };
});
