from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / "backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

import bond_temperature as bt  # noqa: E402


HERE = Path(__file__).resolve().parent
INPUT = HERE / "raw" / "chinabond_daily_2025_present.csv"
OUTPUT = HERE / "output"
FIELD_MAP = {
    "ytm_tbond_10y": "treasury_10y",
    "ytm_tbond_30y": "treasury_30y",
    "ytm_cdb_10y": "cdb_10y",
    "spread_10y_1y": "spread_10y_1y_bp",
    "spread_30y_10y": "spread_30y_10y_bp",
    "spread_cdb10y_tbond10y": "spread_cdb10y_treasury10y_bp",
}


def correlation(left: pd.Series, right: pd.Series) -> float | None:
    pair = pd.concat([left, right], axis=1).dropna()
    if len(pair) < 10:
        return None
    value = pair.corr().iloc[0, 1]
    return round(float(value), 4) if np.isfinite(value) else None


def score_frame(frame: pd.DataFrame) -> pd.DataFrame:
    output = frame.copy()
    histories = {key: [] for key in FIELD_MAP}
    prior_smoothed = None
    rows = []
    for _, source in output.iterrows():
        scores = {}
        for key, column in FIELD_MAP.items():
            value = float(source[column])
            scores[key] = bt.indicator_score(key, value, histories[key])
            histories[key].append(value)
        groups = bt.aggregate_group_scores(scores)
        # This is the production formula's rate and curve component, normalized
        # over those two groups. It is a diagnostic sub-index, not the full
        # temperature because the 65% total-coverage gate is not met.
        diagnostic_raw = (
            groups["rate_temp"] * bt.GROUP_WEIGHTS["rate_temp"]
            + groups["curve_temp"] * bt.GROUP_WEIGHTS["curve_temp"]
        ) / (bt.GROUP_WEIGHTS["rate_temp"] + bt.GROUP_WEIGHTS["curve_temp"])
        diagnostic_smoothed = (
            diagnostic_raw
            if prior_smoothed is None
            else diagnostic_raw * bt.SMOOTHING_ALPHA + prior_smoothed * (1 - bt.SMOOTHING_ALPHA)
        )
        prior_smoothed = diagnostic_smoothed
        rows.append(
            {
                **source.to_dict(),
                **scores,
                **groups,
                "yield_curve_temperature": round(diagnostic_smoothed, 4),
                "yield_curve_temperature_raw": round(diagnostic_raw, 4),
                "inverse_10y": -float(source["treasury_10y"]),
            }
        )
    return pd.DataFrame(rows)


def horizon_metrics(frame: pd.DataFrame, horizon: int) -> dict:
    future = (frame["treasury_10y"].shift(-horizon) - frame["treasury_10y"]) * 100
    pair = pd.DataFrame({"score": frame["yield_curve_temperature"], "future_bp": future}).dropna()
    low = pair["score"].quantile(0.25)
    high = pair["score"].quantile(0.75)
    bottom = pair.loc[pair["score"] <= low, "future_bp"]
    top = pair.loc[pair["score"] >= high, "future_bp"]
    predictors = [
        "yield_curve_temperature",
        "yield_curve_temperature_raw",
        "rate_temp",
        "curve_temp",
        "inverse_10y",
    ]
    return {
        "observations": int(len(pair)),
        "predictor_correlations": {
            predictor: correlation(frame[predictor], future)
            for predictor in predictors
        },
        "bottom_quartile_future_bp": round(float(bottom.mean()), 3),
        "top_quartile_future_bp": round(float(top.mean()), 3),
        "top_minus_bottom_bp": round(float(top.mean() - bottom.mean()), 3),
        "bottom_quartile_yield_fall_hit_rate": round(float((bottom < 0).mean()), 4),
        "top_quartile_yield_rise_hit_rate": round(float((top > 0).mean()), 4),
    }


def evaluate(frame: pd.DataFrame) -> dict:
    result = {
        "scope": "Official daily ChinaBond rate/curve diagnostic sub-index; not full market temperature.",
        "observations": int(len(frame)),
        "start_date": frame["date"].iloc[0],
        "end_date": frame["date"].iloc[-1],
        "production_coverage_weight": round(bt.GROUP_WEIGHTS["rate_temp"] + bt.GROUP_WEIGHTS["curve_temp"], 2),
        "required_coverage_weight": bt.MIN_TOTAL_COVERAGE,
        "full_temperature_available": False,
        "contemporaneous_change_correlation": correlation(
            frame["yield_curve_temperature"].diff(), frame["treasury_10y"].diff()
        ),
        "full_sample": {},
        "by_year": {},
    }
    for horizon in (1, 5, 10, 20):
        result["full_sample"][str(horizon)] = horizon_metrics(frame, horizon)
    for year, subset in frame.groupby(pd.to_datetime(frame["date"]).dt.year):
        result["by_year"][str(year)] = {
            str(horizon): horizon_metrics(subset.reset_index(drop=True), horizon)
            for horizon in (1, 5, 10, 20)
        }
    return result


def plot(frame: pd.DataFrame, path: Path) -> None:
    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    dates = pd.to_datetime(frame["date"])
    fig, score_axis = plt.subplots(figsize=(13.2, 6.8), dpi=160)
    score_axis.plot(dates, frame["yield_curve_temperature"], color="#c8523b", linewidth=1.8, label="利率/曲线温度子指数")
    score_axis.set_ylabel("子指数（0–100）")
    score_axis.grid(axis="y", color="#d8dde3", linewidth=0.7)
    yield_axis = score_axis.twinx()
    yield_axis.plot(dates, frame["treasury_10y"], color="#1f5a75", linewidth=1.6, label="10年国债收益率")
    yield_axis.set_ylabel("10年国债收益率（%）")
    yield_axis.invert_yaxis()
    handles1, labels1 = score_axis.get_legend_handles_labels()
    handles2, labels2 = yield_axis.get_legend_handles_labels()
    score_axis.legend(handles1 + handles2, labels1 + labels2, loc="upper left", frameon=False)
    score_axis.set_title("2025年以来：生产公式利率/曲线子指数与10年国债收益率", loc="left", fontsize=14, fontweight="bold")
    score_axis.set_xlabel("日期")
    fig.tight_layout()
    fig.savefig(path, facecolor="white", bbox_inches="tight")
    plt.close(fig)


def main() -> int:
    frame = pd.read_csv(INPUT, encoding="utf-8-sig").sort_values("date").drop_duplicates("date").reset_index(drop=True)
    scored = score_frame(frame)
    metrics = evaluate(scored)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    scored.to_csv(OUTPUT / "chinabond_daily_scored.csv", index=False, encoding="utf-8-sig")
    (OUTPUT / "chinabond_daily_metrics.json").write_text(
        json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    plot(scored, OUTPUT / "chinabond_daily_temperature_vs_10y.png")
    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
