from __future__ import annotations

import json
import ssl
from datetime import date, datetime, timedelta
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from market_database import save_payload_snapshot


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT.parent / "data"
CACHE_FILE = DATA_DIR / "chinabond_ncd_valuation_cache.json"
SEARCH_URL = "https://yield.chinabond.com.cn/cbweb-mn/yc/searchYc"
REFERER = "https://yield.chinabond.com.cn/cbweb-mn/"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BondDashboard/1.0"
NETWORK_TIMEOUT_SECONDS = 10
MEMORY_TTL_SECONDS = 600

NCD_AAA_ID = "8308218D1D030E0DE0540010E03EE6DA"
NCD_AAA_NAME = "\u4e2d\u503a\u5546\u4e1a\u94f6\u884c\u540c\u4e1a\u5b58\u5355\u6536\u76ca\u7387\u66f2\u7ebf(AAA)(\u5230\u671f)"
TERM_POINTS = {
    "1M": 1 / 12,
    "3M": 0.25,
    "6M": 0.5,
    "9M": 0.75,
    "1Y": 1.0,
}
_MEMORY_CACHE: tuple[datetime, dict] | None = None


def load_cache() -> dict:
    if not CACHE_FILE.exists():
        return {}
    try:
        payload = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}
    return payload if isinstance(payload, dict) else {}


def save_cache(payload: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    CACHE_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def nearest_value(series: list[list[float]], years: float) -> float | None:
    if not series:
        return None
    best = min(series, key=lambda point: abs(float(point[0]) - years))
    if abs(float(best[0]) - years) > 0.03:
        return None
    return round(float(best[1]), 4)


def normalize_ncd_curve(row: dict) -> dict:
    series = row.get("seriesData") or []
    term_yields = {
        term: nearest_value(series, years)
        for term, years in TERM_POINTS.items()
    }
    return {
        "date": row.get("worktime"),
        "curveId": row.get("ycDefId") or NCD_AAA_ID,
        "curveName": row.get("ycDefName") or NCD_AAA_NAME,
        "rating": "AAA",
        "termYields": term_yields,
        "source": "chinabond",
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
    }


def post_curve(work_date: date) -> list[dict]:
    context = ssl.create_default_context()
    if hasattr(ssl, "OP_LEGACY_SERVER_CONNECT"):
        context.options |= ssl.OP_LEGACY_SERVER_CONNECT
    body = {
        "xyzSelect": "txy",
        "workTimes": work_date.isoformat(),
        "dxbj": "0",
        "qxll": "0,",
        "yqqxN": "N",
        "yqqxK": "K",
        "ycDefIds": NCD_AAA_ID,
        "wrjxCBFlag": "0",
        "locale": "zh_CN",
    }
    request = Request(
        SEARCH_URL,
        data=urlencode(body).encode("utf-8"),
        headers={
            "User-Agent": USER_AGENT,
            "Referer": REFERER,
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        },
        method="POST",
    )
    raw = urlopen(request, timeout=NETWORK_TIMEOUT_SECONDS, context=context).read()
    payload = json.loads(raw.decode("utf-8"))
    return payload if isinstance(payload, list) else []


def fetch_ncd_valuation(search_date: str | None = None) -> dict:
    anchor = date.fromisoformat(search_date) if search_date else date.today()
    for offset in range(14):
        work_date = anchor - timedelta(days=offset)
        rows = post_curve(work_date)
        if rows:
            return normalize_ncd_curve(rows[0])
    raise RuntimeError("ChinaBond NCD valuation curve unavailable")


def query_ncd_valuation(search_date: str | None = None, refresh: bool = False) -> dict:
    global _MEMORY_CACHE
    if not refresh:
        cached = load_cache()
        if cached:
            if not search_date or cached.get("date") == search_date:
                return cached
            try:
                requested = date.fromisoformat(search_date)
                cached_date = date.fromisoformat(str(cached.get("date")))
            except (TypeError, ValueError):
                requested = cached_date = None
            if requested and cached_date and timedelta(0) <= requested - cached_date <= timedelta(days=14):
                return {
                    **cached,
                    "source": "cache",
                    "requestedDate": search_date,
                    "asOfFallback": True,
                }
        if _MEMORY_CACHE:
            cached_at, payload = _MEMORY_CACHE
            if (datetime.now() - cached_at).total_seconds() < MEMORY_TTL_SECONDS:
                return payload
    try:
        payload = fetch_ncd_valuation(search_date)
        save_cache(payload)
        save_payload_snapshot("interbank_cd_valuation", payload)
        _MEMORY_CACHE = (datetime.now(), payload)
        return payload
    except Exception as exc:
        cached = load_cache()
        if cached:
            return {**cached, "source": "cache", "error": str(exc)}
        return {
            "date": search_date or date.today().isoformat(),
            "curveId": NCD_AAA_ID,
            "curveName": NCD_AAA_NAME,
            "rating": "AAA",
            "termYields": {},
            "source": "unavailable",
            "error": str(exc),
            "updatedAt": datetime.now().isoformat(timespec="seconds"),
        }


if __name__ == "__main__":
    print(json.dumps(query_ncd_valuation(refresh=True), ensure_ascii=False, indent=2))
