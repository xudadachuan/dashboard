from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import zipfile
from datetime import date, datetime, timedelta
from pathlib import Path
from xml.etree import ElementTree as ET


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT.parent / "data"
PRIMARY_DIR = DATA_DIR / "primary_issuance_excel"
INPUT_DIR = PRIMARY_DIR / "input"
EXPORT_DIR = PRIMARY_DIR / "exports"
LATEST_JSON = EXPORT_DIR / "primary_issuance_latest.json"
LATEST_CSV = EXPORT_DIR / "primary_issuance_latest.csv"
SUPPORTED_EXTENSIONS = {".xlsx"}

NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
REL_NS = {"r": "http://schemas.openxmlformats.org/package/2006/relationships"}

DATE_HEADERS = {"招标日", "缴款日", "上市日", "起息日"}
NUMBER_FIELDS = {
    "计划发行额（亿）",
    "实际发行额（亿）",
    "加权利率(%)",
    "边际利率(%)",
    "票面利率(%)",
    "全场倍数",
    "边际倍数",
    "承销费(Bp)",
    "手续费",
}


def ensure_dirs() -> None:
    INPUT_DIR.mkdir(parents=True, exist_ok=True)
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def excel_serial_to_date(value: str | int | float | None) -> str | None:
    if value in (None, ""):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        text = str(value).strip()
        match = re.search(r"(20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})", text)
        if match:
            return date(int(match.group(1)), int(match.group(2)), int(match.group(3))).isoformat()
        return text or None
    return (datetime(1899, 12, 30) + timedelta(days=number)).date().isoformat()


def parse_number(value) -> float | None:
    if value in (None, ""):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).replace(",", "").strip()
    if not text:
        return None
    match = re.search(r"-?\d+(?:\.\d+)?", text)
    return float(match.group(0)) if match else None


def cell_column(cell_ref: str) -> int:
    letters = re.match(r"[A-Z]+", cell_ref or "")
    if not letters:
        return 0
    value = 0
    for char in letters.group(0):
        value = value * 26 + ord(char) - ord("A") + 1
    return value


def _read_inline_text(cell: ET.Element) -> str:
    texts = [node.text or "" for node in cell.findall(".//m:t", NS)]
    return "".join(texts).strip()


def _read_shared_strings(zf: zipfile.ZipFile) -> list[str]:
    try:
        raw = zf.read("xl/sharedStrings.xml")
    except KeyError:
        return []
    root = ET.fromstring(raw)
    return ["".join(node.text or "" for node in item.findall(".//m:t", NS)) for item in root.findall("m:si", NS)]


def _first_sheet_path(zf: zipfile.ZipFile) -> str:
    workbook = ET.fromstring(zf.read("xl/workbook.xml"))
    sheet = workbook.find("m:sheets/m:sheet", NS)
    if sheet is None:
        raise ValueError("workbook has no worksheet")
    rel_id = sheet.attrib.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
    rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    for rel in rels.findall("r:Relationship", REL_NS):
        if rel.attrib.get("Id") == rel_id:
            target = rel.attrib.get("Target", "")
            return "xl/" + target.lstrip("/")
    raise ValueError("worksheet relationship not found")


def read_xlsx_rows(path: Path) -> list[list[object]]:
    with zipfile.ZipFile(path) as zf:
        shared_strings = _read_shared_strings(zf)
        sheet_path = _first_sheet_path(zf)
        sheet = ET.fromstring(zf.read(sheet_path))
        rows: list[list[object]] = []
        for row in sheet.findall(".//m:sheetData/m:row", NS):
            values: dict[int, object] = {}
            for cell in row.findall("m:c", NS):
                column = cell_column(cell.attrib.get("r", ""))
                cell_type = cell.attrib.get("t")
                raw_value = cell.findtext("m:v", default="", namespaces=NS)
                if cell_type == "inlineStr":
                    value: object = _read_inline_text(cell)
                elif cell_type == "s":
                    value = shared_strings[int(raw_value)] if raw_value else ""
                elif raw_value == "":
                    value = ""
                else:
                    number = parse_number(raw_value)
                    value = number if number is not None else raw_value
                values[column] = value
            if values:
                rows.append([values.get(index, "") for index in range(1, max(values) + 1)])
        return rows


def latest_excel(input_dir: Path = INPUT_DIR) -> Path | None:
    if not input_dir.exists():
        return None
    files = [path for path in input_dir.rglob("*") if path.is_file() and path.suffix.lower() in SUPPORTED_EXTENSIONS]
    if not files:
        return None
    # Files copied from the terminal can receive the same (or an arbitrary)
    # filesystem timestamp.  Prefer the business date embedded in the filename
    # so an older "副本" cannot hide a newer daily export.
    def sort_key(path: Path) -> tuple[date, float, str]:
        match = re.search(r"(20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})", path.stem)
        try:
            data_day = date(int(match.group(1)), int(match.group(2)), int(match.group(3))) if match else date.min
        except ValueError:
            data_day = date.min
        return data_day, path.stat().st_mtime, path.name

    return max(files, key=sort_key)


def infer_data_date(rows: list[list[object]], path: Path) -> str:
    header_text = " ".join(str(value) for row in rows[:2] for value in row if value)
    match = re.search(r"(20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})", header_text)
    if not match:
        match = re.search(r"(20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})", path.stem)
    if match:
        return date(int(match.group(1)), int(match.group(2)), int(match.group(3))).isoformat()
    return date.today().isoformat()


def classify_bond(name: str, code: str) -> str:
    text = f"{name} {code}"
    if "国债" in text:
        return "国债"
    if any(keyword in text for keyword in ("国开", "农发", "进出", "口行", "清发")) or code.startswith("09"):
        return "政策性金融债"
    return "其他"


def normalize_rows(rows: list[list[object]], source_file: Path, source_hash: str) -> tuple[str, list[dict]]:
    header_index = next(
        (index for index, row in enumerate(rows) if any(str(value).strip() == "债券简称" for value in row)),
        None,
    )
    if header_index is None:
        raise ValueError("Excel header row with 债券简称 not found")
    headers = [str(value).strip() for value in rows[header_index]]
    data_date = infer_data_date(rows, source_file)
    items: list[dict] = []
    for row_index, row in enumerate(rows[header_index + 1 :], start=1):
        if not any(value not in ("", None) for value in row):
            continue
        raw = {headers[index]: row[index] if index < len(row) else "" for index in range(len(headers)) if headers[index]}
        name = str(raw.get("债券简称") or "").strip()
        code = str(raw.get("债券代码") or "").strip()
        if not name and not code:
            continue
        item = {
            "data_date": data_date,
            "source_file": str(source_file),
            "source_hash": source_hash,
            "row_index": row_index,
            "bond_name": name,
            "bond_code": code,
            "bond_type": classify_bond(name, code),
            "auction_date": excel_serial_to_date(raw.get("招标日")),
            "auction_time": str(raw.get("招标时间") or "").strip(),
            "maturity": str(raw.get("发行期限") or "").strip(),
            "planned_amount_100m": parse_number(raw.get("计划发行额（亿）")),
            "actual_amount_100m": parse_number(raw.get("实际发行额（亿）")),
            "weighted_rate": parse_number(raw.get("加权利率(%)")),
            "marginal_rate": parse_number(raw.get("边际利率(%)")),
            "coupon_rate": parse_number(raw.get("票面利率(%)")),
            "subscription_multiple": parse_number(raw.get("全场倍数")),
            "marginal_multiple": parse_number(raw.get("边际倍数")),
            "underwriting_fee_bp": parse_number(raw.get("承销费(Bp)")),
            "payment_date": excel_serial_to_date(raw.get("缴款日")),
            "listing_date": excel_serial_to_date(raw.get("上市日")),
            "interest_start_date": excel_serial_to_date(raw.get("起息日")),
            "fee": parse_number(raw.get("手续费")),
        }
        items.append(item)
    return data_date, items


def summarize_items(items: list[dict]) -> dict:
    by_type: dict[str, dict] = {}
    auction_dates = sorted({str(item.get("auction_date")) for item in items if item.get("auction_date")})
    for item in items:
        bond_type = item.get("bond_type") or "其他"
        bucket = by_type.setdefault(bond_type, {"bondType": bond_type, "count": 0, "plannedAmount100m": 0.0, "actualAmount100m": 0.0})
        bucket["count"] += 1
        bucket["plannedAmount100m"] += float(item.get("planned_amount_100m") or 0)
        bucket["actualAmount100m"] += float(item.get("actual_amount_100m") or 0)
    ordered = [by_type[key] for key in ("国债", "政策性金融债", "其他") if key in by_type]
    auction_start = auction_dates[0] if auction_dates else None
    auction_end = auction_dates[-1] if auction_dates else None
    auction_range = None
    if auction_start and auction_end:
        auction_range = auction_start if auction_start == auction_end else f"{auction_start} 至 {auction_end}"
    return {
        "itemCount": len(items),
        "totalPlannedAmount100m": round(sum(item["plannedAmount100m"] for item in ordered), 4),
        "totalActualAmount100m": round(sum(item["actualAmount100m"] for item in ordered), 4),
        "auctionDateStart": auction_start,
        "auctionDateEnd": auction_end,
        "auctionDateRange": auction_range,
        "byType": [
            {
                **item,
                "plannedAmount100m": round(item["plannedAmount100m"], 4),
                "actualAmount100m": round(item["actualAmount100m"], 4),
            }
            for item in ordered
        ],
    }


def write_exports(payload: dict) -> dict:
    ensure_dirs()
    LATEST_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    dated_json = EXPORT_DIR / f"primary_issuance_{payload.get('date') or 'latest'}.json"
    dated_json.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    columns = [
        "data_date",
        "bond_type",
        "bond_name",
        "bond_code",
        "auction_date",
        "auction_time",
        "maturity",
        "planned_amount_100m",
        "actual_amount_100m",
        "weighted_rate",
        "marginal_rate",
        "coupon_rate",
        "subscription_multiple",
        "marginal_multiple",
        "underwriting_fee_bp",
        "payment_date",
        "listing_date",
        "interest_start_date",
        "source_file",
    ]
    with LATEST_CSV.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(payload.get("items") or [])
    return {"json": str(LATEST_JSON), "csv": str(LATEST_CSV)}


def process_excel_file(path: Path) -> dict:
    ensure_dirs()
    source_hash = file_sha256(path)
    rows = read_xlsx_rows(path)
    data_date, items = normalize_rows(rows, path, source_hash)
    payload = {
        "date": data_date,
        "source": "dm_excel",
        "sourceName": "DM 终端 Excel",
        "sourceFile": str(path),
        "sourceHash": source_hash,
        "summary": summarize_items(items),
        "items": items,
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
    }
    payload["exports"] = write_exports(payload)
    return payload


def process_latest_excel(input_dir: Path = INPUT_DIR) -> dict:
    path = latest_excel(input_dir)
    if path is None:
        ensure_dirs()
        # Never replace a usable dashboard snapshot with an empty payload just
        # because the input share is temporarily unavailable or a DM export is
        # late. The next valid Excel will replace this snapshot normally.
        if LATEST_JSON.exists():
            try:
                previous = json.loads(LATEST_JSON.read_text(encoding="utf-8"))
                if isinstance(previous, dict) and previous.get("items"):
                    return {
                        **previous,
                        "source": "cache",
                        "note": f"No xlsx files found in {input_dir}; showing the latest valid DM export",
                    }
            except (OSError, json.JSONDecodeError):
                pass
        return {
            "date": None,
            "source": "dm_excel",
            "sourceName": "DM 终端 Excel",
            "summary": summarize_items([]),
            "items": [],
            "updatedAt": datetime.now().isoformat(timespec="seconds"),
            "note": f"No xlsx files found in {input_dir}",
        }
    return process_excel_file(path)


def query_primary_issuance(query_date: str | None = None) -> dict:
    try:
        from primary_issuance_merge import query_primary_issuance_from_db
        merged = query_primary_issuance_from_db(query_date)
        if merged is not None:
            return merged
    except Exception:
        pass
    newest = latest_excel()
    if newest:
        try:
            current = json.loads(LATEST_JSON.read_text(encoding="utf-8")) if LATEST_JSON.exists() else {}
        except (OSError, json.JSONDecodeError):
            current = {}
        try:
            newest_hash = file_sha256(newest)
            newest_date = infer_data_date(read_xlsx_rows(newest), newest)
            # The hash check is essential when DM corrects a report but keeps
            # the same filename and business date.
            if (
                not LATEST_JSON.exists()
                or current.get("sourceFile") != str(newest)
                or current.get("sourceHash") != newest_hash
                or current.get("date") != newest_date
            ):
                process_excel_file(newest)
        except Exception as exc:
            # A partially copied/corrupt new file must not blank the page.
            # Continue serving the last valid snapshot and retry next request.
            if isinstance(current, dict) and current.get("items"):
                current = {**current, "source": "cache", "error": str(exc)}
                if not query_date or current.get("date") == query_date:
                    return current
            raise
    if LATEST_JSON.exists():
        payload = json.loads(LATEST_JSON.read_text(encoding="utf-8"))
        if not query_date or payload.get("date") == query_date:
            return payload
    if query_date:
        dated_json = EXPORT_DIR / f"primary_issuance_{query_date}.json"
        if dated_json.exists():
            return json.loads(dated_json.read_text(encoding="utf-8"))
    return process_latest_excel()


def main() -> None:
    parser = argparse.ArgumentParser(description="Read DM primary issuance Excel files.")
    parser.add_argument("--input-dir", default=str(INPUT_DIR), help="Folder containing DM xlsx files.")
    parser.add_argument("--file", default=None, help="Specific xlsx file to process.")
    parser.add_argument("--query", action="store_true", help="Only print current exported payload.")
    parser.add_argument("--date", default=None, help="Query a specific exported data date.")
    args = parser.parse_args()

    if args.query:
        print(json.dumps(query_primary_issuance(args.date), ensure_ascii=False, indent=2))
        return
    result = process_excel_file(Path(args.file)) if args.file else process_latest_excel(Path(args.input_dir))
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
