[CmdletBinding()]
param([string]$PublicIp = "127.0.0.1")

$ErrorActionPreference = "Stop"

$backend = Invoke-RestMethod -Uri "http://127.0.0.1:8765/api/health" -TimeoutSec 10
$public = Invoke-WebRequest -UseBasicParsing -Uri "http://$PublicIp/api/health" -TimeoutSec 10

[pscustomobject]@{
    BackendStatus = $backend.status
    PublicStatusCode = $public.StatusCode
    BackendTask = (Get-ScheduledTaskInfo -TaskName "BondDashboard_Backend").LastTaskResult
    CaddyTask = (Get-ScheduledTaskInfo -TaskName "BondDashboard_Caddy").LastTaskResult
}
