[CmdletBinding()]
param([string]$AppRoot = "C:\BondDashboard")

$ErrorActionPreference = "Stop"

$tasks = @(
    @{ Name = "BondDashboard_PBOC_OMO_Update"; Script = "update_pboc_omo.bat"; Time = "09:35" },
    @{ Name = "BondDashboard_Market_Data_Update"; Script = "update_market_data.bat"; Time = "17:00" },
    @{ Name = "BondDashboard_AI_Summary_Update"; Script = "update_ai_summary.bat"; Time = "17:10" },
    @{ Name = "BondDashboard_ETF_Data_Update"; Script = "update_etf_data.bat"; Time = "21:00" }
)

$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew -RestartCount 8 -RestartInterval (New-TimeSpan -Minutes 15) -ExecutionTimeLimit (New-TimeSpan -Hours 2)
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest

foreach ($task in $tasks) {
    $scriptPath = Join-Path $AppRoot $task.Script
    if (-not (Test-Path -LiteralPath $scriptPath)) {
        throw "缺少更新脚本：$scriptPath"
    }
    $action = New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\cmd.exe" -Argument "/c `"`"$scriptPath`"`"" -WorkingDirectory $AppRoot
    $trigger = New-ScheduledTaskTrigger -Daily -At ([datetime]::ParseExact($task.Time, "HH:mm", $null))
    Register-ScheduledTask -TaskName $task.Name -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Description "Bond dashboard automatic update: $($task.Script)" -Force | Out-Null
}
