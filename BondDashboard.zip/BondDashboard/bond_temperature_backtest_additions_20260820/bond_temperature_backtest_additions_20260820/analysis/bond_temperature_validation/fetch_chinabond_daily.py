from __future__ import annotations

import argparse
import csv
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, timedelta
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
BACKEND = ROOT / "backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))

from chinabond_yields import fetch_for_date  # noqa: E402


FIELDS = [
    "date",
    "treasury_1y",
    "treasury_10y",
    "treasury_30y",
    "cdb_10y",
    "spread_10y_1y_bp",
    "spread_30y_10y_bp",
    "spread_cdb10y_treasury10y_bp",
]


def weekdays(start: date, end: date) -> list[date]:
    output = []
    current = start
    while current <= end:
        if current.weekday() < 5:
            output.append(current)
        current += timedelta(days=1)
    return output


def fetch_day(target: date) -> dict | None:
    payload = fetch_for_date(target)
    if not payload:
        return None
    treasury = payload["curves"]["treasury"]["keyRates"]
    cdb = payload["curves"]["cdb"]["keyRates"]
    t1 = treasury.get("1Y")
    t10 = treasury.get("10Y")
    t30 = treasury.get("30Y")
    c10 = cdb.get("10Y")
    if None in (t1, t10, t30, c10):
        return None
    return {
        "date": target.isoformat(),
        "treasury_1y": t1,
        "treasury_10y": t10,
        "treasury_30y": t30,
        "cdb_10y": c10,
        "spread_10y_1y_bp": round((t10 - t1) * 100, 4),
        "spread_30y_10y_bp": round((t30 - t10) * 100, 4),
        "spread_cdb10y_treasury10y_bp": round((c10 - t10) * 100, 4),
    }


def load_existing(path: Path) -> dict[str, dict]:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return {row["date"]: row for row in csv.DictReader(handle)}


def save_rows(path: Path, rows: dict[str, dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows[key] for key in sorted(rows))


def main() -> int:
    parser = argparse.ArgumentParser(description="Fetch official daily ChinaBond Treasury/CDB curves.")
    parser.add_argument("--start", type=date.fromisoformat, default=date(2025, 1, 1))
    parser.add_argument("--end", type=date.fromisoformat, default=date.today())
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).resolve().parent / "raw" / "chinabond_daily_2025_present.csv",
    )
    args = parser.parse_args()

    rows = load_existing(args.output)
    targets = [item for item in weekdays(args.start, args.end) if item.isoformat() not in rows]
    print(f"existing={len(rows)} pending={len(targets)}")
    if not targets:
        return 0

    with ThreadPoolExecutor(max_workers=max(1, min(args.workers, 6))) as executor:
        futures = {executor.submit(fetch_day, target): target for target in targets}
        for index, future in enumerate(as_completed(futures), start=1):
            target = futures[future]
            try:
                row = future.result()
            except Exception as exc:
                print(f"failed date={target}: {exc}")
                continue
            if row:
                rows[row["date"]] = row
            if index % 20 == 0 or index == len(futures):
                save_rows(args.output, rows)
                print(f"progress={index}/{len(futures)} saved={len(rows)}")
    save_rows(args.output, rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
