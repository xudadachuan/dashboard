from __future__ import annotations

import json
import math
import sqlite3
from datetime import date, datetime, timedelta
from pathlib import Path
from statistics import mean

from market_database import load_payload_snapshot, load_snapshot, payload_available_dates, save_payload_snapshot
from trading_calendar import is_interbank_trading_day, latest_interbank_trading_day


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT.parent / "data"
YIELD_CACHE = DATA_DIR / "chinabond_yields_cache.json"
FUNDING_CACHE = DATA_DIR / "funding_rates_cache.json"
CD_CACHE = DATA_DIR / "interbank_cd_cache.json"
OMO_CACHE = DATA_DIR / "pboc_omo_payload.json"
OUTPUT_FILE = DATA_DIR / "bond_temperature_index.json"
DB_PATH = DATA_DIR / "bond_market.db"


INDICATORS = {
    "ytm_tbond_10y": {"group": "rate_temp", "direction": "negative", "label": "10Y国债收益率", "anchor": (1.55, 2.15), "weight": 1.2, "source": "chinabond", "unit": "%"},
    "ytm_tbond_30y": {"group": "rate_temp", "direction": "negative", "label": "30Y国债收益率", "anchor": (2.05, 2.75), "weight": 1.0, "source": "chinabond", "unit": "%"},
    "ytm_cdb_10y": {"group": "rate_temp", "direction": "negative", "label": "10Y国开收益率", "anchor": (1.70, 2.35), "weight": 1.0, "source": "chinabond", "unit": "%"},
    "spread_10y_1y": {"group": "curve_temp", "direction": "negative", "label": "10Y-1Y国债利差", "anchor": (35, 85), "weight": 1.0, "source": "chinabond", "unit": "BP"},
    "spread_30y_10y": {"group": "curve_temp", "direction": "negative", "label": "30Y-10Y国债利差", "anchor": (35, 80), "weight": 0.8, "source": "chinabond", "unit": "BP"},
    "spread_cdb10y_tbond10y": {"group": "curve_temp", "direction": "negative", "label": "10Y国开-10Y国债利差", "anchor": (0, 25), "weight": 0.8, "source": "chinabond", "unit": "BP"},
    "cd_3m_spread": {"group": "curve_temp", "direction": "negative", "label": "3M存单-3M国债利差", "anchor": (20, 75), "weight": 0.6, "source": "chinabond", "unit": "BP"},
    "dr007": {"group": "funding_temp", "direction": "negative", "label": "DR007", "anchor": (1.35, 2.10), "weight": 1.2, "source": "chinamoney", "unit": "%"},
    "r007_dr007": {"group": "funding_temp", "direction": "negative", "label": "R007-DR007", "anchor": (0, 50), "weight": 0.8, "source": "chinamoney", "unit": "BP"},
    "repo_rate_7d": {"group": "funding_temp", "direction": "negative", "label": "7天逆回购利率", "anchor": (1.20, 2.00), "weight": 0.4, "source": "pboc", "unit": "%"},
    "omo_5d_net": {"group": "funding_temp", "direction": "positive", "label": "近5日公开市场累计净投放", "anchor": (-10000, 10000), "weight": 0.3, "source": "pboc", "unit": "亿元"},
    "treasury_futures_momentum": {"group": "trading_temp", "direction": "positive", "label": "国债期货5日价格动量", "anchor": (-2, 2), "weight": 1.0, "source": "cffex", "unit": "%"},
    "treasury_futures_crowding": {"group": "trading_temp", "direction": "positive", "label": "国债期货成交持仓比", "anchor": (0.2, 1.2), "weight": 0.5, "source": "cffex", "unit": "倍"},
    "sse_treasury_index": {"group": "trading_temp", "direction": "positive", "label": "上证国债指数5日涨跌", "anchor": (-1, 1), "weight": 0.6, "source": "sse", "unit": "%"},
    "sse_treasury_turnover": {"group": "trading_temp", "direction": "positive", "label": "上交所国债成交额", "anchor": (0, 5000), "weight": 0.4, "source": "sse", "unit": "亿元"},
}

OFFICIAL_SOURCE_REGISTRY = {
    "chinabond": {
        "label": "中债估值/中央结算公司",
        "shortLabel": "中债估值",
        "indicatorKeys": [
            "ytm_tbond_10y", "ytm_tbond_30y", "ytm_cdb_10y",
            "spread_10y_1y", "spread_30y_10y", "spread_cdb10y_tbond10y",
            "cd_3m_spread",
        ],
    },
    "chinamoney": {
        "label": "中国货币网/外汇交易中心",
        "shortLabel": "中国货币网",
        "indicatorKeys": ["dr007", "r007_dr007"],
    },
    "pboc": {
        "label": "中国人民银行",
        "shortLabel": "人民银行",
        "indicatorKeys": ["repo_rate_7d", "omo_5d_net"],
    },
    "cffex": {
        "label": "中国金融期货交易所",
        "shortLabel": "中金所",
        "indicatorKeys": ["treasury_futures_momentum", "treasury_futures_crowding"],
    },
    "sse": {
        "label": "上海证券交易所",
        "shortLabel": "上交所",
        "indicatorKeys": ["sse_treasury_index", "sse_treasury_turnover"],
    },
}

GROUP_WEIGHTS = {
    "rate_temp": 0.35,
    "funding_temp": 0.30,
    "curve_temp": 0.20,
    "trading_temp": 0.15,
}

MAX_HISTORY_SAMPLES = 750
MIN_PERCENTILE_SAMPLES = 20
FULL_PERCENTILE_SAMPLES = 60
MAX_PERCENTILE_WEIGHT = 0.70
MAX_STALENESS_DAYS = 5
TREND_TRADING_DAYS = 5
MIN_GROUP_COVERAGE = 0.60
MIN_TOTAL_COVERAGE = 0.65
SMOOTHING_ALPHA = 0.65

GROUP_LABELS = {
    "rate_temp": "利率水位",
    "funding_temp": "资金面",
    "curve_temp": "曲线与利差",
    "trading_temp": "交易与拥挤度",
}

INDICATOR_METHOD_LABELS = {
    "ytm_tbond_10y": "10Y国债收益率",
    "ytm_tbond_30y": "30Y国债收益率",
    "ytm_cdb_10y": "10Y国开收益率",
    "spread_10y_1y": "10Y-1Y国债期限利差",
    "spread_30y_10y": "30Y-10Y国债期限利差",
    "spread_cdb10y_tbond10y": "10Y国开-10Y国债品种利差",
    "cd_3m_spread": "3M同业存单-3M国债利差",
    "dr007": "DR007",
    "r007_dr007": "R007-DR007",
    "repo_rate_7d": "7天逆回购利率",
    "omo_5d_net": "近5日公开市场累计净投放",
    "treasury_futures_momentum": "国债期货5日价格动量",
    "treasury_futures_crowding": "国债期货成交持仓比",
    "sse_treasury_index": "上证国债指数5日涨跌",
    "sse_treasury_turnover": "上交所国债成交额",
}

GROUP_METHOD_LABELS = {
    "rate_temp": "利率水位",
    "funding_temp": "资金面",
    "curve_temp": "曲线与利差",
    "trading_temp": "交易与拥挤度",
}


def build_method_details(
    latest_values: dict[str, float],
    latest_scores: dict[str, float],
    sample_sizes: dict[str, int] | None = None,
    source_dates: dict[str, str] | None = None,
) -> dict:
    indicators = []
    for key, config in INDICATORS.items():
        group = config["group"]
        group_total_weight = sum(item["weight"] for item in INDICATORS.values() if item["group"] == group)
        group_weight = GROUP_WEIGHTS[group]
        within_group_weight = config["weight"] / group_total_weight if group_total_weight else 0.0
        indicators.append({
            "key": key,
            "label": INDICATOR_METHOD_LABELS.get(key) or config.get("label") or key,
            "group": group,
            "groupLabel": GROUP_METHOD_LABELS.get(group) or GROUP_LABELS.get(group) or group,
            "groupWeight": group_weight,
            "weight": config["weight"],
            "withinGroupWeight": round(within_group_weight, 6),
            "overallMaxWeight": round(group_weight * within_group_weight, 6),
            "direction": config["direction"],
            "anchor": list(config["anchor"]),
            "value": latest_values.get(key),
            "score": latest_scores.get(key),
            "sampleSize": (sample_sizes or {}).get(key, 0),
            "sourceDate": (source_dates or {}).get(key),
            "sourceId": config["source"],
            "sourceLabel": OFFICIAL_SOURCE_REGISTRY[config["source"]]["label"],
            "unit": config["unit"],
            "included": key in latest_scores,
            "status": "available" if key in latest_scores else "pending",
            "available": key in latest_scores,
        })
    return {
        "formula": "本系统自定义透明综合指标：单指标得分 = 锚定区间得分与历史分位得分的加权平均；历史样本不足20个交易日时仅使用锚定区间，样本达到60个交易日后历史分位权重为70%。组内按指标权重加权平均，组间再按固定权重加权平均。",
        "scoreDirection": "温度越高表示债市越热。收益率、利差和资金价格越低越热；净投放、债券价格动量和顺势拥挤度越高越热。",
        "availabilityRule": "每个维度的可用指标权重须达到该维度配置权重的60%；至少两个维度且组间可用权重合计达到65%时才输出总温度。单项缺失时，仅在该维度内按可得权重归一化。为保证趋势连续，固定展示含今日在内的前五个交易日；单项最多沿用最近五个自然日的官方可得值，并保留原始数据日期。",
        "groupWeights": {
            key: {
                "label": GROUP_METHOD_LABELS.get(key) or GROUP_LABELS.get(key) or key,
                "weight": weight,
            }
            for key, weight in GROUP_WEIGHTS.items()
        },
        "indicators": indicators,
    }


def read_json(path: Path):
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def to_float(value) -> float | None:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    return parsed if math.isfinite(parsed) else None


def term_value(curve: dict, term: str, field: str) -> float | None:
    for point in curve.get("points") or []:
        if point.get("term") == term:
            return to_float(point.get(field))
    return None


def add_value(rows: dict[str, dict], row_date: str | None, key: str, value: float | None) -> None:
    if row_date and value is not None:
        rows.setdefault(row_date, {"date": row_date})[key] = value


def is_future_date(value: str | None) -> bool:
    if not value:
        return False
    try:
        return date.fromisoformat(str(value)) > date.today()
    except ValueError:
        return False


def collect_yield_rows() -> dict[str, dict]:
    rows: dict[str, dict] = {}
    snapshots = [load_payload_snapshot("chinabond_yields", item) for item in payload_available_dates("chinabond_yields")]
    snapshots = [item for item in snapshots if item] or [read_json(YIELD_CACHE)]
    for payload in snapshots:
        for field, row_date in [("previous", payload.get("previousDate")), ("today", payload.get("date"))]:
            treasury = ((payload.get("curves") or {}).get("treasury") or {})
            cdb = ((payload.get("curves") or {}).get("cdb") or {})
            t_3m = term_value(treasury, "3M", field)
            t_1y = term_value(treasury, "1Y", field)
            t_10y = term_value(treasury, "10Y", field)
            t_30y = term_value(treasury, "30Y", field)
            cdb_10y = term_value(cdb, "10Y", field)
            add_value(rows, row_date, "ytm_tbond_3m", t_3m)
            add_value(rows, row_date, "ytm_tbond_10y", t_10y)
            add_value(rows, row_date, "ytm_tbond_30y", t_30y)
            add_value(rows, row_date, "ytm_cdb_10y", cdb_10y)
            if t_10y is not None and t_1y is not None:
                add_value(rows, row_date, "spread_10y_1y", (t_10y - t_1y) * 100)
            if t_30y is not None and t_10y is not None:
                add_value(rows, row_date, "spread_30y_10y", (t_30y - t_10y) * 100)
            if cdb_10y is not None and t_10y is not None:
                add_value(rows, row_date, "spread_cdb10y_tbond10y", (cdb_10y - t_10y) * 100)
    return rows


def collect_funding_rows() -> dict[str, dict]:
    latest_payload = load_payload_snapshot("funding_rates")
    rows: dict[str, dict] = {}
    payloads = [latest_payload] if latest_payload else []
    cached = read_json(FUNDING_CACHE)
    payloads.extend(item for key, item in cached.items() if key != "__latest__" and isinstance(item, dict))
    if isinstance(cached.get("__latest__"), dict):
        payloads.append(cached["__latest__"])
    for payload in payloads:
        row_date = payload.get("date")
        metrics = payload.get("metrics") or {}
        dr007 = to_float((metrics.get("DR007") or {}).get("value"))
        r007 = to_float((metrics.get("R007") or {}).get("value"))
        add_value(rows, row_date, "dr007", dr007)
        if dr007 is not None and r007 is not None:
            add_value(rows, row_date, "r007_dr007", (r007 - dr007) * 100)
    return rows


def collect_policy_rows(payload: dict | None = None) -> dict[str, dict]:
    payload = payload or load_payload_snapshot("pboc_omo") or read_json(OMO_CACHE)
    daily = sorted(
        [item for item in payload.get("omoDaily") or [] if item.get("date")],
        key=lambda item: item["date"],
    )
    rows: dict[str, dict] = {}
    rolling_values: list[float] = []
    for item in daily:
        row_date = item["date"]
        net = to_float(item.get("value"))
        if net is not None:
            rolling_values.append(net)
            rolling_values = rolling_values[-5:]
            add_value(rows, row_date, "omo_5d_net", sum(rolling_values))
        add_value(rows, row_date, "repo_rate_7d", to_float(item.get("repoRate7d")))
    return rows


def collect_cd_rows() -> dict[str, dict]:
    payload = load_snapshot("interbank_cd_daily") or read_json(CD_CACHE)
    row_date = payload.get("date")
    rows: dict[str, dict] = {}
    term_buckets = payload.get("termBuckets") or []
    cd_3m = next((to_float(item.get("valuationYield")) for item in term_buckets if item.get("term") == "3M"), None)
    add_value(rows, row_date, "cd_3m", cd_3m)
    rows.update(collect_historical_cd_rows())
    return rows


def collect_historical_cd_rows(db_path: Path = DB_PATH) -> dict[str, dict]:
    if not db_path.exists():
        return {}
    rows: dict[str, dict] = {}
    try:
        with sqlite3.connect(db_path) as conn:
            conn.row_factory = sqlite3.Row
            items = conn.execute(
                """
                SELECT data_date, payload_json
                FROM interbank_cd_daily
                ORDER BY data_date
                """
            ).fetchall()
    except sqlite3.Error:
        return {}
    for item in items:
        try:
            payload = json.loads(item["payload_json"])
        except (TypeError, json.JSONDecodeError):
            continue
        term_buckets = payload.get("termBuckets") or []
        cd_3m = next((to_float(bucket.get("valuationYield")) for bucket in term_buckets if bucket.get("term") == "3M"), None)
        add_value(rows, item["data_date"], "cd_3m", cd_3m)
    return rows


def merge_rows(*sources: dict[str, dict]) -> list[dict]:
    merged: dict[str, dict] = {}
    for source in sources:
        for row_date, values in source.items():
            merged.setdefault(row_date, {"date": row_date}).update(values)
    for row in merged.values():
        if row.get("cd_3m") is not None and row.get("ytm_tbond_3m") is not None:
            row["cd_3m_spread"] = (row["cd_3m"] - row["ytm_tbond_3m"]) * 100
    return [merged[key] for key in sorted(merged) if not is_future_date(key)]


def forward_fill_rows(rows: list[dict], max_staleness_days: int = MAX_STALENESS_DAYS) -> list[dict]:
    last_seen: dict[str, tuple[date, float]] = {}
    output: list[dict] = []
    for raw_row in sorted(rows, key=lambda item: str(item.get("date") or "")):
        try:
            row_date = date.fromisoformat(str(raw_row.get("date")))
        except ValueError:
            continue
        row = dict(raw_row)
        source_dates: dict[str, str] = {}
        for key in INDICATORS:
            value = to_float(raw_row.get(key))
            if value is not None:
                last_seen[key] = (row_date, value)
                source_dates[key] = row_date.isoformat()
                row[key] = value
                continue
            previous = last_seen.get(key)
            if previous and (row_date - previous[0]).days <= max_staleness_days:
                row[key] = previous[1]
                source_dates[key] = previous[0].isoformat()
            else:
                row.pop(key, None)
        row["_sourceDates"] = source_dates
        output.append(row)
    return output


def latest_trading_dates(count: int = TREND_TRADING_DAYS, as_of: date | None = None) -> list[str]:
    """Return exactly ``count`` interbank trading days ending on today (if tradable)."""
    target = latest_interbank_trading_day(as_of or date.today())
    dates: list[str] = []
    while len(dates) < count:
        if is_interbank_trading_day(target):
            dates.append(target.isoformat())
        target -= timedelta(days=1)
    return list(reversed(dates))


def add_trading_date_spine(rows: list[dict], count: int = TREND_TRADING_DAYS) -> list[dict]:
    """Keep five calendar trading-day slots when official sources publish late."""
    merged = {str(row["date"]): dict(row) for row in rows if row.get("date")}
    for row_date in latest_trading_dates(count):
        merged.setdefault(row_date, {"date": row_date})
    return [merged[row_date] for row_date in sorted(merged)]


def percentile_rank(values: list[float], current: float) -> float | None:
    sample = [value for value in values if math.isfinite(value)]
    if not sample:
        return None
    less = sum(1 for value in sample if value < current)
    equal = sum(1 for value in sample if value == current)
    return (less + 0.5 * equal) / len(sample) * 100


def anchored_score(value: float, low_hot: float, high_cold: float, direction: str) -> float:
    if high_cold == low_hot:
        return 50.0
    position = (value - low_hot) / (high_cold - low_hot)
    position = max(0.0, min(1.0, position))
    raw = position * 100
    return 100 - raw if direction == "negative" else raw


def indicator_score(key: str, value: float, history: list[float]) -> float | None:
    config = INDICATORS[key]
    prior_history = [item for item in history[-MAX_HISTORY_SAMPLES:] if math.isfinite(item)]
    pct = percentile_rank(prior_history, value)
    percentile_score = None if pct is None else (pct if config["direction"] == "positive" else 100 - pct)
    anchor_score = anchored_score(value, *config["anchor"], config["direction"])
    if percentile_score is None or len(prior_history) < MIN_PERCENTILE_SAMPLES:
        return round(anchor_score, 1)
    percentile_weight = min(
        MAX_PERCENTILE_WEIGHT,
        MAX_PERCENTILE_WEIGHT * len(prior_history) / FULL_PERCENTILE_SAMPLES,
    )
    return round(anchor_score * (1 - percentile_weight) + percentile_score * percentile_weight, 1)


def aggregate_group_scores(indicator_scores: dict[str, float]) -> dict[str, float]:
    output: dict[str, float] = {}
    for group in GROUP_WEIGHTS:
        configured = [(key, config) for key, config in INDICATORS.items() if config["group"] == group]
        total_weight = sum(config["weight"] for _, config in configured)
        available = [
            (indicator_scores[key], config["weight"])
            for key, config in configured
            if key in indicator_scores
        ]
        available_weight = sum(weight for _, weight in available)
        if total_weight and available_weight / total_weight >= MIN_GROUP_COVERAGE:
            score = weighted_mean(available)
            if score is not None:
                output[group] = round(score, 1)
    return output


def aggregate_temperature(group_scores: dict[str, float], previous_smoothed: float | None = None) -> dict | None:
    active = {key: GROUP_WEIGHTS[key] for key in GROUP_WEIGHTS if key in group_scores}
    coverage = sum(active.values())
    if len(active) < 2 or coverage + 1e-9 < MIN_TOTAL_COVERAGE:
        return None
    raw = sum(group_scores[key] * weight for key, weight in active.items()) / coverage
    smoothed = raw if previous_smoothed is None else raw * SMOOTHING_ALPHA + previous_smoothed * (1 - SMOOTHING_ALPHA)
    return {
        "rawBondTemp": round(raw, 1),
        "bond_temp": round(smoothed, 1),
        "bond_temp_level": classify_temp(smoothed),
        "coverageWeight": round(coverage, 2),
    }


def classify_temp(value: float | None) -> str | None:
    if value is None or not math.isfinite(value):
        return None
    if value < 30:
        return "冷清 / 可关注"
    if value < 70:
        return "中性"
    return "拥挤 / 谨慎"


def signal_for_temp(value: float | None) -> str:
    if value is None or not math.isfinite(value):
        return "当前数据不足，暂无法给出温度信号。"
    if value < 20:
        return "情绪过冷，可留意机会。"
    if value > 80:
        return "极度拥挤，警惕回调。"
    return {
        "冷清 / 可关注": "当前市场情绪偏冷，可关注配置机会。",
        "中性": "当前市场情绪中性，赔率和拥挤度暂不极端。",
        "拥挤 / 谨慎": "当前市场情绪偏热，长久期资产需关注回撤风险。",
    }[classify_temp(value)]


def weighted_mean(items: list[tuple[float, float]]) -> float | None:
    valid = [(value, weight) for value, weight in items if value is not None and math.isfinite(value) and weight > 0]
    if not valid:
        return None
    total_weight = sum(weight for _, weight in valid)
    return sum(value * weight for value, weight in valid) / total_weight


def build_bond_temperature() -> dict:
    rows = forward_fill_rows(add_trading_date_spine(
        merge_rows(collect_yield_rows(), collect_funding_rows(), collect_cd_rows(), collect_policy_rows())
    ))
    if not rows:
        return {
            "date": None,
            "bond_temp": None,
            "bond_temp_level": None,
            "signal": "当前数据不足，暂无法计算债市温度。",
            "comment": "当前数据不足，暂无法计算债市温度。",
            "components": {},
            "updatedAt": datetime.now().isoformat(timespec="seconds"),
        }

    history = {key: [] for key in INDICATORS}
    output_rows = []
    previous_bond_temp = None
    for row in rows:
        indicator_scores: dict[str, float] = {}
        indicator_values: dict[str, float] = {}
        indicator_sample_sizes: dict[str, int] = {}
        for key in INDICATORS:
            value = to_float(row.get(key))
            if value is None:
                continue
            indicator_values[key] = value
            indicator_sample_sizes[key] = len(history[key][-MAX_HISTORY_SAMPLES:])
            score = indicator_score(key, value, history[key])
            if score is not None:
                indicator_scores[key] = score
            history[key].append(value)

        group_scores = aggregate_group_scores(indicator_scores)
        result = {
            "date": row["date"],
            "indicator_scores": indicator_scores,
            "indicatorValues": indicator_values,
            "indicatorSampleSizes": indicator_sample_sizes,
            "indicatorSourceDates": row.get("_sourceDates") or {},
            **group_scores,
        }
        aggregate = aggregate_temperature(group_scores, previous_bond_temp)
        if aggregate:
            result.update(aggregate)
            previous_bond_temp = aggregate["bond_temp"]
        output_rows.append(result)

    latest = next((row for row in reversed(output_rows) if row.get("bond_temp") is not None), output_rows[-1])
    available_groups = [key for key in GROUP_WEIGHTS if key in latest]
    missing_groups = [key for key in GROUP_WEIGHTS if key not in latest]
    hot_groups = [GROUP_LABELS[key] for key in available_groups if to_float(latest.get(key)) is not None and latest[key] >= 70]
    cool_groups = [GROUP_LABELS[key] for key in available_groups if to_float(latest.get(key)) is not None and latest[key] <= 35]

    temp = latest.get("bond_temp")
    level = latest.get("bond_temp_level")
    if temp is None:
        comment = "当前可得数据不足，暂无法计算债市温度。"
    else:
        driver_text = "、".join(hot_groups or cool_groups or [GROUP_LABELS[key] for key in available_groups[:2]])
        comment = f"当前债市温度为 {temp:.1f}，处于{level}区间。主要观察维度：{driver_text}。"
        if missing_groups:
            comment += " 缺失维度未参与加权；仅在覆盖门槛满足时输出总温度。"

    payload = {
        **latest,
        "level": level,
        "signal": signal_for_temp(temp),
        "comment": comment,
        "components": {
            key: {
                "label": GROUP_LABELS[key],
                "value": latest.get(key),
                "available": key in latest,
            }
            for key in GROUP_WEIGHTS
        },
        "availableGroups": available_groups,
        "missingGroups": missing_groups,
        "sampleSize": len(rows),
        "method": "单指标映射为0–100分，组内按指标权重加权，组间按固定权重合成：利率水位35%、资金面30%、曲线与利差20%、交易与拥挤度15%。",
        "calculationId": "transparent-bond-temperature-composite",
        "methodDetails": build_method_details(
            latest.get("indicatorValues") or {},
            latest.get("indicator_scores") or {},
            latest.get("indicatorSampleSizes") or {},
            latest.get("indicatorSourceDates") or {},
        ),
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
        "history": output_rows[-60:],
    }
    return payload


def save_bond_temperature() -> dict:
    payload = build_bond_temperature()
    DATA_DIR.mkdir(exist_ok=True)
    OUTPUT_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    save_payload_snapshot("bond_temperature", payload)
    return payload


def has_current_temperature_schema(payload: dict) -> bool:
    if payload.get("bond_temp") is None:
        return False
    return (
        payload.get("calculationId") == "transparent-bond-temperature-composite"
        and "sources" not in (payload.get("methodDetails") or {})
    )


def query_bond_temperature(refresh: bool = False) -> dict:
    if not refresh:
        stored = load_payload_snapshot("bond_temperature")
        if stored and has_current_temperature_schema(stored):
            return stored
    try:
        return save_bond_temperature()
    except Exception as exc:
        stored = load_payload_snapshot("bond_temperature")
        if stored:
            stored["source"] = "cache"
            stored["error"] = str(exc)
            return stored
        cached = read_json(OUTPUT_FILE)
        if cached:
            cached["source"] = "cache"
            cached["error"] = str(exc)
            save_payload_snapshot("bond_temperature", cached)
            return cached
        return {
            "date": None,
            "bond_temp": None,
            "bond_temp_level": None,
            "level": None,
            "signal": "债市温度指数计算失败",
            "comment": f"债市温度指数计算失败：{exc}",
            "components": {},
            "updatedAt": datetime.now().isoformat(timespec="seconds"),
            "error": str(exc),
        }


if __name__ == "__main__":
    print(json.dumps(save_bond_temperature(), ensure_ascii=False, indent=2))
