"""Fetch the public Eastmoney CFFEX treasury-futures snapshot into the CSV input format.

This is deliberately a market-only adapter.  It does not fabricate historical
open-interest or exchange-trading-calendar values; the generated CSV therefore
contains the latest snapshot and the dashboard reports the remaining gaps.
"""

from __future__ import annotations

import csv
import json
import re
from datetime import date, timedelta
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parent
INPUT_DIR = ROOT.parent / "data" / "treasury_futures" / "input"
CALENDAR_FILE = ROOT.parent / "data" / "interbank_calendar.json"
PRODUCT_ENDPOINTS = {"TS": "6", "TF": "5", "T": "4", "TL": "8"}
TOKEN = "8163b6a9200dc68c03113094df2db2c7"
URL = "https://futsseapi.eastmoney.com/list/variety/220/{product}"
HEADERS = {"User-Agent": "Mozilla/5.0", "Referer": "https://futures.eastmoney.com/"}


def fetch_product(product: str) -> list[dict]:
    params = urlencode({
        "orderBy": "zdf", "sort": "desc", "pageSize": 20, "pageIndex": 0,
        "token": TOKEN, "field": "zdf,sc,dm,name,p,zde,vol,ccl,zjsj",
    })
    request = Request(f"{URL.format(product=PRODUCT_ENDPOINTS[product])}?{params}", headers=HEADERS)
    with urlopen(request, timeout=20) as response:
        payload = json.loads(response.read().decode("utf-8"))
    return payload.get("list") or []


def last_trading_date(contract: str) -> str | None:
    match = re.fullmatch(r"[A-Z]+(\d{2})(\d{2})", contract)
    if not match:
        return None
    year, month = 2000 + int(match.group(1)), int(match.group(2))
    first = date(year, month, 1)
    first_friday = first + timedelta(days=(4 - first.weekday()) % 7)
    return (first_friday + timedelta(days=7)).isoformat()


def trading_days_to_last(data_date: str, last_date: str) -> int | None:
    """Count future sessions using the maintained holiday/workday calendar."""
    try:
        calendar = json.loads(CALENDAR_FILE.read_text(encoding="utf-8"))
        holidays = set(calendar.get("holidays") or [])
        workdays = set(calendar.get("workdays") or [])
        current, end = date.fromisoformat(data_date) + timedelta(days=1), date.fromisoformat(last_date)
    except (OSError, json.JSONDecodeError, ValueError):
        return None
    count = 0
    while current <= end:
        value = current.isoformat()
        if value in workdays or (current.weekday() < 5 and value not in holidays):
            count += 1
        current += timedelta(days=1)
    return count


def to_row(product: str, item: dict, data_date: str) -> dict | None:
    contract = str(item.get("dm") or "").upper()
    if not re.fullmatch(rf"{product}\d{{4}}", contract):
        return None
    price = item.get("p")
    change = item.get("zde")
    volume = item.get("vol")
    open_interest = item.get("ccl")
    if any(value is None for value in (price, change, volume, open_interest)):
        return None
    return {
        "date": data_date,
        "product": product,
        "contract": contract,
        "last_trading_date": last_trading_date(contract) or "",
        "trading_days_to_last": trading_days_to_last(data_date, last_trading_date(contract) or ""),
        "open": "", "high": "", "low": "",
        "close": price,
        "previous_close": round(float(price) - float(change), 6),
        "settlement": item.get("zjsj") or "",
        "volume": volume,
        "open_interest": open_interest,
        "ctd_code": "", "conversion_factor": "", "ctd_dirty_price": "",
        "ctd_dv01": "", "basis": "", "irr": "",
    }


def main() -> None:
    data_date = date.today().isoformat()
    rows: list[dict] = []
    errors: list[str] = []
    for product in PRODUCT_ENDPOINTS:
        try:
            items = fetch_product(product)
            seen: set[str] = set()
            for item in items:
                row = to_row(product, item, data_date)
                if row and row["contract"] not in seen:
                    rows.append(row)
                    seen.add(row["contract"])
        except Exception as exc:
            errors.append(f"{product}: {type(exc).__name__}: {exc}")
    INPUT_DIR.mkdir(parents=True, exist_ok=True)
    output = INPUT_DIR / f"treasury_futures_{data_date}.csv"
    fields = list(rows[0]) if rows else [
        "date", "product", "contract", "last_trading_date", "trading_days_to_last",
        "open", "high", "low", "close", "previous_close", "settlement", "volume",
        "open_interest", "ctd_code", "conversion_factor", "ctd_dirty_price", "ctd_dv01",
        "basis", "irr",
    ]
    with output.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({"date": data_date, "file": str(output), "rows": len(rows), "errors": errors}, ensure_ascii=False))


if __name__ == "__main__":
    main()
