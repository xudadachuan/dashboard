from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
DB_PATH = DATA_DIR / "bond_market.db"
AI_SUMMARY_FILE = DATA_DIR / "ai_summary.json"


MAINSTREAM_VIEWS = [
    {
        "as_of_date": "2026-07-03",
        "source_name": "Trading Economics",
        "source_type": "market_data_commentary",
        "source_url": "https://zh.tradingeconomics.com/china/government-bond-yield",
        "source_published_at": "2026-07-03",
        "view_title": "10年国债收益率反弹至1.74%，央行购债放缓被解读为谨慎信号",
        "view_summary": "市场将央行6月净买入国债规模下降解读为限制收益率过快下行、抑制债市过度投机的信号；10年国债收益率从前日1.73%反弹至约1.74%。",
        "view_tone": "cautious",
        "risk_level": "medium",
        "tags": "10Y,央行购债,政策信号,收益率反弹",
        "confidence": 0.88,
    },
    {
        "as_of_date": "2026-07-03",
        "source_name": "Trading Economics",
        "source_type": "market_data_forecast",
        "source_url": "https://zh.tradingeconomics.com/china/government-bond-yield",
        "source_published_at": "2026-07-02",
        "view_title": "10年收益率月内小幅下行，模型预期中期仍偏低位",
        "view_summary": "其数据称7月2日中国10年期国债收益率约1.73%，较前一日下降约1bp，过去一个月下降约2bp；模型预期本季度末约1.73%、12个月后约1.67%。",
        "view_tone": "neutral",
        "risk_level": "low",
        "tags": "10Y,月度变化,预测,低位震荡",
        "confidence": 0.82,
    },
    {
        "as_of_date": "2025-07-22",
        "source_name": "财联社/东方财富",
        "source_type": "market_close_commentary",
        "source_url": "https://finance.eastmoney.com/a/202507223464225857.html",
        "source_published_at": "2025-07-22",
        "view_title": "股市和商品走强，利率债中长端承压",
        "view_summary": "文章称权益和商品市场上涨时，利率债中长端品种收益率普遍上行；同时资金利率继续下行，短端表现好于中长端，体现曲线压力集中在长端。",
        "view_tone": "cautious",
        "risk_level": "medium",
        "tags": "风险偏好,股债跷跷板,中长端,资金面",
        "confidence": 0.78,
    },
    {
        "as_of_date": "2025-07-27",
        "source_name": "金融界/搜狐",
        "source_type": "market_analysis",
        "source_url": "https://www.sohu.com/a/918156348_114984",
        "source_published_at": "2025-07-27",
        "view_title": "债基赎回和风险偏好变化加剧债市调整",
        "view_summary": "文章认为权益市场强势、大宗商品上涨和债基赎回压力共同压制债市；但10年期国债收益率上行幅度约7bp，仍未达到历史极端回调水平。",
        "view_tone": "cautious",
        "risk_level": "medium",
        "tags": "债基赎回,风险偏好,回调幅度,配置窗口",
        "confidence": 0.74,
    },
    {
        "as_of_date": "2025-07-27",
        "source_name": "金融界/搜狐",
        "source_type": "market_analysis",
        "source_url": "https://www.sohu.com/a/918156348_114984",
        "source_published_at": "2025-07-27",
        "view_title": "赎回压力释放后，债市可能回到稳定配置窗口",
        "view_summary": "文章提到部分机构认为，若赎回压力逐步释放，债市有望迎来相对稳定的配置窗口；这属于偏中性的后续观察观点。",
        "view_tone": "neutral",
        "risk_level": "low",
        "tags": "赎回压力,配置窗口,稳定,中性观察",
        "confidence": 0.70,
    },
]


def connect() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("pragma journal_mode=wal")
    return conn


def ensure_schema(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        create table if not exists market_views (
            id integer primary key autoincrement,
            as_of_date text not null,
            source_name text not null,
            source_type text not null,
            source_url text not null,
            source_published_at text,
            view_title text not null,
            view_summary text not null,
            view_tone text not null,
            risk_level text not null,
            tags text,
            confidence real not null default 0.7,
            created_at text not null,
            unique(source_name, source_url, view_title)
        )
        """
    )
    conn.execute(
        """
        create table if not exists ai_summary_reviews (
            id integer primary key autoincrement,
            summary_date text,
            summary_update_time text,
            summary_headline text,
            summary_text text,
            market_consensus text not null,
            alignment text not null,
            gaps text not null,
            created_at text not null
        )
        """
    )


def upsert_views(conn: sqlite3.Connection) -> int:
    now = datetime.now().isoformat(timespec="seconds")
    count = 0
    for item in MAINSTREAM_VIEWS:
        conn.execute(
            """
            insert into market_views (
                as_of_date, source_name, source_type, source_url, source_published_at,
                view_title, view_summary, view_tone, risk_level, tags, confidence, created_at
            ) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            on conflict(source_name, source_url, view_title) do update set
                as_of_date=excluded.as_of_date,
                source_type=excluded.source_type,
                source_published_at=excluded.source_published_at,
                view_summary=excluded.view_summary,
                view_tone=excluded.view_tone,
                risk_level=excluded.risk_level,
                tags=excluded.tags,
                confidence=excluded.confidence,
                created_at=excluded.created_at
            """,
            (
                item["as_of_date"],
                item["source_name"],
                item["source_type"],
                item["source_url"],
                item["source_published_at"],
                item["view_title"],
                item["view_summary"],
                item["view_tone"],
                item["risk_level"],
                item["tags"],
                item["confidence"],
                now,
            ),
        )
        count += 1
    return count


def read_ai_summary() -> dict:
    if not AI_SUMMARY_FILE.exists():
        return {}
    try:
        payload = json.loads(AI_SUMMARY_FILE.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}
    return payload if isinstance(payload, dict) else {}


def save_review(conn: sqlite3.Connection, summary: dict) -> dict:
    consensus = "主流观点整体指向：10年国债在1.73%-1.74%附近低位震荡；资金面偏稳或偏松，但央行购债放缓、风险资产走强、债基赎回等因素会压制中长端，市场语气以中性偏谨慎为主。"
    alignment = "AI日评的“窄幅震荡、曲线小幅走平、市场情绪中性”与低位震荡和资金平稳的主流描述基本一致。"
    gaps = "不足是没有体现央行购债放缓、股债跷跷板、债基赎回压力等外部主流叙事；若用于首页短评可以接受，若用于复盘报告建议补充这些风险偏好和政策行为因素。"
    now = datetime.now().isoformat(timespec="seconds")
    conn.execute(
        """
        insert into ai_summary_reviews (
            summary_date, summary_update_time, summary_headline, summary_text,
            market_consensus, alignment, gaps, created_at
        ) values (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            summary.get("date"),
            summary.get("update_time"),
            summary.get("headline"),
            summary.get("summary"),
            consensus,
            alignment,
            gaps,
            now,
        ),
    )
    return {"market_consensus": consensus, "alignment": alignment, "gaps": gaps}


def main() -> int:
    with connect() as conn:
        ensure_schema(conn)
        inserted = upsert_views(conn)
        review = save_review(conn, read_ai_summary())
        conn.commit()
    print(json.dumps({"market_views_upserted": inserted, "review": review}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
