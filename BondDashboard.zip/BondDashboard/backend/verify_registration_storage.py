import sqlite3
import sys

database_path = r"C:\BondDashboard\data\accounts.db"
username = sys.argv[1]

with sqlite3.connect(database_path) as connection:
    row = connection.execute(
        "SELECT password_hash, password_salt FROM users WHERE username = ?",
        (username,),
    ).fetchone()

print(f"stored_on_server={row is not None}")
print(f"password_is_hashed={bool(row and row[0] and row[1])}")
print(f"database_path={database_path}")
