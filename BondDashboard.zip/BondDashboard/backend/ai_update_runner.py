from __future__ import annotations

import subprocess
import sys
import traceback
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent
LOG_DIR = ROOT.parent / "logs"
COMMANDS = [
    [sys.executable, "generate_ai_summary.py"],
    [sys.executable, "market_commentary.py", "--daily"],
]


def append_log(message: str) -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_file = LOG_DIR / f"ai_summary_update_{datetime.now():%Y-%m-%d}.log"
    with log_file.open("a", encoding="utf-8") as handle:
        handle.write(message if message.endswith("\n") else f"{message}\n")


def main() -> int:
    for command in COMMANDS:
        completed = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        append_log(f"$ {' '.join(command)}\n{completed.stdout}")
        if completed.returncode:
            append_log(f"failed: command exited {completed.returncode}")
            return completed.returncode
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        append_log(traceback.format_exc())
        raise
