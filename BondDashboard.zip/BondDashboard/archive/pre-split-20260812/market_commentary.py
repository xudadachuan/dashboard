from __future__ import annotations

import argparse
import json
import os
import urllib.error
import urllib.request
from datetime import datetime, time
from pathlib import Path

from backend_api import market_payload
from market_database import (
    load_market_commentary,
    load_payload_snapshot,
    payload_available_dates,
    save_daily_commentary,
    save_weekly_commentary,
)


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
COMMENTARY_FILE = DATA_DIR / "market_commentary.json"
DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"
DEFAULT_MODEL = "deepseek-v4-flash"
REQUEST_TIMEOUT_SECONDS = 60


FALLBACK_DAILY = {
    "title": "债市窄幅震荡走弱，收盘点评",
    "summary": "今日债市收益率多数小幅上行，10年国债、国开上行约0.5BP，30年国债上行1BP，3年国开微降。资金面平稳，曲线小幅走陡。市场整体窄幅波动，情绪中性。",
    "tone": "neutral",
    "risk_level": "low",
}


def load_dotenv(path: Path = ROOT / ".env") -> None:
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def write_debug_json() -> dict:
    payload = load_market_commentary(limit=7)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    COMMENTARY_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return payload


def number(value) -> float | None:
    try:
        if value is None or value == "":
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def card(payload: dict, key: str) -> dict:
    return next((item for item in ((payload.get("chinabondYields") or {}).get("cards") or []) if item.get("key") == key), {})


def build_daily_prompt(snapshot: dict) -> str:
    concise = {
        "date": (snapshot.get("chinabondYields") or {}).get("date") or (snapshot.get("fundingRates") or {}).get("date"),
        "rates": {
            "10y_treasury_bp": number(card(snapshot, "treasury10").get("changeBp")),
            "10y_cdb_bp": number(card(snapshot, "cdb10").get("changeBp")),
            "30y_treasury_bp": number(card(snapshot, "treasury30").get("changeBp")),
            "3y_cdb_bp": number(card(snapshot, "cdb3").get("changeBp")),
        },
        "funding": (snapshot.get("fundingRates") or {}).get("metrics") or {},
        "temperature": {
            "value": (snapshot.get("bondTemperature") or {}).get("bond_temp"),
            "level": (snapshot.get("bondTemperature") or {}).get("bond_temp_level"),
        },
    }
    return f"""
请基于以下中国债市数据，生成一条每日收盘点评。只返回 JSON，不要 Markdown。
JSON 字段：
{{
  "title": "标题，12-24个中文字符",
  "summary": "80-140个中文字符，覆盖利率、资金、曲线和情绪",
  "tone": "neutral|positive|cautious",
  "risk_level": "low|medium|high"
}}
写作口径：收益率上行代表债市走弱，下行代表债市走强；主要期限变动小于 1BP 时表述为窄幅震荡；不得编造未提供的数据。
市场数据：
{json.dumps(concise, ensure_ascii=False, indent=2)}
""".strip()


def build_weekly_prompt(history: list[dict]) -> str:
    return f"""
请基于最近一周每日债市收盘点评，生成周度复盘。只返回 JSON，不要 Markdown。
JSON 字段：
{{
  "title": "标题，12-24个中文字符",
  "summary": "120-220个中文字符，概括本周方向、资金面、曲线和下周关注点",
  "tone": "neutral|positive|cautious",
  "risk_level": "low|medium|high"
}}
每日点评：
{json.dumps(history, ensure_ascii=False, indent=2)}
""".strip()


def parse_json_response(text: str) -> dict:
    content = text.strip()
    if content.startswith("```"):
        content = content.removeprefix("```json").removeprefix("```").strip()
        content = content.removesuffix("```").strip()
    return json.loads(content)


def call_deepseek(prompt: str, model: str, api_key: str) -> dict:
    body = {
        "model": model,
        "messages": [
            {"role": "system", "content": "你是专业中国固定收益分析师。必须返回合法 JSON 对象。"},
            {"role": "user", "content": prompt},
        ],
        "response_format": {"type": "json_object"},
        "temperature": 0.35,
        "max_tokens": 700,
        "stream": False,
    }
    request = urllib.request.Request(
        DEEPSEEK_URL,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=REQUEST_TIMEOUT_SECONDS) as response:
        payload = json.loads(response.read().decode("utf-8"))
    content = (((payload.get("choices") or [{}])[0].get("message") or {}).get("content") or "").strip()
    if not content:
        raise RuntimeError("DeepSeek returned empty content")
    return parse_json_response(content)


def normalize_commentary(result: dict, fallback: dict) -> dict:
    title = str(result.get("title") or result.get("headline") or fallback["title"]).strip()
    summary = str(result.get("summary") or fallback["summary"]).strip()
    tone = result.get("tone") if result.get("tone") in {"neutral", "positive", "cautious"} else fallback["tone"]
    risk_level = result.get("risk_level") if result.get("risk_level") in {"low", "medium", "high"} else fallback["risk_level"]
    return {"title": title, "summary": summary, "tone": tone, "risk_level": risk_level}


def format_bp(value) -> str:
    parsed = number(value)
    if parsed is None:
        return "--"
    direction = "上行" if parsed > 0 else "下行" if parsed < 0 else "持平"
    return f"{direction}{abs(parsed):.2f}BP"


def fallback_daily_from_snapshot(snapshot: dict) -> dict:
    treasury10 = number(card(snapshot, "treasury10").get("changeBp"))
    cdb10 = number(card(snapshot, "cdb10").get("changeBp"))
    treasury30 = number(card(snapshot, "treasury30").get("changeBp"))
    changes = [value for value in (treasury10, cdb10, treasury30) if value is not None]
    avg_change = sum(changes) / len(changes) if changes else 0
    if avg_change <= -1:
        title = "债市偏强，收益率下行"
        tone = "positive"
    elif avg_change >= 1:
        title = "债市偏弱，收益率上行"
        tone = "cautious"
    else:
        title = "债市窄幅震荡"
        tone = "neutral"

    funding = (snapshot.get("fundingRates") or {}).get("metrics") or {}
    dr007 = number((funding.get("DR007") or {}).get("value"))
    r007 = number((funding.get("R007") or {}).get("value"))
    temp = snapshot.get("bondTemperature") or {}
    temp_value = number(temp.get("bond_temp"))
    temp_level = temp.get("bond_temp_level") or temp.get("level")
    risk_level = "high" if temp_value is not None and temp_value >= 75 else "medium" if temp_value is not None and temp_value >= 60 else "low"
    summary = (
        f"当日债市{title.replace('债市', '')}，10年国债{format_bp(treasury10)}，"
        f"10年国开{format_bp(cdb10)}，30年国债{format_bp(treasury30)}。"
    )
    summary += f"资金面整体平稳，DR007{dr007:.3f}%" if dr007 is not None else "资金面数据暂缺"
    if r007 is not None:
        summary += f"，R007{r007:.3f}%"
    if temp_value is not None:
        summary += f"。市场温度{temp_value:.1f}，处于{temp_level or '中性'}区间。"
    return {"title": title, "summary": summary, "tone": tone, "risk_level": risk_level}


def build_snapshot_for_date(data_date: str) -> dict:
    return {
        "chinabondYields": load_payload_snapshot("chinabond_yields", data_date) or {},
        "fundingRates": load_payload_snapshot("funding_rates", data_date) or {},
        "bondTemperature": load_payload_snapshot("bond_temperature", data_date) or {},
    }


def available_commentary_dates(limit: int = 7) -> list[str]:
    dates = set()
    for dataset in ("chinabond_yields", "funding_rates", "bond_temperature"):
        dates.update(payload_available_dates(dataset))
    return sorted(dates, reverse=True)[:limit]


def generate_daily(
    force_deepseek: bool = False,
    snapshot: dict | None = None,
    data_date: str | None = None,
    use_deepseek: bool = True,
) -> dict:
    load_dotenv()
    if not os.environ.get("DEEPSEEK_API_KEY") and os.environ.get("YOUR_API_KEY"):
        os.environ["DEEPSEEK_API_KEY"] = os.environ["YOUR_API_KEY"]
    model = os.environ.get("DEEPSEEK_MODEL", DEFAULT_MODEL)
    snapshot = snapshot or market_payload()
    data_date = data_date or (snapshot.get("chinabondYields") or {}).get("date") or (snapshot.get("fundingRates") or {}).get("date") or datetime.now().date().isoformat()
    source = "fallback"
    result = fallback_daily_from_snapshot(snapshot)

    api_key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if api_key and use_deepseek:
        try:
            result = normalize_commentary(call_deepseek(build_daily_prompt(snapshot), model, api_key), FALLBACK_DAILY)
            source = "deepseek"
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, ValueError, RuntimeError):
            if force_deepseek:
                raise

    payload = {
        "date": data_date,
        "category": "收盘点评",
        "source": source,
        "model": model if source == "deepseek" else "fallback",
        "createdAt": datetime.now().isoformat(timespec="seconds"),
        **result,
    }
    save_daily_commentary(payload, keep_days=7)
    write_debug_json()
    return payload


def backfill_daily_commentary(limit: int = 7) -> list[dict]:
    existing = {item.get("date") for item in (load_market_commentary(limit=limit).get("daily") or [])}
    created = []
    for data_date in available_commentary_dates(limit=limit):
        if data_date in existing:
            continue
        snapshot = build_snapshot_for_date(data_date)
        if not any(snapshot.values()):
            continue
        payload = generate_daily(snapshot=snapshot, data_date=data_date, use_deepseek=False)
        created.append(payload)
        existing.add(data_date)
        if len(existing) >= limit:
            break
    if created:
        write_debug_json()
    return created


def generate_weekly(force: bool = False, force_deepseek: bool = False) -> dict | None:
    now = datetime.now()
    if not force and (now.weekday() != 6 or now.time() < time(17, 0)):
        return None
    load_dotenv()
    model = os.environ.get("DEEPSEEK_MODEL", DEFAULT_MODEL)
    history = load_market_commentary(limit=7).get("daily") or []
    if not history:
        return None
    fallback = {
        "title": "债市周度窄幅震荡",
        "summary": "本周债市整体以窄幅震荡为主，收益率变动有限，资金面保持平稳，曲线形态小幅变化。市场情绪整体中性，下周继续关注资金价格、长端利率和风险偏好变化。",
        "tone": "neutral",
        "risk_level": "low",
    }
    source = "fallback"
    result = fallback
    api_key = os.environ.get("DEEPSEEK_API_KEY", "").strip() or os.environ.get("YOUR_API_KEY", "").strip()
    if api_key:
        try:
            result = normalize_commentary(call_deepseek(build_weekly_prompt(history), model, api_key), fallback)
            source = "deepseek"
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, ValueError, RuntimeError):
            if force_deepseek:
                raise
    payload = {
        "weekEndDate": now.date().isoformat(),
        "category": "周度复盘",
        "source": source,
        "model": model if source == "deepseek" else "fallback",
        "createdAt": now.isoformat(timespec="seconds"),
        **result,
    }
    save_weekly_commentary(payload)
    write_debug_json()
    return payload


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--daily", action="store_true", help="生成每日收盘点评")
    parser.add_argument("--weekly", action="store_true", help="生成周度复盘")
    parser.add_argument("--backfill-daily", action="store_true", help="补齐最近七个可得数据日的每日点评")
    parser.add_argument("--force-weekly", action="store_true", help="忽略周日下午5点限制，立即生成周度复盘")
    parser.add_argument("--force-deepseek", action="store_true", help="DeepSeek 调用失败时返回非零状态")
    args = parser.parse_args()

    outputs: dict[str, object] = {}
    if args.backfill_daily and not args.daily and not args.weekly:
        outputs["dailyBackfill"] = backfill_daily_commentary()
    elif args.weekly and not args.daily:
        weekly = generate_weekly(force=args.force_weekly, force_deepseek=args.force_deepseek)
        outputs["weekly"] = weekly
    else:
        outputs["daily"] = generate_daily(force_deepseek=args.force_deepseek)
        if args.backfill_daily:
            outputs["dailyBackfill"] = backfill_daily_commentary()
        outputs["weekly"] = generate_weekly(force=args.force_weekly, force_deepseek=args.force_deepseek)
    print(json.dumps(outputs, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
