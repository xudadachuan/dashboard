@echo off
setlocal
cd /d "%~dp0"

if not exist "logs" mkdir "logs"
set "LOG=%CD%\logs\market_data_update.log"

echo ==== %date% %time% ====>> "%LOG%"
python funding_update_runner.py 1>> "%LOG%" 2>>&1
exit /b %errorlevel%
