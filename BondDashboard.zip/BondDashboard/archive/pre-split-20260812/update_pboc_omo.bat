@echo off
setlocal
cd /d "%~dp0"
if not defined PYTHON_EXE set "PYTHON_EXE=C:\Program Files\Python313\python.exe"
if not exist "%PYTHON_EXE%" set "PYTHON_EXE=python"

if not exist "logs" mkdir "logs"
set "LOG=%CD%\logs\pboc_omo_update.log"

echo ==== %date% %time% ====>> "%LOG%"
"%PYTHON_EXE%" update_runner.py
exit /b %errorlevel%
