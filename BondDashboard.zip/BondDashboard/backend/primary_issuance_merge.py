from __future__ import annotations

import argparse
import json
from datetime import date, datetime, timedelta
from pathlib import Path

from market_database import (
    connect, ensure_market_data_schema, load_primary_issuance_daily,
    load_primary_issuance_items, primary_issuance_has_baseline,
    primary_issuance_processed_hashes, save_primary_issuance_daily,
    save_primary_issuance_items, save_primary_issuance_merge_log,
)
from primary_issuance_excel import (
    INPUT_DIR, SUPPORTED_EXTENSIONS, ensure_dirs, file_sha256, normalize_rows,
    read_xlsx_rows, summarize_items, write_exports,
)


ROOT = Path(__file__).resolve().parent
LOG_DIR = ROOT.parent / "logs"
WINDOW_DAYS_BACK = 4
WINDOW_DAYS_FORWARD = 7


def scan_input_files() -> list[Path]:
    if not INPUT_DIR.exists():
        return []
    return sorted(
        (path for path in INPUT_DIR.rglob("*") if path.is_file() and path.suffix.lower() in SUPPORTED_EXTENSIONS),
        key=lambda path: (path.stat().st_mtime, path.name),
    )


def input_file_date(path: Path) -> str | None:
    try:
        data_date, _ = normalize_rows(read_xlsx_rows(path), path, file_sha256(path))
        return data_date
    except Exception:
        return None


def _window(mode: str, window_start: str | None, window_end: str | None) -> tuple[str, str]:
    today = date.today()
    return (
        window_start or (today - timedelta(days=WINDOW_DAYS_BACK)).isoformat(),
        window_end or (today + timedelta(days=WINDOW_DAYS_FORWARD)).isoformat(),
    )


def _append_summary_log(stats: dict) -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    line = (
        f"PrimaryIssuance {stats['mode']} at={stats['run_at']} "
        f"window={stats['window_start']}..{stats['window_end']} "
        f"files={stats['files_processed']}/{stats['files_selected']}/{stats['files_scanned']} "
        f"inserted={stats['inserted']} updated={stats['updated']} skipped={stats['skipped']} "
        f"filtered={stats['filtered']} errors={stats['errors']}"
    )
    try:
        with (LOG_DIR / "market_data_update.log").open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")
    except (OSError, PermissionError):
        print(line)


def merge_files(mode: str, window_start: str | None = None, window_end: str | None = None) -> dict:
    if mode not in {"baseline", "incremental"}:
        raise ValueError(f"unsupported merge mode: {mode}")
    start, end = _window(mode, window_start, window_end)
    if date.fromisoformat(start) > date.fromisoformat(end):
        raise ValueError("window start must not be after window end")
    all_files = scan_input_files()
    files = all_files if mode == "baseline" else [
        path for path in all_files if input_file_date(path) == date.today().isoformat()
    ]
    stats = {
        "mode": mode, "run_at": datetime.now().isoformat(timespec="seconds"),
        "window_start": start, "window_end": end, "files_scanned": len(all_files),
        "files_selected": len(files), "files_processed": 0, "inserted": 0,
        "updated": 0, "skipped": 0, "filtered": 0, "errors": 0, "error_detail": [],
    }
    with connect() as conn:
        ensure_market_data_schema(conn)
        processed = primary_issuance_processed_hashes(conn)
        if not files:
            save_primary_issuance_merge_log(conn, {
                "run_at": stats["run_at"], "mode": mode, "source_file": None,
                "source_hash": None, "window_start": start, "window_end": end,
                "rows_parsed": 0, "rows_inserted": 0, "rows_updated": 0,
                "rows_skipped": 0, "rows_filtered": 0, "error": None,
            })
        for path in files:
            source_hash: str | None = None
            try:
                source_hash = file_sha256(path)
                if source_hash in processed:
                    stats["skipped"] += 1
                    save_primary_issuance_merge_log(conn, {
                        "run_at": stats["run_at"], "mode": mode, "source_file": str(path),
                        "source_hash": source_hash, "window_start": start, "window_end": end,
                        "rows_parsed": 0, "rows_inserted": 0, "rows_updated": 0,
                        "rows_skipped": 1, "rows_filtered": 0, "error": None,
                    })
                    continue
                data_date, raw_items = normalize_rows(read_xlsx_rows(path), path, source_hash)
                items = [item for item in raw_items if item.get("auction_date") and start <= str(item["auction_date"]) <= end]
                inserted, updated, invalid = save_primary_issuance_items(conn, items, data_date, source_hash, str(path))
                filtered = len(raw_items) - len(items) + invalid
                save_primary_issuance_merge_log(conn, {
                    "run_at": stats["run_at"], "mode": mode, "source_file": str(path),
                    "source_hash": source_hash, "window_start": start, "window_end": end,
                    "rows_parsed": len(raw_items), "rows_inserted": inserted,
                    "rows_updated": updated, "rows_skipped": 0, "rows_filtered": filtered, "error": None,
                })
                processed.add(source_hash)
                stats["files_processed"] += 1
                stats["inserted"] += inserted
                stats["updated"] += updated
                stats["filtered"] += filtered
            except Exception as exc:
                stats["errors"] += 1
                stats["error_detail"].append(f"{path.name}: {exc}")
                save_primary_issuance_merge_log(conn, {
                    "run_at": stats["run_at"], "mode": mode, "source_file": str(path),
                    "source_hash": source_hash, "window_start": start, "window_end": end,
                    "rows_parsed": 0, "rows_inserted": 0, "rows_updated": 0,
                    "rows_skipped": 0, "rows_filtered": 0, "error": str(exc),
                })
        if mode == "incremental":
            conn.execute(
                "DELETE FROM primary_issuance_items WHERE auction_date < ?",
                ((date.today() - timedelta(days=WINDOW_DAYS_BACK)).isoformat(),),
            )
    _append_summary_log(stats)
    return stats


def build_baseline(window_start: str | None = None, window_end: str | None = None) -> dict:
    return merge_files("baseline", window_start, window_end)


def run_incremental(window_start: str | None = None, window_end: str | None = None) -> dict:
    return merge_files("incremental", window_start, window_end)


def build_daily_payload(today: str | None = None) -> dict:
    data_date = today or date.today().isoformat()
    data_day = date.fromisoformat(data_date)
    window_start = (data_day - timedelta(days=WINDOW_DAYS_BACK)).isoformat()
    window_end = (data_day + timedelta(days=WINDOW_DAYS_FORWARD)).isoformat()
    with connect() as conn:
        ensure_market_data_schema(conn)
        items = load_primary_issuance_items(conn, window_start, window_end)
    has_current_dm_update = any(item.get("data_date") == data_date for item in items)
    if not items or not has_current_dm_update:
        previous_cutoff = (date.fromisoformat(data_date) - timedelta(days=1)).isoformat()
        previous = load_primary_issuance_daily(previous_cutoff)
        if previous:
            payload = {
                **previous,
                "windowStart": window_start,
                "windowEnd": window_end,
                "summary": summarize_items(items),
                "items": items,
                "requestedDate": data_date,
                "asOfFallback": True,
                "checkedAt": datetime.now().isoformat(timespec="seconds"),
                "note": f"{data_date} 尚无新增 DM 数据，沿用最近有效数据日 {previous.get('date')}；展示区间为 {window_start} 至 {window_end}",
            }
            ensure_dirs()
            payload["exports"] = write_exports(payload)
            save_primary_issuance_daily(payload)
            return payload
        return {
            "date": None, "requestedDate": data_date, "asOfFallback": True,
            "windowStart": window_start, "windowEnd": window_end,
            "source": "unavailable", "sourceName": "DM 终端 Excel",
            "summary": summarize_items([]), "items": [],
            "checkedAt": datetime.now().isoformat(timespec="seconds"),
            "note": "暂无历史有效一级发行数据",
        }
    payload = {
        "date": data_date, "windowStart": window_start, "windowEnd": window_end,
        "source": "dm_excel_merged", "sourceName": "DM 终端 Excel（基线+每日增量）",
        "summary": summarize_items(items), "items": items,
        "updatedAt": datetime.now().isoformat(timespec="seconds"),
    }
    ensure_dirs()
    payload["exports"] = write_exports(payload)
    save_primary_issuance_daily(payload)
    return payload


def run_daily_pipeline(today: str | None = None) -> dict:
    with connect() as conn:
        ensure_market_data_schema(conn)
        needs_baseline = not primary_issuance_has_baseline(conn)
    baseline = build_baseline() if needs_baseline else None
    incremental = run_incremental()
    output = build_daily_payload(today)
    return {"mode": "daily_pipeline", "baselineBuilt": needs_baseline, "baseline": baseline, "incremental": incremental, "output": output}


def query_primary_issuance_from_db(query_date: str | None = None) -> dict | None:
    return load_primary_issuance_daily(query_date)


def main() -> None:
    parser = argparse.ArgumentParser(description="DM primary issuance baseline/incremental merge pipeline")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--baseline", action="store_true")
    group.add_argument("--incremental", action="store_true")
    group.add_argument("--daily", action="store_true")
    group.add_argument("--output", action="store_true")
    group.add_argument("--query", action="store_true")
    parser.add_argument("--date")
    parser.add_argument("--window-start")
    parser.add_argument("--window-end")
    args = parser.parse_args()
    if args.baseline:
        result = build_baseline(args.window_start, args.window_end)
    elif args.incremental:
        result = run_incremental(args.window_start, args.window_end)
    elif args.daily:
        result = run_daily_pipeline(args.date)
    elif args.output:
        result = build_daily_payload(args.date)
    else:
        result = query_primary_issuance_from_db(args.date)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
