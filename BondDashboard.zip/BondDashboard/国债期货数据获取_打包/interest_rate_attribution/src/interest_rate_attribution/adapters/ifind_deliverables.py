from __future__ import annotations

"""可交割券与转换因子适配器。

数据源优先级：
1. iFinD 可交割券专题数据或基础资料
2. 中金所官方交割券及转换因子文件
3. 人工导入并双人复核

转换因子必须按「合约—债券」保存，不能只按债券保存，
因为不同交割合约对应的转换因子可能不同。
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd


DELIVERABLE_COLUMNS = [
    "contract_code",
    "bond_code",
    "conversion_factor",
    "delivery_month",
    "first_delivery_date",
    "last_delivery_date",
    "mapping_effective_from",
    "mapping_effective_to",
    "source",
    "retrieved_at",
]


@dataclass
class DeliverableRecord:
    contract_code: str
    bond_code: str
    conversion_factor: float
    delivery_month: str
    first_delivery_date: str
    last_delivery_date: str
    mapping_effective_from: str
    mapping_effective_to: str
    source: str
    retrieved_at: str


def empty_deliverable_mapping() -> pd.DataFrame:
    """返回空的可交割券映射表结构。"""
    return pd.DataFrame(columns=DELIVERABLE_COLUMNS)


def load_deliverable_mapping(csv_path: Path | str) -> pd.DataFrame:
    """从 CSV 加载可交割券映射表（人工导入或中金所官方文件）。"""
    frame = pd.read_csv(csv_path, dtype=str)
    if "conversion_factor" in frame.columns:
        frame["conversion_factor"] = pd.to_numeric(
            frame["conversion_factor"], errors="coerce"
        )
    return frame


def validate_deliverable_mapping(frame: pd.DataFrame) -> list[str]:
    """校验映射表完整性，返回问题列表。

    关键规则：
    - 转换因子必须按「合约—债券」唯一键保存
    - 不允许同一 (contract_code, bond_code) 出现多个冲突的转换因子
    - 关键日期字段不得缺失
    """
    problems: list[str] = []
    required = {"contract_code", "bond_code", "conversion_factor"}
    missing = required - set(frame.columns)
    if missing:
        problems.append(f"缺少必需列: {sorted(missing)}")
        return problems

    # 转换因子缺失
    if frame["conversion_factor"].isna().any():
        problems.append("存在转换因子缺失的 (合约, 债券) 记录")

    # 唯一键冲突
    dup = frame.duplicated(subset=["contract_code", "bond_code"], keep=False)
    if dup.any():
        conflicts = frame[dup][["contract_code", "bond_code", "conversion_factor"]]
        # 进一步检查是否转换因子值冲突
        groups = frame.groupby(["contract_code", "bond_code"])["conversion_factor"].nunique()
        conflicting = groups[groups > 1]
        if len(conflicting) > 0:
            problems.append(
                f"{len(conflicting)} 个 (合约, 债券) 存在冲突的转换因子"
            )

    return problems


def extract_conversion_factors_from_ifind(result: Any) -> pd.DataFrame:
    """从 iFinD 可交割券专题返回中提取转换因子表。

    返回标准化的 DELIVERABLE_COLUMNS 结构。
    """
    if isinstance(result, pd.DataFrame):
        frame = result.copy()
    else:
        data = getattr(result, "data", None)
        if isinstance(data, pd.DataFrame):
            frame = data.copy()
        else:
            return empty_deliverable_mapping()

    out = empty_deliverable_mapping()
    col_map = {
        "contract_code": ["contract_code", "合约代码", "thscode"],
        "bond_code": ["bond_code", "可交割券代码", "债券代码", "securitycode"],
        "conversion_factor": ["conversion_factor", "转换因子"],
        "delivery_month": ["delivery_month", "交割月份"],
        "first_delivery_date": ["first_delivery_date", "首个交割日"],
        "last_delivery_date": ["last_delivery_date", "最后交割日"],
    }
    for target, candidates in col_map.items():
        for cand in candidates:
            if cand in frame.columns:
                out[target] = frame[cand]
                break
    if "conversion_factor" in out.columns:
        out["conversion_factor"] = pd.to_numeric(
            out["conversion_factor"], errors="coerce"
        )
    if "source" not in out.columns:
        out["source"] = "ifind"
    out = out[DELIVERABLE_COLUMNS]
    return out


def merge_conversion_factors(
    primary: pd.DataFrame, secondary: pd.DataFrame
) -> pd.DataFrame:
    """合并多个来源的转换因子，主来源优先，避免覆盖已确认的值。"""
    if primary.empty:
        return secondary.copy() if secondary is not None else empty_deliverable_mapping()
    if secondary is None or secondary.empty:
        return primary.copy()
    key = ["contract_code", "bond_code"]
    merged = primary.copy()
    secondary_only = secondary[~secondary.set_index(key).index.isin(primary.set_index(key).index)]
    if not secondary_only.empty:
        merged = pd.concat([merged, secondary_only], ignore_index=True)
    return merged[DELIVERABLE_COLUMNS]
